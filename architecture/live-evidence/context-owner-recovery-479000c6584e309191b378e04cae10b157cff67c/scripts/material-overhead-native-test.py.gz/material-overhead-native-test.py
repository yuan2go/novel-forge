import hashlib,json,os,subprocess
from pathlib import Path

def test_materials_plus_same_output_reserve_fit_but_complete_native_request_overflows():
    from tests.integration.test_chapter_model_effects_postgres import ChapterModelEffectsPostgresTests
    source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    assert source=='479000c6584e309191b378e04cae10b157cff67c'
    ChapterModelEffectsPostgresTests.setUpClass()
    case=ChapterModelEffectsPostgresTests('test_complete_request_overflow_compresses_before_native_draft_and_reads_saved_prose')
    case._assert_full_chapter_slice_uses_unified_execution_gateway(task_scoped=True,capacity_overflow=True,request_limit=460500)
    root=Path(os.environ['NOVEL_FORGE_POSTGRES_EVIDENCE_DIR'])/'complete-request-460500'
    original=json.loads((root/'original-materials.json').read_text());projection=json.loads((root/'compression-projection.json').read_text());receipt=json.loads((root/'receipts.json').read_text());admission=receipt['provider_admission'];admission=admission.get('contract',admission)
    # The experiment measures a canonical material representation and the actual native full request separately.
    material=len(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());size=projection['measurement'];contract=admission['provider_admission']['accounting_contract'];reserve=contract['output_reserve']+contract['framing_overhead']+contract['safety_margin']
    assert material+reserve<=size['limit']<size['before_reserved']
    assert size['after_reserved']<=size['limit']
    result={'source_sha':source,'status':'PASS','scope':'CONTROLLED_NATIVE_FIXTURE_BYTES; actual material+output/protocol reserve fits, fully rendered native request overflows; not real Provider tokens','original_canonical_material_bytes':material,'same_output_protocol_and_fixture_margin':reserve,'materials_plus_same_reserve':material+reserve,'full_request_before_reserved':size['before_reserved'],'full_request_after_reserved':size['after_reserved'],'capacity':size['limit'],'actual_provider_tokens':None,'accounting_contract':contract,'original_material_sha256':hashlib.sha256((root/'original-materials.json').read_bytes()).hexdigest(),'final_request_sha256':hashlib.sha256((root/'final-request.txt').read_bytes()).hexdigest(),'native_saved_readback_sha256':hashlib.sha256((root/'native-prose.txt').read_bytes()).hexdigest(),'driver_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'entry':'Existing Chapter application.admit + scheduler.tick -> ExternalEffect gateway -> saved chapter.draft readback'}
    (root/'material-vs-complete-request-proof.json').write_text(json.dumps(result,indent=2)+'\n')
