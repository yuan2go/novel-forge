import json,os,subprocess,uuid,sys
from pathlib import Path
import psycopg
root=Path('/Users/yuan/.codex/worktrees/semantic-owner-adapters/novel-forge')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha=='479000c6584e309191b378e04cae10b157cff67c'
p=Path('/tmp/nf-capacity-regression-resource.json');r=json.loads(p.read_text());db='nf_p0_'+uuid.uuid4().hex+'_test';label='semantic-479000c6-process-restart';e=Path(r['artifact_root'])/label;e.mkdir()
with psycopg.connect('postgresql://novel_forge:novel_forge@127.0.0.1:'+str(r['port'])+'/postgres',autocommit=True) as c:c.execute('CREATE DATABASE '+db+' OWNER novel_forge')
r.setdefault('additional_databases',[]).append({'database':db,'label':label,'source_root':str(root),'source_sha':sha,'evidence':str(e)});p.write_text(json.dumps(r,indent=2))
env={**os.environ,'PATH':'/Users/yuan/.codex/worktrees/context-512k-e2e/novel-forge/.venv/bin:/opt/homebrew/opt/postgresql@16/bin:'+os.environ['PATH'],'PYTHONPATH':str(root/'src')+':'+str(root),'NOVEL_FORGE_DATABASE_URL':'postgresql://novel_forge:novel_forge@127.0.0.1:'+str(r['port'])+'/'+db,'NOVEL_FORGE_QUALIFICATION_DATABASE_NAME':db,'NOVEL_FORGE_POSTGRES_EVIDENCE_DIR':str(e),'NOVEL_FORGE_MIGRATION_BACKUP_DIR':str(e/'backups')}
(e/'backups').mkdir(mode=0o700)
python='/Users/yuan/.codex/worktrees/context-512k-e2e/novel-forge/.venv/bin/python'
with (e/'migration.log').open('w') as f:subprocess.run([python,'-c','import os; from novel_forge.storage.migrations import run_migrations; assert run_migrations(os.environ["NOVEL_FORGE_DATABASE_URL"])["ok"]'],cwd=root,env=env,check=True,stdout=f,stderr=subprocess.STDOUT)
with (e/'pytest.log').open('w') as f:
 for mode,expected in [('checkpoint',75),('resume',0)]:
  result=subprocess.run([python,'/tmp/nf-semantic-process-restart-native.py',mode,'--journal',str(e/'checkpoint.json')],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert result.returncode==expected,(mode,result.returncode)
print('NATIVE_PROCESS_RESTART_PASS',sha,e)
