import json,os,subprocess,sys,uuid
from pathlib import Path
import psycopg
root=Path(sys.argv[1]); label=sys.argv[2]; tests=sys.argv[3:]
p=Path('/tmp/nf-capacity-regression-resource.json'); r=json.loads(p.read_text()); db='nf_p0_'+uuid.uuid4().hex+'_test'
with psycopg.connect('postgresql://novel_forge:novel_forge@127.0.0.1:'+str(r['port'])+'/postgres',autocommit=True) as c:c.execute('CREATE DATABASE '+db+' OWNER novel_forge')
e=Path(r['artifact_root'])/label;e.mkdir()
r.setdefault('additional_databases',[]).append({'database':db,'label':label,'source_root':str(root),'evidence':str(e)});p.write_text(json.dumps(r,indent=2))
python='/Users/yuan/.codex/worktrees/context-512k-e2e/novel-forge/.venv/bin/python'
env={**os.environ,'PATH':'/Users/yuan/.codex/worktrees/context-512k-e2e/novel-forge/.venv/bin:/opt/homebrew/opt/postgresql@16/bin:'+os.environ['PATH'],'PYTHONPATH':str(root/'src')+':'+str(root),'NOVEL_FORGE_DATABASE_URL':'postgresql://novel_forge:novel_forge@127.0.0.1:'+str(r['port'])+'/'+db,'NOVEL_FORGE_QUALIFICATION_DATABASE_NAME':db,'NOVEL_FORGE_POSTGRES_EVIDENCE_DIR':str(e),'NOVEL_FORGE_MIGRATION_BACKUP_DIR':str(e/'backups')}
(e/'backups').mkdir(mode=0o700)
with (e/'migration.log').open('w') as f: subprocess.run([python,'-c','import os; from novel_forge.storage.migrations import run_migrations; assert run_migrations(os.environ["NOVEL_FORGE_DATABASE_URL"])["ok"]'],cwd=root,env=env,check=True,stdout=f,stderr=subprocess.STDOUT)
with (e/'pytest.log').open('w') as f: result=subprocess.run([python,'-m','pytest','-q','--junitxml='+str(e/'pytest.xml'),*tests],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
(e/'result.json').write_text(json.dumps({'source_root':str(root),'label':label,'tests':tests,'exit_code':result.returncode,'database':db},indent=2))
print(e);print((e/'pytest.log').read_text()[-2500:]);sys.exit(result.returncode)
