import datetime,hashlib,json,lzma,subprocess
from pathlib import Path
r=json.load(open('/tmp/nf-capacity-regression-resource.json'));container='nf-p0-85fa5a57fdd44ad6ae1d8d79bbd2b665-authority-postgres-test-1';info=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0];assert info['Id']=='eeb98832a809c649dee5b6d5ee75675fb001f9b029203d02c88119d01f4f2265';assert info['Config']['Labels']['com.docker.compose.project']==r['compose_project'];assert info['Config']['Labels']['novel-forge.qualification.run-id']==r['run_id'];out=Path('/tmp/nf-final-owned-context-custody/479000c6-overhead-supplement');out.mkdir(exist_ok=True);results=[]
for label in ['semantic-479000c6-native-overhead']:
    entry=next(x for x in r['additional_databases'] if x['label']==label);run=Path(entry['evidence']);assert (run/'result.json').exists() or (run/'receipts.json').exists();target=out/(label+'.sql.xz');assert not target.exists();h=hashlib.sha256();size=0;tail=b'';command=['docker','exec',container,'pg_dump','-U','novel_forge','--create',entry['database']]
    with (out/(label+'.stderr.log')).open('wb') as errors:
        p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=errors)
        with lzma.open(target,'wb',preset=3) as writer:
            while block:=p.stdout.read(1024*1024):h.update(block);size+=len(block);tail=(tail+block)[-4096:];writer.write(block)
        code=p.wait()
    assert code==0 and b'PostgreSQL database dump complete' in tail
    verified=hashlib.sha256();verified_size=0
    with lzma.open(target,'rb') as reader:
        while block:=reader.read(1024*1024):verified.update(block);verified_size+=len(block)
    assert (size,h.hexdigest())==(verified_size,verified.hexdigest())
    results.append({'label':label,'database':entry['database'],'source_sha':'479000c6584e309191b378e04cae10b157cff67c','command':command,'exit_code':code,'archive':target.name,'raw_bytes':size,'raw_sha256':h.hexdigest(),'storage_bytes':target.stat().st_size,'storage_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'decompression_verified':True})
record={'status':'PASS_DUMP_AND_LOSSLESS_READBACK_ONLY','source_sha':'479000c6584e309191b378e04cae10b157cff67c','container_id':info['Id'],'completed_at':datetime.datetime.now(datetime.UTC).isoformat(),'delivery_prior_receipts':['../../context-owner-recovery-5c54f5250b192d2c8c2e122189675883e4da29ac/custody/complete-owned-cluster.json','../../context-owner-recovery-5c54f5250b192d2c8c2e122189675883e4da29ac/custody/reader-retry-supplement.json','supplements.json'],'scope':'One additional4790 material-overhead diagnostic database after task-owned cluster restart. Prior receipt references resolve from final delivery custody directory. No historical UNKNOWN task resumed or replaced. Archive only; actual PostgreSQL restore NOT_RUN.','supplements':results};(out/'overhead-supplement.json').write_text(json.dumps(record,indent=2));print(json.dumps({'status':record['status'],'databases':len(results),'storage_bytes':sum(x['storage_bytes'] for x in results)}),flush=True)
