import datetime,gzip,hashlib,json,lzma,subprocess
from pathlib import Path

registry=json.load(open('/tmp/nf-capacity-regression-resource.json'))
container='nf-p0-85fa5a57fdd44ad6ae1d8d79bbd2b665-authority-postgres-test-1'
info=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
assert info['Config']['Labels']['com.docker.compose.project']==registry['compose_project']
assert info['Config']['Labels']['novel-forge.qualification.run-id']==registry['run_id']
root=Path('/tmp/nf-final-owned-context-custody');root.mkdir(exist_ok=True);target=root/'complete-owned-cluster.sql.xz';assert not target.exists()
started=datetime.datetime.now(datetime.timezone.utc).isoformat();raw_hash=hashlib.sha256();raw_bytes=0;tail=b''
with (root/'pg-dumpall.stderr.log').open('wb') as errors:
    command=['docker','exec',container,'pg_dumpall','-U','novel_forge','--no-role-passwords']
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=errors)
    with lzma.open(target,'wb',preset=3) as output:
        while block:=process.stdout.read(1024*1024):
            raw_hash.update(block);raw_bytes+=len(block);tail=(tail+block)[-4096:];output.write(block)
    code=process.wait()
assert code==0 and b'PostgreSQL database cluster dump complete' in tail
verified=hashlib.sha256();size=0
with lzma.open(target,'rb') as source:
    while block:=source.read(1024*1024):verified.update(block);size+=len(block)
assert (size,verified.hexdigest())==(raw_bytes,raw_hash.hexdigest())
parts=[]
with target.open('rb') as source:
    while block:=source.read(32_000_000):
        part=root/(target.name+'.part-'+str(len(parts)).zfill(3));part.write_bytes(block)
        parts.append({'name':part.name,'bytes':len(block),'sha256':hashlib.sha256(block).hexdigest()})
result={'schema_version':'novel-forge.owned-context-cluster-custody.v1','status':'PASS_DUMP_AND_LOSSLESS_READBACK_ONLY','cluster_container':container,'container_id':info['Id'],'compose_project':registry['compose_project'],'run_id':registry['run_id'],'started_at':started,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exit_code':code,'raw_sql_bytes':raw_bytes,'raw_sql_sha256':raw_hash.hexdigest(),'archive_bytes':target.stat().st_size,'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'lossless_decompression_verified':True,'parts':parts,'scope':'All databases in this task-owned qualification cluster, including failed/UNKNOWN/OOM histories. No production or unrelated cluster dumped/modified. No role passwords.','restore':'NOT_RUN; restore only to an isolated compatible PostgreSQL16 cluster. This is custody, not restored business qualification.'}
(root/'complete-owned-cluster.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','raw_sql_bytes','archive_bytes','raw_sql_sha256']}),flush=True)
