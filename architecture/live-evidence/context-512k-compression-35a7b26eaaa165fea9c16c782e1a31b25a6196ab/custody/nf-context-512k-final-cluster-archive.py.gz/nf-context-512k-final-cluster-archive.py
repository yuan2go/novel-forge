from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess
import psycopg

owned = json.loads(Path('/tmp/nf-context-512k-current-resource.json').read_text())
assert owned['port'] == 55012 and owned['project'] == 'nf-context-d21a42d7195b49b3a3942c7b1088ce92'
directory = Path('/tmp/nf-context-512k-owned-database-archives')
target = directory / 'native-final-complete-cluster.sql.gz'
assert not target.exists()
with psycopg.connect('postgresql://novel_forge:novel_forge@127.0.0.1:55012/postgres') as connection:
    connection.execute('SET TRANSACTION READ ONLY')
    databases = [r[0] for r in connection.execute('SELECT datname FROM pg_database WHERE NOT datistemplate ORDER BY datname')]
    assert all(db == 'postgres' or db in [owned['database'], *owned['additional_databases']] for db in databases)
    active = list(connection.execute("SELECT datname,pid,state FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()"))
    assert not active, active
with gzip.GzipFile(filename=str(target), mode='wb', mtime=0) as writer:
    process = subprocess.Popen(['/opt/homebrew/opt/postgresql@16/bin/pg_dumpall', '-h', '127.0.0.1', '-p', '55012', '-U', 'novel_forge', '--no-role-passwords'], env={**os.environ, 'PGPASSWORD': 'novel_forge'}, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    while block := process.stdout.read(1024 * 1024):
        writer.write(block)
    error = process.stderr.read().decode()
    assert process.wait() == 0, error
raw_hash = hashlib.sha256()
raw_size = 0
tail = b''
seen = set()
with gzip.open(target, 'rb') as reader:
    for line in reader:
        raw_hash.update(line)
        raw_size += len(line)
        tail = (tail + line)[-8192:]
        if line.startswith(b'CREATE DATABASE '):
            seen.add(line.decode().split()[2])
assert b'PostgreSQL database cluster dump complete' in tail
assert set(databases) - {'postgres'} <= seen, (set(databases) - {'postgres'} - seen)
storage_hash = hashlib.sha256()
with target.open('rb') as reader:
    while block := reader.read(1024 * 1024):
        storage_hash.update(block)
record = {'schema_version': 'novel-forge.owned-native-cluster-archive.v1', 'recorded_at_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'container': owned['project'] + '-authority-postgres-test-1', 'scope': 'EXACT_TASK_OWNED_DISPOSABLE_NATIVE_CLUSTER_ONLY', 'databases': databases, 'database_count': len(databases), 'client_connections_before_dump': 0, 'pg_dumpall_exit_code': 0, 'sql_completion_footer_verified': True, 'all_owned_database_creation_statements_verified': True, 'archive': str(target), 'archive_bytes': target.stat().st_size, 'archive_sha256': storage_hash.hexdigest(), 'uncompressed_bytes': raw_size, 'uncompressed_sha256': raw_hash.hexdigest(), 'role_passwords': 'NOT_EXPORTED; restore isolated fixture credentials explicitly', 'production_or_author_database_changed': False, 'restore': 'Restore this complete SQL cluster dump with PostgreSQL16 psql into a fresh isolated test cluster using an administrative role absent from this dump. Reapply only disposable fixture login credentials. Original database names/roles/schema/rows remain in the dump; do not restore over production or author data.', 'action': 'VERIFIED_COMPLETE_CLUSTER_ARCHIVE_BEFORE_STOP'}
(directory / 'native-final-complete-cluster.json').write_text(json.dumps(record, indent=2) + '\n')
with (directory / 'receipts.jsonl').open('a') as writer:
    writer.write(json.dumps(record) + '\n')
print(json.dumps({k: record[k] for k in ('database_count', 'archive_bytes', 'uncompressed_bytes', 'uncompressed_sha256', 'action')}), flush=True)
