from pathlib import Path
import gzip, hashlib, json, lzma, shutil

root = Path('/tmp/nf-context-512k-owned-database-archives')
record_path = root / 'native-final-complete-cluster.json'
record = json.loads(record_path.read_text())
assert record['action'] == 'STOPPED_EXACT_OWNED_CLUSTER_AFTER_VERIFIED_FULL_ARCHIVE'
source = Path(record['archive'])
target = root / 'native-final-complete-cluster.sql.xz'
assert not target.exists()
with gzip.open(source, 'rb') as reader, lzma.open(target, 'wb', preset=3) as writer:
    shutil.copyfileobj(reader, writer, length=1024 * 1024)
raw_hash = hashlib.sha256()
raw_size = 0
with lzma.open(target, 'rb') as reader:
    while block := reader.read(1024 * 1024):
        raw_hash.update(block)
        raw_size += len(block)
assert raw_hash.hexdigest() == record['uncompressed_sha256'] and raw_size == record['uncompressed_bytes']
pieces = []
storage_hash = hashlib.sha256()
with target.open('rb') as reader:
    index = 0
    while block := reader.read(32_000_000):
        path = root / (target.name + f'.part-{index:03d}')
        assert not path.exists()
        path.write_bytes(block)
        storage_hash.update(block)
        pieces.append({'filename': path.name, 'bytes': len(block), 'sha256': hashlib.sha256(block).hexdigest()})
        index += 1
record['delivery_storage'] = {'format': 'XZ stream split into ordered <=32000000-byte storage pieces; not independently decompressible', 'bytes': target.stat().st_size, 'sha256': storage_hash.hexdigest(), 'raw_bytes': raw_size, 'raw_sha256': raw_hash.hexdigest(), 'decompression_verified': True, 'pieces': pieces, 'assembly': 'Concatenate pieces in listed order to one .sql.xz file, verify aggregate SHA256, then decompress and verify raw SHA256 before isolated PostgreSQL16 restoration. This is lossless host storage, unrelated to model input compression.'}
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record['delivery_storage']), flush=True)
