from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess
import psycopg
from psycopg import sql
registry=Path('/tmp/nf-context-512k-current-resource.json');owned=json.loads(registry.read_text());archive=Path('/tmp/nf-context-512k-owned-database-archives');archive.mkdir(exist_ok=True)
for label in ('semantic-core-22de17d0','semantic-upstream-22de17d0','semantic-retained-upgrade-22de17d0'):
 env=json.loads(Path('/tmp/nf-context-512k-'+label+'-env.json').read_text());db=env['NOVEL_FORGE_QUALIFICATION_DATABASE_NAME']
 assert db in owned['additional_databases'] and db.startswith('nf_p0_') and db.endswith('_test')
 with psycopg.connect('postgresql://novel_forge:novel_forge@127.0.0.1:55012/postgres',autocommit=True) as admin:
  assert admin.execute('SELECT count(*) FROM pg_stat_activity WHERE datname=%s',[db]).fetchone()[0]==0
  assert admin.execute('SELECT 1 FROM pg_database WHERE datname=%s',[db]).fetchone()
 with psycopg.connect(env['NOVEL_FORGE_DATABASE_URL']) as c:
  facts={name:c.execute(sql.SQL('SELECT count(*) FROM {}').format(sql.Identifier(name))).fetchone()[0] for name in ('authority_external_effect','authority_external_receipt','authority_model_call_log','authority_cost_ledger','authority_asset_version') if c.execute('SELECT to_regclass(%s)',[name]).fetchone()[0]}
 target=archive/(db+'.sql.gz')
 assert not target.exists()
 with gzip.GzipFile(filename=str(target),mode='wb',mtime=0) as out:
  p=subprocess.Popen(['/opt/homebrew/opt/postgresql@16/bin/pg_dump','-h','127.0.0.1','-p','55012','-U','novel_forge','--no-owner',db],env={**os.environ,'PGPASSWORD':'novel_forge'},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  while chunk:=p.stdout.read(1024*1024):out.write(chunk)
  err=p.stderr.read().decode();assert p.wait()==0,err
 digest=hashlib.sha256();total=0;tail=b''
 with gzip.open(target,'rb') as inp:
  while chunk:=inp.read(1024*1024):digest.update(chunk);total+=len(chunk);tail=(tail+chunk)[-8192:]
 assert b'PostgreSQL database dump complete' in tail
 record={'label':label,'source_sha':'22de17d0ca1071f9b834e03bce817dfa4ea712b6','database':db,'archive':str(target),'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'archive_bytes':target.stat().st_size,'uncompressed_sha256':digest.hexdigest(),'uncompressed_bytes':total,'sql_completion_footer_verified':True,'facts':facts,'scope':'EXACT_REGISTERED_OBSOLETE_TASK_OWNED_NATIVE_TEST_DATABASE','recorded_at':datetime.datetime.now(datetime.UTC).isoformat()}
 with (archive/'receipts.jsonl').open('a') as f:f.write(json.dumps({**record,'action':'VERIFIED_ARCHIVE_BEFORE_DROP'})+'\n')
 with psycopg.connect('postgresql://novel_forge:novel_forge@127.0.0.1:55012/postgres',autocommit=True) as admin:
  assert admin.execute('SELECT count(*) FROM pg_stat_activity WHERE datname=%s',[db]).fetchone()[0]==0
  admin.execute(sql.SQL('DROP DATABASE {}').format(sql.Identifier(db)))
 with (archive/'receipts.jsonl').open('a') as f:f.write(json.dumps({**record,'action':'DROPPED_EXACT_OWNED_DATABASE_AFTER_VERIFIED_BACKUP'})+'\n')
 print(label,total,target.stat().st_size,flush=True)
