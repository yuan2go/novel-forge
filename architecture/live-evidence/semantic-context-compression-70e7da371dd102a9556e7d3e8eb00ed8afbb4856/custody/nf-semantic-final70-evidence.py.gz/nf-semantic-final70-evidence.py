from pathlib import Path
import datetime, gzip, hashlib, json, lzma, runpy, shutil, subprocess
from novel_forge.tools.implementation_tree_identity import build_implementation_tree_identity

H = runpy.run_path('/tmp/nf-delivery-evidence-helpers.py')
repo = Path.cwd()
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert sha == '70e7da371dd102a9556e7d3e8eb00ed8afbb4856'
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
out = Path('/tmp/nf-semantic-evidence-stage') / sha
out.mkdir(parents=True, exist_ok=True)
base = Path('/tmp/nf-context-512k-d21a42d7195b49b3a3942c7b1088ce92')
dump = lambda name, value: H['dump'](out, name, value)
archive = lambda source, name: H['archive'](out, source, name)

historical_sha = 'c1f6a507410c870dd523b683cd60886fde11df07'
historical = out / 'historical' / historical_sha
if not historical.exists():
    shutil.copytree(Path('/tmp/nf-semantic-evidence-stage') / historical_sha, historical)
dump('historical/status-boundary.json', {'source_sha': historical_sha, 'scope': 'Byte-preserved historical stage, including earlier native source bindings and raw PostgreSQL JSON line exports. It was packaged while its formal matrix was in progress; that matrix was subsequently interrupted after confirmed pre-protection JSON precision loss. Its original manifest is not relabelled as current qualification.', 'current_source_sha': sha})

labels = ('semantic-core-70e7da37', 'semantic-upstream-70e7da37', 'semantic-retained-upgrade-70e7da37', 'semantic-process-restart-70e7da37')
native = []
for label in labels:
    status = H['test_status']('/tmp/nf-context-512k-' + label + '.log')
    assert status['status'] == 'PASS', (label, status)
    archive('/tmp/nf-context-512k-' + label + '.log', 'native/' + label + '/execution.log.gz')
    H['archive_tree'](out, base / label, 'native/' + label + '/artifacts')
    database = H['export_database'](out, label, sha)
    native.append({'label': label, 'source_sha': sha, **status, 'database': database['database'], 'project_ids': database['project_ids'], 'database_index': 'native/' + label + '/database-index.json'})
dump('native/index.json', native)
dump('native/storage-boundary.json', {'database_exports': 'Read-only terminal database state after each native suite. Core pytest fixtures clean some rows between cases; per-case captured receipts/requests/readback are retained separately under artifacts. Full upstream, retained-upgrade and distinct-process databases preserve their source asset/version and complete Effect chains.', 'source_of_truth': 'Original PostgreSQL rows, immutable AssetVersions and per-case durable receipts; summary JSON is a checked index, not replacement business authority.', 'model_call_cost': 'All schema-backed model_call_log and cost_ledger assets remain in raw authority_asset_version exports; no physical authority_model_call_log table is assumed.'})

archive_root = Path('/tmp/nf-context-512k-owned-database-archives')
journal = [json.loads(line) for line in (archive_root / 'receipts.jsonl').read_text().splitlines()]
archives = []
for row in journal:
    if row.get('action') != 'VERIFIED_ARCHIVE_BEFORE_DROP' or not row.get('label', '').endswith(('67c07ef0', 'f87b2d0d', '7f1b6d2f')):
        continue
    source = Path(row['archive'])
    assert H['digest'](source) == row['archive_sha256']
    target = out / 'historical' / 'archived-native-databases' / (row['label'] + '.sql.xz')
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        with gzip.open(source, 'rb') as reader, lzma.open(target, 'wb', preset=3) as writer:
            shutil.copyfileobj(reader, writer)
    raw_hash = hashlib.sha256()
    size = 0
    footer = b''
    with lzma.open(target, 'rb') as reader:
        for block in iter(lambda: reader.read(1024 * 1024), b''):
            raw_hash.update(block)
            size += len(block)
            footer = (footer + block)[-4096:]
    assert raw_hash.hexdigest() == row['uncompressed_sha256'] and size == row['uncompressed_bytes']
    assert b'PostgreSQL database dump complete' in footer
    archive('/tmp/nf-context-512k-' + row['label'] + '.log', 'historical/native/' + row['label'] + '/execution.log.gz')
    H['archive_tree'](out, base / row['label'], 'historical/native/' + row['label'] + '/artifacts')
    archives.append({**row, 'original_archive_local_only': row['archive'], 'delivered_archive': str(target.relative_to(out)), 'delivered_sha256': H['digest'](target), 'delivered_bytes': target.stat().st_size, 'lossless_transcode_verified': True})
dump('custody/archived-native-databases.json', archives)
archive(archive_root / 'receipts.jsonl', 'custody/owned-database-archive-receipts.jsonl.gz')
for filename in ('nf-context-512k-archive-old-semantic22.py', 'nf-context-512k-archive-pre-final-native.py', 'nf-context-512k-archive-pre-final-native.log'):
    archive(Path('/tmp') / filename, 'custody/' + filename + '.gz')
for filename in ('nf-delivery-evidence-helpers.py', 'nf-semantic-final70-evidence.py'):
    archive(Path('/tmp') / filename, 'custody/' + filename + '.gz')

for label in ('c1f6a507', '67c07ef0', 'f87b2d0d', 'f87b2d0d-configured', '7f1b6d2f', '70e7da37'):
    root = Path('/tmp/nf-semantic-pr-' + label)
    if not root.exists():
        continue
    destination = 'formal-current' if label == '70e7da37' else 'historical/qualification-' + label
    H['archive_tree'](out, root, destination)
    archive(str(root) + '.log', destination + '/console.log.gz')

for filename in ('nf-semantic-compare-production.py', 'nf-semantic-comparison-baseline-35a7b26e.json', 'nf-semantic-comparison-new-70e7da37.json', 'nf-semantic-scope-production-verifier.py', 'nf-semantic-scope-baseline-22de17d0.json', 'nf-semantic-scope-current-70e7da37.json', 'nf-semantic-json-production-verifier.py', 'nf-semantic-json-baseline-35a7b26e.json', 'nf-semantic-json-current-70e7da37.json', 'nf-semantic-process-restart-native.py', 'nf-semantic-process-restart-driver.py', 'nf-context-512k-environment-observation.json', 'nf-context-512k-runtime-final-observation.json'):
    shutil.copyfile(Path('/tmp') / filename, out / filename)
for filename in ('nf-context-512k-frozen-runtime-policy-raw.json', 'nf-context-512k-frozen-runtime-policy-observation.json'):
    shutil.copyfile(Path('/tmp') / filename, out / filename)
shutil.copyfile('/tmp/nf-semantic-final-review.json', out / 'final-readonly-reviews.json')
for filename in ('nf-semantic-json-final-focused.log', 'nf-semantic-json-prefix-final.log', 'nf-semantic-pr-7f1b6d2f.log', 'nf-context-512k-semantic-process-restart-7f1b6d2f-preflight-negative.log'):
    archive(Path('/tmp') / filename, 'checks/' + filename + '.gz')
shutil.copyfile(repo / 'tests/fixtures/semantic_compression_gold.json', out / 'semantic_compression_gold.json')
H['archive_tree'](out, base / 'immutable-tokenizers', 'tokenizers')

old = json.loads((out / 'nf-semantic-comparison-baseline-35a7b26e.json').read_text())
new = json.loads((out / 'nf-semantic-comparison-new-70e7da37.json').read_text())
assert old['input_hash'] == new['input_hash'] and old['task_without_algorithm_hash'] == new['task_without_algorithm_hash']
dump('comparison.json', {'evidence_class': 'FIXED_ORIGINAL_GOLD_EXACT_SUPPORT_NOT_MODEL_COMPREHENSION', 'input_hash': new['input_hash'], 'task_hash': new['task_without_algorithm_hash'], 'gold_sha256': new['gold_sha256'], 'gold_fixed_before_compression': True, 'capacity_unit': new['capacity_unit'], 'capacity_limit': new['limit'], 'baseline': {'source_sha': old['source_sha'], 'question_support_complete': sum(q['exact_original_support_complete'] for q in old['questions']), 'explicit_quotes_preserved': sum(q['present_in_one_original_source'] for q in old['explicit_quotes']), 'before_bytes': old['before_bytes'], 'after_bytes': old['after_bytes'], 'controlled_calls': old['model_calls']}, 'current': {'source_sha': new['source_sha'], 'question_support_complete': sum(q['exact_original_support_complete'] for q in new['questions']), 'explicit_quotes_preserved': sum(q['present_in_one_original_source'] for q in new['explicit_quotes']), 'before_bytes': new['before_bytes'], 'after_bytes': new['after_bytes'], 'controlled_calls': new['model_calls']}, 'question_denominator': 13, 'quote_denominator': 2, 'selection_interpretation': 'Question support paragraphs were supplied as explicit preserve_quotes; this compares host protection of predefined necessary evidence, not autonomous importance discovery. The native Gold uses located unreviewed observations as required support.', 'semantic_error_count': None, 'free_text_semantic_equivalence': 'NOT_VERIFIED', 'literary_quality': 'NOT_RUN'})

chains = []
for label, folder in (('semantic-upstream-70e7da37', 'upstream-complete-request'), ('semantic-retained-upgrade-70e7da37', 'upstream-main-unsent-upgrade')):
    receipt = json.loads((base / label / folder / 'receipts.json').read_text())
    effects = []
    for proof in receipt['proofs']:
        p = proof['projection']
        effects.append({'effect_id': proof['effect_id'], 'stage': p['stage'], 'source_projection_hash': p['original_hash'], 'derived_projection_hash': p['result_hash'], 'final_supplied_projection_hash': p.get('final_composition', {}).get('supplied_projection_hash'), 'measurement': p['measurement'], 'sent_request_sha256': proof['sent_request_sha256'], 'admission': proof['admission']['provider_admission']})
    chains.append({'label': label, 'source_sha': sha, 'evidence_class': receipt['evidence_class'], 'gold_applied': receipt.get('gold_applied'), 'route_windows': receipt.get('route_windows'), 'effects': effects, 'upgrade': receipt.get('upgrade'), 'receipts_path': 'native/' + label + '/artifacts/' + folder + '/receipts.json.gz', 'readback_path': 'native/' + label + '/artifacts/' + folder + '/native-manuscript-readback.txt.gz'})
restart = json.loads((base / 'semantic-process-restart-70e7da37/receipts.json').read_text())
dump('source-to-result-chain.json', {'source_sha': sha, 'native_chains': chains, 'distinct_process_restart': {k: restart[k] for k in ('source_sha', 'evidence_class', 'checkpoint_process_id', 'checkpoint', 'project_id', 'root_operation_id', 'request_limit', 'before_effect_ids', 'resume_process_id', 'resumed_fixture_calls', 'saved_source_asset_version_id', 'saved_content_hash', 'status')}, 'unknown_in_flight_call_kill': 'NOT_RUN', 'real_provider': 'NOT_RUN', 'real_512k_tokens': 'NOT_RUN', 'free_text_semantic_comprehension': 'NOT_VERIFIED', 'literary_quality': 'NOT_RUN'})

measurements = []
for path in (base / 'semantic-core-70e7da37').glob('*/compression-projection.json'):
    receipt = json.loads((path.parent / 'receipts.json').read_text())
    p = json.loads(path.read_text())
    measurements.append({'case': path.parent.name, 'source_sha': sha, 'evidence_class': receipt['evidence_class'], 'material_measurement': p['measurement'], 'final_request_admission': receipt['provider_admission']['provider_admission'], 'source_projection_hash': p['original_hash'], 'derived_projection_hash': p['result_hash'], 'final_supplied_projection_hash': p['final_composition']['supplied_projection_hash'], 'interpretation': 'SCRIPTED_UTF8_BYTES_EXACT_V1 engineering fixture; exact bytes are not actual model tokens, no real 512K or memory quality claim.'})
dump('measurements.json', measurements)

coverage = json.loads(Path('/tmp/nf-context-512k-evidence-stage/6ba71cf1d2f16aafb88644218355cda07cb1c1ed/entry-coverage.json').read_text())
observed = {p['stage'] for chain in chains for p in chain['effects']}
coverage['tested_source_sha'] = sha
coverage['observed_upstream_stages'] = sorted(observed)
for entry in coverage['entries']:
    entry['policy_source'] = entry['policy_source'].replace('Context v3', 'Context v4')
    entry['entry'] = entry['entry'].replace('PostgresChapterExecutionContractBinder.bind', 'PostgresChapterExecutionContractBinder.freeze_before_external_effect')
    entry.pop('native_execution_source_sha', None)
    entry['overflow_evidence_state'] = 'WIRED' if entry.get('overflow_evidence_state') != 'NOT_APPLICABLE' else None
    if entry['stage'] in observed | {'draft', 'context_compress', 'context_fidelity'}:
        entry.update(overflow_evidence_state='EXECUTABLE', native_execution_source_sha=sha)
    else:
        entry['native_capacity_execution'] = 'NOT_RUN on current source; ordinary stage wiring is separate'
    entry['semantic_policy'] = 'source-unit-dependency-and-final-composition.v2 only when actual frozen Context v4 is selected; older frozen semantics remain'
coverage['other_contracts'].extend([{'entry': 'Vector/embedding protocol', 'reason': 'Different physical protocol, existing physical admission retained; no mechanical historical text compression.'}, {'entry': 'retrieval_query_expansion', 'reason': 'Own bounded selector source contract; no ordinary historical-expression compression claim. Shared final text request admission remains.'}])
coverage['semantic_history_protection'] = {'frozen_field': 'capacity_history_exact_chapters', 'new_pack_default': 1, 'older_field_absent': 'ORIGINAL_RECENT_COMPLETE_PROTECTION', 'preparation_complete_history': 'UNCHANGED', 'required_quotes_facts_dependencies': 'RETAINED'}
dump('entry-coverage.json', coverage)

formal_root = Path('/tmp/nf-semantic-pr-70e7da37')
formal = formal_root / ('pr-governance-' + sha + '.json')
qualification = json.loads(formal.read_text()) if formal.exists() else {'status': 'IN_PROGRESS'}
backend_paths = list(formal_root.glob('novel-forge-p0-*/backend-pytest-process.json'))
backend = json.loads(backend_paths[0].read_text())['stdout'].splitlines()[-1] if backend_paths else 'IN_PROGRESS'
dump('validation.json', {'source_sha': sha, 'focused': {'status': 'PASS', 'passed': 112}, 'formal_changed_contracts': {'status': 'PASS', 'passed': 525}, 'backend_summary': backend, 'formal_pr_qualification': qualification, 'native_runs': native, 'reviews': {'standards': 'Readonly review through corrected projection implementation; no outstanding confirmed issue.', 'spec': 'Readonly final syntax/lexeme classification review of source70e: 12 targeted production tests passed, no confirmed issue.'}, 'actual_worker_process_restart': 'PASS after settled compression plus known durable native retryable failure; original two Effects unchanged, six remaining calls, one Writer', 'unknown_inflight_process_kill': 'NOT_RUN', 'real_provider_compression_fidelity_prose': 'NOT_RUN', 'real_512k_tokens': 'NOT_RUN', 'long_form_memory_quality': 'NOT_RUN', 'literary_quality': 'NOT_RUN', 'deployment': 'UNVERIFIED_NOT_PERFORMED'})
dump('recovery-entrypoints.json', {'capacity_continuation': 'Approve/deploy/activate the compatible same-Book Pack through existing Pack Authority, then novel-forge authority-creation continue --project-id PROJECT --formation-run-id RUN --repository-root ACTUAL_CHECKOUT --foreground', 'original_history_read': 'novel-forge authority-manuscript read --project-id PROJECT --book-run-id BOOK_RUN --candidate-version ORIGINAL_VERSION', 'original_history_export': 'novel-forge authority-manuscript export --project-id PROJECT --book-run-id BOOK_RUN --candidate-version ORIGINAL_VERSION --output NEW_PATH', 'writer_index_dry_run': 'NOVEL_FORGE_DATABASE_URL=OWNED_DB PYTHONPATH=src .venv/bin/python scripts/rebuild_writer_retrieval.py --project-id PROJECT --book-id BOOK --from-chapter FIRST --to-chapter LAST --limit 100 --after-id CURSOR --manifest NEW_MANIFEST.json', 'writer_index_apply': 'Same environment; scripts/rebuild_writer_retrieval.py --manifest FROZEN_MANIFEST.json --apply', 'writer_index_rollback': 'Same environment; scripts/rebuild_writer_retrieval.py --manifest FROZEN_MANIFEST.json --apply --rollback', 'writer_index_resume': 'Use next after-id from the bounded dry-run result with a new manifest. Source version/hash, plan hash and compare-and-swap guards must match; no Provider call or original manuscript rewrite.', 'diagnostics': ['Original Operation/Attempt, immutable source AssetVersions and frozen Capability Pack snapshot', 'Per-chunk ExternalEffect intent/hash, trusted receipt, reservation settlement and capacity source bindings', 'Main Effect _context_capacity_projection.final_composition, actual admission prompt hash, saved manuscript source version', 'Uncarried ranges remain retrievable from original source; omission does not mean an event never happened'], 'unknown': 'Reconcile the original Effect before continuation; no new ID blind retry and no zero-send claim from merely unsent Writer.'})
dump('cleanup-and-compatibility.json', {'canonical_docs': 'Existing canonical docs only. Documentation gaps corrected before source changes; no parallel architecture or narrative delivery report.', 'defaults': 'Context v4 / Chapter3.2 / Planning2.18-2.19 / Creationv4 / workingv7; no cumulative token/call or unsupported local generation timer veto.', 'historical': 'Published migrations and old frozen Catalogs remain byte preserved. Failed/UNKNOWN cost evidence retained. Older task upgrades append native successors, never read new defaults into old contracts.', 'source_projection': 'Strict new JSON projection preserves numeric lexemes before filtering and actual Provider render. Full valid duplicate/nonfinite source JSON rejects explicitly. Plain story prefixes stay plain. Source-bound field/record recovery cannot import unselected fields or choose ambiguous origins.', 'scope': 'No production deployment, manuscript replacement, active Canon mutation or author acceptance.', 'storage': 'XZ/gzip lossless custody is unrelated to model input compression and carries verified decompressed hashes.'})
dump('known-boundaries.json', {'system_ceiling': {'classification': 'CONFIGURABLE_POLICY', 'tokens': 512000, 'selected_route': 'Confirmed smaller physical capacity still applies; a larger interface never increases the system ceiling.'}, 'numeric_unit_decoder': {'classification': 'CURRENT_RUNTIME_FACT', 'behavior': 'Valid JSON numeric objects not exactly representable by the unit decoder remain mandatory original objects. Decoded strings still locate quotations and dependencies. The raw numeric lexeme is retained before filtering through Provider projection.', 'limitation': 'Partial extraction of such an opaque numeric object is unsupported. Its protected-size failure is a current representation/progress limitation, not proof that every conceivable encoding of its necessary story facts is irreducible.'}, 'semantic_proof': {'classification': 'UNRESOLVED_DESIGN_CONSTRAINT', 'deterministic': 'Explicit source ranges, field/record identity, required support and declared dependency closure checked.', 'not_qualified': 'Free-text equivalence, implicit relations and model understanding have no independent real-Provider sample qualification; supported/coverage_complete and legal IDs alone do not prove these.'}, 'real_measurement': {'classification': 'UNRESOLVED_DESIGN_CONSTRAINT', 'status': 'NOT_RUN', 'reason': 'Membership credentials exist, but the selected native interface has no jointly qualified matching complete-protocol meter and physical route capacity evidence. Scripted bytes and character tokenizers are separate engineering fixtures.'}, 'restart': {'classification': 'CURRENT_RUNTIME_FACT', 'verified': 'Different OS processes resume after known settled compression and native retryable bookkeeping, retaining original Effects.', 'not_verified': 'Unknown in-flight physical Provider kill/query/reconciliation was not exercised against a real Provider.'}, 'upstream_coverage': 'See entry-coverage.json: WIRED does not imply native overflow EXECUTABLE for every stage.', 'literary_and_long_form': 'NOT_RUN; controlled samples and repeated load do not qualify an entire novel, long-form memory stability or literary quality.'})
dump('remote-ref-correction.json', {'event_at_utc': '2026-10-16T23:01:06Z', 'cause': 'An asynchronous git push HEAD resolved after the working branch switched, pushing a semantic merge to the capacity feature branch. GitHub automatically marked dependent PR179 merged into that feature branch.', 'unintended_feature_tip': 'd97a486bb3b413f84a875fceee93588c5f8c4b74', 'preserved_semantic_branch': 'codex/wp-nf-semantic-context-compression-01', 'restored_capacity_tip': '53c1be9e1207e8cea5e37ccf03a7cfaab06806cd', 'correction': 'Preserve semantic commit remotely first, then restore only the owned capacity feature branch with force-with-lease requiring exactly d97a486b. Subsequent pushes use explicit source commit SHAs.', 'main_sha_verified_unchanged': '6b69b22b331191331292a51a905833871b17b283', 'current_pr': 'https://github.com/yuan2go/novel-forge/pull/180', 'superseded_pr': 'https://github.com/yuan2go/novel-forge/pull/179', 'production_or_manuscripts_changed': False, 'qualification_inferred_from_github_merged_state': False})
dump('manifest.json', {'schema_version': 'novel-forge.semantic-context-delivery-evidence.v1', 'work_package': 'WP-NF-SEMANTIC-CONTEXT-COMPRESSION-01', 'source_sha': sha, 'baseline_capacity_sha': '35a7b26eaaa165fea9c16c782e1a31b25a6196ab', 'reference_main_sha': '6b69b22b331191331292a51a905833871b17b283', 'implementation_tree_sha': build_implementation_tree_identity(repo)['implementation_tree_sha'], 'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'evidence_ceiling': 'EXECUTABLE', 'formal_qualification': qualification.get('status'), 'runtime_identity_boundary': 'Fixture Build/Release identities in native requests are controlled and separate from executing Git source SHA; no production deployment is inferred.', 'remote_pr': 'https://github.com/yuan2go/novel-forge/pull/180', 'files': H['manifest_files'](out)})
H['copy_cluster_custody'](out)
manifest = json.loads((out / 'manifest.json').read_text())
manifest['files'] = H['manifest_files'](out)
dump('manifest.json', manifest)
print(out)
