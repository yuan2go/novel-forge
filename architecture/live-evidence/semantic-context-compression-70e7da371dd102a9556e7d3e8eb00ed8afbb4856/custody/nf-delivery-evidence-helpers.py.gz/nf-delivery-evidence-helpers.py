from pathlib import Path
import gzip, hashlib, json, lzma, re, shutil
import psycopg
from psycopg import sql

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as reader:
        for block in iter(lambda: reader.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def dump(root, name, value):
    target = Path(root) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + '\n')

def archive(root, source, name):
    source = Path(source)
    if not source.is_file():
        return False
    target = Path(root) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.suffix in {'.gz', '.xz'}:
        shutil.copyfile(source, target)
    else:
        with source.open('rb') as reader, gzip.GzipFile(filename=str(target), mode='wb', mtime=0) as writer:
            shutil.copyfileobj(reader, writer)
    return True

def archive_tree(root, source, name):
    source = Path(source)
    for path in source.rglob('*'):
        if path.is_file():
            suffix = '' if path.suffix in {'.gz', '.xz'} else '.gz'
            archive(root, path, str(Path(name) / path.relative_to(source)) + suffix)

def test_status(path):
    text = Path(path).read_text() if Path(path).is_file() else ''
    if 'NATIVE_PROCESS_RESTART_PASS' in text:
        return {'status': 'PASS', 'summary': text[-800:]}
    matches = re.findall(r'(?m)^.*?\d+ passed[^\n]*', text)
    if not matches:
        return {'status': 'FAIL' if re.search(r'\d+ failed', text[-2000:]) else 'IN_PROGRESS'}
    latest = matches[-1].strip('= ')
    return {'status': 'FAIL' if re.search(r'\d+ failed', latest) else 'PASS', 'summary': latest}

def export_database(root, label, source_sha):
    root = Path(root)
    index_path = root / 'native' / label / 'database-index.json'
    if index_path.is_file():
        result = json.loads(index_path.read_text())
        for table in result['tables'].values():
            assert digest(root / table['path']) == table['storage_sha256']
        return result
    env = json.loads(Path('/tmp/nf-context-512k-' + label + '-env.json').read_text())
    result = {'source_sha': source_sha, 'database': env['NOVEL_FORGE_QUALIFICATION_DATABASE_NAME'], 'isolation': 'REPEATABLE READ READ ONLY', 'serialization': 'PostgreSQL SELECT to_jsonb(t)::text, UTF-8 JSON lines, no Python JSON numeric round-trip', 'storage': 'XZ lossless host custody only; unrelated to model context compression', 'tables': {}}
    with psycopg.connect(env['NOVEL_FORGE_DATABASE_URL']) as connection:
        connection.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        tables = [row[0] for row in connection.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' ORDER BY table_name")]
        result['project_ids'] = [row[0] for row in connection.execute('SELECT DISTINCT project_id FROM authority_operation ORDER BY project_id')]
        for table in tables:
            target = root / 'native' / label / 'database' / (table + '.jsonl.xz')
            target.parent.mkdir(parents=True, exist_ok=True)
            raw_digest = hashlib.sha256()
            size = count = 0
            with connection.cursor(name='export_' + table) as cursor, lzma.open(target, 'wb', preset=3) as writer:
                cursor.execute(sql.SQL('SELECT to_jsonb(t)::text FROM {} t').format(sql.Identifier(table)))
                for row in cursor:
                    data = (row[0] + '\n').encode()
                    writer.write(data)
                    raw_digest.update(data)
                    size += len(data)
                    count += 1
            restored_digest = hashlib.sha256()
            restored_size = 0
            with lzma.open(target, 'rb') as reader:
                for block in iter(lambda: reader.read(1024 * 1024), b''):
                    restored_digest.update(block)
                    restored_size += len(block)
            assert restored_digest.digest() == raw_digest.digest() and restored_size == size
            result['tables'][table] = {'rows': count, 'path': str(target.relative_to(root)), 'raw_sha256': raw_digest.hexdigest(), 'raw_bytes': size, 'storage_sha256': digest(target), 'storage_bytes': target.stat().st_size, 'decompression_verified': True}
    result['model_call_cost_storage'] = 'Schema-backed model_call_log/cost_ledger assets are retained in authority_asset and authority_asset_version; no absent physical log table is assumed.'
    dump(root, str(index_path.relative_to(root)), result)
    return result

def manifest_files(root):
    return [{'path': str(path.relative_to(root)), 'sha256': digest(path), 'size_bytes': path.stat().st_size} for path in sorted(Path(root).rglob('*')) if path.is_file() and path != Path(root) / 'manifest.json']

def copy_cluster_custody(root):
    directory = Path('/tmp/nf-context-512k-owned-database-archives')
    record = json.loads((directory / 'native-final-complete-cluster.json').read_text())
    assert record['action'] == 'STOPPED_EXACT_OWNED_CLUSTER_AFTER_VERIFIED_FULL_ARCHIVE'
    assert record['delivery_storage']['decompression_verified']
    combined = hashlib.sha256()
    for piece in record['delivery_storage']['pieces']:
        source = directory / piece['filename']
        assert source.stat().st_size == piece['bytes'] and digest(source) == piece['sha256']
        destination = Path(root) / 'custody' / piece['filename']
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        with destination.open('rb') as reader:
            for block in iter(lambda: reader.read(1024 * 1024), b''):
                combined.update(block)
    assert combined.hexdigest() == record['delivery_storage']['sha256']
    record['evidence_scope'] = 'Complete custody archive of 32 task-owned native databases across independently source-bound runs. This is not a claim that all archived executions ran on the manifest source SHA. Individual native run evidence retains its own SHA.'
    dump(root, 'custody/native-final-complete-cluster.json', record)
    for filename in ('nf-context-512k-final-cluster-archive.py', 'nf-context-512k-final-cluster-archive.log', 'nf-context-512k-cluster-lossless-storage.py', 'nf-context-512k-cluster-lossless-storage.log'):
        archive(root, Path('/tmp') / filename, 'custody/' + filename + '.gz')
