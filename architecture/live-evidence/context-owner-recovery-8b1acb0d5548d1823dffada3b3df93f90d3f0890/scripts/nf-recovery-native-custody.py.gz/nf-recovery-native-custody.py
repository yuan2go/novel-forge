import argparse,json,lzma,runpy
from pathlib import Path
from novel_forge.tools.implementation_tree_identity import build_git_implementation_tree_identity

parser=argparse.ArgumentParser();parser.add_argument('--source',default='8b1acb0d5548d1823dffada3b3df93f90d3f0890');args=parser.parse_args()
sha=args.source;repo=Path.cwd();out=repo/'architecture/live-evidence'/('context-owner-recovery-'+sha);out.mkdir(exist_ok=True)
H=runpy.run_path('/tmp/nf-delivery-evidence-helpers.py');registry=json.load(open('/tmp/nf-capacity-regression-resource.json'))
for label in ['semantic-8b1acb0d-native-core','semantic-8b1acb0d-native-adapter-regressions','semantic-8b1acb0d-native-retained-upgrade']:
    entry=next(x for x in registry['additional_databases'] if x['label']==label);run=Path(entry['evidence'])
    if not (run/'result.json').is_file():continue
    H['archive_tree'](out,run,'native/'+label+'/run')
    Path('/tmp/nf-context-512k-'+label+'-env.json').write_text(json.dumps({'NOVEL_FORGE_DATABASE_URL':'postgresql://novel_forge:novel_forge@127.0.0.1:'+str(registry['port'])+'/'+entry['database'],'NOVEL_FORGE_QUALIFICATION_DATABASE_NAME':entry['database']}))
    H['export_database'](out,label,sha)
    database=out/'native'/label/'database'
    def rows(table):
        with lzma.open(database/(table+'.jsonl.xz'),'rt') as source:return [json.loads(line) for line in source]
    effects=rows('authority_external_effect');assets={x['asset_version_id']:x for x in rows('authority_asset_version')};outputs=rows('authority_operation_output_asset');attempts=rows('authority_attempt');reservations=rows('authority_budget_reservation');chains=[];retained=[]
    for effect in effects:
        payload=effect.get('request_payload') or {};projection=(payload.get('input') or {}).get('_context_capacity_projection');metadata=payload.get('_production_execution') or {};runtime=metadata.get('capability_runtime') or {}
        owned_outputs=[{'asset_version_id':link['asset_version_id'],'output_key':link['output_key'],'content_hash':assets[link['asset_version_id']]['content_hash']} for link in outputs if link['operation_id']==effect['operation_id'] and link['asset_version_id'] in assets]
        if projection:
            chunks=[]
            for sub in effects:
                task=(sub.get('request_payload') or {}).get('input',{}).get('context_compression_task',{})
                if task.get('task',{}).get('source_projection_hash')==projection['original_hash'] and sub['operation_id']==effect['operation_id']:
                    chunks.append({'effect_id':sub['external_effect_id'],'stage':sub['request_payload']['stage'],'status':sub['status'],'request_hash':sub['request_hash'],'source_binding':task.get('source_binding'),'task_fingerprint':task.get('task_fingerprint')})
            chains.append({'source_boundary':projection['source_boundary'],'original_provider_projection_hash':projection['original_hash'],'derived_provider_projection_hash':projection['result_hash'],'compression_and_check_effects':chunks,'replacements':projection['replacements'],'final_composition':projection.get('final_composition'),'measurement':projection['measurement'],'main_effect_id':effect['external_effect_id'],'status':effect['status'],'frozen_request_hash':effect['request_hash'],'provider_request_envelope_hash':runtime.get('provider_request_envelope_hash'),'provider_admission':runtime.get('provider_admission'),'frozen_pack_snapshot_hash':runtime.get('snapshot_hash'),'native_outputs':owned_outputs})
        if payload.get('stage')=='reader_outcome':
            operation=effect['operation_id'];owned_attempts=sorted([x for x in attempts if x['operation_id']==operation],key=lambda x:x['attempt_number'])
            retained.append({'operation_id':operation,'attempts':[{'attempt_id':x['attempt_id'],'number':x['attempt_number'],'status':x['status'],'result':x['result']} for x in owned_attempts],'original_context':[x for x in metadata.get('input_artifacts',[]) if x['artifact_type']=='context_bundle'],'effect_id':effect['external_effect_id'],'effect_status':effect['status'],'frozen_request_hash':effect['request_hash'],'effects_in_operation':len([x for x in effects if x['operation_id']==operation]),'reservations':[{'reservation_id':x['reservation_id'] if 'reservation_id' in x else x.get('budget_reservation_id'),'status':x['status']} for x in reservations if x['operation_id']==operation],'native_outputs':owned_outputs})
    H['dump'](out,'native/'+label+'/source-to-result-chain.json',{'source_sha':sha,'implementation_tree_sha':build_git_implementation_tree_identity(repo,sha)['implementation_tree_sha'],'scope':'CONTROLLED_NATIVE_ENGINEERING; exact source and raw PostgreSQL JSON retain full evidence. Synthetic capacity is not actual Provider token capacity.','serialization':'Summary identity fields only; original precision/text are retained in PostgreSQL-to-JSONL XZ exports','compression_chains':chains,'known_receipt_recovery':retained})
H['archive'](out,'/tmp/nf-recovery-native-custody.py','scripts/nf-recovery-native-custody.py.gz')
print(out)
