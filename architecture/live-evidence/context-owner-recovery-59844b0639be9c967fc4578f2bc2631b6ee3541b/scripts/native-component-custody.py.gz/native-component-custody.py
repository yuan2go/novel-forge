import datetime,gzip,hashlib,json,lzma,runpy,subprocess
from pathlib import Path
from novel_forge.tools.implementation_tree_identity import build_git_implementation_tree_identity

repo=Path.cwd();sha='59844b0639be9c967fc4578f2bc2631b6ee3541b';parent='479000c6584e309191b378e04cae10b157cff67c'
out=repo/'architecture/live-evidence'/('context-owner-recovery-'+sha);out.mkdir(exist_ok=True)
H=runpy.run_path('/tmp/nf-delivery-evidence-helpers.py');dump=lambda n,v:H['dump'](out,n,v)
r=json.load(open('/tmp/nf-capacity-regression-resource.json'));label='semantic-59844b06-legacy-planning-upgrade';entry=next(x for x in r['additional_databases'] if x['label']==label);run=Path(entry['evidence'])
result=json.loads((run/'result.json').read_text());assert result['exit_code']==0
H['archive_tree'](out,run,'native/'+label+'/run')
Path('/tmp/nf-context-512k-'+label+'-env.json').write_text(json.dumps({'NOVEL_FORGE_DATABASE_URL':'postgresql://novel_forge:novel_forge@127.0.0.1:'+str(r['port'])+'/'+entry['database'],'NOVEL_FORGE_QUALIFICATION_DATABASE_NAME':entry['database']}))
db=H['export_database'](out,label,sha)
def rows(table):
    with lzma.open(out/db['tables'][table]['path'],'rt') as source:return [json.loads(line) for line in source]
continuations=rows('authority_story_planning_runtime_continuation');assert len(continuations)==1
record=continuations[0];effects=rows('authority_external_effect');ops={x['operation_id']:x for x in rows('authority_operation')};assets=rows('authority_asset_version')
contexts=[{'asset_version_id':x['asset_version_id'],'content_hash':x['content_hash'],'policy':x['content'].get('planning_context_policy_version')} for x in assets if isinstance(x.get('content'),dict) and x['content'].get('planning_context_policy_version') in {'context-policy:chapter-generation-pack:v2','context-policy:chapter-generation-pack:v3'}]
dump('native/'+label+'/upgrade-chain.json',{'source_sha':sha,'database':entry['database'],'continuation':record,'source_operation':ops[record['source_operation_id']],'successor_operation':ops[record['successor_operation_id']],'source_effects':sum(x['operation_id']==record['source_operation_id'] for x in effects),'successor_effects':sum(x['operation_id']==record['successor_operation_id'] for x in effects),'context_versions':contexts,'scope':'Existing native Formation scheduler and Planning runtime successor under controlled member transport. No real Provider; no production task resumed.'})
container='nf-p0-85fa5a57fdd44ad6ae1d8d79bbd2b665-authority-postgres-test-1';info=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
assert info['Id']=='eeb98832a809c649dee5b6d5ee75675fb001f9b029203d02c88119d01f4f2265' and info['Config']['Labels']['novel-forge.qualification.run-id']==r['run_id']
custody=out/'custody';custody.mkdir(exist_ok=True);target=custody/(label+'.sql.xz');assert not target.exists();h=hashlib.sha256();size=0;tail=b''
command=['docker','exec',container,'pg_dump','-U','novel_forge','--create',entry['database']]
with (custody/'pg-dump.stderr.log').open('wb') as errors:
    p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=errors)
    with lzma.open(target,'wb',preset=3) as writer:
        while block:=p.stdout.read(1024*1024):h.update(block);size+=len(block);tail=(tail+block)[-4096:];writer.write(block)
    code=p.wait()
assert code==0 and b'PostgreSQL database dump complete' in tail
verified=hashlib.sha256();verified_size=0
with lzma.open(target,'rb') as reader:
    while block:=reader.read(1024*1024):verified.update(block);verified_size+=len(block)
assert (size,h.hexdigest())==(verified_size,verified.hexdigest())
dump('custody/supplement.json',{'status':'PASS_DUMP_AND_LOSSLESS_READBACK_ONLY','source_sha':sha,'container_id':info['Id'],'database':entry['database'],'command':command,'archive':target.name,'raw_bytes':size,'raw_sha256':h.hexdigest(),'storage_bytes':target.stat().st_size,'storage_sha256':H['digest'](target),'decompression_verified':True,'actual_postgresql_restore':'NOT_RUN','prior_receipts':['../../context-owner-recovery-'+parent+'/custody/supplements.json','../../context-owner-recovery-'+parent+'/custody/overhead-supplement.json']})
subprocess.run(['docker','stop',container],check=True,capture_output=True);stopped=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0];assert stopped['State']['Status']=='exited'
dump('custody/stopped-owned-resource.json',{'source_sha':sha,'observed_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'container_id':info['Id'],'compose_project':r['compose_project'],'action':'STOPPED_EXACT_OWNED_CLUSTER_AFTER_VERIFIED_ADDITIONAL_DATABASE_ARCHIVE','state':stopped['State'],'volumes_preserved':True,'unrelated_resources_modified':False})
dump('readonly-reviews.json',{'source_sha':sha,'fixed_point':parent,'standards':'No confirmed issue: native explicit historical builder flags and exact6b policy replace manifest surgery; old assertions and gates unchanged.','spec':'No confirmed issue: original zero Effect, concurrent idempotency, command and repair number, oldv2/newv3 Context, projection hash and saved candidate assertions retained.','scope':'Read-only static two-axis review under repository code-review skill; no test, database or Provider use by reviewers.'})
paths=subprocess.check_output(['git','diff','--name-only',parent,sha],text=True).splitlines();assert paths==['architecture/reality-evidence.json','tests/integration/test_synthesis_formation_postgres.py']
dump('validation.json',{'source_sha':sha,'implementation_tree_sha':build_git_implementation_tree_identity(repo,sha)['implementation_tree_sha'],'unchanged_business_source':parent,'changed_paths':paths,'focused_native':{'status':'PASS','tests':1,'seconds':20.95,'entry':result['tests'][0],'raw':'native/'+label+'/run/pytest.xml.gz'},'formal_whole_source':'NOT_RUN on this test-only correction; same business-source full4790 P0 is FAIL, not transferred as PASS','retained_parent_formal':'../context-owner-recovery-'+parent+'/formal-qualification.json','qualification':'NOT_QUALIFIED','before':'v2 test Manifest retained new v4 semantic history constraint; compiler rejected mixed contracts','after':'Use native coherent legacy builder, frozen6b Creation policy and explicit v3 successor; all original upgrade assertions retained','real_provider':'NOT_RUN','production':'NOT_RUN'})
H['archive'](out,'/tmp/nf-59844b06-delivery-component.py','scripts/native-component-custody.py.gz')
dump('manifest.json',{'schema_version':'novel-forge.compression-recovery-evidence.v1','source_sha':sha,'evidence_ceiling':'EXECUTABLE','scope':'Historical Planning native upgrade component, test-only correction after full4790 failed gate. Does not qualify the whole release.','files':H['manifest_files'](out)})
print(json.dumps({'source_sha':sha,'status':'PASS_CONTROLLED_NATIVE_COMPONENT','contexts':contexts,'evidence':str(out)}),flush=True)
