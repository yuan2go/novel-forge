import gzip,json,hashlib
from pathlib import Path
import psycopg
p=Path('/Volumes/DevSSD/Development/Workspace/task-data/WP-NF-AUTHOR-FIRST-CONTINUATION-AND-RECOVERY-01')
out=Path('/Users/yuan/.codex/worktrees/author-first-continuation/novel-forge/architecture/live-evidence/author-first-token-unlimited-707356da/real-provider');out.mkdir(exist_ok=True)
url='postgresql://yuan@127.0.0.1:56437/nf_author_first_native'
with psycopg.connect(url,options='-c default_transaction_read_only=on') as c:
 identity=c.execute('SELECT current_database(),(SELECT system_identifier::text FROM pg_control_system()),clock_timestamp()').fetchone()
 tables=['authority_story_formation_run','authority_story_planning_generation','authority_operation','authority_attempt','authority_external_effect','authority_external_effect_dispatch','authority_external_receipt','authority_generation_isolation','authority_story_planning_runtime_continuation','authority_budget_reservation','authority_book_production','authority_book_chapter_request','authority_book_manuscript_delivery','authority_story_planning_validation_report']
 data={}
 for t in tables:
  cols={r[0] for r in c.execute('SELECT column_name FROM information_schema.columns WHERE table_schema=\'public\' AND table_name=%s',[t]).fetchall()}
  if 'project_id' in cols:rows=c.execute('SELECT to_jsonb(x) FROM '+t+' x WHERE project_id=%s',['project:wp-nf-author-first-20261017']).fetchall()
  else:rows=c.execute('SELECT to_jsonb(x) FROM '+t+' x').fetchall()
  data[t]=[r[0] for r in rows]
 assets=[r[0] for r in c.execute('SELECT jsonb_build_object(\'asset_type\',a.asset_type,\'asset_id\',a.asset_id,\'version\',to_jsonb(v)) FROM authority_asset a JOIN authority_asset_version v USING(asset_id) WHERE a.project_id=%s',['project:wp-nf-author-first-20261017']).fetchall()]
 migration=[r[0] for r in c.execute('SELECT migration_id FROM nf_schema_migrations ORDER BY applied_at,migration_id').fetchall()]
report={'evidence_class':'REAL_PROVIDER_NATIVE_CREATION','source_runtime_sha':'809e81f9548fc3bb6ab6bffdb06453aa7506062d','engineering_test_sha':'707356dad005e5e23d020ec8993eb2f4cf1dc62d','identity':{'database':identity[0],'cluster':identity[1],'read_at':identity[2]},'assets':assets,'tables':data,'migration_ids':migration}
(out/'native-checkpoint.json.gz').write_bytes(gzip.compress((json.dumps(report,ensure_ascii=False,indent=2,default=str)+'\n').encode(),mtime=0))
for name in ['creation-request.json','start-command.json','start.exit.json','start.stdout.json','continue-01.exit.json','continue-01.stdout.json','recover-world-01.command.json','recover-world-01.exit.json','recover-world-01.stdout.json','provider-preflight.json','provider-preflight-02.json']:
 f=p/name
 if f.exists() and f.stat().st_size:(out/name).write_bytes(f.read_bytes())
files=[]
for f in (p/'executions').rglob('*'):
 if f.is_file():files.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':'sha256:'+hashlib.sha256(f.read_bytes()).hexdigest()})
(out/'retained-execution-files.json').write_text(json.dumps({'root':str(p),'files':files},ensure_ascii=False,indent=2)+'\n')
print('native checkpoint',identity[2],len(assets),'assets',len(files),'physical files')
