from pathlib import Path
import ast, json, re, subprocess, hashlib, inspect, math
from collections import Counter
BASE=Path('/Users/yuan/Documents/Codex/audits/novel-forge-instructions-20261003')
ROOT=BASE/'snapshot'
def dump(name,value): (BASE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def read(path): return (ROOT/path).read_text()
def digest(text): return 'sha256:'+hashlib.sha256(text.encode()).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def metrics(text):
 return {'characters':len(text),'utf8_bytes':len(text.encode()),'utf8_byte_token_upper_bound':len(text.encode()),'legacy_bytes_div3_estimate':max(1,(len(text.encode())+2)//3),'negative_markers':len(re.findall(r'不要|禁止|不得|必须避免|严禁|\bDo not\b|\bNever\b|\bmust not\b',text,re.I)),'mandatory_markers':len(re.findall(r'必须|\bMUST\b|\brequired\b',text,re.I))}
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')[:-1]
pattern=re.compile(r'prompt\s*=|system\s*=|instructions?\s*=|messages\s*=|context\s*=|template\s*=|system.prompt|developer.prompt|instruction|few.shot|\.render\(|\.format\(|\.invoke\(|\.generate\(|\.complete\(|\.chat\(|responses\.create|chat/completions|SKILL\.md',re.I)
scan=[]
for relative in tracked:
 p=ROOT/relative
 if p.suffix.lower() not in {'.py','.md','.json','.yaml','.yml','.toml','.ts','.tsx','.js','.mjs','.txt'}:continue
 # Discovery records identities and matching line numbers only; private manuscript/source text is never reproduced.
 try:text=p.read_text()
 except (UnicodeError,OSError):continue
 lines=[n for n,line in enumerate(text.splitlines(),1) if pattern.search(line)]
 if lines:scan.append({'path':relative,'lines':lines,'match_line_count':len(lines),'sha256':digest(text),'role':'HISTORICAL_OR_SOURCE_NOT_RUNTIME_PROOF' if relative.startswith(('novels/','architecture/live-evidence/','reports/','tests/')) else 'CANDIDATE_REQUIRES_CALL_CHAIN'})
dump('repository-search-inventory.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'tracked_file_count':len(tracked),'search_patterns':pattern.pattern,'matches':scan,'requested_directory_presence':{d:(ROOT/d).exists() for d in ['skills','prompts','prompt','templates','agents','workflow','runtime','provider','context','memory','review','editor','craft','admission','qualification','governance','config','resources']}})
from novel_forge.modules.capability_packs.artifacts import default_chapter_artifact_resolver,ArtifactKind
from novel_forge.modules.capability_packs.longform_profiles import build_story_planning_pack_profile,build_reader_outcome_pack_profile,build_longform_prose_review_pack_profile,build_narrative_evaluation_pack_profile
from novel_forge.modules.capability_packs.screenplay_profiles import build_screenplay_pack_profile
from novel_forge.modules.capability_pack_authority.application import _select_capability_skill
from novel_forge.modules.production_execution.capability_registry import default_capability_registry
from novel_forge.modules.chapter_authority.execution_gateway import _stage_semantic_contract,_stage_semantic_contract_v3,_project_prose_skill,_materialize_production_codex_prompt
from novel_forge.modules.chapter_authority.provider_output_contracts import chapter_provider_output_schema,chapter_provider_output_schema_ref
from novel_forge.modules.chapter_authority.provider_views import build_provider_task_view,build_provider_context_view,build_provider_knowledge_view,project_retrieved_state_context
from novel_forge.modules.story_planning_runtime.foundation_generation import foundation_task,FOUNDATION_GENERATORS
from novel_forge.modules.context_builder.domain import build_authority_context_bundle,replay_context_bundle
from novel_forge.modules.context_contracts import ContextCandidate
from novel_forge.modules.production_execution.contracts import TargetScope
resolver=default_chapter_artifact_resolver(ROOT)
base_manifest=json.loads(read('config/capability_packs/chapter_generation_pack.json'))
profiles=[]
for f in [build_story_planning_pack_profile,build_reader_outcome_pack_profile,build_longform_prose_review_pack_profile,build_narrative_evaluation_pack_profile]:profiles.append(f(ROOT,operation_definition_hash='sha256:'+'0'*64))
for s in ['screenplay_generate','screenplay_review','screenplay_revision']:profiles.append(build_screenplay_pack_profile(ROOT,stage=s,operation_definition_hash='sha256:'+'0'*64))
all_artifacts={}
for a in resolver.artifacts():all_artifacts[(a.kind.value,a.ref,a.version,a.content_hash)]=a.to_dict()
for p in profiles:
 for a in p.artifact_catalog['artifacts']:all_artifacts[(a['kind'],a['ref'],a['version'],a['content_hash'])]=a
bindings=[]
for manifest in [base_manifest,*[p.manifest for p in profiles]]:
 for n in manifest['workflow_template']['nodes']:
  c=default_capability_registry().resolve(n['capability_id'])
  try:s=_select_capability_skill(manifest['skill_binding']['skills'],capability_id=n['capability_id'],input_contract_ref=c.input_schema_ref,output_contract_ref=c.output_schema_ref)
  except Exception as e:s={'error':str(e)}
  bindings.append({'pack':manifest['identity']['pack_id'],'stage':n['stage'],'capability':n['capability_id'],'skill':s,'prompt_binding':manifest['prompt_binding'],'is_model_stage':n['stage'] in {'memo','retrieval','draft','review','revision','rereview','canon_extraction','canon_support','quality_structural','quality_commercial','quality_source_originality','quality_longform','quality_platform'} or manifest['identity']['pack_id']!='chapter_generation_pack'})
dump('runtime-bindings.json',bindings)
dump('resolved-artifact-catalog.json',list(all_artifacts.values()))
used_paths={a['source_identity'] for a in all_artifacts.values() if a['kind']=='SKILL'}
# Agent pack resolves this Skill independently of the 22-node Chapter saga.
used_paths.add('skills/agent-loop-governance/SKILL.md')
skills=[]
for path in sorted(p for p in tracked if p.startswith('skills/') and p.endswith('.md')):
 versions=[a for a in all_artifacts.values() if a['kind']=='SKILL' and a['source_identity']==path]
 name=path.split('/')[1]
 stages=sorted({b['stage'] for b in bindings if b['skill'].get('skill_ref')==name and b['is_model_stage']})
 if name=='agent-loop-governance':stages=['agent_session']
 if name=='context-builder-source-isolation':stages=sorted(set(stages)|{'retrieval','retrieval_query_expansion','context_compress','context_fidelity'})
 status='LEGACY' if '/legacy-' in path else 'ACTIVE' if name in {'prose-generation','chapter-outline','quality-review','canon-continuity-graph'} else 'CONDITIONAL' if path in used_paths else 'UNREACHABLE'
 skills.append({'id':'S%03d'%(len(skills)+1),'name':name,'file':path,'symbol':'default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill','caller':'CapabilityPackAuthority resolve and materialize_attempt_artifacts','downstream':'_materialize_production_codex_prompt -> ProviderRequestEnvelope','runtime_reachable':path in used_paths,'status':status,'stage':stages,'versions':[{'ref':a['ref'],'version':a['version'],'hash':a['content_hash']} for a in versions], 'load_policy':'Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.','dynamic':name=='prose-generation','dynamic_variables':['stage','targeted_edits_only'] if name=='prose-generation' else [],'dependent_skills':'References in prose do not cause automatic nested loading','context':'Provider task + authorized context + required Knowledge, stage dependent','memory':'accepted history only through Context; generic Agent session has frozen observations','historical_review':'revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON','logs':'not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence','other_prompts':'system,template,stage semantic contract,schema','enters_llm':path in used_paths,'metrics':metrics(read(path)),'sha256':digest(read(path)),'text':read(path)})
dump('skill-inventory.json',skills)
out=['# Complete Skill Inventory — frozen main\n','ACTIVE means the current code/default Pack binding, not observed PostgreSQL activation. CONDITIONAL requires the corresponding runtime stage and admitted route. UNREACHABLE means no formal novel-production text consumer was found in this audit, not global dead code. LEGACY is eligible only through an exact frozen historical catalog.\n']
for s in skills:
 out+=['## '+s['id']+' '+s['file']+'\n','```json\n'+json.dumps({k:v for k,v in s.items() if k!='text'},ensure_ascii=False,indent=2)+'\n```\n','完整原文：\n````markdown\n'+s['text']+'\n````\n']
(BASE/'04-complete-skill-inventory.md').write_text('\n'.join(out))
prompts=[]
for a in all_artifacts.values():
 if a['kind'] not in {'PROMPT_SYSTEM_INSTRUCTION','PROMPT_TEMPLATE','KNOWLEDGE'}:continue
 matching=[b for b in bindings if any(b['prompt_binding'].get(k)==a['ref'] and b['prompt_binding'].get(v)==a['version'] for k,v in [('system_instruction_ref','system_instruction_version'),('template_ref','template_version')])]
 legacy=a['ref'].startswith(('prompt-system:chapter','prompt-template:chapter')) and not matching
 status='LEGACY' if legacy or a['ref'].endswith('cost:v1') else 'CONDITIONAL' if a['ref'].startswith('prompt-system:agent') or a['ref'].startswith('prompt-template:agent') else 'ACTIVE'
 stages=sorted({b['stage'] for b in matching if b['is_model_stage']})
 if 'agent-session' in a['ref']:stages=['agent_session']
 if a['kind']=='KNOWLEDGE':stages=['all stages whose registered Pack requires this exact Knowledge version']
 if legacy:stages=['frozen legacy recovery; active persisted binding UNKNOWN']
 text=a['content'].get('text') if isinstance(a['content'],dict) else None
 if text is None:text=canonical(a['content'])
 prompts.append({'id':'P%03d'%(len(prompts)+1),'name':a['ref']+'@'+a['version'],'file':a['source_identity'],'symbol':'default_chapter_artifact_resolver / _bind_domain_artifacts','caller':'materialize_attempt_artifacts -> _materialize_production_codex_prompt','downstream':'Provider task/context projection -> ProviderRequestEnvelope -> admitted adapter','runtime_reachable':True,'status':status,'stage':stages,'prompt_type':a['kind'],'dynamic':a['kind']=='PROMPT_TEMPLATE','dynamic_variables':re.findall(r'\{\{([^}]+)\}\}',text),'skills':sorted({b['skill'].get('skill_ref','')+'@'+b['skill'].get('version','') for b in matching if b['is_model_stage']}),'context':'Exact stage ProviderContext view; templates contain canonical serialized task/context, not raw frozen materialization','memory':'L0-L9 selected accepted facts/history through Context; actual rows unknown','historical_review':'explicit Revision/ReReview; conditional inherited L0 selected_review leak','logs':'not a filesystem log loader; conditional nested accepted provider_evidence/Agent observation leak','other_prompts':'One System + one Skill + required Knowledge + one template + one semantic contract + schema','enters_llm':True,'content_hash':a['content_hash'],'metrics':metrics(text),'text':text})
# Unreferenced files remain inventory records rather than being promoted by existence.
covered={p['file'] for p in prompts}
for path in tracked:
 if path.startswith('config/capability_packs/artifacts/') and path.endswith('.md') and path not in covered:
  prompts.append({'id':'P%03d'%(len(prompts)+1),'name':Path(path).stem,'file':path,'symbol':'NONE_FOUND','caller':'No formal text consumer found','downstream':'NONE_FOUND','runtime_reachable':False,'status':'UNREACHABLE','stage':[],'prompt_type':'UNBOUND_TEMPLATE','dynamic':bool(re.search(r'\{\{',read(path))),'dynamic_variables':re.findall(r'\{\{([^}]+)\}\}',read(path)),'skills':[],'context':None,'memory':None,'historical_review':False,'logs':False,'other_prompts':False,'enters_llm':False,'metrics':metrics(read(path)),'text':read(path)})
dump('prompt-inventory.json',prompts)
out=['# Complete Prompt Inventory — artifact originals\n','Dynamic code instructions, effective emitted stage contracts, output schemas and full builders are in 03-dynamic-instructions.md. No catalog entry alone establishes live activation; bindings and callers are supplied separately.\n']
for p in prompts:out+=['## '+p['id']+' '+p['name']+'\n','```json\n'+json.dumps({k:v for k,v in p.items() if k!='text'},ensure_ascii=False,indent=2)+'\n```\n','完整原文：\n````text\n'+p['text']+'\n````\n']
(BASE/'02-complete-prompt-inventory.md').write_text('\n'.join(out))
# Export complete instruction builders, including data-dependent branches; source is exact, never summarized.
code_files={
 'src/novel_forge/modules/chapter_authority/execution_gateway.py':['_required_language_from_context','_language_semantic_contract','_stage_semantic_contract_v3','_stage_semantic_contract','_bind_language_contract','_project_prose_skill','_materialize_production_codex_prompt','_materialize_chapter_codex_prompt'],
 'src/novel_forge/modules/chapter_authority/provider_views.py':['build_provider_task_view','build_provider_context_view','build_provider_knowledge_view','_build_planning_context_view','_build_narrative_evaluation_context_view','_build_longform_prose_review_context_view','_cross_chapter_task'],
 'src/novel_forge/modules/chapter_authority/realization_composition.py':['_legacy_scene_craft_tasks','_scene_craft_tasks'],
 'src/novel_forge/modules/review/craft.py':['craft_provider_task','craft_revision_contract'],
 'src/novel_forge/modules/story_planning_runtime/foundation_generation.py':['foundation_task','foundation_output_schema','world_generation_contract'],
 'src/novel_forge/modules/story_planning_runtime/world_preparation.py':['generation_stage','evaluation_stage','_task'],
 'src/novel_forge/modules/worldbuilding/actor_isolation.py':['actor_task'],
 'src/novel_forge/modules/story_planning_runtime/knowledge_translation.py':['add_translation_contract'],
 'src/novel_forge/modules/mkaos_authority/craft_context_projection.py':['project_planning_craft_histories'],
 'src/novel_forge/modules/book_followup_authority/screenplay_execution.py':['screenplay_context_view'],
 'src/novel_forge/modules/agent_runtime/coordinator.py':['execute_candidate'],
 'src/novel_forge/modules/agent_collaboration/application.py':['execute_turn'],
}
code_records=[]
for path,symbols in code_files.items():
 text=read(path);tree=ast.parse(text);lines=text.splitlines()
 for n in ast.walk(tree):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in symbols:
   code_records.append({'id':'D%03d'%(len(code_records)+1),'file':path,'symbol':n.name,'line':n.lineno,'end_line':n.end_lineno,'runtime_reachable':n.name not in {'execute_candidate','execute_turn'},'classification':'WIRE_INPUT_ONLY_NOT_FINAL_PROMPT' if n.name in {'execute_candidate','execute_turn'} else 'DYNAMIC_INSTRUCTION_BUILDER','caller':'PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder','downstream':'_materialize_production_codex_prompt -> ProviderRequestEnvelope','stage':'see complete conditional branches in source','dynamic':True,'dynamic_variables':'function signature and all conditional source branches reproduced verbatim','skills':'exact selected Pack Skill, one per stage','context':'task-scoped authorized projection','memory':'accepted Context; Agent observations only in agent_session','historical_review':'stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths','logs':'conditional inherited nested artifact; no filesystem log scanning','other_prompts':'this builder composes or contributes to System/Skill/Task/Schema','enters_llm':n.name not in {'execute_candidate','execute_turn'},'source':'\n'.join(lines[n.lineno-1:n.end_lineno])})
stages=['memo','draft','review','revision','rereview','canon_extraction','canon_support','quality_structural','quality_commercial','quality_source_originality','quality_longform','quality_platform','retrieval','retrieval_query_expansion','context_compress','context_fidelity','agent_session','narrative_semantic_evaluation','longform_prose_review','reader_outcome','screenplay_generate','screenplay_review','screenplay_revision',*FOUNDATION_GENERATORS,'book_plan.generate','volume_plan.generate','arc_plan.generate','chapter_group_plan.generate','chapter_plan.generate','world_candidates.generate','world_candidates.evaluate','world_candidates.actor_0','world_candidates.actor_1','world_candidates.actor_2']
contracts=[]
for stage in stages:
 for version,f in [('compact_v3_v4_v5',_stage_semantic_contract_v3),('legacy_or_domain',_stage_semantic_contract)]:
  try:result=f(stage,required_language='zh-CN',embedding_output_contract={'embedding_dimensions':3,'embedding_model':'DYNAMIC_MODEL','embedding_provider':'DYNAMIC_PROVIDER','embedding_projection_version':'DYNAMIC_VERSION'})
  except Exception as e:result='DYNAMIC_ARGUMENT_REQUIRED: '+str(e)+'; full builder above preserves exact branch.'
  contracts.append({'id':'C%03d'%(len(contracts)+1),'stage':stage,'variant':version,'symbol':f.__name__,'file':'src/novel_forge/modules/chapter_authority/execution_gateway.py','text':result,'metrics':metrics(result)})
schemas={}
for stage in stages:
 try:schemas[stage]=chapter_provider_output_schema(stage)
 except Exception:pass
schemas['targeted_revision']=chapter_provider_output_schema('revision',targeted_revision=True)
schemas['legacy_draft']=chapter_provider_output_schema('draft',legacy_contract=True)
dump('emitted-semantic-contracts.json',contracts);dump('output-schemas.json',schemas);dump('dynamic-builder-inventory.json',code_records)
out=['# Complete Dynamic Instructions and Construction\n','This attachment is part of the Prompt Inventory. C entries are evaluated pure string builders; D entries preserve complete original construction, including every branch and dynamic variable. NO Provider invocation. Wire-only DomainExecutionCommand labels are not counted as final prompts.\n']
for c in contracts:out+=['## '+c['id']+' '+c['stage']+' / '+c['variant']+'\n','Symbol: '+c['symbol']+'; calls follow the frozen template version. Dynamic language=zh-CN for this emitted variant.\n','````text\n'+c['text']+'\n````\n']
for d in code_records:out+=['## '+d['id']+' '+d['symbol']+'\n','```json\n'+json.dumps({k:v for k,v in d.items() if k!='source'},ensure_ascii=False,indent=2)+'\n```\n','完整构造原文：\n````python\n'+d['source']+'\n````\n']
out+=['# Output Schemas\n','```json\n'+json.dumps(schemas,ensure_ascii=False,indent=2)+'\n```\n']
(BASE/'03-dynamic-instructions.md').write_text('\n'.join(out))
# Pure witness through the real Context builder: no hand-authored PASS receipt.
common={'project_id':'audit-project','book_id':'audit-book','estimated_tokens':100,'content_digest':'sha256:'+'1'*64,'policy_version':'audit-source.v1','relevance_score':1.0,'provenance':{'source':'SYNTHETIC_AUDIT_ONLY'},'accepted_boundary':{'accepted_through_chapter':1},'context_class':'RETRIEVABLE','compression_method':'none'}
plan_candidate=ContextCandidate(asset_version_id='audit-plan',asset_type='chapter_plan',safe_summary='本章目标：角色面对旧承诺。',structured_facts=(),**common)
private_fact={'key':'accepted_quality_observations','value':'AUDIT_PRIVATE_REVIEW_MARKER','provider_visibility':'INTERNAL_QUALITY_ONLY'}
history_text=canonical({'text':'AUDIT_ACCEPTED_PROSE_MARKER','provider_evidence':{'trace_id':'AUDIT_TRACE_MARKER','input_tokens':10,'prompt_version':'AUDIT_OLD_PROMPT_VERSION'},'selected_review':{'issues':[{'revision_goal':'AUDIT_OLD_REVIEW_INSTRUCTION','preserve':['AUDIT_OLD_PRESERVE']}],'provider_evidence':{'model_id':'AUDIT_REVIEW_MODEL'}},'candidate_comparison':{'stop_reason':'AUDIT_COMPARISON_MARKER'}})
history_candidate=ContextCandidate(asset_version_id='audit-history',asset_type='narrative_retrieval_document',safe_summary=history_text,structured_facts=(private_fact,),physical_asset_type='best_draft_candidate',**common)
from novel_forge.modules.context_builder.task_compression import compile_task_context,_units
compiled,task_receipt=compile_task_context([plan_candidate,history_candidate],task={'stage':'draft','accepted_boundary':{'accepted_through_chapter':1},'plan':{}},token_budget=16000,required_asset_types=('chapter_plan',))
dump('synthetic-task-context-evidence.json',{'receipt':task_receipt,'retained_private_fact':any(f.get('provider_visibility')=='INTERNAL_QUALITY_ONLY' for c in compiled for f in c.structured_facts),'review_required_units':[u for u in _units(history_candidate,{'stage':'draft'}) if 'review' in u['unit_id'] or 'comparison' in u['unit_id']],'provider_calls':0})
bundle=build_authority_context_bundle(project_id='audit-project',book_id='audit-book',stage='draft',created_by_operation_id='audit-assembly-only',context_profile_version='draft-context-profile-v4',candidates=compiled,task_context_receipt=task_receipt,token_budget=16000,narrative_position={'book_id':'audit-book','chapter':2},target_capability_id='prose.chapter.draft',authority_state_boundary={'accepted_through_chapter':1})
inputs={'plan':{'chapter':2,'chapter_objective':'角色面对旧承诺。','scene_sequence':['audit-scene'],'scene_plan':[{'scene_id':'audit-scene','participants':['audit-actor'],'goal':'作出当前决定。'}]},'style':{'narrator':'limited','language':'zh-CN'},'chapter_memo':{'creative_guidance':{'focus':'AUDIT_MEMO_GUIDANCE'},'scene_directives':[]},'realization_contract':{'contract_version':'scene-realization-composition.v2','slots':[{'slot_id':'audit-slot','scene_id':'audit-scene','capability':'SKELETON','character_ids':['audit-actor'],'accessible_knowledge':[]}]}}
def art(kind,ref,version):
 matches=[a for a in all_artifacts.values() if a['kind']==kind and a['ref']==ref and a['version']==version]
 return matches[0]
system=art('PROMPT_SYSTEM_INSTRUCTION','prompt-system:chapter-generation-pack','v2')
template=art('PROMPT_TEMPLATE','prompt-template:chapter-generation-pack','v5')
skill=art('SKILL','prose-generation','prose-generation-v3')
knowledge=art('KNOWLEDGE','knowledge:chapter-causal-cost:v2','v2')
materialization={'pack_artifacts':{'system_instruction':system,'prompt_template':template,'skill':skill},'context_selection':[{'asset_version_id':'audit-context','content':bundle}], 'knowledge_selection':[knowledge], 'tool_permissions':{'allowed':['model.provider.invoke']},'output_schema':{'ref':chapter_provider_output_schema_ref('draft'),'content':chapter_provider_output_schema('draft')}}
prompt,evidence=_materialize_production_codex_prompt(target_scope=TargetScope(scope_kind='chapter',scope_id='audit-chapter',project_id='audit-project',book_id='audit-book',chapter_number=2).to_dict(),stage='draft',inputs=inputs,materialization=materialization)
(BASE/'synthetic-effective-writer-context.txt').write_text(prompt)
dump('synthetic-assembly-evidence.json',{'kind':'PURE_FUNCTION_ASSEMBLY_NOT_A_REAL_BOOK_RUN','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'receipt':bundle['context_correctness'],'replay':replay_context_bundle(bundle),'evidence':evidence,'markers_reach_final_prompt':{marker:marker in prompt for marker in ['AUDIT_PRIVATE_REVIEW_MARKER','AUDIT_OLD_REVIEW_INSTRUCTION','AUDIT_TRACE_MARKER','AUDIT_OLD_PROMPT_VERSION','AUDIT_COMPARISON_MARKER']},'provider_calls':0,'database_connections':0})
# Static effective prompt: exact fixed text, explicitly unresolved runtime placeholders.
schema=chapter_provider_output_schema('draft')
static_template=read('config/capability_packs/artifacts/chapter_generation_template_v5.md').replace('{{stage}}','draft').replace('{{input_manifest}}','${CANONICAL_PROVIDER_TASK_VIEW}').replace('{{context_bundle}}','${CANONICAL_PROVIDER_CONTEXT_VIEW}')
static='\n\n'.join(['<system_instruction>\n'+system['content']['text']+'\n</system_instruction>','<governed_skill>\n'+_project_prose_skill(skill['content']['text'],stage='draft',targeted=False)+'\n</governed_skill>','<required_knowledge>\n'+canonical(build_provider_knowledge_view([knowledge]))+'\n</required_knowledge>','<prompt_template>\n'+static_template+'\n</prompt_template>','<stage_semantic_contract>\n'+_stage_semantic_contract_v3('draft',required_language='zh-CN')+'\n</stage_semantic_contract>','<output_schema>\n'+canonical(schema)+'\n</output_schema>'])
(BASE/'05-static-effective-writer-context.txt').write_text(static)
components={'system':system['content']['text'],'projected_skill':_project_prose_skill(skill['content']['text'],stage='draft',targeted=False),'required_knowledge':canonical(build_provider_knowledge_view([knowledge])),'template_fixed':read('config/capability_packs/artifacts/chapter_generation_template_v5.md').replace('{{stage}}','draft').replace('{{input_manifest}}','').replace('{{context_bundle}}',''),'semantic_contract_zhCN':_stage_semantic_contract_v3('draft',required_language='zh-CN'),'schema':canonical(schema)}
dump('composition-metrics.json',{'method':'exact characters and UTF-8 bytes; bytes are the repository conservative admission upper bound, not tokenizer counts. No actual dynamic story ratio was measured.','static_components':{k:metrics(v) for k,v in components.items()},'static_total_without_xml_wrappers':metrics(''.join(components.values())),'synthetic_provider_view':evidence['provider_view'],'source_file_metrics':{p:metrics(read(p)) for p in used_paths if (ROOT/p).exists()},'planning_system':metrics(read('config/capability_packs/artifacts/story_planning_system_instruction.md'))})
# Original history evidence, scoped to reachable instruction builders.
paths=['skills/prose-generation/SKILL.md','skills/quality-review/SKILL.md','skills/long-outline/SKILL.md','skills/hot-novel-business-deconstruction/SKILL.md','config/capability_packs/artifacts/chapter_generation_system_instruction.md','config/capability_packs/artifacts/story_planning_system_instruction.md','src/novel_forge/modules/capability_packs/screenplay_profiles.py','src/novel_forge/modules/chapter_authority/provider_views.py','src/novel_forge/storage/book_authority_repositories.py']
history={p:subprocess.check_output(['git','log','-12','--format=%H %cI %s','--',p],cwd=ROOT).decode() for p in paths}
dump('history-index.json',history)
print(json.dumps({'tracked_files':len(tracked),'candidate_files':len(scan),'skill_files':len(skills),'artifact_prompt_records':len(prompts),'emitted_contracts':len(contracts),'dynamic_builders':len(code_records),'pure_markers':{m:m in prompt for m in ['AUDIT_PRIVATE_REVIEW_MARKER','AUDIT_OLD_REVIEW_INSTRUCTION','AUDIT_TRACE_MARKER']},'correctness':bundle['context_correctness']['overall_status'],'replay':replay_context_bundle(bundle)['status'],'static_metrics':{k:len(v) for k,v in components.items()}},ensure_ascii=False,indent=2))
