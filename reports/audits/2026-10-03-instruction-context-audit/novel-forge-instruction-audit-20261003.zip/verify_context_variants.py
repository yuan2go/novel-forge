from pathlib import Path
import json,hashlib
from novel_forge.modules.context_contracts import ContextCandidate
from novel_forge.modules.context_builder.domain import build_authority_context_bundle,replay_context_bundle
from novel_forge.modules.context_builder.task_compression import compile_task_context
from novel_forge.modules.context_builder.production_retrieval import _selected_document
from novel_forge.modules.chapter_authority.provider_views import project_retrieved_state_context
from novel_forge.modules.chapter_authority.execution_gateway import _materialize_production_codex_prompt
from novel_forge.modules.chapter_authority.provider_output_contracts import chapter_provider_output_schema,chapter_provider_output_schema_ref
from novel_forge.modules.production_execution.contracts import TargetScope
BASE=Path('/Users/yuan/Documents/Codex/audits/novel-forge-instructions-20261003')
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(v):return 'sha256:'+hashlib.sha256(v.encode()).hexdigest()
artifacts=json.loads((BASE/'resolved-artifact-catalog.json').read_text())
def a(kind,ref,version):return next(x for x in artifacts if x['kind']==kind and x['ref']==ref and x['version']==version)
common={'project_id':'audit-project','book_id':'audit-book','estimated_tokens':200,'policy_version':'audit-source.v1','relevance_score':1,'provenance':{'source':'SYNTHETIC_READ_ONLY_AUDIT'},'accepted_boundary':{'accepted_through_chapter':1},'context_class':'RETRIEVABLE','compression_method':'none'}
plan=ContextCandidate(asset_version_id='audit-plan',asset_type='chapter_plan',safe_summary='Current scene objective',structured_facts=(),content_digest=sha('Current scene objective'),**common)
accepted=canon({'text':'AUDIT_ACCEPTED_PROSE_MARKER','provider_evidence':{'trace_id':'AUDIT_TRACE_MARKER'},'selected_review':{'issues':[{'revision_goal':'AUDIT_OLD_REVIEW_INSTRUCTION'}]},'candidate_comparison':{'stop_reason':'AUDIT_COMPARISON_MARKER'}})
fact={'key':'quality_metadata','value':'AUDIT_PRIVATE_REVIEW_MARKER','provider_visibility':'INTERNAL_QUALITY_ONLY'}
history=ContextCandidate(asset_version_id='audit-history',asset_type='narrative_retrieval_document',physical_asset_type='best_draft_candidate',safe_summary=accepted,structured_facts=(fact,),content_digest=sha(accepted),**common)
projected=project_retrieved_state_context({'safe_summary':accepted,'structured_facts':[fact]},projection={},chapter=2)
results={'evidence_kind':'SYNTHETIC_PURE_FUNCTIONS_NOT_PRODUCTION_RUN','private_fact_producer_in_real_book_unknown':True,'project_retrieved_nonstate_keeps_summary_and_private_fact':projected=={'safe_summary':accepted,'structured_facts':[fact]},'profiles':{}}
for version in ['v2','v3','v4']:
 candidates=[plan,history];receipt=None
 if version=='v4':candidates,receipt=compile_task_context(candidates,task={'stage':'draft','accepted_boundary':{'accepted_through_chapter':1},'plan':{}},token_budget=6000,required_asset_types=('chapter_plan',))
 bundle=build_authority_context_bundle(project_id='audit-project',book_id='audit-book',stage='draft',created_by_operation_id='audit-only',context_profile_version='draft-context-profile-'+version,candidates=candidates,token_budget=6000,narrative_position={'book_id':'audit-book','chapter':2},target_capability_id='prose.chapter.draft',authority_state_boundary={'accepted_through_chapter':1},task_context_receipt=receipt)
 materialization={'pack_artifacts':{'system_instruction':a('PROMPT_SYSTEM_INSTRUCTION','prompt-system:chapter-generation-pack','v2'),'prompt_template':a('PROMPT_TEMPLATE','prompt-template:chapter-generation-pack','v5'),'skill':a('SKILL','prose-generation','prose-generation-v3')},'context_selection':[{'asset_version_id':'audit-context','content':bundle}],'knowledge_selection':[a('KNOWLEDGE','knowledge:chapter-causal-cost:v2','v2')],'tool_permissions':{'allowed':['model.provider.invoke']},'output_schema':{'ref':chapter_provider_output_schema_ref('draft'),'content':chapter_provider_output_schema('draft')}}
 prompt,evidence=_materialize_production_codex_prompt(target_scope=TargetScope(scope_kind='chapter',scope_id='audit-chapter',project_id='audit-project',book_id='audit-book',chapter_number=2).to_dict(),stage='draft',inputs={'plan':{'chapter':2,'chapter_objective':'AUDIT_OBJECTIVE'},'style':{'language':'zh-CN'},'chapter_memo':{'creative_guidance':{},'scene_directives':[]},'realization_contract':{'slots':[{'slot_id':'audit-slot'}]}},materialization=materialization)
 results['profiles'][version]={'correctness':bundle['context_correctness']['overall_status'],'replay':replay_context_bundle(bundle)['status'],'private_marker_in_prompt':'AUDIT_PRIVATE_REVIEW_MARKER' in prompt,'old_review_in_prompt':'AUDIT_OLD_REVIEW_INSTRUCTION' in prompt,'provider_metadata_in_prompt':'AUDIT_TRACE_MARKER' in prompt,'provider_prompt_hash':sha(prompt)}
# A bounded JSON extract can spend its entire allowance on metadata preceding reader-facing prose.
long=canon({'candidate_comparison':{'comparison_evidence':['AUDIT_TECHNICAL_EVIDENCE_'+str(i) for i in range(300)]},'provider_evidence':{'trace_id':'AUDIT_TRACE_MARKER'},'scene_artifacts':[{'slot_id':'s','text':'AUDIT_READER_PROSE_MARKER'+'x'*8000}],'selected_review':{'issues':[{'revision_goal':'AUDIT_OLD_REVIEW_INSTRUCTION'}]},'text':'AUDIT_CHAPTER_TEXT_MARKER'+'x'*8000})
item={'content_text':long,'source_asset_version_id':'audit-long','source_content_hash':sha(long),'projection_hash':sha(long)}
bounded=_selected_document(item,preserve_text=False);full=_selected_document(item,preserve_text=True)
try:json.loads(bounded['safe_summary']);is_json=True
except ValueError:is_json=False
results['L0_bounded_extract']={'input_characters':len(long),'bounded_characters':len(bounded['safe_summary']),'method':bounded['compression_method'],'extract_is_complete_json':is_json,'scene_prose_present':'AUDIT_READER_PROSE_MARKER' in bounded['safe_summary'],'chapter_prose_present':'AUDIT_CHAPTER_TEXT_MARKER' in bounded['safe_summary'],'has_technical_evidence':'AUDIT_TECHNICAL_EVIDENCE' in bounded['safe_summary'],'full_preserves_all':full['safe_summary']==long,'interpretation':'EXISTENCE_WITNESS_NOT_MEASUREMENT_OF_REAL_METADATA_SIZE'}
results.update(provider_calls=0,database_connections=0)
(BASE/'synthetic-context-variant-evidence.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
