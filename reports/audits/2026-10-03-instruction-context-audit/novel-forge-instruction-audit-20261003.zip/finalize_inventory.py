from pathlib import Path
import ast,json,hashlib
from novel_forge.modules.chapter_authority.execution_gateway import _stage_semantic_contract,_stage_semantic_contract_v3
BASE=Path('/Users/yuan/Documents/Codex/audits/novel-forge-instructions-20261003');ROOT=BASE/'snapshot'
modules=['src/novel_forge/modules/chapter_authority/chapter_plan_views.py','src/novel_forge/modules/chapter_authority/context_compression_provider.py','src/novel_forge/modules/chapter_authority/creative_memo.py','src/novel_forge/modules/story_design_authority/author_input.py','src/novel_forge/modules/source_import/corpus_ingestion/narrative_contracts.py','src/novel_forge/modules/source_import/execution_contracts.py','src/novel_forge/modules/source_import/craft_discovery.py']
index=json.loads((BASE/'instruction-source-index.json').read_text())
with (BASE/'06-instruction-source-corpus.md').open('a') as out:
 for p in modules:
  text=(ROOT/p).read_text();index.append({'file':p,'line':1,'end_line':len(text.splitlines()),'sha256':hashlib.sha256(text.encode()).hexdigest(),'scope':'COMPLETE_MODULE_NO_RUNTIME_DATA'});out.write('\n## '+p+'\n\n````python\n'+text+'\n````\n')
 p='src/novel_forge/modules/source_import/execution.py';text=(ROOT/p).read_text();lines=text.splitlines()
 for n in ast.walk(ast.parse(text)):
  if isinstance(n,ast.FunctionDef) and n.name in {'execute_classification','execute_deconstruction','execute_mkaos_extraction'}:
   fragment='\n'.join(lines[n.lineno-1:n.end_lineno]);index.append({'file':p,'symbol':n.name,'line':n.lineno,'end_line':n.end_lineno,'scope':'EXACT_FUNCTION_OR_CONSTANT'});out.write('\n## '+p+':'+str(n.lineno)+' '+n.name+'\n\n````python\n'+fragment+'\n````\n')
(BASE/'instruction-source-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
contracts=json.loads((BASE/'emitted-semantic-contracts.json').read_text())
for c in contracts:
 if c['stage']=='retrieval':
  fn=_stage_semantic_contract_v3 if c['variant']=='compact_v3_v4_v5' else _stage_semantic_contract
  text=fn('retrieval',required_language='zh-CN',embedding_output_contract={'embedding_dimensions':3,'embedding_model':'${FROZEN_EMBEDDING_MODEL}','vector_normalization':'L2_UNIT','placeholder_vectors_allowed':False})
  c['text']=text;c['dynamic']='Exact model identity and dimensions remain frozen runtime variables; 3 is a synthetic demonstration only.'
(BASE/'emitted-semantic-contracts.json').write_text(json.dumps(contracts,ensure_ascii=False,indent=2)+'\n')
d=json.loads((BASE/'dynamic-builder-inventory.json').read_text());schemas=json.loads((BASE/'output-schemas.json').read_text())
out=['# Complete Dynamic Instructions and Construction\n','C entries are evaluated code-built instructions. Language zh-CN is conditional on governed language evidence. D entries preserve full original construction. Additional helper constants and complete source branches: 06-instruction-source-corpus.md. NO Provider invocation. Wire-only labels are excluded from final prompts.\n']
for c in contracts:out+=['## '+c['id']+' '+c['stage']+' / '+c['variant']+'\n','Symbol: '+c['symbol']+'; final selected variant follows frozen template version.\n','````text\n'+c['text']+'\n````\n']
for x in d:out+=['## '+x['id']+' '+x['symbol']+'\n','```json\n'+json.dumps({k:v for k,v in x.items() if k!='source'},ensure_ascii=False,indent=2)+'\n```\n','完整构造原文：\n````python\n'+x['source']+'\n````\n']
out+=['# Output Schemas\n','```json\n'+json.dumps(schemas,ensure_ascii=False,indent=2)+'\n```\n']
(BASE/'03-dynamic-instructions.md').write_text('\n'.join(out))
# Discovery inventory for non-root Coding Agent rules. Their presence does not cause LLM injection.
tracked=json.loads((BASE/'repository-search-inventory.json').read_text());tracked['coding_instruction_rule_files']=[p for p in __import__('subprocess').check_output(['git','ls-files'],cwd=ROOT).decode().splitlines() if Path(p).name in {'AGENTS.md','CLAUDE.md','SKILL.md'} and not p.startswith('skills/')]
(BASE/'repository-search-inventory.json').write_text(json.dumps(tracked,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_exports':len(index),'coding_rule_files':len(tracked['coding_instruction_rule_files']),'dynamic_contract_failures':[c['id'] for c in contracts if c['text'].startswith('DYNAMIC_ARGUMENT_REQUIRED')]}))
