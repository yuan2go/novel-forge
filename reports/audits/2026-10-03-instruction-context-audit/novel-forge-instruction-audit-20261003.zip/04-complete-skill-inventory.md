# Complete Skill Inventory — frozen main

ACTIVE = current default code binding; live DB activation UNKNOWN. CONDITIONAL = admitted phase needed. LEGACY = exact historical catalog only. UNREACHABLE = no formal production or governed source-analysis text consumer found. Source analysis Skills are included to prevent confusing indirect reusable assets with direct Writer instructions.

## S001 skills/agent-loop-governance/SKILL.md

```json
{
  "id": "S001",
  "name": "agent-loop-governance",
  "file": "skills/agent-loop-governance/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "agent_session"
  ],
  "versions": [
    {
      "ref": "agent-loop-governance",
      "version": "agent-loop-governance-v1",
      "hash": "sha256:caf8f32bda87c6e48b3c4514133646de94c714a3222e0c86193ba7517b564fcc"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 5005,
    "utf8_bytes": 5005,
    "utf8_byte_token_upper_bound": 5005,
    "legacy_bytes_div3_estimate": 1669,
    "negative_markers": 3,
    "mandatory_markers": 2
  },
  "sha256": "sha256:d35583efb62fb6b7cca223af3e7506a991a0d51690323ee4cf4f847a1452436b"
}
```

完整原文：
````markdown
---
name: agent-loop-governance
description: Use when governing bounded Agent Runtime execution through AgentRun operations, sessions, budgets, checkpoints, gates, retries, dead letters, and owner-approved domain submission.
---

# Agent Runtime Loop Governance

## Purpose

- Turn one bounded Agent task into an auditable AgentRun and, when a model/tool dialogue
  is required, an Agent Session bound to a Command Kernel Operation.
- Review scheduler, checkpoint, gate, budget, retry, dead-letter and recovery behavior.
- Preserve the distinction between Agent execution evidence and domain Authority state.

## Input contract

- Project/workspace scope, Principal and requested Agent definition/version.
- Frozen operation definition, runtime binding, Capability Pack, ContextBundle and Tool
  policy identities.
- Token/cost/time limits, checkpoint/gate policy, retry ceiling and stop conditions.
- Current Operation, Attempt, Lease, Fence, ExternalEffect, session and transcript
  evidence when resuming or diagnosing.

Reject cross-project inputs, floating versions, missing execution mappings and any task
whose requested domain mutation has no owning Authority command.

## Allowed context

- Current project-scoped ContextBundle and accepted Canon/Narrative State evidence.
- Frozen Agent definition, Capability Pack, prompt/Skill hashes and runtime policy.
- Relevant ReviewIssue, gate, budget, trace, audit and recovery evidence.
- No raw source document or ungoverned chat memory as domain truth.

## Authority boundary

- Agent Runtime owns definitions, activations, runtime bindings, AgentRun projection,
  sessions, transcripts and dispatch evidence.
- Command Kernel owns Operation, Attempt, Lease, Fence and ExternalEffect lifecycle.
- The Agent may submit a candidate or typed command only. Story Design, Planning, Plan
  Change, Book, Chapter, Quality and Canon Authorities retain their decisions.
- A repository or coordinator cannot convert Agent output into accepted narrative truth.

## Procedure

1. Resolve the production entry, Agent definition, capability execution mapping and
   frozen instruction/context identities.
2. Admit one bounded AgentRun Operation and record its task, budgets, stop conditions and
   expected output contract.
3. Let the Agent scheduler claim the current Attempt under lease and fence; create or
   resume the bound Agent Session when the operation uses the harness.
4. Route model/tool I/O through Production Execution and durable ExternalEffect intent.
5. Append transcript, cost/usage, checkpoint and gate evidence; never overwrite a
   terminal Attempt or session event.
6. Submit resulting candidates or commands to their owning domain Authority and retain
   its acceptance/rejection evidence.
7. On retry, create a new Attempt under the declared ceiling. On ambiguous effect or
   commit outcome, stop and reconcile before dispatch. On exhaustion, dead-letter with a
   recovery instruction.

## Output contract

Return a schema-backed governance record containing:

- AgentRun/Operation and optional Agent Session identities;
- Agent definition, runtime binding, Capability Pack, prompt/Skill and ContextBundle
  identities;
- task scope, budgets, stop condition and current status;
- Attempt/Lease/Fence, ExternalEffect, checkpoint, transcript and gate references;
- domain submission and owner decision references, if any;
- retry, dead-letter or reconciliation instruction on failure;
- `trace_id`, correlation/causation identity, validation status and evidence paths.

## Quality criteria

- Every execution step is traceable to the same frozen project-scoped contract.
- Budget, permission, Provider and Tool limits fail closed.
- Agent completion is not reported as domain acceptance without owner evidence.
- Retry/recovery appends new versioned facts and ambiguous effects are never blindly
  resent.
- Fixture, scripted Provider, credentialed Provider and production proof remain distinct.

## Failure semantics

- Missing/stale binding, context, instruction identity, budget or permission: reject
  admission or hard-stop the active Attempt.
- Lost lease or stale fence: reject completion and let the scheduler reacquire according
  to policy.
- Ambiguous external outcome: enter reconciliation; do not redispatch.
- Blocking owner gate or human decision: checkpoint as waiting evidence, not success.
- Exhausted retry ceiling: dead-letter with a durable recovery instruction.

## Required evidence

- `AgentRuntimeAuthorityApplication` and `AgentAuthorityScheduler` result.
- Operation/Attempt/Lease/Fence and ExternalEffect/receipt records.
- Agent runtime binding, session/transcript and Capability Pack materialization records.
- ContextBundle, prompt/Skill identity, model usage/cost and Tool-call evidence.
- Owning domain Authority result and gate decision for every submitted mutation.

## Related Skills

- `context-builder-source-isolation`
- `provider-runtime-policy`
- `review-issue-gate`
- `novel-os-engineering-audit`

````

## S002 skills/analysis-to-asset-conversion/SKILL.md

```json
{
  "id": "S002",
  "name": "analysis-to-asset-conversion",
  "file": "skills/analysis-to-asset-conversion/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 1878,
    "utf8_bytes": 2320,
    "utf8_byte_token_upper_bound": 2320,
    "legacy_bytes_div3_estimate": 774,
    "negative_markers": 6,
    "mandatory_markers": 5
  },
  "sha256": "sha256:831a6b877cd6dba22b98f86d211a80c3c6f6ac4923903e78729ac5b8016c7883"
}
```

完整原文：
````markdown
---
name: analysis-to-asset-conversion
description: Convert abstract analysis reports into schema-backed reusable creative assets with explicit copyright boundary, reuse scope, and rejected high-risk items.
---

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

用于把分析报告转换成可生产使用的抽象资产，如素材卡、知识卡、写作模板、技法模板和审稿规则包。

## 输入要求

- schema-backed analysis report path.
- requested conversion targets.
- project workspace path when available.
- source risk and allowed pipeline.

## 操作流程

1. Read the analysis report by path.
2. Reject any item that depends on protected expression, names, settings, or event sequence.
3. Convert safe mechanisms into schema-backed creative assets.
4. Write `analysis_conversion_report` under `data/analysis`.
5. Record created assets, rejected items, reuse scope, copyright risk, and validation status.

## 输出格式

Write one JSON asset with type `analysis_conversion_report` under `data/analysis`, plus any created creative assets in their mapped data directories.

## 质量标准

- All outputs pass schema validation.
- Created assets declare abstract copyright boundary.
- High copyright risk material is rejected or marked for human gate.
- Source report itself is not inserted into generation RAG.

## 禁止事项

- Do not copy protected text.
- Do not create draft prose.
- Do not hide rejected high-risk items.
- Do not bypass schema validation.

## 与其他模块的关系

Converted assets can feed topic, material, knowledge, template, context, and review workflows after project review.

````

## S003 skills/anti-copy-abstraction/SKILL.md

```json
{
  "id": "S003",
  "name": "anti-copy-abstraction",
  "file": "skills/anti-copy-abstraction/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "source.mkaos.extract"
  ],
  "versions": [
    {
      "ref": "anti-copy-abstraction",
      "version": "1.0.0",
      "hash": "sha256:574222188fe361af4530d1b50b3ab71cd00dfe788c852e05419fc9ccc7893515",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2291,
    "utf8_bytes": 3971,
    "utf8_byte_token_upper_bound": 3971,
    "legacy_bytes_div3_estimate": 1324,
    "negative_markers": 11,
    "mandatory_markers": 13
  },
  "sha256": "sha256:574222188fe361af4530d1b50b3ab71cd00dfe788c852e05419fc9ccc7893515"
}
```

完整原文：
````markdown
---
name: anti-copy-abstraction
description: Use when converting concrete reference-work analysis into reusable abstract mechanisms, writing principles, and review checks that cannot be used to reconstruct or imitate a protected work.
---

# Anti Copy Abstraction

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 热门小说拆解后，进入题材、世界观、人物、大纲或正文前。
- 拆解报告包含具体桥段、人物关系、独特反转或世界设定风险。
- 审稿时怀疑产物过度接近已有作品。

## 输入要求

- 拆解报告、来源标识、可复用点和禁止复用点。
- 任何具体剧情、台词、人物组合和独特设定都必须标记为高风险。
- 不接受无来源的“爆款套路”直接进入生成链路。
- 正式输入必须是已提交的 Observation AssetVersion，并保留其 EvidenceSpan lineage；不得将 raw SourceChunk 内容重新复制进抽象 Prompt。

## Observation 到 Candidate 合同

- `Observation` 只说明来源中观察到什么，`Knowledge Candidate` 才说明经过抽象后可复用什么；两者不得共用一个资产或状态。
- 一个 Observation 可以在不同 abstraction policy / schema / prompt / model 版本下产生多个 Candidate；旧 Candidate 必须保留并可被 rejected、superseded 或 deprecated。
- Candidate 只允许保存跨作品成立的因果机制、约束、冲突生成器和审稿检查，不得保存可复原单一作品的角色组合、事件序列、专有名词或表达。
- Candidate 必须引用 Observation AssetVersion；正式 API 不接受只有 SourceChunk 的 Candidate。

## 操作流程

1. 将输入分成表达、剧情、设定、结构、机制和读者效果。
2. 删除或标记表达、具体剧情、独特设定和可识别人物组合。
3. 保留结构、机制和读者效果。
4. 将具体桥段改写为类型无关的因果机制。
5. 为每条原则补适用范围、禁用范围和审稿检查项。
6. 输出 schema-backed Knowledge Candidate，进入 Validation、Source Isolation、Originality Gate 与人工 Approval；未批准前不得成为 KnowledgeCard。

## 输出格式

```markdown
# 反抄袭抽象报告

## 输入来源
## 高风险具体内容
## 删除或禁用内容
## 抽象机制
## 可复用创作原则
## 适用题材
## 审稿检查项
## 原创风险等级
## 是否允许进入下游
```

## 质量标准

- 输出不能让创作者复原原作品的具体桥段。
- 每条抽象原则必须脱离单一作品语境也能成立。
- 必须明确哪些内容不能进入 prompt、正文、素材库和生成输出。
- 必须能被 `quality-review` 用作原创风险检查依据。
- 必须声明 abstraction policy version、input Observation versions、confidence、copyright boundary 和所有 rejected mechanisms。

## 禁止事项

- 禁止保留可识别人物组合。
- 禁止保留独特反转和具体案件结构。
- 禁止用“致敬”“参考风格”规避版权边界。
- 禁止将拆解结果直接交给 `prose-generation`。

## 与其他模块的关系

- 上游：`hot-novel-deconstruction`、`data/decompositions/`。
- 下游：`data/knowledge/`、`data/materials/`、`quality-review`。
- Agent：Knowledge Agent、Review Agent、Quality Agent。

````

## S004 skills/canon-continuity-graph/SKILL.md

```json
{
  "id": "S004",
  "name": "canon-continuity-graph",
  "file": "skills/canon-continuity-graph/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "ACTIVE",
  "stage": [
    "canon_extraction",
    "canon_support"
  ],
  "versions": [
    {
      "ref": "canon-continuity-graph",
      "version": "canon-continuity-graph-v2",
      "hash": "sha256:72cc55db18b93ddd7fefb2d99dbe02f04204fc2c2323bb166c8bb7f186f790f8"
    },
    {
      "ref": "canon-continuity-graph",
      "version": "canon-continuity-graph-qualification-v1",
      "hash": "sha256:72cc55db18b93ddd7fefb2d99dbe02f04204fc2c2323bb166c8bb7f186f790f8"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 977,
    "utf8_bytes": 977,
    "utf8_byte_token_upper_bound": 977,
    "legacy_bytes_div3_estimate": 326,
    "negative_markers": 1,
    "mandatory_markers": 0
  },
  "sha256": "sha256:a5b946be2a78e72d68c830ef8f14670f0ba8df82f8451c4af85e17bcc47a4296"
}
```

完整原文：
````markdown
---
name: canon-continuity-graph
description: Extract or assess candidate narrative facts against accepted state.
---

# Canon and Continuity

Extract only events and state changes supported by the exact final candidate prose. Quote the supporting words; the host locates spans and binds the candidate version. A literal match alone does not establish a fact, so distinguish observed events from dialogue, belief, hearsay, plans, and reader disclosure.

Use the frozen accepted boundary and exact in-scope character, Arc, obligation, and world identities. A character's knowledge and the reader's knowledge are separate from story truth. Preserve accepted history and flag uncertain or contradictory claims rather than repairing them by invention.

The result is a proposal for semantic support and domain validation. Book acceptance alone commits Canon and Narrative State. Return only the declared JSON result; do not self-report persistence, approval, or Provider receipts.

````

## S005 skills/canon-continuity-graph/legacy-v1.md

```json
{
  "id": "S005",
  "name": "canon-continuity-graph",
  "file": "skills/canon-continuity-graph/legacy-v1.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "LEGACY",
  "stage": [
    "canon_extraction",
    "canon_support"
  ],
  "versions": [
    {
      "ref": "canon-continuity-graph",
      "version": "canon-continuity-graph-v1",
      "hash": "sha256:544403d3856c07938f96db9e90ef7333f975daa4c942214235f797b6720c4a38"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 3942,
    "utf8_bytes": 5392,
    "utf8_byte_token_upper_bound": 5392,
    "legacy_bytes_div3_estimate": 1798,
    "negative_markers": 11,
    "mandatory_markers": 11
  },
  "sha256": "sha256:47cc7b18ffb04bd3e754a0f274d0a63b77dac4aca250602dc3e0a642a8114065"
}
```

完整原文：
````markdown
---
name: canon-continuity-graph
description: Use when designing, reviewing, or debugging Canon Graph, as-of continuity, character/world state, deterministic narrative rules, foreshadowing, invalidation, rollback evidence, or continuity gates across long-form production flows.
---

# Canon Continuity Graph

## 适用场景

- 建立或审计 Canon Graph、continuity fact、world rule、character state、arc state、foreshadowing 和 payoff。
- 检查 outline、chapter plan、draft、revision、recap、publish 或 feedback 是否破坏正典。
- 设计 invalidation、impact report、rollback evidence 和 conflict resolution。
- 区分可由已接受结构化状态确定性判断的矛盾，与需要理解动机、OOC 或情绪合理性的 semantic judgment。

## 输入要求

- `project_id`、target asset、flow、canon graph snapshot、continuity facts 和 revision intent。
- CharacterCard、WorldBible、Outline、ChapterPlan、DraftChapter、ReviewIssue、Recap、PublishGateReport。
- evidence refs、trace_id、prior accepted version、candidate version 和 rollback target。
- 需要跨章节判断时，输入必须包含 `TemporalQueryService` 的 as-of 结果和 chapter boundary；不得让 Skill 自行查询数据库。

## Novel OS Runtime Contract

- 被接受的正典事实必须有 asset id、version、source flow、trace_id 和 gate status。
- 任何修改 accepted canon 的动作必须产生 impact report、invalidation scope 和 rollback evidence。
- high / critical canon conflict 必须转成 blocking ReviewIssue 或 human_review gate。
- 不能通过 recap、feedback、revision 或 publish flow 静默改写人物状态、世界规则或伏笔承诺。
- 时态读取必须来自 PostgreSQL Accepted Canon projection；Legacy LocalStorage Canon Query 不能作为生产证据。
- 确定性发现必须进入 `canon.validate` / `continuity.validate` 的结构化报告；高严重度发现进入 ReviewIssue / Gate，不由 Skill 文本直接激活或回滚 Canon。

## Deterministic / Semantic Boundary

以下规则仅在 Authority 已有明确字段和 lineage 时交给 deterministic validator：

- timeline ordering、future-state leakage、invalid state transition；
- character identity、dead-character usage、knowledge boundary、relationship transition；
- promise / foreshadow lifecycle ordering；
- resource balance、world-rule、power-state transition、graph integrity。

人物动机、OOC、情绪可信度、关系变化是否“自然”等需要语义理解的问题交给 provider judge，并保留 evidence spans、qualification、model call 与 cost ledger。Authority 数据不足时输出 `INSUFFICIENT_STATE` 或未实现规则，不得使用关键词、正则或常识 heuristic 假装确定性验证。

## 操作流程

1. 读取目标资产、chapter boundary、accepted canon snapshot 和必要的 as-of temporal query 结果。
2. 抽取候选结构化事实：人物状态、身份、关系、资源、知识、力量、世界规则、时间线、plot thread、伏笔和承诺。
3. 先运行 deterministic rules；每条 finding 记录 rule、当前/前序 evidence、chapter、severity 和 missing-state 状态。
4. 只把动机、OOC、情绪合理性等剩余问题路由到 semantic judge。
5. 对比 accepted canon，标记 MATCH、NEW、UPDATE、CONFLICT、DEPRECATE、NEEDS_DECISION。
6. 为 UPDATE / CONFLICT 生成 impact report、affected assets、ReviewIssue 和 rollback instruction。
7. 计算 continuity gate：continue、revise、block、human_review。
8. 输出 canon continuity report，不直接覆盖 accepted canon。

## 输出格式

```markdown
# Canon Continuity Report

## Scope
- target:
- canon snapshot:
- candidate version:

## Fact Changes
- new:
- updated:
- conflicts:
- deprecated:

## Deterministic Findings
- rule:
- as-of chapter:
- evidence refs:
- missing state:

## Semantic Findings
- judge qualification:
- evidence spans:

## Impact
- affected chapters:
- affected arcs:
- invalidation:
- rollback:

## Gate
- result:
- review issues:
- human decisions:
```

## 质量标准

- 每条事实变化必须可追溯到输入资产和版本。
- deterministic finding 必须可由结构化 accepted state 重放；不得依赖 LLM 或字面模式。
- as-of 查询不得返回目标章节之后的事实，supersession、rollback、missing state 和 project isolation 必须显式。
- 冲突必须说明破坏了哪个已接受事实、影响哪些下游资产。
- rollback instruction 必须足够让后续 Agent 恢复旧状态或创建新版本。

## 禁止事项

- 禁止静默修改 accepted canon。
- 禁止用“作者想改”跳过 impact report。
- 禁止让反馈或发布文案反向覆盖正文正典。
- 禁止把参考作品设定作为 canon fact。
- 禁止把 `SKILL.md` 当作状态查询器、validator implementation 或 Canon Authority。
- 禁止用 semantic judge 重判可确定性计算的 lifecycle、balance、identity 或 ordering 规则。

## 与其他模块的关系

- 上游：WorldBible、CharacterCard、Outline、ChapterPlan、DraftChapter、Recap、FeedbackInsight、`temporal.query`。
- 下游：Context Builder、ReviewIssue Gate、RevisionTask、Publish Gate、Command Kernel。
- 关联 Skill：`longform-temporal-query`、`context-builder-source-isolation`、`review-issue-gate`、`agent-loop-governance`。

````

## S006 skills/chapter-outline/SKILL.md

```json
{
  "id": "S006",
  "name": "chapter-outline",
  "file": "skills/chapter-outline/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "ACTIVE",
  "stage": [
    "arc_plan.generate",
    "book_plan.generate",
    "chapter_group_plan.generate",
    "chapter_plan.generate",
    "memo",
    "volume_plan.generate"
  ],
  "versions": [
    {
      "ref": "chapter-outline",
      "version": "chapter-plan-skill-v2",
      "hash": "sha256:d70ad57ec4d0452e2544e3465c96efe9776e347a39966fdc8834c8e4e27ac61f"
    },
    {
      "ref": "chapter-outline",
      "version": "chapter-outline-qualification-v1",
      "hash": "sha256:d70ad57ec4d0452e2544e3465c96efe9776e347a39966fdc8834c8e4e27ac61f"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1064,
    "utf8_bytes": 1064,
    "utf8_byte_token_upper_bound": 1064,
    "legacy_bytes_div3_estimate": 355,
    "negative_markers": 1,
    "mandatory_markers": 0
  },
  "sha256": "sha256:e23e0e8f3fe0660896496115b2eb86c0fcd54b79b103ca3180870d00b65a29c9"
}
```

完整原文：
````markdown
---
name: chapter-outline
description: Plan chapters or prepare a Chapter Memo from frozen story intent.
---

# Chapter Planning and Memo

For a planning task, propose a concrete chapter function, scene goals, actors, knowledge boundaries, causal sequence, and obligations using the frozen author and accepted-state inputs. Distinguish proposed future events from accepted facts.

For a Memo task, turn the already frozen mission into useful scene and voice guidance. Do not repeat the Plan as an audit report or invent an accepted outcome. A character may observe, hesitate, maintain a position, or make a choice according to this chapter's function. Name a cost only when the action, author direction, arc, or due obligation makes it relevant.

Commercial devices such as reward, reversal, growth, and a hook are methods to consider, not mandatory fields of every scene. Preserve explicit author constraints and promised obligations. Use only source material permitted by the Context boundary. Return the declared JSON result; the host binds versions and state.

````

## S007 skills/chapter-outline/legacy-v1.md

```json
{
  "id": "S007",
  "name": "chapter-outline",
  "file": "skills/chapter-outline/legacy-v1.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "LEGACY",
  "stage": [
    "arc_plan.generate",
    "book_plan.generate",
    "chapter_group_plan.generate",
    "chapter_plan.generate",
    "memo",
    "volume_plan.generate"
  ],
  "versions": [
    {
      "ref": "chapter-outline",
      "version": "chapter-plan-skill-v1",
      "hash": "sha256:6434e396a96a6d29f9a839bdbfade605a57bbc129bfbef350434a2f9911744ed"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2204,
    "utf8_bytes": 3864,
    "utf8_byte_token_upper_bound": 3864,
    "legacy_bytes_div3_estimate": 1288,
    "negative_markers": 9,
    "mandatory_markers": 14
  },
  "sha256": "sha256:fd8d3e02c7cc428eb96037d9d7d8036b59b26252f76388ba7f44e3338fe5bf76"
}
```

完整原文：
````markdown
---
name: chapter-outline
description: Use when creating or reviewing chapter plans so every chapter has a goal, cast, scene list, conflict, information gain, payoff, suspense, reversal, ending hook, and next-chapter handoff.
---

# Chapter Outline

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 将全书大纲或卷纲拆成可写作的章节细纲。
- 正文生成前检查章节是否具备最小商业单元。
- 审稿时发现章节缺冲突、缺爽点、缺钩子，需要退回细纲。
- 章节存在信息跳跃、概念未铺垫、伏笔/payoff 没有 reader grounding 时，配合 `narrative-beat-design` 重排 beat path。

## 输入要求

- Outline、CharacterCard、WorldBible、前文上下文和本章位置。
- 本章必须推进的信息、必须设置或回收的伏笔。
- 禁止事项和原创风险边界。

## 操作流程

1. 明确本章目标和必须完成的剧情功能。
2. 列出出场人物、人物目标、冲突关系和场景。
3. 设计本章冲突、阻力、行动、代价和结果。
4. 定义本章 reader prerequisites 和 grounded set：读者进入本章前已经知道的人物状态、世界规则、伏笔和承诺。
5. 设计 beat path：每个 beat 标注 function、requires、grounds、hook/payoff 和风险。
6. 安排信息增量、爽点、悬念、反转和情绪变化，确保后续 beat 不依赖未 grounded 概念。
7. 设计开头钩子、小钩子、结尾钩子和下一章承接点；标注 hook type、information gap、reader question、promise id、horizon 和证据位置。
8. 检查章节最小商业单元：冲突、推进、奖励、代价、钩子。
9. 输出可交给正文模型执行的细纲。

## 输出格式

```markdown
# 第 N 章细纲

## 本章目标
## 出场人物
## 场景列表
## 本章冲突
## 信息增量
## Reader Grounding
## Beat Path
## 读者爽点
## 悬念与反转
## 代价
## 开头钩子
## 结尾钩子
## Hook Horizon 与 Promise Binding
## 下一章承接点
## 章节最小商业单元检查
```

## 质量标准

- 每章必须有冲突、推进、奖励、代价和钩子。
- 每个场景必须有目标、阻力、行动、信息增量和情绪变化。
- 每个关键 beat 的 requires 必须已经是 prerequisite 或由早先 beat grounded。
- 如果本章需要解释世界规则、专业知识或伏笔，必须先说明它服务哪个行动、冲突或 payoff。
- 结尾钩子必须制造下一章阅读理由。
- Hook horizon 应由 reader promise、arc 和 serial function 决定，不得硬编码统一兑现窗口。
- 细纲必须足够具体，能约束 `prose-generation` 不脱纲。

## 禁止事项

- 禁止用“铺垫一章”替代章节功能。
- 禁止只有设定说明，没有人物行动。
- 禁止为了反转牺牲因果链。
- 禁止创建没有 promise lineage 或后续承接责任的空钩子。
- 禁止绕过细纲直接生成正文。

## 与其他模块的关系

- 上游：`long-outline`、`character-design`、`worldbuilding`。
- 下游：`prose-generation`、`quality-review`、`DraftChapter`。
- 关联 Skill：`narrative-beat-design`。
- Agent：Draft Agent、Review Agent、Quality Agent。

````

## S008 skills/character-design/SKILL.md

```json
{
  "id": "S008",
  "name": "character-design",
  "file": "skills/character-design/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "character.cast.generate"
  ],
  "versions": [
    {
      "ref": "character-design",
      "version": "character-design-qualification-v1",
      "hash": "sha256:2e735e1d9c3a8d05bf215881e808d1a5bb33308f0c8e971f2665c2d6b6bde566"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1547,
    "utf8_bytes": 2847,
    "utf8_byte_token_upper_bound": 2847,
    "legacy_bytes_div3_estimate": 949,
    "negative_markers": 7,
    "mandatory_markers": 8
  },
  "sha256": "sha256:4eb820e8f541067ad5f3277b860596a095dd8f2f67c5d80bec44e95333f02cea"
}
```

完整原文：
````markdown
---
name: character-design
description: Use when creating or reviewing character cards so each character has goals, desires, fears, obsessions, abilities, flaws, relationships, growth arc, and actions that serve the main conflict.
---

# Character Design

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 创建主角、反派、配角或关键关系人物。
- 审查人物是否能推动主线冲突。
- 大纲、细纲或草稿中出现动机漂移、降智或工具人问题。

## 输入要求

- TopicSeed、WorldBible、项目方向或章节目标。
- 主线冲突、目标读者、核心爽点和世界规则。
- 已有人物关系、阶段剧情需求和禁止事项。

## 操作流程

1. 明确人物在主线中的功能：推动者、阻碍者、诱因、镜像或代价承担者。
2. 定义外部目标、内在欲望、恐惧、执念和底层缺口。
3. 定义能力、资源、限制、缺陷和行动代价。
4. 建立关系网：利益关系、情感关系、秘密关系和冲突关系。
5. 设计成长弧：开局信念、中段崩塌、关键选择和最终变化。
6. 检查关键行动是否服务主线冲突或人物成长。
7. 输出人物卡和崩人设风险清单。

## 输出格式

```markdown
# 人物卡

## 基础身份
## 主线功能
## 外部目标
## 内在欲望
## 恐惧与执念
## 能力与资源
## 缺陷与代价
## 关系网
## 成长弧
## 行为逻辑
## 不可做的事
## 主线冲突贡献
```

## 质量标准

- 人物行动必须有欲望、压力、选择和代价。
- 关键人物必须能制造或解决主线冲突。
- 反派必须有可理解的收益和压力。
- 配角不能只负责解释设定或推动主角升级。

## 禁止事项

- 禁止让人物为剧情需要突然降智。
- 禁止只写标签化人设，不写行为逻辑。
- 禁止让成长弧脱离主线冲突。
- 禁止复用具体作品的人物身份组合和关系组合。

## 与其他模块的关系

- 上游：`generate-topic`、`generate-world`、`WorldBible`。
- 下游：`generate-outline`、`generate-chapter-plan`、`quality-review`。
- Agent：Chief Editor Agent、Draft Agent、Review Agent。

````

## S009 skills/classic-literary-depth-analysis/SKILL.md

```json
{
  "id": "S009",
  "name": "classic-literary-depth-analysis",
  "file": "skills/classic-literary-depth-analysis/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "source.deconstruction.observe"
  ],
  "versions": [
    {
      "ref": "classic-literary-depth-analysis",
      "version": "1.0.0",
      "hash": "sha256:55a22fd03ae6410f8d0e8148a6feccf424d24fcb50ce7dc5305d1a008b6733b2",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1739,
    "utf8_bytes": 2209,
    "utf8_byte_token_upper_bound": 2209,
    "legacy_bytes_div3_estimate": 737,
    "negative_markers": 6,
    "mandatory_markers": 5
  },
  "sha256": "sha256:55a22fd03ae6410f8d0e8148a6feccf424d24fcb50ce7dc5305d1a008b6733b2"
}
```

完整原文：
````markdown
---
name: classic-literary-depth-analysis
description: Analyze classic literature references into abstract theme systems, social pressure graphs, symbol functions, fate curves, and reusable craft constraints.
---

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

用于经典名著深度拆解，提取主题系统、社会关系、象征功能、命运曲线和道德困境。只转化结构功能，不复用具体文本或标志性场景。

## 输入要求

- schema-backed source asset path.
- project workspace path when available.
- source rights and copyright boundary.
- analysis scope and desired abstraction level.

## 操作流程

1. Read the referenced source asset by path.
2. Identify deep structure, theme system, symbol functions, social relation model, and fate curve.
3. Mark non-transferable protected elements.
4. Produce `classic_literary_analysis_report`.
5. Record validation status and reusable abstractions.

## 输出格式

Write one JSON asset with type `classic_literary_analysis_report` under `data/analysis`.

## 质量标准

- Report passes schema validation.
- Transferable items are abstract functions, not scenes.
- Non-transferable elements are explicit.
- `metadata.use_in_generation_rag` is `false`.

## 禁止事项

- Do not copy protected text.
- Do not reuse recognizable set pieces.
- Do not write draft prose.
- Do not treat public fame as permission to copy.

## 与其他模块的关系

Output can be converted into `knowledge_card`, `craft_template`, or `review_rule_pack`.

````

## S010 skills/context-builder-source-isolation/SKILL.md

```json
{
  "id": "S010",
  "name": "context-builder-source-isolation",
  "file": "skills/context-builder-source-isolation/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "context_compress",
    "context_fidelity",
    "retrieval",
    "retrieval_query_expansion"
  ],
  "versions": [
    {
      "ref": "context-builder-source-isolation",
      "version": "context-builder-source-isolation-v1",
      "hash": "sha256:beba0a22037fe37179f884bac2a1f37cb96ea226b5f8bcd92e07fae61b5841f6"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2717,
    "utf8_bytes": 3477,
    "utf8_byte_token_upper_bound": 3477,
    "legacy_bytes_div3_estimate": 1159,
    "negative_markers": 7,
    "mandatory_markers": 7
  },
  "sha256": "sha256:16071b45e41ec6c55f835653ef137e19bace61d904b434024196112307d1d513"
}
```

完整原文：
````markdown
---
name: context-builder-source-isolation
description: Use when building, reviewing, or debugging ContextBundle and KnowledgePack inputs for outline, chapter plan, draft, review, revision, recap, publish, and feedback flows with strict source isolation and token-budget governance.
---

# Context Builder Source Isolation

## 适用场景

- 为核心 Agent 生产 ContextBundle、ContextBuildPlan 或 prompt preview。
- 审计 RAG、MKAOS pack、Canon/Character/Arc/Foreshadowing/WorldRule、ReviewIssue 是否被安全注入。
- 修复或验证 raw source text、parallel pair、runtime asset 污染生成链路的问题。

## 输入要求

- `project_id`、target asset、task type、flow、token budget、source policy、runtime environment。
- KnowledgePack、ContextBundle、RAG retrieval report、evidence refs、ReviewIssue 和 prior issue 引用。
- 禁止项清单：raw text、clean text、quote、source_text、target_text、unreviewed provider output。

## Novel OS Runtime Contract

- 所有核心生产动作必须通过 Context Builder 形成 `context_bundle_id`；`knowledge_pack_id` 仅在 active Capability Pack / stage 明确要求或本次选择了项目 Knowledge Pack 时存在。
- ContextBundle 必须记录 source policy、source isolation、selected knowledge ids、review rules、risk warnings、selector policy version。
- controlled runtime 下缺 context bundle、缺 Capability 所要求的 knowledge pack 或 source isolation 失败必须 fail closed；Capability 未要求时不得为了形式完整强塞空 Knowledge Pack。
- compat fallback 只能用于旧 fixture/sample，并必须写 trace、policy warning 和 metadata。

## 操作流程

1. 收集 flow 所需的 canon、arc、character、foreshadowing、world rule、MKAOS pack、ReviewIssue 和 revision constraints。
2. 对每个输入执行 source isolation lint，拒绝 raw/clean/source/target text 进入生成上下文。
3. 按 token budget、质量、风险和任务目标裁剪上下文。
4. 生成 ContextBundle，并记录 evidence refs、selector decision、risk warnings 和 trace。
5. 运行 MKAOS production gate 或对应 flow gate。
6. 输出可审计的 bundle 摘要，不展开受保护来源正文。

## 输出格式

```markdown
# Context Bundle Report

## Contract
- context_bundle_id:
- knowledge_pack_id: # optional unless Capability/stage requires it
- knowledge_requirement: # OPTIONAL / REQUIRED
- flow:
- source_policy:

## Included Context
- canon:
- mkaos:
- review rules:
- prior issues:

## Gates
- source isolation:
- token budget:
- blocking issues:
```

## 质量标准

- ContextBundle 可从 AgentRun、Chapter Saga、PublishGate、FeedbackBackflow 反查。
- 所有上下文片段都有来源类型、允许用途和裁剪理由。
- 必须记录 `knowledge_requirement`；REQUIRED 不允许空 pack，OPTIONAL 未选择时记录 `NOT_REQUESTED`，不得伪造空 pack。

## 禁止事项

- 禁止 Agent 各自拼 prompt 绕过 Context Builder。
- 禁止把 `.local/workspace` 的 runtime asset 当作 generation RAG 内容。
- 禁止 source_chunk、source_document、parallel_pair 的原文或清洗文本进入正文上下文。

## 与其他模块的关系

- 上游：MKAOS、Canon Graph、RAG、ReviewIssue、Runtime Policy。
- 下游：Agent Runtime、Command Kernel、Draft/Review/Revision/Recap/Publish/Feedback flows。
- 关联 Skill：`mkaos-knowledge-asset-os`、`review-issue-gate`、`agent-loop-governance`。

````

## S011 skills/evidence-fact-verification/SKILL.md

```json
{
  "id": "S011",
  "name": "evidence-fact-verification",
  "file": "skills/evidence-fact-verification/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2771,
    "utf8_bytes": 3649,
    "utf8_byte_token_upper_bound": 3649,
    "legacy_bytes_div3_estimate": 1217,
    "negative_markers": 6,
    "mandatory_markers": 7
  },
  "sha256": "sha256:906df71ccfee72274cf6d926597637469427aa1574a41ceabd1c8eed6918e6c0"
}
```

完整原文：
````markdown
---
name: evidence-fact-verification
description: Use when extracting a factual claim, binding source evidence, checking cross-source agreement and temporal freshness, and producing a fail-closed verification decision for story research or review.
---

# Evidence / Fact Verification

## Novel OS Runtime Contract

- 本 Skill 不建立第二套 Source、Evidence、Knowledge 或 Vector Store；必须复用 Source Governance、MKAOS、KnowledgePack、Context Builder、AssetVersion 和 Trace。
- 正式链路为 Claim extraction → evidence retrieval → evidence binding → cross-source verification → decision → Fact Gate。
- `fact.verify` 只能使用同项目、带 lineage 和 temporal metadata 的 evidence；无充分 evidence 返回 `INSUFFICIENT_EVIDENCE`，不得让 LLM 用常识补齐。
- Claim、verification report、ReviewIssue / GateResult 必须 schema-backed，保留 trace；Provider 调用还需 model call、cost ledger 和 qualification。

## 适用场景

- 审核现实世界事实、专业细节、时间敏感断言或不同来源互相冲突的 claim。
- 为 WorldBible、Outline、ChapterPlan、Draft Review 或 Publish Gate 提供 evidence-backed fact decision。
- 判断 VERIFIED、DISPUTED、UNSUPPORTED、OUTDATED 或 INSUFFICIENT_EVIDENCE。

## 输入要求

- `claim_id`、`project_id`、statement、domain、source id、trace id。
- evidence refs、source published/retrieved time、temporal valid range、source quality、stance 和 confidence。
- verification as-of time、freshness policy、fictionalization policy 和 downstream target。

## 操作流程

1. 抽取最小可验证 Claim，不把观点集合伪装为单一事实。
2. 通过 MKAOS / KnowledgePack 检索 eligible evidence，保留 source 与 chunk lineage。
3. 绑定支持、反对和中性 evidence；过滤跨项目、未授权、无 lineage 或时间上无效的记录。
4. 检查来源质量、独立性、published/retrieved time、temporal validity 和 freshness。
5. 产生 VERIFIED / DISPUTED / UNSUPPORTED / OUTDATED / INSUFFICIENT_EVIDENCE 决策及理由。
6. 将 blocking decision 写入 ReviewIssue / Fact Gate；`fictionalization_allowed` 只表达策略，不把假事实标记为 VERIFIED。

## 输出格式

```markdown
# Fact Verification Report

## Claim
- id / project / statement / domain:
- temporal validity:
- fictionalization allowed:

## Evidence Binding
- supporting:
- contradicting:
- excluded and reason:

## Decision
- status:
- source quality / confidence:
- freshness:
- trace:
- gate / revision action:
```

## 质量标准

- VERIFIED 必须有适用时间内、lineage 完整且达到质量门槛的支持证据。
- DISPUTED 必须保留冲突双方，不以单一 provider 偏好抹去反证。
- OUTDATED 必须说明失效时间或 freshness policy；UNSUPPORTED 与 INSUFFICIENT_EVIDENCE 不混淆。
- 所有 evidence 与 Claim 必须同项目，跨来源结论必须能列出绑定关系。

## 禁止事项

- 禁止“让 LLM 根据常识检查是否正确”。
- 禁止无 evidence 返回 VERIFIED，或把模型 confidence 当作 source quality。
- 禁止重复建设 MKAOS、Source Governance、Knowledge DB、Vector Store 或 Provider Runtime。
- 禁止把原始受保护来源文本直接放进 Draft / Publish 上下文。

## 与其他模块的关系

- 上游：Source、Evidence、MKAOS、KnowledgePack、Context Builder、Trace。
- 下游：ReviewIssue、Fact Gate、RevisionPlan、WorldBible / Draft review、Publish Gate。
- 关联 Skill：`mkaos-knowledge-asset-os`、`context-builder-source-isolation`、`multidisciplinary-knowledge`、`quality-review`。

````

## S012 skills/hot-novel-business-deconstruction/SKILL.md

```json
{
  "id": "S012",
  "name": "hot-novel-business-deconstruction",
  "file": "skills/hot-novel-business-deconstruction/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "reader.promise.generate",
    "source.deconstruction.observe"
  ],
  "versions": [
    {
      "ref": "hot-novel-business-deconstruction",
      "version": "hot-novel-business-deconstruction-qualification-v1",
      "hash": "sha256:a876ca898d9662821c24097e6cb6e237e1f40d40d338cec7f0e15ebb9ab43ddc"
    },
    {
      "ref": "hot-novel-business-deconstruction",
      "version": "1.0.0",
      "hash": "sha256:7feaaf6da55d30956f953f4b12228729dacb18bf4d4ebdf505727b625f77dcdf",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1925,
    "utf8_bytes": 2421,
    "utf8_byte_token_upper_bound": 2421,
    "legacy_bytes_div3_estimate": 807,
    "negative_markers": 6,
    "mandatory_markers": 5
  },
  "sha256": "sha256:7feaaf6da55d30956f953f4b12228729dacb18bf4d4ebdf505727b625f77dcdf"
}
```

完整原文：
````markdown
---
name: hot-novel-business-deconstruction
description: Analyze web fiction references into abstract commercial structure, reader promise, hooks, pacing, and reusable review constraints without copying protected expression.
---

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

用于把网文或连载参考作品拆解成商业结构、爽点循环、章节钩子、人设压力和平台节奏。只输出抽象机制，不输出可直接复用的正文、角色名、设定名或情节顺序。

## 输入要求

- schema-backed source asset path.
- project workspace path when available.
- source rights and copyright boundary.
- target platform, genre, and reader promise if available.

## 操作流程

1. Read the referenced source asset by path.
2. Identify reader promise, hook system, payoff loop, pacing model, and retention risks.
3. Remove source-specific names, protected scenes, unique settings, and prose.
4. Produce `web_fiction_business_analysis_report`.
5. Record source asset id, expected output path, validation command, and risk boundary.

## 输出格式

Write one JSON asset with type `web_fiction_business_analysis_report` under `data/analysis`.

## 质量标准

- Report passes schema validation.
- Analysis is abstract and mechanism-level.
- `metadata.use_in_generation_rag` is `false`.
- High-risk findings are marked for conversion review.

## 禁止事项

- Do not copy protected text.
- Do not reuse source-specific names, settings, or plot sequence.
- Do not write draft prose.
- Do not insert analysis reports directly into generation RAG.

## 与其他模块的关系

Output can be converted by the asset converter into `material_card`, `writing_template`, `craft_template`, or `review_rule_pack`.

````

## S013 skills/hot-novel-deconstruction/SKILL.md

```json
{
  "id": "S013",
  "name": "hot-novel-deconstruction",
  "file": "skills/hot-novel-deconstruction/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "source.deconstruction.observe"
  ],
  "versions": [
    {
      "ref": "hot-novel-deconstruction",
      "version": "2.0.0",
      "hash": "sha256:3844f7152f4d1bd1c2b5a8b95c916abb5d44d8a26e0c84800bdf6a7e38270cdb",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 3403,
    "utf8_bytes": 5405,
    "utf8_byte_token_upper_bound": 5405,
    "legacy_bytes_div3_estimate": 1802,
    "negative_markers": 12,
    "mandatory_markers": 13
  },
  "sha256": "sha256:3844f7152f4d1bd1c2b5a8b95c916abb5d44d8a26e0c84800bdf6a7e38270cdb"
}
```

完整原文：
````markdown
---
name: hot-novel-deconstruction
description: Use when analyzing popular novels or genre samples to extract abstract structure, pacing, payoff mechanics, character mechanisms, conflict patterns, emotion curves, chapter hooks, and commercial logic without copying protected expression or plot combinations.
---

# Hot Novel Deconstruction

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 拆解热门小说、爆款章节、同赛道样本或类型文片段。
- 为 `decompose`、`extract-knowledge`、`build-materials` 或题材策划提供抽象输入。
- 需要判断一个样本为什么有追读、爽点和商业吸引力。

## 输入要求

- 来源、范围、类型、目标读者和拆解目的。
- 版权边界说明：输入只用于结构分析，不进入正文生成。
- 若样本来自单一作品，必须标记为高原创风险输入。
- 正式运行只接收 Source Authority 提供的 `source_document_id`、`source_transform_id`、不可变 `source_chunk_asset_version_id` 与稳定 `evidence_span_id`；不得从文件名推断来源身份。
- 每次运行必须冻结 analyzer / schema / prompt / Skill / capability / provider-policy / aggregation-policy 版本和 execution evidence。

## 正式 Deconstruction Intelligence 合同

- 输出首先是 `Observation`，不是 `KnowledgeCard`，也不是一篇整书 Markdown 总结。
- 维度按需独立运行：`structure`、`pacing`、`hook`、`reward_payoff`、`reader_promise`、`conflict`、`character_mechanism`、`relationship_mechanism`、`emotion_curve`、`foreshadowing`、`information_progression`、`serialization`、`commercial_logic`、`originality_copyright_risk`。
- 尺度从 `CHAPTER`、`CHAPTER_WINDOW`、`CHAPTER_GROUP` 逐级聚合到 `ARC`、`VOLUME`、`BOOK`、`CROSS_BOOK_PATTERN`；禁止默认整本一次模型调用。
- 下层 Observation 已足够时，上层聚合只读取 Observation，不重新读取原文；确定性聚合不得调用模型。
- 每条 finding 必须引用本次冻结输入中的 `evidence_span_id` 或 lower-scale Observation AssetVersion，并包含 confidence 与 originality risk。
- 相同 scope + analyzer contract + observation 内容必须重放已有结果；合约升级只重算目标维度及 lineage 下游。

## 操作流程

1. 记录来源、样本范围、类型、目标读者和拆解问题。
2. 拆出结构：开局问题、阶段目标、冲突升级、阶段奖励和结尾压力。
3. 拆出节奏：信息增量、压迫、缓释、反转、奖励兑现和章节钩子间隔。
4. 拆出人物机制：欲望、恐惧、能力、缺陷、关系压力和行动代价。
5. 拆出冲突机制：目标冲突、资源冲突、身份冲突、价值冲突和制度压力。
6. 拆出商业逻辑：读者期待、爽点承诺、情绪释放、追读理由和禁用风险。
7. 先提交结构化 Observation，明确 `knowledge_status=NOT_ABSTRACTED`。
8. 交给 `anti-copy-abstraction` 生成独立 Knowledge Candidate；不得把 Observation 直接当生产知识。

## 输出格式

生产输出必须匹配 `source-deconstruction-observation.v1`，至少包含：

```json
{
  "findings": [{
    "finding_code": "hook.chapter_end_pressure",
    "statement": "仅描述抽象观察，不复述来源表达",
    "evidence_span_ids": ["source-evidence-span:..."]
  }],
  "confidence": 0.0,
  "originality_risk": "LOW_AFTER_ABSTRACTION",
  "knowledge_status": "NOT_ABSTRACTED"
}
```

以下 Markdown 只允许作为 operator handoff，不是生产 Authority：

```markdown
# 热门小说拆解报告

## 来源与范围
## 类型与目标读者
## 结构拆解
## 节奏拆解
## 爽点机制
## 人设机制
## 冲突机制
## 情绪曲线
## 章节钩子
## 商业化逻辑
## 可复用抽象原则
## 禁止复用内容
## 原创风险等级
```

## 质量标准

- 输出重点是结构、机制和读者效果，不是剧情复述。
- 每个可复用点必须说明适用边界。
- 每个高风险点必须进入禁止复用内容。
- Observation 必须能通过后续 Abstraction/Governance 转成 Candidate，但自身永远不是可生成知识。

## 禁止事项

- 禁止复制原文表达、台词、人物身份、独特设定和具体桥段。
- 禁止把单一热门小说直接转成新书剧情骨架。
- 禁止输出换名仿写建议。
- 禁止把原文片段保存为可生成素材。

## 与其他模块的关系

- 上游：`data/raw/`、`data/cleaned/`、`docs/00-product/copyright-and-compliance.md`。
- 下游：`anti-copy-abstraction`、Source Deconstruction Authority、MKAOS Candidate/Governance；任何 operator handoff 都不是生产 Authority。
- Agent：Knowledge Agent、Material Agent、Chief Editor Agent。

````

## S014 skills/long-outline/SKILL.md

```json
{
  "id": "S014",
  "name": "long-outline",
  "file": "skills/long-outline/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "ending.intent.generate"
  ],
  "versions": [
    {
      "ref": "long-outline",
      "version": "long-outline-v1",
      "hash": "sha256:d410db2b1c30fcae81eb9bfa52071b1b3c003adffa2bf5159f7d57d26ea08d46"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2183,
    "utf8_bytes": 3871,
    "utf8_byte_token_upper_bound": 3871,
    "legacy_bytes_div3_estimate": 1291,
    "negative_markers": 9,
    "mandatory_markers": 12
  },
  "sha256": "sha256:4e4a9f2183602bc506d5daba09e446df9bbd849532b02b72e22b4ae6b7e6219b"
}
```

完整原文：
````markdown
---
name: long-outline
description: Use when creating or reviewing full-book outlines, volume plans, long-serial arcs, enemy escalation, resource progression, relationship changes, payoff distribution, and foreshadowing/recovery plans.
---

# Long Outline

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 生成全书大纲、卷纲、前 30 章规划或长期连载节奏。
- 审查大纲是否能支撑主线目标和持续追读。
- 将题材、世界观和人物转化为可执行剧情路线。
- 长线结构需要检查 reader grounding、beat 解锁顺序、伏笔/payoff 路径和信息递进时，配合 `narrative-beat-design`。

## 输入要求

- TopicSeed、WorldBible、CharacterCard、MaterialCard。
- 目标读者、核心爽点、主线冲突和连载长度预期。
- 已有伏笔、禁用项、原创风险边界。

## 操作流程

1. 明确全书主线目标和不可回避的核心冲突。
2. 划分阶段目标或卷目标，并定义每阶段的敌人升级和资源升级。
3. 规划人物关系变化、信念变化和关键代价。
4. 定义每阶段 reader prerequisites、已 grounded 规则、人物状态和读者承诺。
5. 规划阶段 beat path：每个阶段必须说明它 requires 什么、grounds 什么、解锁哪些后续冲突或 payoff。
6. 安排爽点分布、情绪曲线、阶段高潮和追读钩子；为跨章节钩子绑定 reader promise、horizon、目标 payoff window 和责任 arc。
7. 建立伏笔设置、延迟兑现和回收计划，确保 payoff 前有足够 grounding。
8. 检查每卷是否有明确奖励、代价、升级和更大压力。
9. 输出全书大纲、卷纲和风险清单。

## 输出格式

```markdown
# 全书大纲

## 一句话主线
## 全书目标
## 核心冲突
## 阶段目标 / 卷纲
## 敌人升级
## 资源升级
## 人物关系变化
## Reader Grounding
## Beat Path
## 爽点分布
## 情绪曲线
## Hook Horizon / Reader Promise
## 伏笔与回收
## 前 3 章目标
## 前 10 章目标
## 风险与返工项
```

## 质量标准

- 每一卷必须有清晰目标、阻力、奖励、代价和结尾升级。
- 主角成长必须对应更强冲突，而不是单纯堆能力。
- 每个阶段关键 beat 必须说明它为后续章节 grounded 了哪些规则、关系、悬念或承诺。
- 伏笔必须有设置位置、回收窗口和剧情功能。
- IMMEDIATE / CHAPTER / MINI_ARC / ARC / VOLUME / BOOK 各尺度 Hook 必须有责任范围和 evidence，不得用单一固定章数替代设计判断。
- 长线规划必须服务追读，不得变成设定年表。

## 禁止事项

- 禁止只有世界设定，没有人物行动。
- 禁止让敌人升级无理由或主角升级无代价。
- 禁止照搬已有作品卷结构。
- 禁止让伏笔只存在于作者笔记，无法进入章节执行。
- 禁止把长期承诺伪装成短期 cliffhanger，或创建独立重复 Hook Agent。

## 与其他模块的关系

- 上游：`character-design`、`worldbuilding`、`TopicSeed`。
- 下游：`chapter-outline`、`prose-generation`、`quality-review`。
- 关联 Skill：`narrative-beat-design`。
- Agent：Chief Editor Agent、Draft Agent、Review Agent。

````

## S015 skills/longform-temporal-query/SKILL.md

```json
{
  "id": "S015",
  "name": "longform-temporal-query",
  "file": "skills/longform-temporal-query/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2685,
    "utf8_bytes": 3635,
    "utf8_byte_token_upper_bound": 3635,
    "legacy_bytes_div3_estimate": 1212,
    "negative_markers": 7,
    "mandatory_markers": 5
  },
  "sha256": "sha256:ea6805f1b44acfaaf0b01e04939864930336eb7f516cd9328a9f6c3eded80f8f"
}
```

完整原文：
````markdown
---
name: longform-temporal-query
description: Use when specifying or reviewing chapter-as-of queries for accepted character, knowledge, relationship, world, power, plot-thread, foreshadow, promise, or change state without leaking future chapters.
---

# Long-form Temporal Query

## Novel OS Runtime Contract

- 本 Skill 只定义查询语义和审查方法；正式读取必须调用 PostgreSQL `TemporalQueryService` / `temporal.query`，不能在 Skill 中实现状态存储或查询。
- 生产数据只来自 accepted Chapter boundary 下 eligible、clear、`ACTIVE` / `SUPERSEDED` 历史 `AssetVersion` 及其 supersession / rollback lineage；`RETIRED` / `DELETED` 不可见。
- 查询输出必须保留 `project_id`、as-of chapter、boundary semantics、source asset/version、trace 和 missing-state 状态。
- Legacy LocalStorage Canon Query 不得作为 Production 实现或证据。

## 适用场景

- 为 ChapterPlan、Context Builder、Draft、Review、Revision、Canon 或 Replan 获取某章当时可知的状态。
- 审查未来信息泄漏、旧关系被新关系覆盖、知识取得时点、rollback/rebuild 和跨项目隔离。
- 设计 `character_state_at`、`character_knows_at`、`relationship_at`、`world_state_at`、`power_state_at`、`plot_thread_at`、`foreshadow_state_at`、`pending_promises_at`、`changes_between` 的调用契约。

## 输入要求

- `project_id`、query kind、as-of chapter 或 `(chapter_from, chapter_to]`。
- 对象 id：character、fact、relationship target 或 thread id；不适用时不得伪造。
- 调用目的、下游资产、accepted-only 要求和 trace context。

## 操作流程

1. 选择最窄查询，不用整本最新快照替代 chapter-as-of state。
2. 固定边界：`*_at(chapter)` 包含目标章；`changes_between` 为 `(from, to]`。
3. 要求 accepted-only、same-project、active eligible clear versions，并解析 supersession / rollback。
4. 检查返回证据的 chapter 不大于 as-of chapter；任何未来记录都视为阻断缺陷。
5. 用 `NOT_FOUND` 和 `missing_reason` 区分缺失状态与空集合，不把 missing state 推断为 false fact。
6. 将结果以 schema-backed query result 交给 Context Builder、validator 或 ReviewIssue，不直接修改 Canon。

## 输出格式

```markdown
# Temporal Query Contract

## Request
- project:
- query:
- as-of / range:
- entity:

## Semantics
- inclusive boundary:
- accepted only:
- supersession / rollback:
- missing-state behavior:

## Result Evidence
- source asset versions:
- effective chapters:
- trace:
- future leakage check:
```

## 质量标准

- 同一输入和 Authority state 必须得到可重放结果。
- Chapter 30 获取的事实在 Chapter 20 查询中不可见；Chapter 40 的关系变化不能覆盖 Chapter 35 的旧关系。
- 每个 SQL / projection 路径必须显式过滤 `project_id`。
- 任何状态结论必须携带来源版本和 effective chapter。

## 禁止事项

- 禁止查询“当前最新”后让 LLM 猜测历史状态。
- 禁止返回未来章节信息、跨项目资产或未接受候选。
- 禁止用 Legacy LocalStorage、全文关键词或 provider 常识替代 PostgreSQL temporal projection。
- 禁止把查询结果当作 Canon mutation authorization。

## 与其他模块的关系

- 上游：Book / Chapter Authority、Accepted Canon、State Event、Snapshot、Projection、Chapter Boundary。
- 下游：Context Builder、`canon.validate`、`continuity.validate`、ReviewIssue、Replan、Publish Gate。
- 关联 Skill：`canon-continuity-graph`、`context-builder-source-isolation`、`quality-review`。

````

## S016 skills/material-curation/SKILL.md

```json
{
  "id": "S016",
  "name": "material-curation",
  "file": "skills/material-curation/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 1816,
    "utf8_bytes": 3072,
    "utf8_byte_token_upper_bound": 3072,
    "legacy_bytes_div3_estimate": 1024,
    "negative_markers": 6,
    "mandatory_markers": 9
  },
  "sha256": "sha256:588efc5a4fc9cb15196fdea17565dfdcffc589e800dc13a754a02c9ba9189060"
}
```

完整原文：
````markdown
---
name: material-curation
description: Use when classifying, tagging, organizing, or quality-checking reusable material assets so raw sources, cleaned text, decompositions, knowledge, and material cards become searchable production assets without mixing source text into generated fiction.
---

# Material Curation

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 将清洗文本、拆解结果、知识卡或素材卡整理成可调用资产。
- 为素材打标签：题材、情绪、冲突、场景、人物类型、钩子、爽点。
- 审查素材是否混入原文、版权内容或不可生成内容。

## 输入要求

- SourceDocument、CleanedText、DecompositionReport、KnowledgeCard 或 MaterialCard。
- 来源、版权边界、抽象程度和目标用途。
- 标签体系或当前项目需要检索的维度。

## 操作流程

1. 确认素材生命周期：raw、cleaned、decomposition、knowledge、material。
2. 检查来源、版权边界、references 和 metadata 是否完整。
3. 区分可生成素材、只可参考素材、只可审稿素材和禁用素材。
4. 打标签：类型、情绪、冲突、场景、角色功能、钩子、爽点、风险。
5. 删除或隔离具体表达、独特桥段、人物组合和不可授权内容。
6. 输出素材卡整理建议和质量问题。
7. 需要创作转化时交给 `topic-development` 或 `multidisciplinary-knowledge`。

## 输出格式

```markdown
# Material Curation Report

## 素材来源
## 当前资产类型
## 版权边界
## 标签
## 可生成内容
## 只可参考内容
## 只可审稿内容
## 禁用内容
## 质量问题
## 推荐下游用途
```

## 质量标准

- 素材必须有来源和可追溯 references。
- 标签必须服务检索、生成、审稿或反馈，不做装饰性分类。
- 可生成内容必须已经抽象化。
- 禁用内容必须明确写出原因和下游限制。

## 禁止事项

- 禁止把原文、台词、具体桥段标为可生成素材。
- 禁止混淆 raw、cleaned、decomposition、knowledge 和 material。
- 禁止无来源素材进入长期资产库。
- 禁止把素材整理当成正文写作。

## 与其他模块的关系

- 上游：`ingest`、`clean`、`decompose`、`extract-knowledge`、`build-materials`。
- 下游：MaterialCard、TopicSeed、ReviewReport。
- Agent：Material Agent、Knowledge Agent、Quality Agent。

````

## S017 skills/mkaos-knowledge-asset-os/SKILL.md

```json
{
  "id": "S017",
  "name": "mkaos-knowledge-asset-os",
  "file": "skills/mkaos-knowledge-asset-os/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 3687,
    "utf8_bytes": 5155,
    "utf8_byte_token_upper_bound": 5155,
    "legacy_bytes_div3_estimate": 1719,
    "negative_markers": 11,
    "mandatory_markers": 12
  },
  "sha256": "sha256:6f26df621b32a5776e1d32aeb47966b39af577e45013cc8b99c196485002d559"
}
```

完整原文：
````markdown
---
name: mkaos-knowledge-asset-os
description: Use when importing, extracting, selecting, gating, tracing, or learning from multidisciplinary knowledge assets through MKAOS while preserving evidence lineage, source isolation, quality scores, and feedback-based evolution.
---

# MKAOS Knowledge Asset OS

## 适用场景

- 将专业书、网文拆解、名著分析、平台规则、读者反馈或 Agent 报告转为 MKAOS 知识资产。
- 设计或审计 KnowledgeCard、RuleCard、TemplateCard、KnowledgeRelation、KnowledgePack、SelectorDecision、QualityScore、LineageReport。
- 需要把知识从“资料说明”抽象成可迁移创作机制、审稿规则、模板或生产约束。

## 输入要求

- `project_id`、任务目标、目标 flow、平台、题材、运行环境和 OS Envelope 或显式 compat 理由。
- 正式导入使用 Source Deconstruction Observation AssetVersion 与其 Evidence lineage；SourceChunk 直连 Candidate 只允许 `MIGRATION_ONLY`，不得由 production API 使用。
- 当前 source policy、copyright boundary、source isolation 要求和质量门禁阈值。

## Novel OS Runtime Contract

- 生产链路输出必须落到 schema-backed asset，不能只停留在对话文本。
- 每个知识资产必须保留来源引用、evidence refs、`project_id`、`trace_id`、质量状态和 mutation audit 线索。
- KnowledgePack 必须通过 Selector、Quality Gate、Source Isolation Gate，并记录 selected/rejected 原因。
- 禁止 raw source text、`source_chunk.raw_text`、parallel pair `source_text/target_text` 进入 KnowledgePack、ContextBundle、prose、publish、recap。
- 高风险、隔离、过低抽象或 source leakage 风险必须转为 ReviewIssue 或 GateResult。
- 正式知识链固定为 `Evidence -> Observation -> Abstraction -> Candidate -> Validation -> Source Isolation/Originality Gate -> Approval -> KnowledgeCard -> Selector -> KnowledgePack`。
- Observation 与 Candidate、Decision、KnowledgeCard、KnowledgePack 之间必须写入 PostgreSQL dependency lineage；新版本不得静默覆盖旧资产。
- KnowledgePack 是可重建 projection，不是知识真相；Selector 升级必须显式 supersede 旧 Pack，不得触发 Source 重导入或重新拆解。

## 操作流程

1. 识别来源类型、权利边界、证据层范围和可下游使用的抽象边界。
2. 从一个或多个结构化 Observation 抽象出知识候选；不得直接从原文或剧情复述生成生产 Candidate。
3. 检查 creative principle、narrative function、conflict function、applicable flows 和 originality boundary 是否完整。
4. 运行质量评分、反百科化、source leakage、冲突检测和 flow binding 检查。
5. 构建 KnowledgeRelation / lineage / selector decision，解释选中和拒绝原因。
6. 将合格知识进入 KnowledgePack；不合格项进入 ReviewIssue、RegressionCase 或 human review queue。
7. 使用 usage event、review result、reader feedback 和 publish gate 结果生成 learning recommendation。
8. Analyzer/Policy/Selector 升级前先读取 reprocessing plan；复用 `REUSE` 项，只执行 `RECOMPUTE` 与 `REBUILD_PROJECTION` 项。

## 输出格式

```markdown
# MKAOS Knowledge Asset Report

## Assets
- source/evidence refs:
- knowledge cards:
- rule cards:
- template cards:
- relations:
- packs:

## Gates
- quality:
- source isolation:
- conflict:
- review issues:

## Selector Decision
- selected:
- rejected:
- budget:
- risk:

## Learning
- feedback signals:
- weight recommendations:
- audit refs:
```

## 质量标准

- 知识必须是抽象机制、生产约束或可迁移模板，不能是来源内容摘要。
- 每条生产可用知识必须有 evidence refs、适用 flow、原创边界和质量分。
- Selector 必须能解释选中、拒绝、降权、隔离和预算裁剪。
- Feedback Learning 默认 advisory；自动调权必须有显式 apply policy 和 audit。
- Candidate 必须声明 `lineage_mode=OBSERVATION_ABSTRACTION`；`MIGRATION_ONLY_DIRECT_EVIDENCE` 不满足正式数据导入准入。
- Pack 必须冻结精确 KnowledgeCard AssetVersion、target AssetVersion、selector policy hash、权重和 selected/rejected 理由。

## 禁止事项

- 禁止把来源原文、译文、摘录、受保护表达或平行语料文本写入生成上下文。
- 禁止无 evidence refs 的生产知识进入 strict / production / operating_system 路径。
- 禁止用百科说明替代创作机制。
- 禁止跳过 Context Builder、ReviewIssue、GateResult 或 mutation audit。
- 禁止因 Prompt、Analyzer 或 Selector 升级而重新上传同一内容、重新生成未变化 Chunk 或整链重跑。

## 与其他模块的关系

- 上游：Source Authority、Source Deconstruction Observation、Audit Log、Feedback Backflow、Quality Qualification；LocalStorage MKAOS Ingestion/Model Extraction 为 `LEGACY_ISOLATED`。
- 下游：Context Builder、AgentRun、Command Kernel、ReviewIssue、Publish Gate、Authority API/admin projection。
- 关联 Skill：`context-builder-source-isolation`、`review-issue-gate`、`platform-strategy-os`、`quality-review`。

````

## S018 skills/multi-scale-pacing/SKILL.md

```json
{
  "id": "S018",
  "name": "multi-scale-pacing",
  "file": "skills/multi-scale-pacing/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2871,
    "utf8_bytes": 3885,
    "utf8_byte_token_upper_bound": 3885,
    "legacy_bytes_div3_estimate": 1295,
    "negative_markers": 6,
    "mandatory_markers": 8
  },
  "sha256": "sha256:5819439651a7e7ac69640b4a834550f67b80091cdaa3e345850de25423d48bc7"
}
```

完整原文：
````markdown
---
name: multi-scale-pacing
description: Use when analyzing or reviewing pacing across scene, chapter, rolling chapter windows, chapter groups, arcs, volumes, or books while separating deterministic measures from semantic quality judgments.
---

# Multi-scale Pacing

## Novel OS Runtime Contract

- 本 Skill 定义节奏分析方法；正式结果必须由 `pacing.analyze` / `pacing.aggregate` 生成 schema-backed `PacingObservation`、`PacingWindowAggregate` 或 `PacingDiagnosis`。
- deterministic measurement 只能读取结构化 Accepted state/change；semantic quality judgment 必须通过 Provider Runtime，记录 evidence spans、qualification、model call、cost ledger 和 trace。
- 所有窗口必须以 accepted Chapter boundary 截断，按 `project_id` 隔离，禁止未来章节泄漏。
- Blocking diagnosis 必须进入 ReviewIssue / Gate；Skill 文本不能直接改 ChapterPlan、Draft 或 Canon。

## 适用场景

- 分析 Scene、Chapter、短窗、长窗、Chapter Group、Arc、Volume、Book 尺度的节奏。
- 检查局部高潮与长线推进是否错位、promise / foreshadow debt 是否积累、状态变化是否过弱或过密。
- 在 Review、Revision、Re-review、Longform Recap 或 Replan 中形成可追溯节奏诊断。

## 输入要求

- `project_id`、chapter boundary、window kind、chapter / group / arc / volume / book id。
- accepted chapter observations、structured state changes、promise / foreshadow lifecycle 和 arc progress。
- semantic 指标所需的 qualified provider evidence；缺失时标记 `NOT_OBSERVED`。

## 操作流程

1. 选择尺度并声明窗口成员和 inclusive as-of boundary。
2. 从结构化变化计算可重放指标：open promises、promise debt、foreshadow debt、state-change magnitude 和显式 arc progress。
3. 将 event/conflict/information/setup/payoff/reward density、emotional intensity/variance、dialogue/action/reflection/exposition ratio、hook/cliffhanger strength 路由到 semantic observation，除非上游已有正式结构化测量。
4. 为每项 semantic observation 保留 evidence span、confidence、provider qualification；无证据不填猜测值。
5. 聚合 Chapter、短/长滚动 Chapter、Chapter Group、Arc、Volume、Book 窗口，并检查未来泄漏与跨项目污染。
6. 生成 diagnosis、ReviewIssue 和 revision actions，不直接修改生产资产。

## 输出格式

```markdown
# Multi-scale Pacing Report

## Scope
- project / as-of chapter:
- scale / members:

## Deterministic Measurements
- metric / value / state evidence:

## Semantic Observations
- metric / value / evidence spans / confidence / qualification:

## Window Aggregate
- open promises / promise debt / foreshadow debt:
- state change / arc progress:

## Diagnosis
- issues:
- revision actions:
- gate:
```

## 质量标准

- 每个指标必须声明 `DETERMINISTIC` 或 `SEMANTIC`，不能混用证据等级。
- 聚合必须可列出窗口成员，且不包含 as-of chapter 之后的数据。
- 多尺度 diagnosis 必须指出局部与长线的具体冲突，而不是只给“节奏快/慢”。
- 缺少 qualified semantic evidence 时必须降级结论，不能由 deterministic 数值冒充质量判断。

## 禁止事项

- 禁止通过关键词、英文正则、标点或字数阈值直接判断节奏质量。
- 禁止把单章观察外推为 Arc / Volume / Book 证明。
- 禁止读取未来章节、未接受资产或跨项目 observation。
- 禁止创建第二套 Workflow、Scheduler、Provider Runtime 或状态库。

## 与其他模块的关系

- 上游：Quality Commercial、HookAnalysis、Accepted Canon changes、Chapter Boundary、Longform Recap。
- 下游：ReviewIssue、RevisionPlan、Re-review、Replan、Publish Gate。
- 关联 Skill：`quality-review`、`narrative-beat-design`、`long-outline`、`canon-continuity-graph`。

````

## S019 skills/multidisciplinary-knowledge/SKILL.md

```json
{
  "id": "S019",
  "name": "multidisciplinary-knowledge",
  "file": "skills/multidisciplinary-knowledge/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "source.deconstruction.observe"
  ],
  "versions": [
    {
      "ref": "multidisciplinary-knowledge",
      "version": "1.0.0",
      "hash": "sha256:ef27e852557903648f86d5a7bd11b595bce4ab859690d9b60597183350f983ef",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1883,
    "utf8_bytes": 3615,
    "utf8_byte_token_upper_bound": 3615,
    "legacy_bytes_div3_estimate": 1205,
    "negative_markers": 11,
    "mandatory_markers": 9
  },
  "sha256": "sha256:ef27e852557903648f86d5a7bd11b595bce4ab859690d9b60597183350f983ef"
}
```

完整原文：
````markdown
---
name: multidisciplinary-knowledge
description: Use when transforming professional or multidisciplinary knowledge into story-safe credibility rules, conflict generators, review checks, and project constraints without turning fiction into exposition or unsafe advice.
---

# Multidisciplinary Knowledge

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 解析专业书籍、学科资料、行业材料或多学科知识。
- 需要把知识转成小说可信度、冲突机制、人物动机或世界规则。
- 审稿时需要检查心理、逻辑、经济、政治、社会、法律、军事、历史或技术可信度。

## 输入要求

- 来源、学科、可信度等级、适用范围和禁用范围。
- 当前题材、世界观、人物、大纲或章节目标。
- 安全边界：不得输出现实高风险操作建议，不得让知识直接进入正文说教。
- 外部资料源策略：GitHub 仓库、论文数据集、论坛语料、古籍数据和官方数据包必须先记录许可、获取方式、可用管线和禁用管线。

## 操作流程

1. 标记知识来源、学科、可信度等级和适用题材。
2. 提取核心概念、约束条件、因果规则和常见误用。
3. 转译为故事功能：可信度规则、冲突生成器、人物行为约束或审稿检查。
4. 删除不相关细节、现实操作步骤和高风险建议。
5. 标记哪些内容只能做审稿检查，不能进入正文。
6. 对 GitHub / 数据集来源，先确认 license_review_status；许可不明、非商业、论坛或爬虫工具来源只能提炼聚合规律、风险规则和审稿检查。
7. 输出 KnowledgeCard 候选或项目约束。
8. 交给 `quality-review` 检查是否压过读者吸引力。

## 输出格式

```markdown
# Multidisciplinary Knowledge Card

## 来源与学科
## 核心概念
## 可信度等级
## 故事功能
## 可生成的冲突
## 人物/世界约束
## 审稿检查项
## 禁止进入正文的内容
## 安全与合规边界
```

## 质量标准

- 知识必须转成故事功能，而不是资料摘录。
- 每条知识必须说明服务哪个剧情问题。
- 高风险现实操作必须删除或抽象。
- 多学科知识只能增强可信度，不能替代爽点和冲突。

## 禁止事项

- 禁止把小说写成论文。
- 禁止输出可执行的现实伤害、违法或高风险操作。
- 禁止未经转译直接塞入正文。
- 禁止让专业合理性破坏追读和情绪奖励。
- 禁止把许可不明、非商业、论坛用户内容、网文正文或爬虫输出作为商业正文生成语料。
- 禁止为了资料获取绕过网站 robots、平台限制、验证码或明确的自动下载禁令。

## 与其他模块的关系

- 上游：SourceDocument、CleanedText、外部专业资料摘要。
- 下游：KnowledgeCard、WorldBible、CharacterCard、ReviewReport。
- Agent：Knowledge Agent、Review Agent、Chief Editor Agent。

````

## S020 skills/narrative-beat-design/SKILL.md

```json
{
  "id": "S020",
  "name": "narrative-beat-design",
  "file": "skills/narrative-beat-design/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "theme.candidates.generate"
  ],
  "versions": [
    {
      "ref": "narrative-beat-design",
      "version": "narrative-beat-design-qualification-v1",
      "hash": "sha256:4c22181605b149f8bc39fc3327907f958b02f4bc5ee4e8be7639b98403f53afe"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 3108,
    "utf8_bytes": 4666,
    "utf8_byte_token_upper_bound": 4666,
    "legacy_bytes_div3_estimate": 1556,
    "negative_markers": 8,
    "mandatory_markers": 14
  },
  "sha256": "sha256:943fcd71f29a854463357e44267a1631c8e76e3f4b0a1bb46792fe2d31c05e06"
}
```

完整原文：
````markdown
---
name: narrative-beat-design
description: Use when designing or reviewing long-outline, chapter-outline, scene sequence, information progression, reader grounding, beat order, hook setup, payoff path, or any narrative plan that must introduce concepts before later beats rely on them.
---

# Narrative Beat Design

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed outline、chapter plan、scene plan、foreshadowing plan 或 review issue，而不是只停留在对话文本。
- 每个 beat 必须保留输入依据、目标资产、`project_id`、可追踪引用、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 beat、prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 设计全书、卷、章节或场景的 beat 顺序。
- 审查 reader grounding：读者是否已经知道后续 beat 依赖的概念、规则、人物动机、承诺或伏笔。
- 修复大纲/细纲中的信息跳跃、解释过载、伏笔未铺、 payoff 没有前置基础的问题。
- 将商业钩子、冲突、反转、代价和信息增量组织成可执行路径。
- 设计 opening / ending hook、information gap、reader question、next-chapter pull 和跨尺度 hook horizon，而不把钩子简化为固定兑现章数。

## 输入要求

- TopicSeed、WorldBible、CharacterCard、Outline、ChapterPlan、ContextBundle 或目标章节位置。
- 目标读者默认已知的 prerequisite concepts。
- 本段必须 introduced 的概念、规则、人物状态、悬念、伏笔、承诺和 payoff。
- 禁用项、原创风险边界、platform rhythm 和 source isolation policy。
- 已有 reader promise、promise lifecycle 和 `HookAnalysis` evidence；没有时明确标记缺口。

## 操作流程

1. 定义 reader prerequisites：读者进入本段前已经知道什么。
2. 建立 grounded set：已知概念、已立规则、已展示关系、已承诺 payoff。
3. 拆出候选 beats：每个 beat 只做一个动作，如设置压力、展示规则、制造选择、兑现奖励、翻转认知。
4. 为每个 beat 标注 `requires` 和 `grounds`：它依赖什么、它让读者新理解什么。
5. 删除或前移不可达 beat：任何依赖未 grounded 概念的 beat 必须先补 grounding beat。
6. 为 opening / ending hook 标注类型、information gap、immediate conflict、reader question、unresolved tension、next-chapter pull、promise binding 和 horizon（IMMEDIATE / CHAPTER / MINI_ARC / ARC / VOLUME / BOOK）。
7. 排列 beat path：优先行动和冲突，解释只在读者需要时出现；horizon 由故事承诺决定，不套用固定 1～3 章规则。
8. 将 beat path 映射回 Outline / ChapterPlan / ScenePlan，并生成 missing groundwork 和 review issues。

## 输出格式

```markdown
# Narrative Beat Design Report

## Scope
- target:
- reader prerequisites:
- grounded at start:

## Beat Path
- beat:
  - function:
  - requires:
  - grounds:
  - hook/payoff:
  - promise id / horizon:
  - evidence:
  - risk:

## Grounding Gaps
- missing concept:
- required before:
- proposed grounding beat:

## Gate
- result:
- review issues:
- downstream asset:
```

## 质量标准

- 每个 beat 必须只有一个主要叙事功能。
- 每个后续 beat 依赖的概念必须已是 prerequisite 或被早先 beat grounding。
- beat path 必须产生行动、冲突、信息增量、情绪变化或 reader payoff。
- 章节级 beat 必须能约束 `prose-generation`，不是抽象口号。
- Hook 判断必须保留 evidence span 和 confidence；无文本/计划证据时不得伪造 promise binding。

## 禁止事项

- 禁止为了漂亮结构跳过因果和 reader grounding。
- 禁止把解释性百科 beat 当作剧情推进。
- 禁止用参考作品 beat 顺序作为新项目骨架。
- 禁止输出正文草稿或 final chapter。
- 禁止把所有 Hook 强制规定为 1～3 章兑现，或另建重复 Hook Agent。

## 与其他模块的关系

- 上游：Topic、WorldBible、CharacterCard、MKAOS Pack、Platform Strategy、Canon Graph。
- 下游：`long-outline`、`chapter-outline`、`quality-review`、`canon-continuity-graph`、DraftChapter。
- Agent：Outline Agent、Chapter Plan Agent、Review Agent、Quality Agent。

````

## S021 skills/novel-os-engineering-audit/SKILL.md

```json
{
  "id": "S021",
  "name": "novel-os-engineering-audit",
  "file": "skills/novel-os-engineering-audit/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 1806,
    "utf8_bytes": 2962,
    "utf8_byte_token_upper_bound": 2962,
    "legacy_bytes_div3_estimate": 988,
    "negative_markers": 6,
    "mandatory_markers": 7
  },
  "sha256": "sha256:8e69cda7879199be989385abeb28763f84da2cfa4f224efd01116100ad61de24"
}
```

完整原文：
````markdown
---
name: novel-os-engineering-audit
description: Use when auditing Novel Forge or Novel Operating System implementation against product docs, architecture docs, tests, runtime gates, source isolation, and acceptance evidence without making code changes unless explicitly requested.
---

# Novel OS Engineering Audit

## 适用场景

- 对比设计文档、审计报告、代码、API、UI、测试和运行资产，判断 Novel OS 能力是否真实完成。
- 审核 MKAOS、Context Builder、ReviewIssue、Command Kernel、Agent Runtime、Publish/Feedback、Platform Strategy、Quality Qualification。
- 生成逐项矩阵、风险台账、修复计划和测试缺口报告。

## 输入要求

- 目标范围、相关 docs、src、tests、web/admin 路径、当前 git 状态和已知验收命令。
- 设计要求、当前实现声明、测试结果、关键 API 或 UI 路由。
- 若涉及外部事实或官方 API，必须使用可信来源或官方文档。

## Novel OS Runtime Contract

- 审计结论必须引用具体文件、函数、API、测试或文档路径。
- 不得凭印象判断；找不到实现时必须记录搜索路径。
- 不得把“超前实现”简单判错，需区分 MATCH、PARTIAL、MISSING、EXTRA_VALID、EXTRA_RISKY、CONFLICT、NEEDS_DECISION。
- 审计本身不修改业务代码；需要改代码时必须另开实现任务。

## 操作流程

1. 读取目标文档、历史报告、代码入口、测试和 UI 注册。
2. 建立设计索引和实现索引，识别主设计、补充设计、过时设计和版本差异。
3. 按模块逐项对比产品目标、信息架构、数据模型、流程接入、门禁、反馈闭环、测试覆盖。
4. 标注一致性、严重级别、证据和建议处理。
5. 输出风险台账、修复计划、测试补充清单和是否可进入下一阶段的判断。
6. 运行只读或指定验收命令，并记录未运行原因。

## 输出格式

```markdown
# Novel OS Engineering Audit

## Scope

## Evidence Index

## Implementation Matrix
| Module | Design Requirement | Current Implementation | Evidence | Judgment | Severity | Recommendation |

## Risks

## Test Results

## Next Actions
```

## 质量标准

- 报告必须能让后续 Agent 直接执行修复，不需要重新猜上下文。
- 严重级别必须服务工业化主线，不能只做文档性排序。
- 测试缺口必须写明缺什么、影响什么、建议在哪个文件补。

## 禁止事项

- 禁止无证据结论。
- 禁止把业务代码修改混入审计任务。
- 禁止忽略 source isolation、fail-closed、ReviewIssue blocking、OS Envelope 和 Context Builder 这些主线约束。

## 与其他模块的关系

- 上游：docs、reports、src、tests、web/admin、runtime assets。
- 下游：remediation plan、phase plan、GitHub issue、Agent handoff。
- 关联 Skill：`agent-loop-governance`、`mkaos-knowledge-asset-os`、`context-builder-source-isolation`。

````

## S022 skills/platform-strategy-os/SKILL.md

```json
{
  "id": "S022",
  "name": "platform-strategy-os",
  "file": "skills/platform-strategy-os/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "source.deconstruction.observe"
  ],
  "versions": [
    {
      "ref": "platform-strategy-os",
      "version": "1.0.0",
      "hash": "sha256:5aff23f16416c66dc03dea781aac7922f35752e9e8e7e54003627b8fa1e61a43",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2093,
    "utf8_bytes": 3103,
    "utf8_byte_token_upper_bound": 3103,
    "legacy_bytes_div3_estimate": 1035,
    "negative_markers": 5,
    "mandatory_markers": 6
  },
  "sha256": "sha256:5aff23f16416c66dc03dea781aac7922f35752e9e8e7e54003627b8fa1e61a43"
}
```

完整原文：
````markdown
---
name: platform-strategy-os
description: Use when adapting topic, outline, chapter plan, draft, review, publish, or feedback strategy to platform-specific production logic such as Qidian, Fanqie, Feilu, Jinjiang, Zhihu Yanxuan, or publishing-oriented releases.
---

# Platform Strategy OS

## 适用场景

- 为同一题材生成不同平台的大纲、节奏、开篇、章节钩子、留存风险和发布策略。
- 构建或审计 PlatformProfile、PlatformRhythmRule、OpeningGate、ChapterGate、RetentionRisk、PublishAdapter、FeedbackBackflow。
- 将读者反馈、平台表现和审稿结果回流到 MKAOS 权重、审稿规则和节奏模板。

## 输入要求

- 目标平台、题材、读者预期、章节阶段、商业目标、平台风险和 release target。
- 当前 outline、chapter plan、ContextBundle、MKAOS pack、ReviewIssue、FeedbackInsight 和 platform metrics。
- 不同平台的节奏边界、语言边界、合规边界和 source policy。

## Novel OS Runtime Contract

- 平台策略必须是结构化资产或 gate policy，不能只作为提示词语气要求。
- 平台 gate 输出必须能进入 ReviewIssue、Publish Gate、Quality Qualification 和 Authority API/admin projection。
- 平台适配不得覆盖 canon facts、人物状态、source isolation 或 originality boundary。
- 真实平台 API 和外部数据导入必须 opt-in；默认使用本地 fixture 或 deterministic metrics。

## 操作流程

1. 选择平台画像：起点、番茄、飞卢、晋江、知乎盐选、微信读书/出版向或自定义。
2. 将平台要求转成节奏规则、开篇门禁、章节门禁、留存风险和发布适配器。
3. 对 topic、outline、chapter plan、draft 或 release package 运行 platform fit 检查。
4. 将平台风险转为 ReviewIssue、RevisionTask 或 PublishGate blocking/warning。
5. 读取反馈回流，生成 platform-specific knowledge/template/rule weight 建议。
6. 输出 near-term chapter strategy 或 release recommendation。

## 输出格式

```markdown
# Platform Strategy Report

## Profile
- platform:
- reader promise:
- rhythm:

## Gates
- opening:
- chapter:
- retention risk:
- publish adapter:

## Backflow
- feedback signals:
- MKAOS weight suggestions:
- review rule changes:
```

## 质量标准

- 平台差异必须体现在生产逻辑上：节奏、冲突密度、钩子、人物关系、留存或主题表达。
- Gate 必须可测试，并能阻断 publish/release 的强风险。
- Feedback backflow 必须可追踪到知识、模板、规则或平台策略。

## 禁止事项

- 禁止只把平台适配理解成“改文风”。
- 禁止为平台留存牺牲正典一致性、版权边界或 source isolation。
- 禁止引入登录、会员、计费或 SaaS 权限逻辑。

## 与其他模块的关系

- 上游：Topic、Outline、ChapterPlan、Feedback、Quality Qualification、MKAOS。
- 下游：ReviewIssue、Publish Gate、Authority API/admin projection、Platform Feedback Backflow。
- 关联 Skill：`mkaos-knowledge-asset-os`、`review-issue-gate`、`quality-review`。

````

## S023 skills/project-planning/SKILL.md

```json
{
  "id": "S023",
  "name": "project-planning",
  "file": "skills/project-planning/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 1983,
    "utf8_bytes": 3667,
    "utf8_byte_token_upper_bound": 3667,
    "legacy_bytes_div3_estimate": 1223,
    "negative_markers": 8,
    "mandatory_markers": 11
  },
  "sha256": "sha256:18904fc154876d5f427bafae96213f5d2e20192c96e7d1c52302d65892dcd41e"
}
```

完整原文：
````markdown
---
name: project-planning
description: Use when planning a new novel project, phase, sprint, roadmap, or task sequence so goals, inputs, outputs, risks, acceptance criteria, and downstream workflow dependencies are explicit and testable.
---

# Project Planning

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 新项目立项、阶段规划、冲刺计划或任务池整理。
- 需要把产品目标转成可执行开发/写作任务。
- 需要判断哪些工作属于 P0/P1/P2，以及是否能进入 pipeline。
- 已有 spec、审计报告或需求清单，需要拆成可交给 Engineering Agent 执行的文件级、接口级、测试级计划。

## 输入要求

- Product vision、roadmap、current state、open issues 或用户目标。
- 已有 schema、workflow、data 目录、docs 和测试入口。
- 业务边界：原创安全、读者吸引力、长期连载和可验证输出。

## 操作流程

1. 明确目标、当前状态、约束和不可做事项。
2. 拆分业务链路：输入、清洗、拆解、知识、素材、题材、世界、人物、大纲、细纲、正文、审稿、反馈。
3. 先建立文件结构图：每个将创建或修改的文件负责什么、依赖什么、对外提供什么接口。
4. 标记每个任务的输入、输出、涉及文件、接口、验收标准和测试方式。
5. 将任务拆成可独立 review 的最小垂直切片；每个切片必须有自己的测试或验证命令。
6. 按 P0/P1/P2 排序：先闭环、再效率、再增强质量。
7. 标记风险、依赖、阻塞项、rollback 建议和 commit 边界。
8. 输出任务清单、阶段计划和下一步最小可验收动作。
9. 需要代码或数据变更时，交给 Engineering Agent 或对应模块 Agent。

## 输出格式

```markdown
# Project Plan

## 目标
## 当前状态
## 约束与禁止事项
## 文件结构与职责
## 任务池
## 接口与依赖
## P0 路线
## P1 路线
## P2 路线
## 风险与依赖
## 验收标准
## 测试命令
## 回滚建议
## 下一步动作
```

## 质量标准

- 每个任务必须有明确输入、输出和验收标准。
- 工程任务必须列出具体文件路径、接口/函数/数据结构、测试命令和预期结果。
- 每个任务边界必须足够小，能被 reviewer 独立接受或拒绝。
- P0 必须优先服务主链路闭环。
- 不把不可测试的愿景标记为完成任务。
- 计划必须能被后续 Agent 接手。

## 禁止事项

- 禁止用宏大愿景替代可执行任务。
- 禁止一次性重构无关模块。
- 禁止写 `TBD`、`TODO`、`类似上一步`、`补充适当测试` 这类不可执行占位。
- 禁止跳过测试、状态记录或验收标准。
- 禁止把未实现能力写成已完成。

## 与其他模块的关系

- 上游：product docs、roadmap、audit、open issues。
- 下游：task pool、workflow plan、Engineering Agent、Quality Agent。
- Agent：Chief Editor Agent、Engineering Agent、Quality Agent。

````

## S024 skills/prose-generation/SKILL.md

```json
{
  "id": "S024",
  "name": "prose-generation",
  "file": "skills/prose-generation/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "ACTIVE",
  "stage": [
    "draft",
    "revision",
    "screenplay_generate",
    "screenplay_revision"
  ],
  "versions": [
    {
      "ref": "prose-generation",
      "version": "prose-generation-v3",
      "hash": "sha256:7728142f0f7319b4aea1d2ee285e7d792e1212357282a8f76c6c3c54e532fa1d"
    },
    {
      "ref": "prose-generation",
      "version": "prose-generation-v1",
      "hash": "sha256:7728142f0f7319b4aea1d2ee285e7d792e1212357282a8f76c6c3c54e532fa1d"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": true,
  "dynamic_variables": [
    "stage",
    "targeted_edits_only"
  ],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2014,
    "utf8_bytes": 2014,
    "utf8_byte_token_upper_bound": 2014,
    "legacy_bytes_div3_estimate": 672,
    "negative_markers": 5,
    "mandatory_markers": 0
  },
  "sha256": "sha256:ae0e31c4435151294bbf2659cc3deb7743a78668a57788f4157e88c956150bd9"
}
```

完整原文：
````markdown
---
name: prose-generation
description: Draft or revise prose from a frozen Chapter plan and accepted Context.
---

# Prose Generation

## Shared rules

Use the frozen Scene and Slot order, actor and POV scope, accessible knowledge, author intent, and accepted facts. Write a continuous narrative: interleave dialogue, action, perception and thought where the scene needs them, and check scene junctions together. Slot coverage and mechanical joining do not prove literary coherence.

Preserve unaffected prose and established advantages during revision. Resolve evidenced blocking problems without adding unplanned facts. A proposed edit does not amend accepted Canon or the active plan. ReReview and candidate comparison determine whether the candidate is acceptable.

Use cost, pressured choice, growth, reversal, reward and hook techniques when the chapter function, character, arc, author intent or due obligation calls for them. Do not insert them to satisfy a universal template. An explicit author constraint, accepted fact or due obligation remains binding.

Never reuse protected reference expression or let a character act on knowledge outside the frozen boundary. Return only the declared JSON semantic result; the host supplies identities, receipts, spans, persistence and approval.

## Draft and full revision

Write reader-facing prose in each frozen Slot once and return scene_artifacts in the declared order. The host joins Slots into the chapter. Do not return a second whole-chapter copy, a Markdown report or a self-assessed gate result.

## Targeted revision

Return only the necessary ordered edits: exact old quotes, replacement prose and linked issue codes, plus the declared resolution codes. The host disambiguates quotes against the exact frozen old draft, enforces diagnosed ranges and Scene Slot boundaries, and derives Slot and chapter prose. Do not return Slot texts or a complete revised chapter. Preserve all unaffected text exactly and read adjacent passages to check continuity.

````

## S025 skills/prose-generation/legacy-v1.md

```json
{
  "id": "S025",
  "name": "prose-generation",
  "file": "skills/prose-generation/legacy-v1.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "LEGACY",
  "stage": [
    "draft",
    "revision",
    "screenplay_generate",
    "screenplay_revision"
  ],
  "versions": [
    {
      "ref": "prose-generation",
      "version": "prose-generation-v1",
      "hash": "sha256:c9436cb57637cac0d788d22699727b9ecf6fee1bede01da9f8fc41e3df7c4c11"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": true,
  "dynamic_variables": [
    "stage",
    "targeted_edits_only"
  ],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1608,
    "utf8_bytes": 2912,
    "utf8_byte_token_upper_bound": 2912,
    "legacy_bytes_div3_estimate": 971,
    "negative_markers": 7,
    "mandatory_markers": 10
  },
  "sha256": "sha256:4e5ca7a08841ae4384585f1385851406fb08a92972eba0c035b985bed7c7616c"
}
```

完整原文：
````markdown
---
name: prose-generation
description: Use when drafting chapter prose from an approved chapter plan while controlling web-novel pacing, dialogue, action, emotion, narrative density, chapter hooks, and post-draft self-checks.
---

# Prose Generation

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 根据已通过检查的 ChapterPlan 生成正文 v0 或修订稿。
- 将场景目标、冲突、行动和情绪变化转化为可审稿文本。
- DeepSeek 或其他正文模型需要明确写作边界时。

## 输入要求

- 已通过 `chapter-outline` 检查的 ChapterPlan。
- 项目上下文、人物状态、世界规则、风格规则和本章审稿重点。
- 禁止复用内容和原创风险边界。

## 操作流程

1. 读取细纲，不新增未经授权的主线设定。
2. 按场景顺序写作，先行动和冲突，后解释设定。
3. 控制叙述密度：每个场景必须有信息增量或情绪变化。
4. 通过对白、动作、选择和代价体现人物。
5. 确保爽点通过行动兑现，结尾留下追读钩子。
6. 生成后自检章节功能是否完成。
7. 输出正文草稿和自检报告，不直接标记为 final。

## 输出格式

```markdown
# 第 N 章正文 v0

## 正文

## 自检

- 是否完成本章目标：
- 是否有明确冲突：
- 是否有信息增量：
- 是否有读者爽点：
- 是否有代价：
- 是否有结尾钩子：
- 是否存在原创风险：
- 是否存在 AI 腔：
```

## 质量标准

- 正文必须严格服务细纲，不能脱纲扩展新主线。
- 开头必须尽快进入异常、冲突或压力。
- 每章结尾必须给出下一章阅读理由。
- 解释不能压过行动，多学科知识只能服务可信度。
- 生成稿必须进入 `quality-review`，不能直接进入 final。

## 禁止事项

- 禁止无细纲生成正文。
- 禁止覆盖 final 或发布稿。
- 禁止复制热门小说表达、桥段、人物或独特设定。
- 禁止用总结式 AI 腔替代场景推进。

## 与其他模块的关系

- 上游：`chapter-outline`、ChapterPlan、MockModel 或未来 Draft adapter。
- 下游：`quality-review`、ReviewReport、RevisionPlan。
- Agent：Draft Agent、Review Agent、Quality Agent。

````

## S026 skills/prose-generation/legacy-v2.md

```json
{
  "id": "S026",
  "name": "prose-generation",
  "file": "skills/prose-generation/legacy-v2.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "LEGACY",
  "stage": [
    "draft",
    "revision",
    "screenplay_generate",
    "screenplay_revision"
  ],
  "versions": [
    {
      "ref": "prose-generation",
      "version": "prose-generation-v2",
      "hash": "sha256:d75cd005721bbee04002324830ea9ab6b7a896d3ddcac4e0db961cf72a545ca1"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": true,
  "dynamic_variables": [
    "stage",
    "targeted_edits_only"
  ],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1153,
    "utf8_bytes": 1153,
    "utf8_byte_token_upper_bound": 1153,
    "legacy_bytes_div3_estimate": 385,
    "negative_markers": 3,
    "mandatory_markers": 0
  },
  "sha256": "sha256:cfc3e878aef3da772a21c6e2e23eb08b3275499f3a2f742e9d2ee04c66ed3c05"
}
```

完整原文：
````markdown
---
name: prose-generation
description: Draft or revise prose from a frozen Chapter plan and accepted Context.
---

# Prose Generation

Use the frozen Scene and Slot order, actor and POV scope, accessible knowledge, author intent, and accepted facts. Write reader-facing prose in each selected Slot once. The host joins Slots into the chapter; do not return a second whole-chapter copy, a Markdown report, or a self-assessed gate result.

For revision, preserve unaffected prose and established advantages. Resolve evidenced blocking problems without adding unplanned facts. A proposed edit does not amend accepted Canon or the active plan.

Use cost, growth, reversal, reward, and hook techniques when the chapter function, character, arc, author intent, or due obligation calls for them. Do not insert them to satisfy a universal template. An explicit author constraint, accepted fact, or due obligation remains binding.

Never reuse protected reference expression or let a character act on knowledge outside the frozen boundary. Return only the declared JSON semantic result; the host supplies identities, receipts, spans, persistence, and approval.

````

## S027 skills/provider-runtime-policy/SKILL.md

```json
{
  "id": "S027",
  "name": "provider-runtime-policy",
  "file": "skills/provider-runtime-policy/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2570,
    "utf8_bytes": 3268,
    "utf8_byte_token_upper_bound": 3268,
    "legacy_bytes_div3_estimate": 1090,
    "negative_markers": 6,
    "mandatory_markers": 4
  },
  "sha256": "sha256:09ad47387807d718628ae952364a6acd95738c0dc071db5f73675c8024e8997f"
}
```

完整原文：
````markdown
---
name: provider-runtime-policy
description: Use when designing, reviewing, or debugging model provider routing, runtime profiles, model hard-stop behavior, fallback approval, timeout, token/cost budgets, model_call_log, cost_ledger, or provider-neutral execution in Novel Forge.
---

# Provider Runtime Policy

## 适用场景

- 设计或审计模型 provider、runtime profile、model routing、fallback 和 hard-stop。
- 检查 `model_call_log`、`cost_ledger`、token budget、timeout、SLA 和 retry 记录。
- 判断 Claude、OpenAI、local/mock provider 或兼容 provider 是否能进入生产链路。

## 输入要求

- task、flow、runtime environment、provider、model、runtime profile 和 provider policy。
- token budget、cost budget、timeout、retry、fallback approval、trace_id 和 workspace/project id。
- `model_call_log`、`cost_ledger`、AgentRun、GateResult、ReviewIssue 或测试证据。

## Novel OS Runtime Contract

- production / strict / operating_system 路径缺 provider policy、budget 或 model_call_log 时必须 fail closed。
- provider timeout、refusal、cancel、budget exceeded、quota exceeded、schema failure 都必须记录为 hard-stop 或显式 approved fallback。
- fallback 不能 silent；必须记录原 provider、失败原因、批准主体、替代 provider、成本影响和质量 gate。
- mock / deterministic provider 只能标记为 fixture、compat 或 test，不得伪装为 production model coverage。

## 操作流程

1. 识别目标 flow 的 provider 需求、预算边界、上下文大小和质量门槛。
2. 检查 runtime profile 是否声明 provider、model、timeout、retry、fallback 和 cost policy。
3. 检查 model call 是否写入 trace、model_call_log、cost_ledger、input/output token 和 stop reason。
4. 判断失败是否应 retry、fallback、human_review、block 或 dead_letter。
5. 将 provider 风险转成 GateResult、ReviewIssue 或 AgentRun recovery instruction。
6. 输出 provider runtime policy report 和测试/证据缺口。

## 输出格式

```markdown
# Provider Runtime Policy Report

## Contract
- flow:
- provider:
- model:
- runtime profile:
- budget:

## Calls
- model_call_log:
- cost_ledger:
- stop/hard-stop:

## Fallback
- allowed:
- approval:
- audit refs:

## Gate
- result:
- blocking issues:
- tests:
```

## 质量标准

- 每个生产 model call 都能反查 provider、model、prompt/context source、token、cost 和 trace。
- provider failure 不产生隐式可发布内容。
- fallback 结果必须重新进入 schema validation、quality gate 和 source isolation gate。

## 禁止事项

- 禁止 silent fallback。
- 禁止把 mock provider 结果标记为真实生产输出。
- 禁止因 provider 成功返回就跳过 schema、ReviewIssue、ContextBundle 或 Publish Gate。
- 禁止在报告、日志或配置中写入 API key、token、cookie 或 secret。

## 与其他模块的关系

- 上游：Runtime Profile、AgentRun、ContextBundle、provider adapter、model_call_log、cost_ledger。
- 下游：Quality Qualification、ReviewIssue Gate、Agent Runtime、Publish Gate、Authority API/admin projection。
- 关联 Skill：`agent-loop-governance`、`review-issue-gate`、`novel-os-engineering-audit`。

````

## S028 skills/publish-release-gate-os/SKILL.md

```json
{
  "id": "S028",
  "name": "publish-release-gate-os",
  "file": "skills/publish-release-gate-os/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2690,
    "utf8_bytes": 3410,
    "utf8_byte_token_upper_bound": 3410,
    "legacy_bytes_div3_estimate": 1137,
    "negative_markers": 6,
    "mandatory_markers": 6
  },
  "sha256": "sha256:f0a59f6399b9f0d1b0dd08dba220d8479c3797b6b21e6adc32245b457d2d9c1f"
}
```

完整原文：
````markdown
---
name: publish-release-gate-os
description: Use when preparing, reviewing, or blocking a Novel Forge release package, publish gate report, platform publish plan, title/summary/hook/schedule, chapter finalization, or post-publish invalidation/resume workflow.
---

# Publish Release Gate OS

## 适用场景

- 检查 DraftChapter、revised draft、canonical chapter 或 release package 是否可以发布。
- 生成 publish gate report、platform publish plan、title/summary/hook/schedule 检查和 release readiness。
- 审计发布前的 ReviewIssue、source isolation、canon continuity、provider/cost trace 和 rollback/resume 证据。

## 输入要求

- release target、platform profile、canonical candidate、ReviewIssue 列表、GateResult、ContextBundle、KnowledgePack。
- Canon continuity report、quality review、provider runtime evidence、model_call_log、cost_ledger。
- title、summary、opening hook、chapter hook、schedule、publish adapter 和 rollback plan。

## Novel OS Runtime Contract

- ReleasePackage 必须引用 accepted asset versions、context_bundle_id、knowledge_pack_id、gate results、model_call_log 和 cost_ledger。
- 未解决 blocking ReviewIssue、canon conflict、source leakage、provider hard-stop 或 platform policy risk 必须阻断发布。
- 发布 gate 只能接受 schema-backed artifacts，不能只接受聊天文本或未验证 Markdown。
- 发布后 invalidation、resume 和 feedback backflow 必须创建新版本或事件记录，不得覆盖历史。

## 操作流程

1. 收集候选 release package 和全部上游 gate evidence。
2. 检查 source isolation、canon continuity、quality review、platform fit、provider runtime 和 cost ledger。
3. 检查 title、summary、chapter hook、schedule 和平台发布适配是否匹配 release target。
4. 将风险归类为 block、revise、warn、human_review 或 accept。
5. 生成 PublishGateReport、ReleasePackage decision、rollback/resume instruction。
6. 若发布后反馈需要回流，生成 FeedbackBackflow 和 MKAOS advisory learning 建议。

## 输出格式

```markdown
# Publish Release Gate Report

## Release
- target:
- candidate:
- platform:
- schedule:

## Evidence
- context bundle:
- knowledge pack:
- review issues:
- canon gate:
- provider/cost:

## Publishing Checks
- title:
- summary:
- hook:
- platform fit:

## Decision
- result:
- blockers:
- warnings:
- rollback/resume:
```

## 质量标准

- 任何 accepted release 都必须能从 release package 反查上游资产、gate 和 trace。
- blocking issue 必须阻断 canonical release 和 publish package。
- 发布建议必须区分平台优化、质量修订和合规/原创阻断。

## 禁止事项

- 禁止发布未审稿、未过 source isolation 或存在 blocking issue 的内容。
- 禁止用手写发布摘要替代 release package。
- 禁止发布后直接覆盖历史章节或 gate result。
- 禁止为平台表现牺牲版权边界、正典一致性或 provider hard-stop。

## 与其他模块的关系

- 上游：Draft/Revision、ReviewIssue Gate、Canon Graph、Context Builder、Platform Strategy、Provider Runtime Policy。
- 下游：Publishing log、Feedback Backflow、Authority API/admin projection、MKAOS learning、Resume/Invalidation。
- 关联 Skill：`platform-strategy-os`、`review-issue-gate`、`canon-continuity-graph`、`provider-runtime-policy`。

````

## S029 skills/published-fiction-craft-analysis/SKILL.md

```json
{
  "id": "S029",
  "name": "published-fiction-craft-analysis",
  "file": "skills/published-fiction-craft-analysis/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "source.deconstruction.observe"
  ],
  "versions": [
    {
      "ref": "published-fiction-craft-analysis",
      "version": "1.0.0",
      "hash": "sha256:ffcbead275b93bff7942dd72bf1c142f37ab94d88dc13b4865822a64f2dafdae",
      "binding": "SourceMethodologyRegistry; separate from chapter-generation Pack"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only. Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1764,
    "utf8_bytes": 2226,
    "utf8_byte_token_upper_bound": 2226,
    "legacy_bytes_div3_estimate": 742,
    "negative_markers": 6,
    "mandatory_markers": 5
  },
  "sha256": "sha256:ffcbead275b93bff7942dd72bf1c142f37ab94d88dc13b4865822a64f2dafdae"
}
```

完整原文：
````markdown
---
name: published-fiction-craft-analysis
description: Analyze published fiction references into abstract scene craft, narrative distance, character arc, subtext, and transferable technique reports.
---

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

用于拆解出版小说的技法层：场景经营、叙事距离、角色弧光、转场、潜台词和语言纹理。只保留技法参数，不模仿具体作者。

## 输入要求

- schema-backed source asset path.
- project workspace path when available.
- source rights and copyright boundary.
- desired craft focus if available.

## 操作流程

1. Read the referenced source asset by path.
2. Separate scene objective, obstacle, turn, after-effect, character belief pressure, and narrative distance.
3. Remove source-specific characters, scenes, prose texture, and sequence.
4. Produce `published_fiction_analysis_report`.
5. Record validation status and copyright boundary.

## 输出格式

Write one JSON asset with type `published_fiction_analysis_report` under `data/analysis`.

## 质量标准

- Report passes schema validation.
- Output stays at craft-parameter level.
- `metadata.use_in_generation_rag` is `false`.
- No specific author imitation request appears.

## 禁止事项

- Do not copy protected text.
- Do not imitate a specific author.
- Do not write draft prose.
- Do not preserve source-specific scene order.

## 与其他模块的关系

Output can be converted into `craft_template`, `writing_template`, or `review_rule_pack` before use in production.

````

## S030 skills/quality-review/SKILL.md

```json
{
  "id": "S030",
  "name": "quality-review",
  "file": "skills/quality-review/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "ACTIVE",
  "stage": [
    "longform_prose_review",
    "narrative_semantic_evaluation",
    "quality_commercial",
    "quality_longform",
    "quality_platform",
    "quality_source_originality",
    "quality_structural",
    "rereview",
    "review",
    "screenplay_review"
  ],
  "versions": [
    {
      "ref": "quality-review",
      "version": "quality-review-v2",
      "hash": "sha256:31ac64c42c096be535787d5c54da17852dcb3418bafa6e239a7d545d4541c8a5"
    },
    {
      "ref": "quality-review",
      "version": "quality-review-v1",
      "hash": "sha256:31ac64c42c096be535787d5c54da17852dcb3418bafa6e239a7d545d4541c8a5"
    },
    {
      "ref": "quality-review",
      "version": "quality-review-narrative-evaluator-v1",
      "hash": "sha256:31ac64c42c096be535787d5c54da17852dcb3418bafa6e239a7d545d4541c8a5"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1030,
    "utf8_bytes": 1030,
    "utf8_byte_token_upper_bound": 1030,
    "legacy_bytes_div3_estimate": 344,
    "negative_markers": 2,
    "mandatory_markers": 0
  },
  "sha256": "sha256:c278970af4057ff3c98318648be312a051da6060acc7102e4011f5bd1daa8a14"
}
```

完整原文：
````markdown
---
name: quality-review
description: Review the exact candidate or evaluate a requested quality dimension.
---

# Quality Review

Judge the actual prose against its frozen author intent, accepted facts, character knowledge, scene function, and due narrative obligations. Distinguish a semantic conflict from an uncertain reading or aesthetic suggestion. Preserve what works when proposing a revision.

Quote exact words that support each finding. The host locates Unicode spans and binds the candidate version. A quote's presence is not semantic proof; explain the causal or narrative support. If the text lacks support, report uncertainty or an unresolved issue instead of inventing evidence.

Assess cost, growth, reversal, reward, and hook only when the current chapter or explicit author and obligation contracts call for them. Do not penalize a chapter merely for omitting an inapplicable technique. Never claim reader or human approval, Canon mutation, or release qualification. Return the declared JSON semantic judgment.

````

## S031 skills/quality-review/legacy-v1.md

```json
{
  "id": "S031",
  "name": "quality-review",
  "file": "skills/quality-review/legacy-v1.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "LEGACY",
  "stage": [
    "longform_prose_review",
    "narrative_semantic_evaluation",
    "quality_commercial",
    "quality_longform",
    "quality_platform",
    "quality_source_originality",
    "quality_structural",
    "rereview",
    "review",
    "screenplay_review"
  ],
  "versions": [
    {
      "ref": "quality-review",
      "version": "quality-review-v1",
      "hash": "sha256:27d5dbd40de81ddcefc90d20a2ead047903e7ca29eebef6a9ab3f28dfd156e23"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 2404,
    "utf8_bytes": 3964,
    "utf8_byte_token_upper_bound": 3964,
    "legacy_bytes_div3_estimate": 1322,
    "negative_markers": 9,
    "mandatory_markers": 10
  },
  "sha256": "sha256:d8ada86b028cbc5e921d0aed88cd691884cc89fd0799b36d86e1c3b24d868496"
}
```

完整原文：
````markdown
---
name: quality-review
description: Use when reviewing topics, worlds, characters, outlines, chapter plans, drafts, revisions, or feedback decisions for logic gaps, consistency, pacing, payoff density, hooks, foreshadowing, commercial weakness, and originality risk.
---

# Quality Review

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 审查题材、世界观、人物、大纲、细纲、正文或反馈采纳方案。
- 正文草稿进入修订或 final 前。
- 判断是否通过、小修、重修、退回细纲或暂停。
- 审核 Commercial Quality 中已有的 `golden_opening`、`reader_promise`、`reward`、`chapter_hook`、`suspense_progression`、`emotional_curve` 和 `serialization_function`，并消费而非重复实现 `HookAnalysis` / `PacingObservation`。

## 输入要求

- 审稿对象文件路径、schema 类型和版本。
- 上游依据：TopicSeed、WorldBible、CharacterCard、Outline、ChapterPlan 或 DraftChapter。
- 原创风险边界、读者吸引力目标和当前验收标准。

## 操作流程

1. 标记审稿对象、版本、输入依据和输出位置。
2. 先查 P0：原创风险、设定崩坏、严重逻辑断裂。
3. 再查 P1：读者吸引力、冲突、爽点、结尾追读。
4. 检查人物动机链、因果链、世界规则、伏笔设置与回收。
5. 检查 HookAnalysis 的 opening/ending hook、promise binding、horizon、evidence lineage；检查 PacingObservation 的多尺度窗口和 qualification。
6. 将明确结构化状态的确定性测量与 provider semantic judgment 分开，禁止用关键词/英文正则代替节奏质量判断。
7. 检查节奏、叙述密度、AI 腔、对白差异和商业化弱点。
8. 给出评分、优先级、是否退回和可执行修改建议。
9. 明确哪些内容不建议改，避免破坏已有优势。

## 输出格式

```markdown
# Quality Review

## 审稿对象
## 版本
## 总分
## 结论
通过 / 小修 / 重修 / 退回细纲 / 暂停
## P0 问题
## P1 问题
## Hook / Promise 证据
## Multi-scale Pacing 诊断
## P2 问题
## P3 问题
## P4 问题
## 可执行修改建议
## 不建议修改内容
## 是否需要主编决策
```

## 质量标准

- 审稿必须区分问题优先级。
- 修改建议必须能直接转成任务或 RevisionPlan。
- 不能只给泛泛评价，必须指出具体问题类型。
- 商业追读和原创边界优先于炫技式设定补完。
- Semantic observation 必须带 evidence、confidence 和 qualification；deterministic aggregate 必须能重放且不得读取未来章节。

## 禁止事项

- 禁止直接覆盖正文终稿。
- 禁止降低原创风险标准。
- 禁止用多学科合理性压制章节爽点。
- 禁止建议突破世界规则或核心人物逻辑。
- 禁止用简单关键词、标点或字面模式宣称节奏质量、情绪合理性或 hook strength 已被确定性证明。

## 与其他模块的关系

- 上游：全部生成资产、`anti-copy-abstraction`、evaluation rubric、`hook.analyze`、`pacing.analyze`、`pacing.aggregate`。
- 下游：ReviewReport、RevisionPlan、FeedbackInsight。
- 关联 Skill：`multi-scale-pacing`、`narrative-beat-design`、`canon-continuity-graph`。
- Agent：Review Agent、Quality Agent、Chief Editor Agent。

````

## S032 skills/reader-feedback/SKILL.md

```json
{
  "id": "S032",
  "name": "reader-feedback",
  "file": "skills/reader-feedback/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "reader_outcome"
  ],
  "versions": [
    {
      "ref": "reader-feedback",
      "version": "reader-feedback-v1",
      "hash": "sha256:1a46be4bd03d15ab5ff9aca58a0d4a849cac466f51af89fbcb46c200240bc7b3"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1676,
    "utf8_bytes": 2904,
    "utf8_byte_token_upper_bound": 2904,
    "legacy_bytes_div3_estimate": 968,
    "negative_markers": 6,
    "mandatory_markers": 9
  },
  "sha256": "sha256:4e050589d442a819970144f6b699aaf65bb306022851b840e1ac07a4594530bc"
}
```

完整原文：
````markdown
---
name: reader-feedback
description: Use when importing, classifying, interpreting, or applying reader feedback so comments improve future chapters without breaking project boundaries, character arcs, world rules, or the main conflict.
---

# Reader Feedback

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 导入评论、评分、读者反馈或测试读者意见后。
- 需要判断反馈应观察、采纳、延后还是拒绝。
- 需要把反馈反哺到后续章节、RevisionPlan 或 FeedbackInsight。

## 输入要求

- ReaderFeedback 或评论来源、时间、章节范围和样本数量。
- 当前 TopicSeed、Outline、ChapterPlan、DraftChapter 或 ReviewReport。
- 项目边界、世界规则、人物成长线和不可修改项。

## 操作流程

1. 按来源、章节、评分、情绪和主题归类反馈。
2. 区分 S/A/B/C 级反馈：主线风险、追读问题、局部体验、噪声。
3. 提取重复出现的读者信号，不被单条评论牵引。
4. 判断反馈影响范围：下一章、未来 3-10 章、卷纲、长期规则或不采纳。
5. 检查是否突破角色弧、世界规则、原创边界或主线承诺。
6. 输出 FeedbackInsight 和可执行后续约束。
7. 将重大调整交给 `quality-review` 或 Chief Editor Agent 决策。

## 输出格式

```markdown
# Reader Feedback Insight

## 来源与范围
## 样本概况
## 高频信号
## 反馈分级
## 可采纳项
## 暂缓观察项
## 不采纳项
## 影响范围
## 后续章节约束
## 是否需要主编决策
```

## 质量标准

- 必须区分高频信号和单条噪声。
- 必须说明采纳反馈的影响范围。
- 必须保护项目核心承诺、人物成长线和世界规则。
- 必须输出可执行调整，不只复述评论。

## 禁止事项

- 禁止让评论直接修改项目核心规则。
- 禁止让高人气配角抢走主角成长线。
- 禁止为短期爽感破坏长期代价机制。
- 禁止把读者原话直接当正文素材。

## 与其他模块的关系

- 上游：`import-feedback`、`analyze-feedback`、ReaderFeedback。
- 下游：FeedbackInsight、RevisionPlan、`quality-review`。
- Agent：Feedback Agent、Chief Editor Agent、Quality Agent。

````

## S033 skills/review-issue-gate/SKILL.md

```json
{
  "id": "S033",
  "name": "review-issue-gate",
  "file": "skills/review-issue-gate/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2167,
    "utf8_bytes": 2783,
    "utf8_byte_token_upper_bound": 2783,
    "legacy_bytes_div3_estimate": 928,
    "negative_markers": 4,
    "mandatory_markers": 6
  },
  "sha256": "sha256:2a1a0efd8c72f2fb5478e793c6517b95af2973078e30f06c14a03c6f528140f2"
}
```

完整原文：
````markdown
---
name: review-issue-gate
description: Use when validation, canon conflict, source leakage, MKAOS risk, evaluation failure, platform risk, or review findings must become structured ReviewIssue records and blocking gates.
---

# Review Issue Gate

## 适用场景

- 将 MKAOS validate、canon conflict、source leakage、evaluation gate、publish gate 或 review report 输出转成 ReviewIssue。
- 判断 canonical chapter、release package、publish gate、revision loop 是否应被阻断。
- 生成 RevisionTask candidate 和 re-review criteria。

## 输入要求

- target asset、flow、severity、issue type、blocking policy、related knowledge ids、context bundle id、knowledge pack id。
- 当前 gate policy、runtime environment、resolved issue 列表和 release target。
- 证据引用，不包含受保护原文。

## Novel OS Runtime Contract

- high / critical 的 source_leakage、canon_conflict、knowledge_conflict、platform_policy_risk 必须结构化为 ReviewIssue。
- critical 默认 blocking；high 是否 blocking 由 gate policy 决定。
- blocking ReviewIssue 必须阻断 canonical draft、release package 和 publish gate。
- resolved 后才能重新通过 gate；不能通过报告文字绕过。

## 操作流程

1. 标准化 issue type、severity、blocking、target asset 和 related knowledge。
2. 为每个 issue 绑定 evidence refs、context bundle、knowledge pack、AgentRun 或 gate report。
3. 创建或更新 ReviewIssue，避免重复但保留历史。
4. 计算 GateResult：continue、revise、block 或 human_review。
5. 为可修复 issue 生成 RevisionTask candidate 和 re-review criteria。
6. 将 blocking 状态暴露给 Command Kernel、Publish Gate、Authority API/admin projection。

## 输出格式

```markdown
# Review Issue Gate Report

## Issues
- id:
- type:
- severity:
- blocking:
- target:
- related knowledge:

## Gate
- result:
- blocked flows:
- revision tasks:
- resolution criteria:
```

## 质量标准

- issue 必须可追溯到证据、资产、上下文、知识包和 gate。
- 阻断必须可被测试证明，而不是只存在报告里。
- 每个 RevisionTask 都必须有 forbidden changes 和 re-review criteria。

## 禁止事项

- 禁止把 blocking issue 只写在 markdown 报告里。
- 禁止发布或 canonical 化存在未解决 blocking issue 的资产。
- 禁止用低严重级别掩盖 source leakage、canon conflict 或平台强违规。

## 与其他模块的关系

- 上游：Quality Review、MKAOS Gate、Canon Graph、Quality Qualification、Platform Strategy。
- 下游：Command Kernel、RevisionTask、Publish Gate、Release Package、Authority API/admin projection。
- 关联 Skill：`quality-review`、`agent-loop-governance`、`platform-strategy-os`。

````

## S034 skills/skill-governance/SKILL.md

```json
{
  "id": "S034",
  "name": "skill-governance",
  "file": "skills/skill-governance/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2608,
    "utf8_bytes": 3680,
    "utf8_byte_token_upper_bound": 3680,
    "legacy_bytes_div3_estimate": 1227,
    "negative_markers": 8,
    "mandatory_markers": 4
  },
  "sha256": "sha256:ffecfa91592be04f911e007be7764dfda1153bdbcbe1bfdfa23db3053c939980"
}
```

完整原文：
````markdown
---
name: skill-governance
description: Use when creating, revising, auditing, syncing, pruning, or adopting Novel Forge project Skills so each Skill remains predictable, single-source-of-truth, progressively disclosed, trigger-safe, license-safe, and aligned with Novel OS runtime boundaries.
---

# Skill Governance

## Novel OS Runtime Contract

- 项目源 Skill 必须维护在 root `skills/`，`.claude/skills/` 只能由 sync 生成或保留 runtime/vendor 工具 Skill。
- 生产相关 Skill 必须包含 Novel OS Runtime Contract，并明确 schema-backed output、Context Builder、Knowledge Pack、ReviewIssue、GateResult、source isolation 和 traceability。
- 外部 Skill 不得直接进入 root `skills/`，除非记录 source、license、scripts、dependencies、network/provider behavior 和 verification。
- Skill 治理只更新仍有长期价值的最小文件：root Skill、`AGENTS.md` 或 `docs/development.md`。不要生成 session-level 审计报告。

## 适用场景

- 新建或更新 project Skill。
- 审计 Skill 是否可预测、触发清晰、无重复、无 runtime drift。
- 判断外部 Skill 是否能 vendor、应改写吸收，还是只保留为 runtime-only。
- 调整 Skill Map、同步 `.claude/skills`、处理许可证或外部工具边界。

## 输入要求

- 目标 Skill 名称、任务上下文、相关 Agent、已有 `skills/<name>/SKILL.md`。
- 外部来源时需提供 source path/URL、license、scripts、references、dependencies、network/provider behavior。
- 相关 docs：`AGENTS.md`、`docs/development.md`。

## 操作流程

1. 明确 invocation：这个 Skill 是否需要 agent 自动触发，还是只该留在文档/外部个人工具中。
2. 检查 description：只写真实触发分支，避免泛化抢占其他 Skill。
3. 检查 single source of truth：同一规则只放一处；其他文件只引用或总结。
4. 检查 progressive disclosure：核心步骤放 `SKILL.md`，长 reference 才拆文件；不要为短 Skill 加无用资源。
5. 检查 predictability：每个流程有可检查完成条件，避免“写得更好”这类不可验收目标。
6. 检查 Novel OS boundary：schema、gate、trace、source isolation、provider/runtime、copyright 是否完整。
7. 更新 root Skill 和最小必要的长期规则文件；再执行 sync dry-run、sync、check。

## 输出格式

```markdown
# Skill Governance Report

## Decision
- skill:
- action:
- source:
- license:

## Trigger Boundary
- model-invoked:
- overlaps:
- protected routes:

## Runtime Boundary
- schema:
- source isolation:
- gate:
- sync:

## Verification
- quick validate:
- sync dry-run:
- check-skills:
- diff check:
```

## 质量标准

- Skill 必须短而可执行，优先流程和边界，少写泛泛理论。
- 每个项目 Skill 只能有一个 canonical root copy。
- 外部 Skill 方法论应改写为 Novel OS 语境，不直接复制不明许可证内容。
- Skill 更新后必须能通过 frontmatter 校验、`make sync-skills-dry-run`、`make check-skills` 和 `git diff --check`。

## 禁止事项

- 禁止直接手工编辑 `.claude/skills` 作为源。
- 禁止把外部 Skill 原样 vendor 到 root `skills/` 而不做许可证和边界审查。
- 禁止创建与既有 Skill 触发重叠但职责不清的新 Skill。
- 禁止让 Skill 绕过 AGENTS.md、schema validation、Runtime Policy、ReviewIssue 或 gate。

## 与其他模块的关系

- 上游：Skill audit、external Skill intake、Agent-Skill map、usage policy。
- 下游：root `skills/`、`.claude/skills` runtime copy、Agent routing。
- Agent：Engineering Agent、Quality Agent、Chief Editor Agent。

````

## S035 skills/topic-development/SKILL.md

```json
{
  "id": "S035",
  "name": "topic-development",
  "file": "skills/topic-development/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "creative.candidates.generate"
  ],
  "versions": [
    {
      "ref": "topic-development",
      "version": "topic-development-qualification-v1",
      "hash": "sha256:9766801ae782b1c3561e0dfc3604571c66882c6584011f957f4c4ad99a8b5893"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1766,
    "utf8_bytes": 3118,
    "utf8_byte_token_upper_bound": 3118,
    "legacy_bytes_div3_estimate": 1040,
    "negative_markers": 6,
    "mandatory_markers": 9
  },
  "sha256": "sha256:34d9235996a0b45808e3183204954a13db0601ef8d7eac7eeb12c7be01f1261e"
}
```

完整原文：
````markdown
---
name: topic-development
description: Use when developing or reviewing a novel topic from abstract patterns, market position, genre fusion, premise generation, and trope variation so the topic has reader appeal, differentiation, and originality boundaries.
---

# Topic Development

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 从 KnowledgeCard、MaterialCard 或抽象拆解结果生成 TopicSeed。
- 判断题材卖点、目标读者、平台适配和差异化。
- 将常见套路转化为原创变体，而不是复刻流行作品。

## 输入要求

- 已通过 `anti-copy-abstraction` 的抽象机制或 MaterialCard。
- 目标读者、平台假设、类型方向和禁用内容。
- 已有相似项目、同质化风险或市场定位约束。

## 操作流程

1. 明确类型基础：玄幻、悬疑、都市、科幻、历史或混合类型。
2. 提炼核心吸引力：主角代入、开局异常、压迫、反击承诺、爽点。
3. 做题材融合：只融合能制造冲突和读者期待的类型机制。
4. 生成一句话 premise：主角、异常、目标、阻力、代价。
5. 做套路变体：保留读者熟悉的期待，替换身份、资源、压力源或冲突场。
6. 检查市场定位：目标读者、平台适配、前 3 章钩子、前 10 章回报。
7. 输出 TopicSeed 候选和原创风险边界。

## 输出格式

```markdown
# Topic Development

## 类型组合
## 目标读者
## 一句话核心创意
## 核心卖点
## 开局异常
## 主角代入点
## 初始压迫
## 爽点承诺
## 前 3 章钩子
## 前 10 章回报
## 差异化设计
## 原创风险边界
## 是否进入世界观/人物设计
```

## 质量标准

- 题材必须能支撑主线冲突和长期连载。
- premise 必须清楚说明主角为什么非行动不可。
- 差异化必须具体，不只写“融合”“创新”。
- 每个套路变体必须避开具体作品的人物、设定、桥段组合。

## 禁止事项

- 禁止直接生成“某作品换皮”题材。
- 禁止只堆类型标签，没有读者承诺。
- 禁止为了新奇牺牲可读性和追读动力。
- 禁止让题材创意绕过 `anti-copy-abstraction`。

## 与其他模块的关系

- 上游：`hot-novel-deconstruction`、`anti-copy-abstraction`、MaterialCard。
- 下游：TopicSeed、`worldbuilding`、`character-design`、`long-outline`。
- Agent：Chief Editor Agent、Material Agent、Outline Agent。

````

## S036 skills/training-exercise/SKILL.md

```json
{
  "id": "S036",
  "name": "training-exercise",
  "file": "skills/training-exercise/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 1579,
    "utf8_bytes": 2961,
    "utf8_byte_token_upper_bound": 2961,
    "legacy_bytes_div3_estimate": 987,
    "negative_markers": 7,
    "mandatory_markers": 8
  },
  "sha256": "sha256:930e8d89a62ad90717344d2236f750202e708f6369ac1304565adf688641cd8d"
}
```

完整原文：
````markdown
---
name: training-exercise
description: Use when designing or reviewing writing, reading-comprehension, translation, or correction-rubric exercises so training tasks produce clear goals, structure, model answers, evaluation criteria, and reusable learning points.
---

# Training Exercise

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 设计作文训练、阅读理解训练、翻译练习或批改标准。
- 将小说工厂中的结构、节奏、人物、逻辑和表达能力转化为训练题。
- 审查训练题是否有明确目标、答案标准和能力点。

## 输入要求

- 训练目标、对象水平、题型、篇幅或时间限制。
- 可用知识点、示例材料或技能目标。
- 禁止内容和版权边界。

## 操作流程

1. 明确训练目标：立意、结构、论证、阅读理解、翻译或修辞表达。
2. 拆分能力点：题目理解、信息提取、逻辑组织、语言表达、审稿修订。
3. 设计题干和输入材料，避免使用未授权长文本。
4. 输出作答要求、评分维度、常见错误和优秀答案特征。
5. 如需示例答案，只给短样例或结构说明，不复制版权材料。
6. 设计批改 rubric 和下一步练习建议。
7. 将训练结果和小说生产能力关联，例如钩子、冲突、情绪推进或逻辑链。

## 输出格式

```markdown
# Training Exercise

## 训练目标
## 适用对象
## 题干
## 输入材料
## 作答要求
## 能力点
## 评分标准
## 常见错误
## 优秀答案特征
## 批改建议
## 下一步训练
```

## 质量标准

- 训练题必须有清晰能力目标。
- 评分标准必须可执行，不只写“语言优美”。
- 阅读或翻译材料必须遵守版权和篇幅边界。
- 训练结果应能反哺写作、审稿或表达能力。

## 禁止事项

- 禁止复制长篇版权文本作为训练材料。
- 禁止只有题目没有评分标准。
- 禁止把训练题做成泛泛鸡汤或空泛模板。
- 禁止输出现实高风险、违法或不安全操作训练。

## 与其他模块的关系

- 上游：KnowledgeCard、MaterialCard、ReviewReport、用户训练目标。
- 下游：TrainingExercise、质量评估、写作能力改进。
- Agent：Chief Editor Agent、Quality Agent、Review Agent。

````

## S037 skills/world-consequence-modeling/SKILL.md

```json
{
  "id": "S037",
  "name": "world-consequence-modeling",
  "file": "skills/world-consequence-modeling/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": false,
  "status": "UNREACHABLE",
  "stage": [],
  "versions": [],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": false,
  "metrics": {
    "characters": 2491,
    "utf8_bytes": 3431,
    "utf8_byte_token_upper_bound": 3431,
    "legacy_bytes_div3_estimate": 1144,
    "negative_markers": 6,
    "mandatory_markers": 5
  },
  "sha256": "sha256:0a88ff4679894cd4e90273821057f25e84811652d64d3de5deb987fb94b8d6c5"
}
```

完整原文：
````markdown
---
name: world-consequence-modeling
description: Use when deriving long-term economic, political, military, infrastructural, technological, religious, educational, criminal, class, geographic, cultural, or generational consequences from accepted world rules.
---

# World Consequence Modeling

## Novel OS Runtime Contract

- `worldbuilding` 定义世界规则；本 Skill 推演规则长期存在的后果，不创建第二套 WorldBible 或 Canon Graph。
- 正式 provider 输出必须经 `world.consequence.analyze`，保留 input WorldRule / WorldBible version、provider receipt、trace、qualification 和 evidence。
- Provider 结果只能成为 Candidate；语义激活属于 Story Design Authority，Canon 接受仍受 Canon Authority / Gate 管辖。
- 任何 conflict 必须成为 ReviewIssue / impact evidence，不能自动覆盖 Accepted Canon。

## 适用场景

- 推演世界规则对经济、政治、军事、基础设施、科技、宗教、教育、犯罪、阶层、地理、文化和世代的长期影响。
- 检查世界设定是否有系统性后果、制度是否会适应、受影响群体是否完整。
- 为 Outline / Arc / ChapterPlan 提供 story opportunity candidate，而不是补写新 Canon。

## 输入要求

- `project_id`、accepted WorldBible / WorldRule version 和 Canon refs。
- 分析范围、时间尺度、受影响群体、禁用项、Context Builder / MKAOS refs。
- Provider Runtime profile、trace context 和候选激活边界。

## 操作流程

1. 识别 WorldRule、约束、成本、资源流和适用群体。
2. 推导 DirectConsequence，再逐层推导 SystemicConsequence、CulturalConsequence 和 InstitutionalAdaptation。
3. 为每条边记录 AffectedGroup、前置 consequence、证据、反例和不确定性。
4. 检查图完整性、循环、悬空规则和与 Accepted Canon 的 contradiction。
5. 提取 StoryOpportunity，但保持 `CANDIDATE`，不写入 Canon 或 Active plan。
6. 通过 Story Design Authority 审核激活；冲突进入 ReviewIssue / Gate。

## 输出格式

```markdown
# World Consequence Candidate

## Source Rules
- world rule / asset version:

## Consequence Graph
- direct:
- systemic:
- cultural:
- affected groups:
- institutional adaptations:
- contradictions:

## Story Opportunities
- opportunity / consequence refs:

## Authority
- status: CANDIDATE
- activation required:
- trace / provider qualification:
```

## 质量标准

- 每个 consequence 必须能回溯到 WorldRule 或上游 consequence，不能凭空生成。
- affected group 和 institutional response 必须显式；图不得有跨项目或悬空引用。
- contradiction 与 opportunity 分开，候选状态和激活权限清晰。
- Provider 证据不等于 Canon 接受证据。

## 禁止事项

- 禁止重复实现 `worldbuilding`、WorldBible、Canon Graph、Context Builder 或 MKAOS。
- 禁止把 candidate 自动写入 Accepted Canon、StoryState 或 Active plan。
- 禁止复制外部作品的具体设定组合或受保护表达。
- 禁止因 provider 返回完整 JSON 就宣称 production / longform proof。

## 与其他模块的关系

- 上游：WorldBible、WorldRule、Accepted Canon、AssetVersion、Context Builder、MKAOS。
- 下游：Story Design Authority、Outline、ChapterPlan、ReviewIssue、Canon impact report。
- 关联 Skill：`worldbuilding`、`canon-continuity-graph`、`multidisciplinary-knowledge`。

````

## S038 skills/worldbuilding/SKILL.md

```json
{
  "id": "S038",
  "name": "worldbuilding",
  "file": "skills/worldbuilding/SKILL.md",
  "symbol": "default_chapter_artifact_resolver / _bind_domain_artifacts / _select_capability_skill",
  "caller": "CapabilityPackAuthority resolve and materialize_attempt_artifacts",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "runtime_reachable": true,
  "status": "CONDITIONAL",
  "stage": [
    "world.design.generate"
  ],
  "versions": [
    {
      "ref": "worldbuilding",
      "version": "worldbuilding-qualification-v1",
      "hash": "sha256:c2f95594a756f9bb0df507c96b4d3f265217e65928dfcfaecdc0e8bf881e5e82"
    }
  ],
  "load_policy": "Exactly one frozen Skill per stage; v3 prose Shared + task method projection; other bound versions load full text. Mentioned related Skills are not recursively loaded. Agent skill.activate records identity only.",
  "dynamic": false,
  "dynamic_variables": [],
  "dependent_skills": "References in prose do not cause automatic nested loading",
  "context": "Provider task + authorized context + required Knowledge, stage dependent",
  "memory": "accepted history only through Context; generic Agent session has frozen observations",
  "historical_review": "revision/rereview explicit; Draft can inherit selected_review through accepted L0 JSON",
  "logs": "not loaded by Skill; accepted artifact JSON or Agent observations can supply technical evidence",
  "other_prompts": "system,template,stage semantic contract,schema",
  "enters_llm": true,
  "metrics": {
    "characters": 1742,
    "utf8_bytes": 3180,
    "utf8_byte_token_upper_bound": 3180,
    "legacy_bytes_div3_estimate": 1060,
    "negative_markers": 7,
    "mandatory_markers": 9
  },
  "sha256": "sha256:8c987220d8aaa4cd5fb8fbe92780d5559c527e35cd17913e6e1a5c6595274cbe"
}
```

完整原文：
````markdown
---
name: worldbuilding
description: Use when designing or reviewing world rules, power systems, resource systems, class structures, organizations, geography, history, taboos, and costs so each setting produces conflict, limits, or story hooks.
---

# Worldbuilding

## Novel OS Runtime Contract

- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。

## 适用场景

- 创建 WorldBible、世界模板或项目世界分支。
- 审查世界观是否能支撑长期冲突。
- 大纲或正文中出现规则失效、资源无代价或设定堆砌问题。
- 定义“规则是什么”；长期系统性后果、制度适应和故事机会交给 `world-consequence-modeling`，不在本 Skill 重复推演。

## 输入要求

- TopicSeed、目标读者、核心爽点和主线冲突。
- 已有知识卡、素材卡和原创风险边界。
- 主角切入口、长期连载目标和类型约束。

## 操作流程

1. 定义世界第一规则和不可修改边界。
2. 设计力量体系、资源体系、代价体系和限制条件。
3. 设计阶层结构、组织势力、法律规则和权力来源。
4. 设计地理空间、历史背景、禁忌、灾难或系统缺陷。
5. 为每个设定标注剧情功能：冲突、限制、钩子、代价或反转条件。
6. 检查是否存在设定过重、资源无主、权力无成本或规则只为剧情服务。
7. 输出世界观卡和风险检查项。

## 输出格式

```markdown
# 世界观设计

## 世界第一规则
## 力量体系
## 资源体系
## 代价机制
## 阶层结构
## 组织势力
## 法律与禁忌
## 地理空间
## 历史背景
## 可产生的冲突
## 可产生的章节钩子
## 不可修改规则
## 风险检查
```

## 质量标准

- 每个核心设定必须产生冲突、限制、代价或钩子。
- 稀缺资源必须有来源、控制者、分配方式和争夺成本。
- 权力结构必须有合法性、维护成本和反抗成本。
- 世界规则必须约束主角，不能只服务主角开挂。

## 禁止事项

- 禁止为炫设定而堆百科。
- 禁止让强资源凭空无限供应。
- 禁止复制具体作品的独特世界观组合。
- 禁止让世界规则在主角需要时失效。
- 禁止把 provider 推演出的 consequence candidate 直接写成 Accepted Canon。

## 与其他模块的关系

- 上游：`TopicSeed`、`KnowledgeCard`、`MaterialCard`。
- 下游：`CharacterCard`、`Outline`、`ChapterPlan`、`quality-review`、`world-consequence-modeling`。
- Agent：Chief Editor Agent、Draft Agent、Review Agent。

````
