from pathlib import Path
import json
from novel_forge.modules.chapter_authority.candidate_selection import CandidateEvidence,compare_candidates,build_best_candidate
BASE=Path('/Users/yuan/Documents/Codex/audits/novel-forge-instructions-20261003')
prior=CandidateEvidence(asset_version_id='audit-accepted-prior',content={'text':'AUDIT_ACCEPTED_TEXT'},score=90,blocker_codes=(),review_asset_version_id='audit-review-prior')
challenger=CandidateEvidence(asset_version_id='audit-rejected-challenger',content={'text':'AUDIT_REJECTED_PROSE_QUOTE','quality_action_observations':['audit-observation']},score=89,blocker_codes=(),review_asset_version_id='audit-challenger-review',quality_resolution_checks=({'observation':'audit-observation','status':'UNRESOLVED','preservation':'REGRESSED','evidence':{'quote':'AUDIT_REJECTED_PROSE_QUOTE'},'target_asset_version_id':'audit-rejected-challenger','target_text_hash':'audit','source_quality_asset_version_id':'audit-quality'},))
comparison=compare_candidates(project_id='audit-project',chapter_root_operation_id='audit-root',previous=prior,challenger=challenger,minimum_net_improvement=3)
best,_=build_best_candidate(comparison=comparison,candidates={prior.asset_version_id:prior.content,challenger.asset_version_id:challenger.content})
result={'evidence_kind':'PURE_FUNCTION_SYNTHETIC_NOT_REAL_ACCEPTANCE','selected_asset_version_id':comparison['selected_asset_version_id'],'rejected_challenger_quote_in_best_candidate_comparison':'AUDIT_REJECTED_PROSE_QUOTE' in json.dumps(best),'direct_selected_text':best['text'],'comparison':comparison,'provider_calls':0,'database_connections':0}
(BASE/'synthetic-rejected-excerpt-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='comparison'},ensure_ascii=False))
