from pathlib import Path
import ast,json,re,hashlib,subprocess
BASE=Path('/Users/yuan/Documents/Codex/audits/novel-forge-instructions-20261003');ROOT=BASE/'snapshot'
def read(p):return (ROOT/p).read_text()
def dump(n,v):(BASE/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
source_versions={'hot-novel-deconstruction':'2.0.0','hot-novel-business-deconstruction':'1.0.0','published-fiction-craft-analysis':'1.0.0','classic-literary-depth-analysis':'1.0.0','multidisciplinary-knowledge':'1.0.0','platform-strategy-os':'1.0.0','anti-copy-abstraction':'1.0.0'}
skills=json.loads((BASE/'skill-inventory.json').read_text())
for s in skills:
 if s['name'] in source_versions and '/legacy-' not in s['file']:
  s['runtime_reachable']=True;s['enters_llm']=True
  if s['status']=='UNREACHABLE':s['status']='CONDITIONAL'
  s['stage']=sorted(set(s['stage'])|({'source.mkaos.extract'} if s['name']=='anti-copy-abstraction' else {'source.deconstruction.observe'}))
  s['versions'].append({'ref':s['name'],'version':source_versions[s['name']],'hash':s['sha256'],'binding':'SourceMethodologyRegistry; separate from chapter-generation Pack'})
  s['load_policy']+=' Source analysis loads exact full root Skill by allowlisted identity and frozen digest; it is not automatically loaded in Writer.'
dump('skill-inventory.json',skills)
out=['# Complete Skill Inventory — frozen main\n','ACTIVE = current default code binding; live DB activation UNKNOWN. CONDITIONAL = admitted phase needed. LEGACY = exact historical catalog only. UNREACHABLE = no formal production or governed source-analysis text consumer found. Source analysis Skills are included to prevent confusing indirect reusable assets with direct Writer instructions.\n']
for s in skills:out+=['## '+s['id']+' '+s['file']+'\n','```json\n'+json.dumps({k:v for k,v in s.items() if k!='text'},ensure_ascii=False,indent=2)+'\n```\n','完整原文：\n````markdown\n'+s['text']+'\n````\n']
(BASE/'04-complete-skill-inventory.md').write_text('\n'.join(out))
# Complete code-source attachment closes indirect helper/constants and dynamic schema branches.
modules=[
'src/novel_forge/modules/chapter_authority/provider_views.py',
'src/novel_forge/modules/chapter_authority/provider_output_contracts.py',
'src/novel_forge/modules/chapter_authority/realization_composition.py',
'src/novel_forge/modules/chapter_authority/semantic_revision.py',
'src/novel_forge/modules/chapter_authority/author_guidance.py',
'src/novel_forge/modules/review/craft.py',
'src/novel_forge/modules/story_planning_runtime/foundation_generation.py',
'src/novel_forge/modules/story_planning_runtime/world_preparation.py',
'src/novel_forge/modules/story_planning_runtime/knowledge_translation.py',
'src/novel_forge/modules/worldbuilding/actor_isolation.py',
'src/novel_forge/modules/mkaos_authority/craft_context_projection.py',
'src/novel_forge/modules/source_import/methodologies.py',
'src/novel_forge/modules/source_import/analysis_profiles.py',
'src/novel_forge/modules/production_execution/codex_configuration.py',
]
extra=[];exports=[]
for p in modules:
 if not (ROOT/p).exists():continue
 exports.append({'file':p,'line':1,'end_line':len(read(p).splitlines()),'sha256':hashlib.sha256(read(p).encode()).hexdigest(),'scope':'COMPLETE_MODULE_NO_RUNTIME_DATA'})
 extra+=['## '+p+'\n','````python\n'+read(p)+'\n````\n']
selected={
'src/novel_forge/modules/chapter_authority/execution_gateway.py':{'_materialize_source_intelligence_prompt'},
'src/novel_forge/modules/source_import/execution.py':{'_materialization','_classifier_spec','_analysis_spec','_mkaos_spec'},
'src/novel_forge/modules/source_import/profiling.py':{'SOURCE_CLASSIFIER_METHODOLOGY'},
'src/novel_forge/modules/story_planning_runtime/execution.py':None,
'src/novel_forge/modules/provider_control/deepseek.py':{'execute'},
'src/novel_forge/modules/provider_control/openai_v2.py':{'execute'},
'src/novel_forge/modules/production_execution/backends.py':{'_prepare_codex_payload'},
'src/novel_forge/modules/chapter_authority/provider_inputs.py':None,
}
for p,names in selected.items():
 if not (ROOT/p).exists():continue
 source=read(p);lines=source.splitlines();tree=ast.parse(source)
 for n in ast.walk(tree):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   selected_n=n.name in names if names is not None else any(x in n.name for x in ('schema','contract','prompt','constraint'))
  elif isinstance(n,(ast.Assign,ast.AnnAssign)):
   ids=[x.id for x in ast.walk(n) if isinstance(x,ast.Name)]
   selected_n=names is not None and any(x in names for x in ids)
  else:continue
  if selected_n:
   fragment='\n'.join(lines[n.lineno-1:n.end_lineno]);symbol=getattr(n,'name',','.join(ids) if isinstance(n,(ast.Assign,ast.AnnAssign)) else '')
   exports.append({'file':p,'symbol':symbol,'line':n.lineno,'end_line':n.end_lineno,'sha256':hashlib.sha256(fragment.encode()).hexdigest(),'scope':'EXACT_FUNCTION_OR_CONSTANT'})
   extra+=['## '+p+':'+str(n.lineno)+' '+symbol+'\n','````python\n'+fragment+'\n````\n']
(BASE/'06-instruction-source-corpus.md').write_text('# Instruction construction source corpus\n\nAll source is copied verbatim from frozen main. This attachment supplies helper constants and complete conditional/schema branches behind 03. It does not contain private novel text, credentials, or a real Provider request. Source intelligence is an upstream analysis boundary, not Writer text.\n\n'+'\n'.join(extra))
dump('instruction-source-index.json',exports)
# Add all Source assembly fixed instructions as named inventory entries.
prompts=json.loads((BASE/'prompt-inventory.json').read_text())
fixed=[('source-intelligence-system@1.0','You analyze governed source evidence for reusable abstract mechanisms. Never reproduce protected expression or treat an Observation as reusable knowledge before MKAOS governance.','_materialization',2050),('source-intelligence-template@frozen-spec','Perform the frozen Source intelligence stage and return a bounded JSON object matching the supplied schema.','_materialization',2063),('source-intelligence-json-output-contract','Return only one JSON object matching the frozen schema. Do not quote, reproduce, or preserve source expression in analysis output.','_materialize_source_intelligence_prompt',4666)]
from novel_forge.modules.source_import.profiling import SOURCE_CLASSIFIER_METHODOLOGY
fixed.append(('source-classifier-methodology@v1',SOURCE_CLASSIFIER_METHODOLOGY,'SOURCE_CLASSIFIER_METHODOLOGY',15))
for name,text,symbol,line in fixed:
 prompts.append({'id':'P%03d'%(len(prompts)+1),'name':name,'file':'src/novel_forge/modules/source_import/execution.py' if symbol=='_materialization' else 'src/novel_forge/modules/source_import/profiling.py' if symbol=='SOURCE_CLASSIFIER_METHODOLOGY' else 'src/novel_forge/modules/chapter_authority/execution_gateway.py','symbol':symbol,'line':line,'caller':'Source import worker -> PostgresContentIntelligenceExecutionPort -> _materialize_source_intelligence_prompt','downstream':'ProviderRequestEnvelope; governed observations -> MKAOS candidates; no direct Writer use','runtime_reachable':True,'status':'CONDITIONAL','stage':['source classification','source deconstruction','MKAOS extraction'],'prompt_type':'SOURCE_ANALYSIS_INSTRUCTION','dynamic':False,'dynamic_variables':[],'skills':list(source_versions),'context':'source_analysis_input transient object-store excerpt + frozen observation boundary; exact construction in 06','memory':'none directly; accepted reusable assets only after governance','historical_review':False,'logs':False,'other_prompts':'System + one exact methodology + template + scope + source input + schema + JSON output instruction','enters_llm':True,'characters':len(text),'text':text})
dump('prompt-inventory.json',prompts)
out=['# Complete Prompt Inventory — artifact originals and governed source boundary\n','Dynamic instruction builders, emitted contracts and schemas: 03-dynamic-instructions.md. Complete helpers/constants: 06-instruction-source-corpus.md. A catalog entry does not prove DB activation or actual calls.\n']
for p in prompts:out+=['## '+p['id']+' '+p['name']+'\n','```json\n'+json.dumps({k:v for k,v in p.items() if k!='text'},ensure_ascii=False,indent=2)+'\n```\n','完整原文：\n````text\n'+p['text']+'\n````\n']
(BASE/'02-complete-prompt-inventory.md').write_text('\n'.join(out))
# Save targeted history, including first introduction, blame and discriminative changes.
paths=['skills/prose-generation/SKILL.md','skills/hot-novel-business-deconstruction/SKILL.md','skills/quality-review/SKILL.md','config/capability_packs/artifacts/story_planning_system_instruction.md','src/novel_forge/modules/capability_packs/screenplay_profiles.py']
h=['# Targeted instruction archaeology\n']
for p in paths:
 for args in [['log','--follow','--format=%H %cI %s','--',p],['blame','--date=iso','--',p]]:
  result=subprocess.check_output(['git',*args],cwd=ROOT).decode();h+=['## git '+' '.join(args)+'\n','````text\n'+result+'\n````\n']
for commit,path in [('e9fd9116','skills/quality-review/SKILL.md'),('ca34b2d0','skills/prose-generation/SKILL.md'),('52357c86','src/novel_forge/modules/chapter_authority/provider_views.py'),('bbd59eb3','config/capability_packs/artifacts/story_planning_system_instruction.md'),('2ae98a46','config/capability_packs/artifacts/story_planning_system_instruction.md')]:
 result=subprocess.check_output(['git','show','--format=fuller',commit,'--',path],cwd=ROOT).decode();h+=['## git show '+commit+' -- '+path+'\n','````diff\n'+result+'\n````\n']
for path,start,end in [('src/novel_forge/storage/book_authority_repositories.py',840,989),('src/novel_forge/modules/capability_pack_authority/application.py',398,470),('src/novel_forge/modules/context_builder/task_compression.py',26,70)]:
 result=subprocess.check_output(['git','blame','-L',f'{start},{end}','--date=iso','--',path],cwd=ROOT).decode();h+=['## git blame '+path+'\n','````text\n'+result+'\n````\n']
(BASE/'07-targeted-git-history.md').write_text('\n'.join(h))
print(json.dumps({'skills':len(skills),'reachable_skill_files':sum(s['runtime_reachable'] for s in skills),'source_only_skill_files':sum(s['runtime_reachable'] and s['stage']==['source.deconstruction.observe'] for s in skills),'prompts':len(prompts),'source_exports':len(exports)},ensure_ascii=False))
