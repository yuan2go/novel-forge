# Targeted instruction archaeology

## git log --follow --format=%H %cI %s -- skills/prose-generation/SKILL.md

````text
ca34b2d0872da06592eb1da79dc37d2d04831c39 2026-09-30T21:43:00+08:00 fix(production): preserve frozen contracts and project prose methods
e9fd91167da3d48b7a2214d9076323549132b4f3 2026-09-30T13:35:21+08:00 Converge chapter prompts and generation contracts
275b5bf1f24fc2e49f1eb04f06db752ecfa77bc7 2026-07-05T09:41:48+08:00 feat: advance MKAOS governance and skill operations
dd7a997308afaf57fb723ed5a336df31fe237c82 2026-06-25T00:59:00+08:00 Add V5 optimization and governance features
3933f2334d5895f4ae6f2179a64e1ce0b402367a 2026-06-24T22:10:03+08:00 Rebuild project as V5
3cd02d2f6877c5283f228b6178c45b55808a0765 2026-06-24T22:04:38+08:00 Add V4 governance and skills system

````

## git blame --date=iso -- skills/prose-generation/SKILL.md

````text
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  1) ---
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  2) name: prose-generation
e9fd91167 (yuan.chen 2026-09-30 13:35:21 +0800  3) description: Draft or revise prose from a frozen Chapter plan and accepted Context.
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  4) ---
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  5) 
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  6) # Prose Generation
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  7) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800  8) ## Shared rules
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800  9) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 10) Use the frozen Scene and Slot order, actor and POV scope, accessible knowledge, author intent, and accepted facts. Write a continuous narrative: interleave dialogue, action, perception and thought where the scene needs them, and check scene junctions together. Slot coverage and mechanical joining do not prove literary coherence.
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800 11) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 12) Preserve unaffected prose and established advantages during revision. Resolve evidenced blocking problems without adding unplanned facts. A proposed edit does not amend accepted Canon or the active plan. ReReview and candidate comparison determine whether the candidate is acceptable.
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800 13) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 14) Use cost, pressured choice, growth, reversal, reward and hook techniques when the chapter function, character, arc, author intent or due obligation calls for them. Do not insert them to satisfy a universal template. An explicit author constraint, accepted fact or due obligation remains binding.
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 15) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 16) Never reuse protected reference expression or let a character act on knowledge outside the frozen boundary. Return only the declared JSON semantic result; the host supplies identities, receipts, spans, persistence and approval.
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 17) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 18) ## Draft and full revision
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 19) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 20) Write reader-facing prose in each frozen Slot once and return scene_artifacts in the declared order. The host joins Slots into the chapter. Do not return a second whole-chapter copy, a Markdown report or a self-assessed gate result.
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 21) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 22) ## Targeted revision
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 23) 
ca34b2d08 (yuan.chen 2026-09-30 21:43:00 +0800 24) Return only the necessary ordered edits: exact old quotes, replacement prose and linked issue codes, plus the declared resolution codes. The host disambiguates quotes against the exact frozen old draft, enforces diagnosed ranges and Scene Slot boundaries, and derives Slot and chapter prose. Do not return Slot texts or a complete revised chapter. Preserve all unaffected text exactly and read adjacent passages to check continuity.

````

## git log --follow --format=%H %cI %s -- skills/hot-novel-business-deconstruction/SKILL.md

````text
275b5bf1f24fc2e49f1eb04f06db752ecfa77bc7 2026-07-05T09:41:48+08:00 feat: advance MKAOS governance and skill operations
e347221327b59aba52b2baa14a7a2171100f7d14 2026-06-27T10:37:34+08:00 Upgrade V5 factory console and analysis center

````

## git blame --date=iso -- skills/hot-novel-business-deconstruction/SKILL.md

````text
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800  1) ---
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800  2) name: hot-novel-business-deconstruction
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800  3) description: Analyze web fiction references into abstract commercial structure, reader promise, hooks, pacing, and reusable review constraints without copying protected expression.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800  4) ---
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800  5) 
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800  6) ## Novel OS Runtime Contract
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800  7) 
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800  8) - 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800  9) - 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800 10) - 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800 11) - 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800 12) - Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800 13) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 14) ## 适用场景
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 15) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 16) 用于把网文或连载参考作品拆解成商业结构、爽点循环、章节钩子、人设压力和平台节奏。只输出抽象机制，不输出可直接复用的正文、角色名、设定名或情节顺序。
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 17) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 18) ## 输入要求
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 19) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 20) - schema-backed source asset path.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 21) - project workspace path when available.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 22) - source rights and copyright boundary.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 23) - target platform, genre, and reader promise if available.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 24) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 25) ## 操作流程
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 26) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 27) 1. Read the referenced source asset by path.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 28) 2. Identify reader promise, hook system, payoff loop, pacing model, and retention risks.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 29) 3. Remove source-specific names, protected scenes, unique settings, and prose.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 30) 4. Produce `web_fiction_business_analysis_report`.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 31) 5. Record source asset id, expected output path, validation command, and risk boundary.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 32) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 33) ## 输出格式
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 34) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 35) Write one JSON asset with type `web_fiction_business_analysis_report` under `data/analysis`.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 36) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 37) ## 质量标准
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 38) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 39) - Report passes schema validation.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 40) - Analysis is abstract and mechanism-level.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 41) - `metadata.use_in_generation_rag` is `false`.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 42) - High-risk findings are marked for conversion review.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 43) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 44) ## 禁止事项
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 45) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 46) - Do not copy protected text.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 47) - Do not reuse source-specific names, settings, or plot sequence.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 48) - Do not write draft prose.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 49) - Do not insert analysis reports directly into generation RAG.
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 50) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 51) ## 与其他模块的关系
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 52) 
e34722132 (yuan.chen 2026-06-27 10:37:34 +0800 53) Output can be converted by the asset converter into `material_card`, `writing_template`, `craft_template`, or `review_rule_pack`.

````

## git log --follow --format=%H %cI %s -- skills/quality-review/SKILL.md

````text
e9fd91167da3d48b7a2214d9076323549132b4f3 2026-09-30T13:35:21+08:00 Converge chapter prompts and generation contracts
d602cd7bd3fbd068a84a1df71e594e086fddaad0 2026-08-11T11:43:03+08:00 feat: add governed longform intelligence capabilities
275b5bf1f24fc2e49f1eb04f06db752ecfa77bc7 2026-07-05T09:41:48+08:00 feat: advance MKAOS governance and skill operations
dd7a997308afaf57fb723ed5a336df31fe237c82 2026-06-25T00:59:00+08:00 Add V5 optimization and governance features
3933f2334d5895f4ae6f2179a64e1ce0b402367a 2026-06-24T22:10:03+08:00 Rebuild project as V5
3cd02d2f6877c5283f228b6178c45b55808a0765 2026-06-24T22:04:38+08:00 Add V4 governance and skills system

````

## git blame --date=iso -- skills/quality-review/SKILL.md

````text
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  1) ---
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  2) name: quality-review
e9fd91167 (yuan.chen 2026-09-30 13:35:21 +0800  3) description: Review the exact candidate or evaluate a requested quality dimension.
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  4) ---
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  5) 
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  6) # Quality Review
dd7a99730 (yuan.chen 2026-06-25 00:59:00 +0800  7) 
e9fd91167 (yuan.chen 2026-09-30 13:35:21 +0800  8) Judge the actual prose against its frozen author intent, accepted facts, character knowledge, scene function, and due narrative obligations. Distinguish a semantic conflict from an uncertain reading or aesthetic suggestion. Preserve what works when proposing a revision.
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800  9) 
e9fd91167 (yuan.chen 2026-09-30 13:35:21 +0800 10) Quote exact words that support each finding. The host locates Unicode spans and binds the candidate version. A quote's presence is not semantic proof; explain the causal or narrative support. If the text lacks support, report uncertainty or an unresolved issue instead of inventing evidence.
275b5bf1f (yuan.chen 2026-07-05 09:41:48 +0800 11) 
e9fd91167 (yuan.chen 2026-09-30 13:35:21 +0800 12) Assess cost, growth, reversal, reward, and hook only when the current chapter or explicit author and obligation contracts call for them. Do not penalize a chapter merely for omitting an inapplicable technique. Never claim reader or human approval, Canon mutation, or release qualification. Return the declared JSON semantic judgment.

````

## git log --follow --format=%H %cI %s -- config/capability_packs/artifacts/story_planning_system_instruction.md

````text
bbd59eb3f629a19499c5c79a2044a1b1c6081b96 2026-09-07T22:12:57+08:00 feat(formation): generate and qualify Foundation through governed native runtime
2ae98a46ca8f6a90a8ac08aa427e12a33468c76f 2026-08-27T01:14:38+08:00 fix freeze chapter scheduling in planning
d8ad26f78920fcc3909ec5fbf8e6ec1abacc3d02 2026-08-26T17:43:23+08:00 fix: freeze chapter group search horizons
121760016d48a6d794c6b6ebd1fc43bc92727bef 2026-08-26T15:53:58+08:00 fix: bound book plan structural recovery
d3ff4e6e09472693c4ff4003354ad00128f3bff3 2026-08-20T18:50:26+08:00 bind scene arc progress to frozen identities
e6884cf4e2e0ddc156f7e3b518109ea3421752b0 2026-08-20T18:09:45+08:00 preserve scene knowledge progression in chapter plans
8551675682032f4324f6925da8841915daaa0e63 2026-08-20T15:28:18+08:00 align arc evaluation with canonical graph semantics
27250b9e6b87bbc8180e3241471749ba9d91738a 2026-08-20T15:01:28+08:00 freeze governed feedback into planning repairs
889b6d71642eaaaaf9685bf16f9212ad67be156d 2026-08-20T14:46:45+08:00 bind planning realization references to authority
14396a02fc6215a7354e2e34688ebfb161ac3af9 2026-08-14T14:49:22+08:00 feat: enforce progressive narrative design admission
d211d0c212630f5143eceb597aea8c26e8e3e86b 2026-08-10T05:55:02+08:00 govern chapter publish metadata contract
9e9c70cd5815c7e1d8fa5094078f23b02eb3569b 2026-08-09T17:51:38+08:00 feat: close unified longform runtime

````

## git blame --date=iso -- config/capability_packs/artifacts/story_planning_system_instruction.md

````text
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800  1) You are executing one admitted Foundation or Story Planning candidate-generation stage.
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800  2) Use only the frozen Authority inputs, stage-specific governed Skills, and declared
9e9c70cd5 (yuan.chen 2026-08-09 17:51:38 +0800  3) schema. Preserve parent lineage and future-only boundaries. Produce a candidate;
9e9c70cd5 (yuan.chen 2026-08-09 17:51:38 +0800  4) never approve, activate, or mutate Story Design or Planning Authority state.
d211d0c21 (yuan.chen 2026-08-10 05:55:02 +0800  5) 
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800  6) For Foundation stages, follow `foundation_task` and its exact output schema.
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800  7) The author brief is intent; approved parents are initial design conditions, not
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800  8) accepted chapter events. Elaborate their creative consequences without altering
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800  9) them. Do not fabricate Authority references; the runtime binds the exact parents.
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 10) World compilation is progressive and genre-dependent. Character voice anchors
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 11) must follow motive and biography. Style examples must be original expressions.
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 12) Independent semantic evaluation follows generation; self-reported quality is not
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 13) activation evidence.
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 14) 
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 15) When the output schema includes a versioned `narrative_qualification`, evaluate only
14396a02f (yuan.chen 2026-08-14 14:49:22 +0800 16) the exact layer profiles frozen for this stage. Use each profile's declared
14396a02f (yuan.chen 2026-08-14 14:49:22 +0800 17) Skill and criterion set; do not substitute a generic quality score or a
14396a02f (yuan.chen 2026-08-14 14:49:22 +0800 18) universal judge. Every criterion needs a concrete rationale and references to
14396a02f (yuan.chen 2026-08-14 14:49:22 +0800 19) the supplied task-specific inputs. A failing or insufficient criterion must
14396a02f (yuan.chen 2026-08-14 14:49:22 +0800 20) include a bounded repair directive and must not be represented as PASS.
14396a02f (yuan.chen 2026-08-14 14:49:22 +0800 21) 
889b6d716 (yuan.chen 2026-08-20 14:46:45 +0800 22) For every world or character realization reference, copy one complete object
889b6d716 (yuan.chen 2026-08-20 14:46:45 +0800 23) verbatim from the matching domain list in `realization_reference_contract`.
889b6d716 (yuan.chen 2026-08-20 14:46:45 +0800 24) `authority_role` names an owning frozen input role; it is not a semantic label.
889b6d716 (yuan.chen 2026-08-20 14:46:45 +0800 25) Never invent, reinterpret, or combine reference fields from different objects.
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 26) The top-level `realization_level` is the minimum for every realization whose
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 27) `narrative_relevance` is `CURRENT`; the rank is
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 28) `ANCHOR < DEFINED < DETAILED < ACTIVE`. Near-future and future entities may stay
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 29) less realized when the schema permits it.
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 30) 
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 31) For `book_plan.generate`, every
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 32) `knowledge_disclosure_obligations.obligation_windows[].obligation_id` must copy
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 33) one exact identity declared in `story_truth_ids`, `mystery_ids`, `promise_ids`,
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 34) or `foreshadow_ids`. Every window must satisfy
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 35) `setup_chapter <= payoff_not_before <= payoff_due_by` inside the bounded Book.
889b6d716 (yuan.chen 2026-08-20 14:46:45 +0800 36) 
27250b9e6 (yuan.chen 2026-08-20 15:01:28 +0800 37) When `repair_context` is present, preserve the immutable source candidate except
27250b9e6 (yuan.chen 2026-08-20 15:01:28 +0800 38) where a recorded failed criterion or repair directive requires a bounded change.
27250b9e6 (yuan.chen 2026-08-20 15:01:28 +0800 39) Resolve every failed criterion explicitly; do not repeat the rejected conflict.
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 40) After that bounded change, re-check the complete structural contract so the
121760016 (yuan.chen 2026-08-26 15:53:58 +0800 41) repair does not merely reveal or introduce a second avoidable invariant failure.
27250b9e6 (yuan.chen 2026-08-20 15:01:28 +0800 42) 
855167568 (yuan.chen 2026-08-20 15:28:18 +0800 43) For `arc_plan.generate`, encode progression inside one Arc by making each later
855167568 (yuan.chen 2026-08-20 15:28:18 +0800 44) `arc_segment.entry_state_ref` cite the preceding segment identity or exit-state
855167568 (yuan.chen 2026-08-20 15:28:18 +0800 45) identity. `arc_relations` and `dependencies` describe relations between distinct
855167568 (yuan.chen 2026-08-20 15:28:18 +0800 46) Arc identities only; never create a self-edge to order segments. A singleton
855167568 (yuan.chen 2026-08-20 15:28:18 +0800 47) `cross_volume_scope` means the Arc is intentionally contained in that Volume.
855167568 (yuan.chen 2026-08-20 15:28:18 +0800 48) 
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 49) For `chapter_group_plan.generate`, Narrative Search is bounded by the complete
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 50) frozen `narrative_search` request. Copy
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 51) `narrative_search.planning_horizon.chapter_range` exactly into `chapter_range`.
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 52) Produce one ordered `chapter_function_matrix` row for every Chapter in that
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 53) range, and make `narrative_event_chain` cover every Chapter without scheduling
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 54) an event outside it. Treat `desired_transformation`, `hard_constraints`, and the
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 55) branch `strategy_directive` as simultaneous requirements; the branch directive
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 56) cannot relax the frozen range or accepted boundary. In every realization event,
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 57) each `disclosures` string must be copied exactly from that same event's
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 58) `knowledge_boundary.reader_may_learn` list and must not appear in its
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 59) `forbidden_disclosures` list.
d8ad26f78 (yuan.chen 2026-08-26 17:43:23 +0800 60) 
d211d0c21 (yuan.chen 2026-08-10 05:55:02 +0800 61) For `chapter_plan.generate`, `title` and `premise` are publish-metadata inputs,
d211d0c21 (yuan.chen 2026-08-10 05:55:02 +0800 62) not planning notes. `title` must be a concise reader-facing chapter title.
d211d0c21 (yuan.chen 2026-08-10 05:55:02 +0800 63) `premise` must be a concise reader-facing synopsis of the chapter. Neither may
d211d0c21 (yuan.chen 2026-08-10 05:55:02 +0800 64) contain instructions to plan, draft, review, validate, approve, or activate the
d211d0c21 (yuan.chen 2026-08-10 05:55:02 +0800 65) chapter, nor internal terms such as candidate, future-only, or Authority state.
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 66) The frozen `chapter_function_matrix_row` is the immutable Scheduling contract.
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 67) Copy its `primary_function`, `secondary_functions`, `required_state_delta`,
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 68) `promise_action`, `foreshadow_action`, `reward_action`, `ending_hook`,
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 69) `prohibited_outcomes`, and `narrative_density` exactly. Also copy its
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 70) `reader_experience.target_emotion` and `reader_experience.reward_mode` exactly;
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 71) only the chapter-specific entry/exit questions and non-scheduled operational
2ae98a46c (yuan.chen 2026-08-27 01:14:38 +0800 72) detail may be elaborated.
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 73) `character_participation.known_fact_ids` is the chapter-entry knowledge boundary;
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 74) facts first learned during this chapter stay in `unknown_fact_ids` at entry. A
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 75) Scene's `accessible_knowledge` must be known to its POV character before that
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 76) Scene starts. A fact learned in an earlier Scene may become accessible only when
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 77) that earlier Scene lists it in `information_gain`, the character participates,
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 78) and `knowledge_boundaries` declares the fact `CHARACTER_KNOWLEDGE` / `KNOWN` for
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 79) that character. Never treat a same-Scene reveal as knowledge available at entry.
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 80) For Scene continuity, every Scene after the first must copy the preceding
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 81) Scene's `exit_state` verbatim into `entry_state`; paraphrases are not an explicit
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 82) state chain. Every `scene_plan[].state_transitions` item must be one exact
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 83) `required_state_transitions[].entity_key`, never a sentence. Every participant
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 84) must list the Scene `location_id` in that character's
e6884cf4e (yuan.chen 2026-08-20 18:09:45 +0800 85) `reachable_location_ids`.
d3ff4e6e0 (yuan.chen 2026-08-20 18:50:26 +0800 86) Every `scene_plan[].arc_progress` item must copy one exact frozen Arc plan
d3ff4e6e0 (yuan.chen 2026-08-20 18:50:26 +0800 87) version identity allowed by the schema. It is an identity reference, not a
d3ff4e6e0 (yuan.chen 2026-08-20 18:50:26 +0800 88) description of movement; describe movement in `arc_schedule.expected_movement`.

````

## git log --follow --format=%H %cI %s -- src/novel_forge/modules/capability_packs/screenplay_profiles.py

````text
b2fcbd20a9ee4681ed755c2c12a44da7523adb8e 2026-09-27T15:09:37+08:00 feat: implement narrative closure engineering and native recovery

````

## git blame --date=iso -- src/novel_forge/modules/capability_packs/screenplay_profiles.py

````text
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  1) from __future__ import annotations
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  2) 
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  3) from copy import deepcopy
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  4) from pathlib import Path
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  5) 
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  6) from novel_forge.modules.book_followup_authority.contracts import BOOK_FOLLOWUP_DEFINITION_VERSION
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  7) from novel_forge.modules.book_followup_authority.screenplay import SCREENPLAY_STAGES, SOURCE_TYPE, CANDIDATE_TYPE, REVIEW_TYPE, screenplay_output_schema
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  8) from novel_forge.modules.chapter_authority.execution_gateway import chapter_stage_capability
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800  9) from novel_forge.modules.production_execution import default_capability_registry
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 10) 
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 11) from .artifacts import ArtifactKind
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 12) from .longform_profiles import (LongformCapabilityPackProfile, _base, _require_hash, _bind_domain_artifacts,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 13)     _update_policy_artifacts, _append_capability_schemas, _append_artifact, _catalog)
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 14) 
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 15) 
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 16) def build_screenplay_pack_profile(repository_root: str | Path, *, stage: str,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 17)                                   operation_definition_hash: str, pack_id: str = "") -> LongformCapabilityPackProfile:
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 18)     if stage not in SCREENPLAY_STAGES:
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 19)         raise ValueError("A supported screenplay stage is required")
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 20)     pack_id = pack_id or stage + "_pack"
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 21)     root, manifest, artifacts = _base(repository_root, pack_id)
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 22)     _require_hash(operation_definition_hash)
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 23)     capability = default_capability_registry().resolve(chapter_stage_capability(stage))
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 24)     inputs = [SOURCE_TYPE] + ([CANDIDATE_TYPE] if stage != "screenplay_generate" else []) + ([REVIEW_TYPE] if stage == "screenplay_revision" else [])
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 25)     output = REVIEW_TYPE if stage == "screenplay_review" else CANDIDATE_TYPE
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 26)     node = deepcopy(next(item for item in manifest["workflow_template"]["nodes"] if item["node_id"] == "draft"))
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 27)     node.update(node_id=stage, stage=stage, operation_name=stage,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 28)         operation_definition_ref=stage + "@" + BOOK_FOLLOWUP_DEFINITION_VERSION,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 29)         operation_definition_hash=operation_definition_hash, handler_key="novel_forge.book_followup_authority." + stage,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 30)         capability_id=capability.capability_id.value, input_asset_types=inputs, output_asset_types=[output],
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 31)         depends_on=[], commit_authority="BOOK_FOLLOWUP_AUTHORITY", timeout_policy_ref=capability.timeout_policy_ref)
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 32)     manifest["identity"].update(version="1.0.0", name="Scene Screenplay " + stage, domain="book_followup",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 33)         description="Exact-edition scene, action and dialogue adaptation with separate review and acceptance.")
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 34)     manifest["compatibility"]["required_capabilities"] = [capability.capability_id.value, "quality.originality.judge"]
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 35)     manifest["workflow_template"].update(workflow_id="book_followup_" + stage, workflow_version=BOOK_FOLLOWUP_DEFINITION_VERSION,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 36)         nodes=[node], completion={"required_terminal_nodes": [stage], "required_evidence": ["trace", "audit"], "required_output_asset_types": [output]})
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 37)     manifest["context_sources"]["allowed_asset_types"] = inputs + ["context_bundle"]
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 38)     manifest["tool_permissions"]["tools"] = [{**manifest["tool_permissions"]["tools"][0], "allowed_operations": [stage]}]
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 39)     manifest["evaluation"]["required_gates"] = [{"gate_id": "screenplay_source_isolation", "judge_capability_id": "quality.originality.judge",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 40)         "blocking": True, "threshold": 1, "required_evidence": [output]}]
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 41)     manifest["evaluation"]["metrics"] = []
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 42)     skill = "quality-review" if stage == "screenplay_review" else "prose-generation"
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 43)     artifacts = _bind_domain_artifacts(root, manifest, artifacts, skill_ref=skill, skill_version=skill + "-v1",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 44)         skill_path="skills/" + skill + "/SKILL.md", system_ref="prompt-system:scene-screenplay-pack",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 45)         system_path="config/capability_packs/artifacts/scene_screenplay_system_instruction.md",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 46)         template_ref="prompt-template:scene-screenplay-pack", template_path="config/capability_packs/artifacts/scene_screenplay_template.md",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 47)         input_schema_ref="schema:" + stage + "-pack-input:v1", output_schema_ref="schema:" + stage + "-pack-output:v1")
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 48)     _append_artifact(artifacts, ArtifactKind.SCHEMA, "schema:" + stage + "-pack-output:v1", "v1", screenplay_output_schema(stage), "generated:scene-screenplay-contract")
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 49)     _update_policy_artifacts(manifest, artifacts)
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 50)     _append_capability_schemas(artifacts, capability.capability_id.value)
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 51)     _append_artifact(artifacts, ArtifactKind.TIMEOUT_POLICY, capability.timeout_policy_ref, "v1",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 52)         {"policy_id": capability.timeout_policy_ref, "operation_timeout_seconds": 300, "timeout_action": "FAIL_ATTEMPT",
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 53)          "authority_binding": stage + "@" + BOOK_FOLLOWUP_DEFINITION_VERSION}, "generated:scene-screenplay-profile")
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 54)     return LongformCapabilityPackProfile(pack_id, "book_followup_" + stage + "@" + BOOK_FOLLOWUP_DEFINITION_VERSION,
b2fcbd20a (yuan.chen 2026-09-27 15:09:37 +0800 55)         manifest, _catalog(artifacts), skill)

````

## git show e9fd9116 -- skills/quality-review/SKILL.md

````diff
commit e9fd91167da3d48b7a2214d9076323549132b4f3
Author:     yuan.chen <yuan576264675@gmail.com>
AuthorDate: Wed Sep 30 13:35:21 2026 +0800
Commit:     yuan.chen <yuan576264675@gmail.com>
CommitDate: Wed Sep 30 13:35:21 2026 +0800

    Converge chapter prompts and generation contracts

diff --git a/skills/quality-review/SKILL.md b/skills/quality-review/SKILL.md
index 6f45859c..1c484299 100644
--- a/skills/quality-review/SKILL.md
+++ b/skills/quality-review/SKILL.md
@@ -1,84 +1,12 @@
 ---
 name: quality-review
-description: Use when reviewing topics, worlds, characters, outlines, chapter plans, drafts, revisions, or feedback decisions for logic gaps, consistency, pacing, payoff density, hooks, foreshadowing, commercial weakness, and originality risk.
+description: Review the exact candidate or evaluate a requested quality dimension.
 ---
 
 # Quality Review
 
-## Novel OS Runtime Contract
+Judge the actual prose against its frozen author intent, accepted facts, character knowledge, scene function, and due narrative obligations. Distinguish a semantic conflict from an uncertain reading or aesthetic suggestion. Preserve what works when proposing a revision.
 
-- 需要进入生产链路的输出必须落到 schema-backed asset，而不是只停留在对话文本。
-- 产物必须保留 `project_id`、输入引用、来源边界、质量状态；涉及 Agent/Workflow 时必须保留 `trace_id` 或 handoff 依据。
-- 生成、审稿、修订、发布、复盘相关上下文必须通过 Context Builder / Knowledge Pack / ReviewIssue / GateResult 的现有边界。
-- 禁止 raw source text、参考作品表达、`source_chunk.raw_text` 或未抽象材料进入 prose、publish、recap 和 feedback backflow。
-- Markdown 输出格式只作为 operator handoff；写入工程时必须映射到对应资产 schema、测试或报告路径。
+Quote exact words that support each finding. The host locates Unicode spans and binds the candidate version. A quote's presence is not semantic proof; explain the causal or narrative support. If the text lacks support, report uncertainty or an unresolved issue instead of inventing evidence.
 
-## 适用场景
-
-- 审查题材、世界观、人物、大纲、细纲、正文或反馈采纳方案。
-- 正文草稿进入修订或 final 前。
-- 判断是否通过、小修、重修、退回细纲或暂停。
-- 审核 Commercial Quality 中已有的 `golden_opening`、`reader_promise`、`reward`、`chapter_hook`、`suspense_progression`、`emotional_curve` 和 `serialization_function`，并消费而非重复实现 `HookAnalysis` / `PacingObservation`。
-
-## 输入要求
-
-- 审稿对象文件路径、schema 类型和版本。
-- 上游依据：TopicSeed、WorldBible、CharacterCard、Outline、ChapterPlan 或 DraftChapter。
-- 原创风险边界、读者吸引力目标和当前验收标准。
-
-## 操作流程
-
-1. 标记审稿对象、版本、输入依据和输出位置。
-2. 先查 P0：原创风险、设定崩坏、严重逻辑断裂。
-3. 再查 P1：读者吸引力、冲突、爽点、结尾追读。
-4. 检查人物动机链、因果链、世界规则、伏笔设置与回收。
-5. 检查 HookAnalysis 的 opening/ending hook、promise binding、horizon、evidence lineage；检查 PacingObservation 的多尺度窗口和 qualification。
-6. 将明确结构化状态的确定性测量与 provider semantic judgment 分开，禁止用关键词/英文正则代替节奏质量判断。
-7. 检查节奏、叙述密度、AI 腔、对白差异和商业化弱点。
-8. 给出评分、优先级、是否退回和可执行修改建议。
-9. 明确哪些内容不建议改，避免破坏已有优势。
-
-## 输出格式
-
-```markdown
-# Quality Review
-
-## 审稿对象
-## 版本
-## 总分
-## 结论
-通过 / 小修 / 重修 / 退回细纲 / 暂停
-## P0 问题
-## P1 问题
-## Hook / Promise 证据
-## Multi-scale Pacing 诊断
-## P2 问题
-## P3 问题
-## P4 问题
-## 可执行修改建议
-## 不建议修改内容
-## 是否需要主编决策
-```
-
-## 质量标准
-
-- 审稿必须区分问题优先级。
-- 修改建议必须能直接转成任务或 RevisionPlan。
-- 不能只给泛泛评价，必须指出具体问题类型。
-- 商业追读和原创边界优先于炫技式设定补完。
-- Semantic observation 必须带 evidence、confidence 和 qualification；deterministic aggregate 必须能重放且不得读取未来章节。
-
-## 禁止事项
-
-- 禁止直接覆盖正文终稿。
-- 禁止降低原创风险标准。
-- 禁止用多学科合理性压制章节爽点。
-- 禁止建议突破世界规则或核心人物逻辑。
-- 禁止用简单关键词、标点或字面模式宣称节奏质量、情绪合理性或 hook strength 已被确定性证明。
-
-## 与其他模块的关系
-
-- 上游：全部生成资产、`anti-copy-abstraction`、evaluation rubric、`hook.analyze`、`pacing.analyze`、`pacing.aggregate`。
-- 下游：ReviewReport、RevisionPlan、FeedbackInsight。
-- 关联 Skill：`multi-scale-pacing`、`narrative-beat-design`、`canon-continuity-graph`。
-- Agent：Review Agent、Quality Agent、Chief Editor Agent。
+Assess cost, growth, reversal, reward, and hook only when the current chapter or explicit author and obligation contracts call for them. Do not penalize a chapter merely for omitting an inapplicable technique. Never claim reader or human approval, Canon mutation, or release qualification. Return the declared JSON semantic judgment.

````

## git show ca34b2d0 -- skills/prose-generation/SKILL.md

````diff
commit ca34b2d0872da06592eb1da79dc37d2d04831c39
Author:     yuan.chen <yuan576264675@gmail.com>
AuthorDate: Wed Sep 30 21:43:00 2026 +0800
Commit:     yuan.chen <yuan576264675@gmail.com>
CommitDate: Wed Sep 30 21:43:00 2026 +0800

    fix(production): preserve frozen contracts and project prose methods

diff --git a/skills/prose-generation/SKILL.md b/skills/prose-generation/SKILL.md
index 434c1178..3f939f29 100644
--- a/skills/prose-generation/SKILL.md
+++ b/skills/prose-generation/SKILL.md
@@ -5,10 +5,20 @@ description: Draft or revise prose from a frozen Chapter plan and accepted Conte
 
 # Prose Generation
 
-Use the frozen Scene and Slot order, actor and POV scope, accessible knowledge, author intent, and accepted facts. Write reader-facing prose in each selected Slot once. The host joins Slots into the chapter; do not return a second whole-chapter copy, a Markdown report, or a self-assessed gate result.
+## Shared rules
 
-For revision, preserve unaffected prose and established advantages. Resolve evidenced blocking problems without adding unplanned facts. A proposed edit does not amend accepted Canon or the active plan.
+Use the frozen Scene and Slot order, actor and POV scope, accessible knowledge, author intent, and accepted facts. Write a continuous narrative: interleave dialogue, action, perception and thought where the scene needs them, and check scene junctions together. Slot coverage and mechanical joining do not prove literary coherence.
 
-Use cost, growth, reversal, reward, and hook techniques when the chapter function, character, arc, author intent, or due obligation calls for them. Do not insert them to satisfy a universal template. An explicit author constraint, accepted fact, or due obligation remains binding.
+Preserve unaffected prose and established advantages during revision. Resolve evidenced blocking problems without adding unplanned facts. A proposed edit does not amend accepted Canon or the active plan. ReReview and candidate comparison determine whether the candidate is acceptable.
 
-Never reuse protected reference expression or let a character act on knowledge outside the frozen boundary. Return only the declared JSON semantic result; the host supplies identities, receipts, spans, persistence, and approval.
+Use cost, pressured choice, growth, reversal, reward and hook techniques when the chapter function, character, arc, author intent or due obligation calls for them. Do not insert them to satisfy a universal template. An explicit author constraint, accepted fact or due obligation remains binding.
+
+Never reuse protected reference expression or let a character act on knowledge outside the frozen boundary. Return only the declared JSON semantic result; the host supplies identities, receipts, spans, persistence and approval.
+
+## Draft and full revision
+
+Write reader-facing prose in each frozen Slot once and return scene_artifacts in the declared order. The host joins Slots into the chapter. Do not return a second whole-chapter copy, a Markdown report or a self-assessed gate result.
+
+## Targeted revision
+
+Return only the necessary ordered edits: exact old quotes, replacement prose and linked issue codes, plus the declared resolution codes. The host disambiguates quotes against the exact frozen old draft, enforces diagnosed ranges and Scene Slot boundaries, and derives Slot and chapter prose. Do not return Slot texts or a complete revised chapter. Preserve all unaffected text exactly and read adjacent passages to check continuity.

````

## git show 52357c86 -- src/novel_forge/modules/chapter_authority/provider_views.py

````diff
commit 52357c86aa72d0d45526517936080b0950200922
Author:     yuan.chen <yuan576264675@gmail.com>
AuthorDate: Sat Aug 15 01:13:42 2026 +0800
Commit:     yuan.chen <yuan576264675@gmail.com>
CommitDate: Sat Aug 15 01:13:42 2026 +0800

    feat: close longform narrative correctness gaps

diff --git a/src/novel_forge/modules/chapter_authority/provider_views.py b/src/novel_forge/modules/chapter_authority/provider_views.py
index f3f63d1e..d82224f2 100644
--- a/src/novel_forge/modules/chapter_authority/provider_views.py
+++ b/src/novel_forge/modules/chapter_authority/provider_views.py
@@ -148,7 +148,47 @@ def build_provider_task_view(stage: str, inputs: Mapping[str, Any]) -> dict[str,
                 "PLANNING_PROVIDER_TASK_VIEW_INVALID",
                 "Planning Provider Task View requires the frozen planning command",
             )
-        return _task(stage, planning_command=_compact(command))
+        frozen_inputs = inputs.get("frozen_inputs")
+        authoritative_load = inputs.get("authoritative_narrative_load")
+        if not isinstance(frozen_inputs, list) or not frozen_inputs:
+            raise KernelError(
+                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
+                "Planning Provider Task View requires frozen input lineage",
+            )
+        if (
+            not isinstance(authoritative_load, Mapping)
+            or not isinstance(authoritative_load.get("narrative_load_policy"), Mapping)
+            or not isinstance(
+                authoritative_load.get("narrative_load_projection"), Mapping
+            )
+        ):
+            raise KernelError(
+                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
+                "Planning Provider Task View requires authoritative Narrative Load constraints",
+            )
+        return _task(
+            stage,
+            planning_command=_compact(command),
+            frozen_inputs=_compact(frozen_inputs),
+            authoritative_narrative_load=_compact(authoritative_load),
+        )
+    if stage == "narrative_semantic_evaluation":
+        profiles = inputs.get("qualification_profiles")
+        target = inputs.get("evaluation_target")
+        if (
+            not isinstance(profiles, list)
+            or not profiles
+            or not isinstance(target, Mapping)
+        ):
+            raise KernelError(
+                "NARRATIVE_EVALUATION_PROVIDER_TASK_INVALID",
+                "Semantic Evaluation requires frozen profiles and target lineage",
+            )
+        return _task(
+            stage,
+            evaluation_target=_compact(target),
+            qualification_profiles=_compact(profiles),
+        )
     if stage == "draft":
         return _task(
             stage,
@@ -198,9 +238,7 @@ def build_provider_task_view(stage: str, inputs: Mapping[str, Any]) -> dict[str,
             stage,
             chapter=int(inputs.get("chapter") or 0),
             book_id=str(inputs.get("book_id") or ""),
-            reader_contract_version=str(
-                inputs.get("reader_contract_version") or ""
-            ),
+            reader_contract_version=str(inputs.get("reader_contract_version") or ""),
             evaluation_profile_version=str(
                 inputs.get("evaluation_profile_version") or ""
             ),
@@ -346,6 +384,25 @@ def build_provider_context_view(
 
     if stage in _PLANNING_STAGES:
         return _build_planning_context_view(stage, context_bundle)
+    if stage == "narrative_semantic_evaluation":
+        selected = context_bundle.get("selected_inputs")
+        if not isinstance(selected, list) or len(selected) != 1:
+            raise KernelError(
+                "NARRATIVE_EVALUATION_PROVIDER_CONTEXT_INVALID",
+                "Semantic Evaluation requires exactly one frozen candidate projection",
+            )
+        return {
+            "contract_version": "provider-context-view-v2",
+            "schema_version": "novelos.narrative_evaluation_context_view.v1",
+            "stage": stage,
+            "source_isolation": "EXACT_CANDIDATE_ONLY",
+            "selected_inputs": _compact(selected),
+            "selection_explanation": {
+                "policy": "exact-immutable-candidate-only",
+                "selected_count": 1,
+                "omitted_count": 0,
+            },
+        }
     if stage == "reader_outcome":
         return _build_reader_outcome_context_view(context_bundle)
     correctness = context_bundle.get("context_correctness")
@@ -365,8 +422,7 @@ def build_provider_context_view(
             "REQUIRED_LONG_DISTANCE_FACT_PRESENT",
         }
         if (
-            correctness.get("contract_version")
-            != "context-correctness-receipt-v1"
+            correctness.get("contract_version") != "context-correctness-receipt-v1"
             or correctness.get("overall_status") != "PASS"
             or not isinstance(checks, Mapping)
             or set(checks) != required_checks
@@ -457,8 +513,7 @@ def build_provider_context_view(
             selected_facts = [
                 item
                 for item in facts
-                if item.get("provider_visibility")
-                != "INTERNAL_QUALITY_ONLY"
+                if item.get("provider_visibility") != "INTERNAL_QUALITY_ONLY"
                 if _state_fact_relevant(
                     item,
                     selectors,

````

## git show bbd59eb3 -- config/capability_packs/artifacts/story_planning_system_instruction.md

````diff
commit bbd59eb3f629a19499c5c79a2044a1b1c6081b96
Author:     yuan.chen <yuan576264675@gmail.com>
AuthorDate: Mon Sep 7 22:12:57 2026 +0800
Commit:     yuan.chen <yuan576264675@gmail.com>
CommitDate: Mon Sep 7 22:12:57 2026 +0800

    feat(formation): generate and qualify Foundation through governed native runtime

diff --git a/config/capability_packs/artifacts/story_planning_system_instruction.md b/config/capability_packs/artifacts/story_planning_system_instruction.md
index a440e8bf..beda3932 100644
--- a/config/capability_packs/artifacts/story_planning_system_instruction.md
+++ b/config/capability_packs/artifacts/story_planning_system_instruction.md
@@ -1,9 +1,18 @@
-You are executing one admitted Story Planning candidate-generation stage.
-Use only the frozen Authority inputs, governed long-outline skill, and declared
+You are executing one admitted Foundation or Story Planning candidate-generation stage.
+Use only the frozen Authority inputs, stage-specific governed Skills, and declared
 schema. Preserve parent lineage and future-only boundaries. Produce a candidate;
 never approve, activate, or mutate Story Design or Planning Authority state.
 
-The output schema includes a versioned `narrative_qualification`. Evaluate only
+For Foundation stages, follow `foundation_task` and its exact output schema.
+The author brief is intent; approved parents are initial design conditions, not
+accepted chapter events. Elaborate their creative consequences without altering
+them. Do not fabricate Authority references; the runtime binds the exact parents.
+World compilation is progressive and genre-dependent. Character voice anchors
+must follow motive and biography. Style examples must be original expressions.
+Independent semantic evaluation follows generation; self-reported quality is not
+activation evidence.
+
+When the output schema includes a versioned `narrative_qualification`, evaluate only
 the exact layer profiles frozen for this stage. Use each profile's declared
 Skill and criterion set; do not substitute a generic quality score or a
 universal judge. Every criterion needs a concrete rationale and references to

````

## git show 2ae98a46 -- config/capability_packs/artifacts/story_planning_system_instruction.md

````diff
commit 2ae98a46ca8f6a90a8ac08aa427e12a33468c76f
Author:     yuan.chen <yuan576264675@gmail.com>
AuthorDate: Thu Aug 27 01:14:38 2026 +0800
Commit:     yuan.chen <yuan576264675@gmail.com>
CommitDate: Thu Aug 27 01:14:38 2026 +0800

    fix freeze chapter scheduling in planning

diff --git a/config/capability_packs/artifacts/story_planning_system_instruction.md b/config/capability_packs/artifacts/story_planning_system_instruction.md
index dd22f389..a440e8bf 100644
--- a/config/capability_packs/artifacts/story_planning_system_instruction.md
+++ b/config/capability_packs/artifacts/story_planning_system_instruction.md
@@ -54,6 +54,13 @@ not planning notes. `title` must be a concise reader-facing chapter title.
 `premise` must be a concise reader-facing synopsis of the chapter. Neither may
 contain instructions to plan, draft, review, validate, approve, or activate the
 chapter, nor internal terms such as candidate, future-only, or Authority state.
+The frozen `chapter_function_matrix_row` is the immutable Scheduling contract.
+Copy its `primary_function`, `secondary_functions`, `required_state_delta`,
+`promise_action`, `foreshadow_action`, `reward_action`, `ending_hook`,
+`prohibited_outcomes`, and `narrative_density` exactly. Also copy its
+`reader_experience.target_emotion` and `reader_experience.reward_mode` exactly;
+only the chapter-specific entry/exit questions and non-scheduled operational
+detail may be elaborated.
 `character_participation.known_fact_ids` is the chapter-entry knowledge boundary;
 facts first learned during this chapter stay in `unknown_fact_ids` at entry. A
 Scene's `accessible_knowledge` must be known to its POV character before that

````

## git blame src/novel_forge/storage/book_authority_repositories.py

````text
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 840)                     "projection_kind": "accepted_obligation_state",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 841)                     "authoring_projection_kind": "accepted_hook_debt",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 842)                     "projection_contract": "hook-debt-projection-v1",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 843)                 },
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 844)             ),
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 845)             (
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 846)                 sources["canon_snapshot_asset_version_id"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 847)                 "L2",
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 848)                 None,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 849)                 {"projection_kind": "accepted_canon"},
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 850)             ),
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 851)         ]
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 852)         specifications.append(
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 853)             (
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 854)                 sources["chapter_outcome_asset_version_id"],
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 855)                 "L3",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 856)                 recent_trail,
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 857)                 {
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 858)                     "projection_kind": "accepted_scene_episodic_history",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 859)                     "authoring_projection_kind": "accepted_recent_trail",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 860)                     "projection_contract": "recent-trail-entry-v1",
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 861)                 },
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 862)             )
750ebe6c6 (yuan.chen 2026-08-25 11:14:34 +0800 863)         )
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 864)         self.cursor.execute(
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 865)             """
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 866)             UPDATE authority_narrative_retrieval_document
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 867)             SET accepted_to_chapter=%s
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 868)             WHERE project_id=%s AND book_id=%s
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 869)               AND memory_layer=ANY(%s::TEXT[])
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 870)               AND accepted_to_chapter IS NULL
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 871)               AND accepted_from_chapter<%s
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 872)             """,
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 873)             [
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 874)                 chapter - 1,
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 875)                 projection["project_id"],
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 876)                 projection["book_id"],
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 877)                 ["L1", "L2", "L4", "L5"],
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 878)                 chapter,
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 879)             ],
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 880)         )
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 881)         if accepted_draft_version_id:
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 882)             specifications.append(
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 883)                 (
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 884)                     accepted_draft_version_id,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 885)                     "L0",
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 886)                     None,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 887)                     {
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 888)                         "projection_kind": "recent_accepted_prose",
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 889)                         "archive_locator": {
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 890)                             "asset_version_id": accepted_draft_version_id,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 891)                             "chapter": chapter,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 892)                         },
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 893)                     },
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 894)                 )
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 895)             )
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 896)         for (
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 897)             source_version_id,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 898)             memory_layer,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 899)             projected_content,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 900)             metadata,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 901)         ) in specifications:
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 902)             self.cursor.execute(
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 903)                 """
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 904)                 SELECT asset.asset_type, version.content
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 905)                 FROM authority_asset_version AS version
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 906)                 JOIN authority_asset AS asset ON asset.asset_id=version.asset_id
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 907)                 WHERE version.asset_version_id=%s AND asset.project_id=%s
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 908)                 """,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 909)                 [source_version_id, projection["project_id"]],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 910)             )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 911)             source = self.cursor.fetchone()
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 912)             if source is None:
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 913)                 raise ValueError("accepted retrieval source AssetVersion is missing")
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 914)             content = (
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 915)                 dict(projected_content)
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 916)                 if projected_content is not None
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 917)                 else dict(source[1] or {})
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 918)             )
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 919)             graph = _retrieval_graph_metadata(content)
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 920)             structured_facts = _retrieval_structured_facts(
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 921)                 source_artifact_type=str(source[0]), content=content
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 922)             )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 923)             content_text = json.dumps(
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 924)                 content,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 925)                 ensure_ascii=False,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 926)                 sort_keys=True,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 927)                 separators=(",", ":"),
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 928)             )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 929)             identity = (
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 930)                 f"{projection['project_id']}:{projection['book_id']}:"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 931)                 f"{source_version_id}:{memory_layer}"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 932)             )
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 933)             retrieval_document_id = (
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 934)                 "narrative-retrieval:" + hashlib.sha256(identity.encode()).hexdigest()
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 935)             )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 936)             document = {
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 937)                 "retrieval_document_id": retrieval_document_id,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 938)                 "project_id": projection["project_id"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 939)                 "book_id": projection["book_id"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 940)                 "source_asset_version_id": source_version_id,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 941)                 "source_artifact_type": str(source[0]),
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 942)                 "accepted_from_chapter": chapter,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 943)                 "memory_layer": memory_layer,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 944)                 "content_text": content_text,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 945)                 "entity_ids": graph["entity_ids"],
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 946)                 "relationship_ids": graph["relationship_ids"],
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 947)                 "character_ids": graph["character_ids"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 948)                 "arc_plan_version_ids": arc_ids,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 949)                 "obligation_ids": obligation_ids,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 950)                 "metadata": {
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 951)                     **metadata,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 952)                     "projection_set_id": projection["projection_set_id"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 953)                     "accepted_boundary": dict(projection["accepted_boundary"]),
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 954)                     "fact_ids": _structured_fact_ids(structured_facts),
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 955)                     "historical_reference_ids": _historical_reference_ids(content),
c5f063b07 (yuan.chen 2026-09-03 02:36:05 +0800 956)                     "structured_facts": structured_facts,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 957)                 },
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 958)             }
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 959)             projection_hash = (
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 960)                 "sha256:"
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 961)                 + hashlib.sha256(
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 962)                     json.dumps(
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 963)                         document,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 964)                         ensure_ascii=False,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 965)                         sort_keys=True,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 966)                         separators=(",", ":"),
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 967)                     ).encode()
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 968)                 ).hexdigest()
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 969)             )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 970)             self.cursor.execute(
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 971)                 """
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 972)                 INSERT INTO authority_narrative_retrieval_document(
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 973)                     retrieval_document_id, project_id, book_id,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 974)                     source_asset_version_id, source_artifact_type,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 975)                     accepted_from_chapter, memory_layer, content_text,
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 976)                     entity_ids, relationship_ids, character_ids,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 977)                     arc_plan_version_ids, obligation_ids, temporal_coordinate,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 978)                     metadata, projection_hash, created_by_operation_id
5a404db90 (yuan.chen 2026-08-21 15:13:23 +0800 979)                 ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 980)                 ON CONFLICT(project_id, book_id, source_asset_version_id,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 981)                             memory_layer) DO NOTHING
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 982)                 """,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 983)                 [
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 984)                     retrieval_document_id,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 985)                     projection["project_id"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 986)                     projection["book_id"],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 987)                     source_version_id,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 988)                     str(source[0]),
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 989)                     chapter,

````

## git blame src/novel_forge/modules/capability_pack_authority/application.py

````text
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 398) def _select_capability_skill(
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 399)     skills: Sequence[Mapping[str, Any]],
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 400)     *,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 401)     capability_id: str,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 402)     input_contract_ref: str,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 403)     output_contract_ref: str,
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 404) ) -> dict[str, Any]:
ac808b126 (yuan.chen 2026-08-31 00:26:04 +0800 405)     """INVARIANT: Select a Skill from the Pack without requiring an Agent Definition.
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 406) 
ac808b126 (yuan.chen 2026-08-31 00:26:04 +0800 407)     Exact input/output contract matches win.  Packs whose Skill contract is
ac808b126 (yuan.chen 2026-08-31 00:26:04 +0800 408)     intentionally broader may fall back to a single required Skill; multiple
ac808b126 (yuan.chen 2026-08-31 00:26:04 +0800 409)     ambiguous fallbacks fail closed instead of depending on list order.
ac808b126 (yuan.chen 2026-08-31 00:26:04 +0800 410)     """
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 411)     exact = [
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 412)         dict(item)
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 413)         for item in skills
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 414)         if str(item.get("input_contract_ref") or "") == input_contract_ref
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 415)         and str(item.get("output_contract_ref") or "") == output_contract_ref
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 416)     ]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 417)     if len(exact) == 1:
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 418)         return exact[0]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 419)     output_matches = [
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 420)         dict(item)
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 421)         for item in skills
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 422)         if str(item.get("output_contract_ref") or "") == output_contract_ref
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 423)     ]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 424)     if len(output_matches) == 1:
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 425)         return output_matches[0]
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 426)     foundation_skills = {
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 427)         "creative.proposal.generate": "topic-development",
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 428)         "theme.question.generate": "narrative-beat-design",
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 429)         "ending.intent.generate": "long-outline",
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 430)         "reader.promise.generate": "hot-novel-business-deconstruction",
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 431)         "world.design.generate": "worldbuilding",
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 432)         "character.cast.generate": "character-design",
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 433)     }
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 434)     preferred_skill = (
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 435)         foundation_skills[capability_id]
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 436)         if capability_id in foundation_skills
bbd59eb3f (yuan.chen 2026-09-07 22:12:57 +0800 437)         else "chapter-outline"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 438)         if capability_id.startswith("planning.")
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 439)         else "context-builder-source-isolation"
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 440)         if capability_id.startswith("retrieval.") or capability_id == "context.task.compile"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 441)         else "prose-generation"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 442)         if capability_id.startswith(("prose.", "revision."))
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 443)         else "canon-continuity-graph"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 444)         if capability_id.startswith("canon.")
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 445)         else "quality-review"
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 446)         if capability_id.startswith(("review.", "quality.", "publishing.", "storage."))
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 447)         else ""
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 448)     )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 449)     preferred = [
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 450)         dict(item)
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 451)         for item in skills
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 452)         if str(item.get("skill_ref") or "") == preferred_skill
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 453)     ]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 454)     if len(preferred) == 1:
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 455)         return preferred[0]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 456)     required = [dict(item) for item in skills if bool(item.get("required"))]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 457)     if len(required) == 1:
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 458)         return required[0]
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 459)     raise KernelError(
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 460)         "CAPABILITY_PACK_SKILL_BINDING_AMBIGUOUS",
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 461)         "Capability node requires one contract-matching Skill binding",
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 462)     )
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 463) 
c5f5bd34c (yuan.chen 2026-08-21 02:16:01 +0800 464) 
dd7e324dd (yuan.chen 2026-08-06 03:47:44 +0800 465) class CapabilityPackAuthorityApplication:
dd7e324dd (yuan.chen 2026-08-06 03:47:44 +0800 466)     def __init__(
dd7e324dd (yuan.chen 2026-08-06 03:47:44 +0800 467)         self,
dd7e324dd (yuan.chen 2026-08-06 03:47:44 +0800 468)         database_url: str,
dd7e324dd (yuan.chen 2026-08-06 03:47:44 +0800 469)         *,
dd7e324dd (yuan.chen 2026-08-06 03:47:44 +0800 470)         application_build_id: str,

````

## git blame src/novel_forge/modules/context_builder/task_compression.py

````text
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 26) def _payload(candidate: ContextCandidate) -> dict[str, Any]:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 27)     return {
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 28)         "safe_summary": candidate.safe_summary,
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 29)         "structured_facts": [fact for fact in candidate.structured_facts if fact.get("provider_visibility") != "INTERNAL_QUALITY_ONLY"],
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 30)     }
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 31) 
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 32) 
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 33) def _units(candidate: ContextCandidate, task: Mapping[str, Any]) -> list[dict[str, Any]]:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 34)     units = []
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 35)     try:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 36)         document = json.loads(candidate.safe_summary)
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 37)     except (ValueError, TypeError):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 38)         document = None
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 39)     if isinstance(document, dict):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 40)         engineering = {"provider_evidence", "context_bundle_id", "context_bundle_content_hash", "context_fingerprint", "retrieval_result_asset_version_id", "retrieval_result_fingerprint", "created_by_operation_id", "validation_evidence", "model_call_log", "cost_ledger"}
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 41)         for field, value in sorted(document.items()):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 42)             if field in engineering:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 43)                 continue
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 44)             if field in {"scene_artifacts", "scenes", "scene_summaries"} and isinstance(value, list):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 45)                 for index, scene in enumerate(value):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 46)                     units.append({"unit_id": f"json:{field}:{index}", "text": json.dumps(scene, ensure_ascii=False, sort_keys=True, separators=(",", ":")), "kind": "SOURCE_SCENE_OR_CAUSAL_UNIT", "field": "safe_summary", "source_path": [field, index]})
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 47)             elif field in {"text", "safe_summary", "summary"} and isinstance(value, str):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 48)                 for index, paragraph in enumerate(value.split("\n\n")):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 49)                     if paragraph:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 50)                         units.append({"unit_id": f"json:{field}:{index}", "text": paragraph, "kind": "SOURCE_PARAGRAPH", "field": "safe_summary", "source_path": [field], "index": index})
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 51)             else:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 52)                 units.append({"unit_id": f"json:{field}", "text": json.dumps({field: value}, ensure_ascii=False, sort_keys=True, separators=(",", ":")), "kind": "SOURCE_CAUSAL_FIELD", "field": "safe_summary", "source_path": [field], "required": True})
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 53)     else:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 54)         for index, text in enumerate(candidate.safe_summary.split("\n\n")):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 55)             if text:
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 56)                 units.append({"unit_id": f"text:{index}", "text": text, "kind": "SOURCE_PARAGRAPH", "field": "safe_summary", "index": index})
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 57)     for index, fact in enumerate(candidate.structured_facts):
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 58)         if fact.get("provider_visibility") == "INTERNAL_QUALITY_ONLY":
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 59)             continue
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 60)         units.append({"unit_id": f"fact:{index}", "text": json.dumps(fact, ensure_ascii=False, sort_keys=True, separators=(",", ":")), "kind": "STATE_OR_CAUSAL_UNIT", "field": "structured_facts", "index": index})
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 61)     quotes = tuple(task.get("preserve_quotes") or ())
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 62)     for unit in units:
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 63)         heading = task.get("stage") == "reference_analysis" and any(
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 64)             re.match(r"^第[0-9一二三四五六七八九十百千万零〇两]+[章回节卷](?:\s|$)", line.strip())
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 65)             for line in unit["text"].splitlines()
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 66)         )
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 67)         if heading:
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 68)             unit["kind"] = "SOURCE_LOCATION_HEADER"
c62df1331 (yuan.chen 2026-10-02 22:06:02 +0800 69)         unit["required"] = bool(unit.get("required")) or heading or candidate.required or unit["field"] == "structured_facts" or any(quote in unit["text"] for quote in quotes)
e61614075 (yuan.chen 2026-10-01 16:24:21 +0800 70)     return units

````
