# Complete Dynamic Instructions and Construction

C entries are evaluated code-built instructions. Language zh-CN is conditional on governed language evidence. D entries preserve full original construction. Additional helper constants and complete source branches: 06-instruction-source-corpus.md. NO Provider invocation. Wire-only labels are excluded from final prompts.

## C001 memo / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Suggest concrete creative guidance for the frozen Chapter mission and Scene roles. A choice, cost, emotional turn, reward, reversal, or hook is applicable only when the chapter function, author intent, Arc or due obligation calls for it. Use null for an inapplicable optional guidance field and [] when no character choice is needed. Provide at least one task-relevant retrieval query for accepted history. Accepted facts and explicit author constraints remain binding. Do not claim an outcome occurred or that the Memo changed the active Plan.
````

## C002 memo / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Turn the frozen Chapter mission into specific creative guidance rather than paraphrasing it. Explain each character choice through motivation and cost, scene conflict, emotional movement, information release and continuity, reader promise and ending change. Respect POV and voice. Use exact Scene/Arc/character identities. Accepted boundary is fact provenance; scene targets are author plans; your choices are suggestions. Never introduce Canon or undisclosed secrets. Keep the plan and accepted boundary unchanged; propose craft decisions within their constraints.
````

## C003 draft / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return one JSON result with scene_artifacts in exact frozen Slot order. Each Slot has one reader-facing prose text and only the in-scope used_fact_ids. Do not return a second chapter text, Markdown, self-check, change log, or approval claim. The host joins Slot text and binds identities and receipts. Respect actor, POV, source and knowledge boundaries, accepted facts, explicit author constraints, and due obligations. Use optional craft techniques only where relevant to this Chapter.
````

## C004 draft / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Produce candidate prose within the frozen Scene realization contract. Each selected specialist slot must appear exactly once in contract order. Use only its accessible fact references; report used_fact_ids explicitly. Do not give a character reader-only knowledge. Keep every factual commitment inside the approved Scene scope and declared voice contracts. The text field must equal slot texts joined with two newlines, or the exact frozen scene_separators when supplied for an author candidate. Preserve those separators. For Revision, preserve unaffected slots and amend only slots needed by the frozen review issues; Quality and Actual reconciliation will run again. If no Scene slots exist, return scene_artifacts=[]. Candidate generation never changes Canon or accepted Narrative Reality.Return only the stage result defined by the frozen output schema.
````

## C005 review / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Judge this exact candidate against applicable author, accepted-state, knowledge, Scene and due-obligation constraints. For evidence return a literal quote only; the host locates Unicode spans against the frozen candidate and rejects missing or ambiguous quotes. A quote alone is not semantic support. Separate conflicts, uncertainty, and taste; do not penalize omitted cost, growth, reversal, reward or hook techniques when they are not required by this Chapter. Never claim human approval.
````

## C006 review / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Diagnose the actual candidate against frozen constraints and creative guidance. Every issue requires category, judgment_kind, literal evidence with Unicode code-point start/end offsets, violated_constraint, revision_goal, preserve and acceptance_criteria. Separate semantic conflicts, uncertain judgments and aesthetic suggestions. Provider opinions are not deterministic proof; taste preferences alone are minor. Do not invent defects from a plan target that prose deliberately leaves unfulfilled. Return resolution_checks=[] on initial review. Evidence must identify a concrete defect and an observable repair condition. For every knowledge_review_target return a knowledge_check using its exact card version. Check mechanism, prerequisites, exceptions, cost and consequences in actual prose, including knowledge/disclosure boundaries, future leakage and false payoff. VERIFIED_IN_PROSE needs literal evidence and explicit conditions_checked/ exceptions_checked; terminology or Writer used_fact_ids is insufficient. Unused inspiration is NOT_USED, uncertainty is UNKNOWN. MISAPPLIED requires linked actionable issue_codes; unresolved CONSTRAINT requires a blocking issue. Return knowledge_checks=[] if no targets. Never call this formal proof or human approval.
````

## C007 revision / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return one JSON result with scene_artifacts in exact frozen Slot order. Each Slot has one reader-facing prose text and only the in-scope used_fact_ids. Do not return a second chapter text, Markdown, self-check, change log, or approval claim. The host joins Slot text and binds identities and receipts. Respect actor, POV, source and knowledge boundaries, accepted facts, explicit author constraints, and due obligations. Use optional craft techniques only where relevant to this Chapter. Preserve every unaffected Slot and the chapter's narrative scale. Address evidenced blocking issues; report a resolved code only when the revised prose actually addresses it. For targeted edits, quote the exact old passage; the host locates it and enforces frozen ranges.
````

## C008 revision / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Produce candidate prose within the frozen Scene realization contract. Each selected specialist slot must appear exactly once in contract order. Use only its accessible fact references; report used_fact_ids explicitly. Do not give a character reader-only knowledge. Keep every factual commitment inside the approved Scene scope and declared voice contracts. The text field must equal slot texts joined with two newlines, or the exact frozen scene_separators when supplied for an author candidate. Preserve those separators. For Revision, preserve unaffected slots and amend only slots needed by the frozen review issues; Quality and Actual reconciliation will run again. If no Scene slots exist, return scene_artifacts=[]. Candidate generation never changes Canon or accepted Narrative Reality.Return text as final reader-facing revised chapter prose only. Resolve every supplied review issue in the prose, prioritizing blocking and major issues; list a code in resolved_issue_codes only after the edit is actually present. For a governed Quality revision task, make the smallest bounded edit that resolves the supplied task, preserve all unrelated scenes, causal links, established facts, and already-passing quality dimensions, and retain the complete reader-facing chapter at its original narrative scale unless chapter_length is itself the supplied task. Never replace the full chapter with a summary or excerpt. Revise the reader-facing prose into the governed language even when the input draft uses another language. Do not preserve a conflicting input language. Do not put a serialized JSON object inside text. Do not include analysis, self-checks, change logs, revision evidence, or operator-facing appendices in text.
````

## C009 rereview / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Judge this exact candidate against applicable author, accepted-state, knowledge, Scene and due-obligation constraints. For evidence return a literal quote only; the host locates Unicode spans against the frozen candidate and rejects missing or ambiguous quotes. A quote alone is not semantic support. Separate conflicts, uncertainty, and taste; do not penalize omitted cost, growth, reversal, reward or hook techniques when they are not required by this Chapter. Never claim human approval. Check every prior diagnosis against revised prose and preserve successful content.
````

## C010 rereview / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Independently verify the revised chapter against the supplied review. Report in issues only defects that remain acceptance-blocking: an unresolved blocking or major issue, or a material regression that prevents acceptance. Do not report optional minor polish or taste preferences in issues. If no acceptance-blocking defect remains, return issues=[] and an evidence-based score. Never suppress an actual blocking or major defect. For EVERY prior diagnosis return a resolution_check tied to its acceptance criteria, with a literal revised-prose evidence location and preservation assessment. SATISFIED requires the repair to be present and required content preserved. A claimed fix, issue omission, or a higher score never establishes resolution; report UNRESOLVED/UNCERTAIN when needed. Recheck every knowledge_review_target against this revised prose in knowledge_checks. Use its exact card version and literal evidence; check mechanisms, prerequisites, exceptions and narrative consequences. MISAPPLIED requires linked actionable issue_codes; unresolved CONSTRAINT requires a blocking issue. Prior verification never transfers to changed prose. Unused inspiration may be NOT_USED; report UNKNOWN for uncertainty; no targets means [].
````

## C011 canon_extraction / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Extract only facts and state changes supported by the revised chapter. Treat from_status, from_state, from_stance, and from_tier only as compare-and-set preconditions against the exact accepted Story State supplied in the governed context. For a first occurrence with no accepted entity baseline, leave from_status, from_state, from_stance, and from_tier null; never infer them from prose, Story Design assets, plans, or ordinary background conditions. For canon_facts, compare each (subject, predicate) slot with the accepted Canon facts supplied in the governed context. If the chapter does not materially change an accepted fact, omit the redundant fact or reuse its object exactly. If the chapter changes, refines, or replaces that fact, copy the accepted fact's exact source_event_id into supersedes_event_id. Never paraphrase an unchanged accepted fact into a different object, and never invent a supersession identity. Treat requires_fact_ids as character-specific epistemic preconditions. Every required fact must already appear in that character's accepted known facts in the governed context, or the chapter must first establish it through an atomic character_knowledge_changes item with fact_id and chapter evidence. World-rule availability is not automatically character knowledge. If the prose and governed context do not establish the knowledge, omit the unsupported action or requirement; never add unsupported knowledge merely to satisfy validation. Keep Story Truth, Character Knowledge, Character Belief, Reader Knowledge, and presentation separate: a Canon fact does not by itself make any character or the reader aware of it; a belief may be false. In character_knowledge_changes, emit one item per character_id plus fact_id or proposition_id; never bundle multiple newly learned facts into one Character Knowledge event. Use only the status field with UNKNOWN, SUSPECTED, KNOWN, or FORGOTTEN; leave the generic state field null. In character_belief_changes, use only stance with BELIEVES, DOUBTS, DISBELIEVES, or UNCERTAIN plus belief_confidence from zero to one; use from_stance only for an exact accepted baseline and leave generic state, status, from_state, and from_status null. In relationship_changes, always copy both directed graph endpoints into source_id and target_id; entity_id cannot replace an endpoint, and the generic character_id field must remain null. Use obligation_changes for the unified accepted Narrative Obligation lifecycle. Copy obligation_id, obligation_type, priority, target_window, and linked Arc identities from governed context. FULFILLED requires a supported payoff: null for a prose payoff that the host binds, or a typed accepted prerequisite for CAUSAL_DEBT. For a non-CAUSAL_DEBT prose payoff set payoff_evidence to null; the host binds this candidate and grounded claim. For CAUSAL_DEBT select only an exact accepted prerequisite source and event from governed context. Arc evidence alone never silently closes an obligation. For CAUSAL_DEBT, preserve causal_plan_asset_version_id and the exact causal_requirement.payload_json predicate from its planning origin. A plan cannot repay debt: FULFILLED requires a satisfied condition and its accepted source event as payoff_evidence.event_id. Other obligation types use null for these two causal fields. World, faction, location, consequence and conflict state changes require world_transition.payload_json: transition_id, actor_id, camera (ON_CAMERA, OFF_CAMERA or UNDERCURRENT), native StoryTime, action, state_kind, exact entity_key, changes, requirements, cause_refs and epistemic_basis. Causes must resolve to accepted source events. Observe only events supported by the final prose, including explicitly narrated off-camera events; a proposed future is not an occurrence. Every typed change must copy its exact stable Authority identity: character_id for character and power state, event_id for timeline, thread_id for foreshadow and plot thread, promise_id, reward_id, rule_id, entity_id plus resource_id for resource balances, fingerprint_id, antagonist_id, character_id plus arc_id for character trajectory, arc_id for narrative Arc state, and disclosure_id for presentation. A generic entity_id never substitutes for another domain's identity. If no stable identity is available in governed context, omit the unsupported change. Emit every supported planned non-WITHHOLD presentation as a disclosure_event, including character-facing events; accepted reader-facing Disclosure alone is deterministically projected into Reader Knowledge. Record how the information was presented through disclosure_mode, audience, and presentation_channel rather than copying Truth into every epistemic layer. Reconcile the frozen execution_expectations exactly. For every required state transition supported by the chapter, emit one change in the corresponding typed array with the exact planned identity and to_state; do not paraphrase either. Omit from_* only when the governed context has no accepted baseline. For every planned disclosure, copy disclosure_id, fact_id, audience, and mode exactly; do not expand the audience. Reader Knowledge will be derived after the Disclosure is accepted. Arc and Narrative Realization evidence describes final candidate prose, never Plan or Future Intent. Return exactly one arc_evidence item for each frozen expected Arc contribution. Use observation_status OBSERVED only when the selected candidate visibly executes that contribution. An OBSERVED Arc item must include at least one unique literal final-candidate prose quote in resolution_evidence; the host binds its location. Otherwise return zero progress_units and an empty resolution_evidence list. Return one realization_evidence item for every frozen Narrative Realization event. OBSERVED realization evidence requires a non-empty accepted_prose_evidence list with unique literal final-candidate quotes plus the observed event identity, action, decision, consequence, and state deltas. Planning context alone never proves observation. Within canon_facts, each (subject, predicate, impact_type) tuple may occur at most once. When one subject has multiple objects for a broad relation, either combine them into one object when they are one bundled fact, or use precise relation-specific predicates. For example, encode separate consent facts as authorizes_testimony and authorizes_public_identification instead of repeating authorizes with two objects. Never emit two different objects for the same semantic tuple. Use resource_state_changes only for quantifiable resource balances. An initial resource baseline must set balance_after; a later transition must set balance_before, delta, and balance_after with exact arithmetic. Do not encode custody, location, protection, ownership, or other qualitative object status as a Resource State merely because the object is a story resource; represent supported qualitative changes as precise canon_facts or timeline_events instead. If the prose supplies no numeric balance, leave resource_state_changes empty.
````

## C012 canon_extraction / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Extract only facts and state changes supported by the revised chapter. Treat from_status, from_state, from_stance, and from_tier only as compare-and-set preconditions against the exact accepted Story State supplied in the governed context. For a first occurrence with no accepted entity baseline, leave from_status, from_state, from_stance, and from_tier null; never infer them from prose, Story Design assets, plans, or ordinary background conditions. For canon_facts, compare each (subject, predicate) slot with the accepted Canon facts supplied in the governed context. If the chapter does not materially change an accepted fact, omit the redundant fact or reuse its object exactly. If the chapter changes, refines, or replaces that fact, copy the accepted fact's exact source_event_id into supersedes_event_id. Never paraphrase an unchanged accepted fact into a different object, and never invent a supersession identity. Treat requires_fact_ids as character-specific epistemic preconditions. Every required fact must already appear in that character's accepted known facts in the governed context, or the chapter must first establish it through an atomic character_knowledge_changes item with fact_id and chapter evidence. World-rule availability is not automatically character knowledge. If the prose and governed context do not establish the knowledge, omit the unsupported action or requirement; never add unsupported knowledge merely to satisfy validation. Keep Story Truth, Character Knowledge, Character Belief, Reader Knowledge, and presentation separate: a Canon fact does not by itself make any character or the reader aware of it; a belief may be false. In character_knowledge_changes, emit one item per character_id plus fact_id or proposition_id; never bundle multiple newly learned facts into one Character Knowledge event. Use only the status field with UNKNOWN, SUSPECTED, KNOWN, or FORGOTTEN; leave the generic state field null. In character_belief_changes, use only stance with BELIEVES, DOUBTS, DISBELIEVES, or UNCERTAIN plus belief_confidence from zero to one; use from_stance only for an exact accepted baseline and leave generic state, status, from_state, and from_status null. In relationship_changes, always copy both directed graph endpoints into source_id and target_id; entity_id cannot replace an endpoint, and the generic character_id field must remain null. Use obligation_changes for the unified accepted Narrative Obligation lifecycle. Copy obligation_id, obligation_type, priority, target_window, and linked Arc identities from governed context. FULFILLED requires a typed payoff_evidence object. For a prose payoff use the literal asset_version_id=$FINAL_CANDIDATE and event_id=$CURRENT_CLAIM; the Authority binds these to this final candidate and grounded claim. Never invent an AssetVersion or accepted event identity. Arc evidence alone never silently closes an obligation. For CAUSAL_DEBT, preserve causal_plan_asset_version_id and the exact causal_requirement.payload_json predicate from its planning origin. A plan cannot repay debt: FULFILLED requires a satisfied condition and its accepted source event as payoff_evidence.event_id. Other obligation types use null for these two causal fields. World, faction, location, consequence and conflict state changes require world_transition.payload_json: transition_id, actor_id, camera (ON_CAMERA, OFF_CAMERA or UNDERCURRENT), native StoryTime, action, state_kind, exact entity_key, changes, requirements, cause_refs and epistemic_basis. Causes must resolve to accepted source events. Observe only events supported by the final prose, including explicitly narrated off-camera events; a proposed future is not an occurrence. Every typed change must copy its exact stable Authority identity: character_id for character and power state, event_id for timeline, thread_id for foreshadow and plot thread, promise_id, reward_id, rule_id, entity_id plus resource_id for resource balances, fingerprint_id, antagonist_id, character_id plus arc_id for character trajectory, arc_id for narrative Arc state, and disclosure_id for presentation. A generic entity_id never substitutes for another domain's identity. If no stable identity is available in governed context, omit the unsupported change. Emit every supported planned non-WITHHOLD presentation as a disclosure_event, including character-facing events; accepted reader-facing Disclosure alone is deterministically projected into Reader Knowledge. Record how the information was presented through disclosure_mode, audience, and presentation_channel rather than copying Truth into every epistemic layer. Reconcile the frozen execution_expectations exactly. For every required state transition supported by the chapter, emit one change in the corresponding typed array with the exact planned identity and to_state; do not paraphrase either. Omit from_* only when the governed context has no accepted baseline. For every planned disclosure, copy disclosure_id, fact_id, audience, and mode exactly; do not expand the audience. Reader Knowledge will be derived after the Disclosure is accepted. Arc and Narrative Realization evidence describes final candidate prose, never Plan or Future Intent. Return exactly one arc_evidence item for each frozen expected Arc contribution. Use observation_status OBSERVED only when the accepted revision visibly executes that contribution. An OBSERVED Arc item must include at least one resolution_evidence string encoded as chars:<start>-<end>:<summary>, where start and end are valid Unicode code-point offsets into final_candidate; otherwise return zero progress_units and an empty resolution_evidence list. Return one realization_evidence item for every frozen Narrative Realization event. OBSERVED realization evidence requires a non-empty accepted_prose_evidence list with valid final_candidate Unicode code-point offsets plus the observed event identity, action, decision, consequence, and state deltas. Planning context alone never proves observation. Within canon_facts, each (subject, predicate, impact_type) tuple may occur at most once. When one subject has multiple objects for a broad relation, either combine them into one object when they are one bundled fact, or use precise relation-specific predicates. For example, encode separate consent facts as authorizes_testimony and authorizes_public_identification instead of repeating authorizes with two objects. Never emit two different objects for the same semantic tuple. Use resource_state_changes only for quantifiable resource balances. An initial resource baseline must set balance_after; a later transition must set balance_before, delta, and balance_after with exact arithmetic. Do not encode custody, location, protection, ownership, or other qualitative object status as a Resource State merely because the object is a story resource; represent supported qualitative changes as precise canon_facts or timeline_events instead. If the prose supplies no numeric balance, leave resource_state_changes empty.
````

## C013 canon_support / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Independently check each candidate claim against final prose and exact accepted references. A matching quote is necessary, never sufficient. Distinguish objective events from dialogue, belief, hearsay, plans and intentions. Knowledge belongs only to the evidenced recipient. GROUNDED_FINAL_CANDIDATE_CLAIM payoff citations identify this candidate's claim, not a historical event; check the actual fulfillment against the final prose. Return UNSUPPORTED or UNCERTAIN when entailment is missing. Do not repair claims or supply events from plans. Review NARRATIVE_OBSERVATION claims against prose as well; a plan is only the comparison target. Check extraction coverage; approve NO_CHANGE only when prose supports no new canonical change. You provide evidence only; Book acceptance remains Authority.
````

## C014 canon_support / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Independently check each candidate claim against final prose and exact accepted references. A matching quote is necessary, never sufficient. Distinguish objective events from dialogue, belief, hearsay, plans and intentions. Knowledge belongs only to the evidenced recipient. GROUNDED_FINAL_CANDIDATE_CLAIM payoff citations identify this candidate's claim, not a historical event; check the actual fulfillment against the final prose. Return UNSUPPORTED or UNCERTAIN when entailment is missing. Do not repair claims or supply events from plans. Review NARRATIVE_OBSERVATION claims against prose as well; a plan is only the comparison target. Check extraction coverage; approve NO_CHANGE only when prose supports no new canonical change. You provide evidence only; Book acceptance remains Authority.
````

## C015 quality_structural / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. PASSED and FAILED dimensions require literal candidate-prose quotes. For other statuses return [] when no prose supports a location. Explain policy and context support in claim. The host binds Unicode positions and candidate identity; a literal match alone is not semantic support. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C016 quality_structural / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. Every returned dimension must include at least one concrete evidence location, including policy-compliance dimensions. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C017 quality_commercial / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. PASSED and FAILED dimensions require literal candidate-prose quotes. For other statuses return [] when no prose supports a location. Explain policy and context support in claim. The host binds Unicode positions and candidate identity; a literal match alone is not semantic support. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C018 quality_commercial / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. Every returned dimension must include at least one concrete evidence location, including policy-compliance dimensions. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C019 quality_source_originality / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. PASSED and FAILED dimensions require literal candidate-prose quotes. For other statuses return [] when no prose supports a location. Explain policy and context support in claim. The host binds Unicode positions and candidate identity; a literal match alone is not semantic support. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. Judge originality as differentiated execution within the supplied project-owned task and the governed source boundary. Universal comparison against every published work is not required and its absence alone is not a reason for REQUIRES_HUMAN_REVIEW. When source isolation is clear, no reference expression or suspicious overlap is present, and the prose contains concrete project-specific causal choices, originality may PASS with provider-uncalibrated evidence. Use REQUIRES_HUMAN_REVIEW only for an identified similarity, lineage, or attribution ambiguity that cannot be resolved from the governed inputs; name that specific risk in the evidence. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C020 quality_source_originality / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. Every returned dimension must include at least one concrete evidence location, including policy-compliance dimensions. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. Judge originality as differentiated execution within the supplied project-owned task and the governed source boundary. Universal comparison against every published work is not required and its absence alone is not a reason for REQUIRES_HUMAN_REVIEW. When source isolation is clear, no reference expression or suspicious overlap is present, and the prose contains concrete project-specific causal choices, originality may PASS with provider-uncalibrated evidence. Use REQUIRES_HUMAN_REVIEW only for an identified similarity, lineage, or attribution ambiguity that cannot be resolved from the governed inputs; name that specific risk in the evidence. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C021 quality_longform / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. PASSED and FAILED dimensions require literal candidate-prose quotes. For other statuses return [] when no prose supports a location. Explain policy and context support in claim. The host binds Unicode positions and candidate identity; a literal match alone is not semantic support. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. For world_rule_conflict and power_state_conflict, distinguish a proven no-op from missing comparison state: when the chapter directly shows no state-changing use or claim and current state candidates contain no transition, return PASSED with concrete no-op evidence; do not require the chapter to exercise the rule or power. When the chapter claims a state or transition but the governed comparison baseline is unavailable, return INSUFFICIENT_EVIDENCE. Treat canon_conflicts as the authoritative deterministic continuity result: when it is empty, do not invent a Canon conflict. Compare world-rule usages against governed_world_rules in the Quality Context; when the exact rule and its limits are present and the chapter stays within them, return PASSED with concrete rule-and-prose evidence. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C022 quality_longform / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. Every returned dimension must include at least one concrete evidence location, including policy-compliance dimensions. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. For world_rule_conflict and power_state_conflict, distinguish a proven no-op from missing comparison state: when the chapter directly shows no state-changing use or claim and current state candidates contain no transition, return PASSED with concrete no-op evidence; do not require the chapter to exercise the rule or power. When the chapter claims a state or transition but the governed comparison baseline is unavailable, return INSUFFICIENT_EVIDENCE. Treat canon_conflicts as the authoritative deterministic continuity result: when it is empty, do not invent a Canon conflict. Compare world-rule usages against governed_world_rules in the Quality Context; when the exact rule and its limits are present and the chapter stays within them, return PASSED with concrete rule-and-prose evidence. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C023 quality_platform / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. PASSED and FAILED dimensions require literal candidate-prose quotes. For other statuses return [] when no prose supports a location. Explain policy and context support in claim. The host binds Unicode positions and candidate identity; a literal match alone is not semantic support. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. Evaluate ai_content_policy only against the exact compiled_platform_policy and its release_scope. When governed assisted content is allowed for internal Provider validation and the chapter meets the listed content requirements, return PASSED with concrete policy and prose evidence. Do not duplicate source-lineage, copyright, or originality review in ai_content_policy; those are independently governed dimensions. A separate human approval required for external publication is not a defect in an internal validation release. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C024 quality_platform / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Evaluate only the requested dimensions. Every returned dimension must include at least one concrete evidence location, including policy-compliance dimensions. Use PASSED only when the supplied chapter or governed context directly supports the claim; otherwise use INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate. Evaluate ai_content_policy only against the exact compiled_platform_policy and its release_scope. When governed assisted content is allowed for internal Provider validation and the chapter meets the listed content requirements, return PASSED with concrete policy and prose evidence. Do not duplicate source-lineage, copyright, or originality review in ai_content_policy; those are independently governed dimensions. A separate human approval required for external publication is not a defect in an internal validation release. For a requested language, platform, or format dimension, treat prose that is not primarily Simplified Chinese as FAILED; Authority acceptance alone is not evidence of language compliance.
````

## C025 retrieval / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Return exactly one numeric embedding vector for each frozen input text, in the same order. The frozen output identity is exact: set embedding_model to "${FROZEN_EMBEDDING_MODEL}" and embedding_dimensions to 3. Every vector must have exactly 3 finite numeric entries and non-zero L2 norm; normalize each vector to unit length. Produce a genuine dense semantic representation whose latent axes remain consistent across calls under this exact contract, so meaningfully similar passages remain close without lexical, entity, Arc, or obligation overlap. Never emit a placeholder, sentinel, all-zero vector, provider-unavailable identity, summary, or invented fact. Do not retrieve or mutate Authority state.
````

## C026 retrieval / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Return exactly one numeric embedding vector for each frozen input text, in the same order. The frozen output identity is exact: set embedding_model to "${FROZEN_EMBEDDING_MODEL}" and embedding_dimensions to 3. Every vector must have exactly 3 finite numeric entries and non-zero L2 norm; normalize each vector to unit length. Produce a genuine dense semantic representation whose latent axes remain consistent across calls under this exact contract, so meaningfully similar passages remain close without lexical, entity, Arc, or obligation overlap. Never emit a placeholder, sentinel, all-zero vector, provider-unavailable identity, summary, or invented fact. Do not retrieve or mutate Authority state.
````

## C027 retrieval_query_expansion / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Return only a bounded retrieval query proposal matching the strict schema. Every query must target one supplied deterministic evidence gap and stay within the frozen accepted chapter boundary and allowed selector dimensions. Never emit SQL, database identifiers, arbitrary AssetVersion identifiers, future-state selectors, retrieved records, sufficiency decisions, or Authority mutations. Deterministic policy validates the proposal and alone decides whether another governed retrieval round executes.
````

## C028 retrieval_query_expansion / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Return only a bounded retrieval query proposal matching the strict schema. Every query must target one supplied deterministic evidence gap and stay within the frozen accepted chapter boundary and allowed selector dimensions. Never emit SQL, database identifiers, arbitrary AssetVersion identifiers, future-state selectors, retrieved records, sufficiency decisions, or Authority mutations. Deterministic policy validates the proposal and alone decides whether another governed retrieval round executes.
````

## C029 context_compress / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Select exact unit_id values from this bounded chunk that retain the task relevant causal meaning. Preserve every required unit and the subject, time, negation, condition, exception, uncertainty, and distinction between fact, belief, suspicion and plan. Keep task important voice, humor, relationship subtext and promise wording. Return unit IDs only; do not rewrite text, invent units, emit source hashes or positions, or decide fidelity. This is a derived extract proposal, never Canon. If required information cannot fit, preserve it and let the host block. 
````

## C030 context_compress / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Select exact unit_id values from this bounded chunk that retain the task relevant causal meaning. Preserve every required unit and the subject, time, negation, condition, exception, uncertainty, and distinction between fact, belief, suspicion and plan. Keep task important voice, humor, relationship subtext and promise wording. Return unit IDs only; do not rewrite text, invent units, emit source hashes or positions, or decide fidelity. This is a derived extract proposal, never Canon. If required information cannot fit, preserve it and let the host block. 
````

## C031 context_fidelity / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Independently inspect the proposed extract against this original source chunk and frozen task. Check forward source support and reverse required meaning coverage. Check subject, time, negation, conditions, exceptions, uncertainty, epistemic status, causal prerequisites, voice, relationship subtext and promises. A legal ID alone is not fidelity proof. Report unsupported or distorted selected IDs and missing original IDs. Fail closed on uncertainty and give a concrete reason. Do not rewrite extracts, mutate story state or rely on a compressor verdict. 
````

## C032 context_fidelity / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Independently inspect the proposed extract against this original source chunk and frozen task. Check forward source support and reverse required meaning coverage. Check subject, time, negation, conditions, exceptions, uncertainty, epistemic status, causal prerequisites, voice, relationship subtext and promises. A legal ID alone is not fidelity proof. Report unsupported or distorted selected IDs and missing original IDs. Fail closed on uncertainty and give a concrete reason. Do not rewrite extracts, mutate story state or rely on a compressor verdict. 
````

## C033 agent_session / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Reason only over the frozen accepted boundary, committed transcript, observations, and server Tool snapshot. Choose exactly one action: request one Tool by copying its exact tool_name, or return one final candidate/proposal response. Encode Tool arguments and final response as one JSON object string in the required payload_json envelope. The outer response must still match the strict schema exactly. A Skill supplies method only and never adds permission. Never claim to mutate Canon, Accepted Narrative State, Arc Actual, Narrative Obligation lifecycle, active Plan pointers, or Chapter acceptance. Authority Commands submit proposals only; the owning Authority decides them.
````

## C034 agent_session / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Reason only over the frozen accepted boundary, committed transcript, observations, and server Tool snapshot. Choose exactly one action: request one Tool by copying its exact tool_name, or return one final candidate/proposal response. Encode Tool arguments and final response as one JSON object string in the required payload_json envelope. The outer response must still match the strict schema exactly. A Skill supplies method only and never adds permission. Never claim to mutate Canon, Accepted Narrative State, Arc Actual, Narrative Obligation lifecycle, active Plan pointers, or Chapter acceptance. Authority Commands submit proposals only; the owning Authority decides them.
````

## C035 narrative_semantic_evaluation / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Independently evaluate the immutable candidate against every frozen qualification profile and criterion. The frozen Provider Context is the complete evidence boundary. For EXACT_CANDIDATE_ONLY, use only the first selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the first selected input as the sole candidate under evaluation and consume each remaining exact qualified dependency's semantic_payload as evidence for that candidate's cross-layer claims. A reference-only BookDesign field is not missing evidence when its exact referenced dependency supplies the semantics. Do not consume prior qualification verdicts, demand downstream plans that cannot legally exist at the candidate's stage, or infer anything outside the frozen candidate-and-dependency envelope. Copy layer, profile_id, profile_version, profile_hash, capability_id, skill_ref, criterion, and candidate evidence identities exactly. Return one verdict per criterion. A non-PASS verdict must include a concrete repair_directive; PASS must leave repair_directive empty. Do not activate, revise, or replace the candidate, and do not infer evidence outside the frozen candidate.
````

## C036 narrative_semantic_evaluation / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Independently evaluate the immutable candidate against every frozen qualification profile and criterion. The frozen Provider Context is the complete evidence boundary. For EXACT_CANDIDATE_ONLY, use only the first selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the first selected input as the sole candidate under evaluation and consume each remaining exact qualified dependency's semantic_payload as evidence for that candidate's cross-layer claims. A reference-only BookDesign field is not missing evidence when its exact referenced dependency supplies the semantics. Do not consume prior qualification verdicts, demand downstream plans that cannot legally exist at the candidate's stage, or infer anything outside the frozen candidate-and-dependency envelope. Copy layer, profile_id, profile_version, profile_hash, capability_id, skill_ref, criterion, and candidate evidence identities exactly. Return one verdict per criterion. A non-PASS verdict must include a concrete repair_directive; PASS must leave repair_directive empty. Do not activate, revise, or replace the candidate, and do not infer evidence outside the frozen candidate.
````

## C037 longform_prose_review / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C038 longform_prose_review / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C039 reader_outcome / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C040 reader_outcome / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C041 screenplay_generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C042 screenplay_generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C043 screenplay_review / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C044 screenplay_review / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C045 screenplay_revision / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C046 screenplay_revision / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C047 creative.candidates.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C048 creative.candidates.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C049 theme.candidates.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C050 theme.candidates.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C051 ending.intent.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C052 ending.intent.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C053 reader.promise.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C054 reader.promise.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C055 world.design.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C056 world.design.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C057 character.cast.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C058 character.cast.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C059 book_plan.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. For world_realization and character_realization, every CURRENT entity's realization_level must be at least the top-level realization_level using ANCHOR < DEFINED < DETAILED < ACTIVE. Every knowledge_disclosure_obligations.obligation_windows[].obligation_id must copy one exact identity declared in story_truth_ids, mystery_ids, promise_ids, or foreshadow_ids, and each window must satisfy setup_chapter <= payoff_not_before <= payoff_due_by inside the bounded Book. 
````

## C060 book_plan.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. For world_realization and character_realization, every CURRENT entity's realization_level must be at least the top-level realization_level using ANCHOR < DEFINED < DETAILED < ACTIVE. Every knowledge_disclosure_obligations.obligation_windows[].obligation_id must copy one exact identity declared in story_truth_ids, mystery_ids, promise_ids, or foreshadow_ids, and each window must satisfy setup_chapter <= payoff_not_before <= payoff_due_by inside the bounded Book. 
````

## C061 volume_plan.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. 
````

## C062 volume_plan.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. 
````

## C063 arc_plan.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. Set cross_volume_scope to exactly the ordered VolumePlan Authority version identifiers supplied by planning_command.input_versions.volume_plan followed by planning_command.arc_scope_volume_plan_version_ids. Each arc_segments[].volume_plan_version_id must copy one identifier from that exact scope, and each narrative_segment_id must copy a Narrative Segment identifier from the corresponding supplied VolumePlan. Never use a logical label such as volume:1 in cross_volume_scope or a volume_plan_version_id. Thread -> Arc -> Arc Segment is the cross-volume graph; Volume -> Narrative Segment remains the Timeline plan.
````

## C064 arc_plan.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. Set cross_volume_scope to exactly the ordered VolumePlan Authority version identifiers supplied by planning_command.input_versions.volume_plan followed by planning_command.arc_scope_volume_plan_version_ids. Each arc_segments[].volume_plan_version_id must copy one identifier from that exact scope, and each narrative_segment_id must copy a Narrative Segment identifier from the corresponding supplied VolumePlan. Never use a logical label such as volume:1 in cross_volume_scope or a volume_plan_version_id. Thread -> Arc -> Arc Segment is the cross-volume graph; Volume -> Narrative Segment remains the Timeline plan.
````

## C065 chapter_group_plan.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. Copy planning_command.narrative_search_planning_horizon.chapter_range exactly into chapter_range. Produce one ordered chapter_function_matrix row for every Chapter in that frozen range, and make narrative_event_chain cover every Chapter without placing an event outside the range. The frozen desired transformation, hard constraints, and branch strategy directive are simultaneous; the branch cannot relax the exact range or accepted boundary. Every narrative_event_chain[].disclosures value must exactly copy a value from the same event's knowledge_boundary.reader_may_learn and must not occur in forbidden_disclosures.
````

## C066 chapter_group_plan.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. Copy planning_command.narrative_search_planning_horizon.chapter_range exactly into chapter_range. Produce one ordered chapter_function_matrix row for every Chapter in that frozen range, and make narrative_event_chain cover every Chapter without placing an event outside the range. The frozen desired transformation, hard constraints, and branch strategy directive are simultaneous; the branch cannot relax the exact range or accepted boundary. Every narrative_event_chain[].disclosures value must exactly copy a value from the same event's knowledge_boundary.reader_may_learn and must not occur in forbidden_disclosures.
````

## C067 chapter_plan.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. Produce an executable Chapter plan: bind its exact Timeline and Arc references, declare Primary/Secondary/Touch/Hold Arc work, knowledge boundaries, disclosures, causal character and state transitions, scene or scene-group execution units, reader experience, and the expected exit state. Every required_state_transitions[].state_kind must use the schema's canonical Narrative State vocabulary. Use exact stable identities in entity_key: character_id for character_state; source_id:target_id for relationship_state; character_id:arc_id for character_arc; character_id:fact_id for character_knowledge; and the state kind's stable Authority identifier. Do not put Reader Knowledge or Disclosure in required_state_transitions: Reader Knowledge is fulfilled only by a planned Disclosure whose mode deterministically yields the knowledge boundary status: HINT -> HINTED, PARTIAL -> SUSPECTED, MISDIRECT -> MISDIRECTED, CONFIRM -> KNOWN, WITHHOLD -> WITHHELD. WITHHOLD does not advance accepted Reader Knowledge. Use audience READER or ALL for reader-facing disclosure; represent a mixed audience as separate Disclosure events with stable identities. Commit only state transitions that this chapter can visibly execute and Canon extraction can type. Use resource_state only for a quantifiable balance with a stable entity/resource identity; object custody, location, ownership, or protection belongs in Canon facts or another typed state.
````

## C068 chapter_plan.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the planning candidate defined by the frozen output schema. Every field ending in _version_id, _version_ids, _ref, or _refs is an immutable Authority reference: copy the exact supplied identifier verbatim and never replace it with a logical label, ordinal, title, or newly invented identifier. Keep Timeline containers and cross-cutting Narrative Arcs orthogonal. Produce an executable Chapter plan: bind its exact Timeline and Arc references, declare Primary/Secondary/Touch/Hold Arc work, knowledge boundaries, disclosures, causal character and state transitions, scene or scene-group execution units, reader experience, and the expected exit state. Every required_state_transitions[].state_kind must use the schema's canonical Narrative State vocabulary. Use exact stable identities in entity_key: character_id for character_state; source_id:target_id for relationship_state; character_id:arc_id for character_arc; character_id:fact_id for character_knowledge; and the state kind's stable Authority identifier. Do not put Reader Knowledge or Disclosure in required_state_transitions: Reader Knowledge is fulfilled only by a planned Disclosure whose mode deterministically yields the knowledge boundary status: HINT -> HINTED, PARTIAL -> SUSPECTED, MISDIRECT -> MISDIRECTED, CONFIRM -> KNOWN, WITHHOLD -> WITHHELD. WITHHOLD does not advance accepted Reader Knowledge. Use audience READER or ALL for reader-facing disclosure; represent a mixed audience as separate Disclosure events with stable identities. Commit only state transitions that this chapter can visibly execute and Canon extraction can type. Use resource_state only for a quantifiable balance with a stable entity/resource identity; object custody, location, ownership, or protection belongs in Canon facts or another typed state.
````

## C069 world_candidates.generate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Generate only bounded candidate world transitions from the supplied frozen Foundation, Intent and accepted Reality. Copy all Authority references exactly. Propose hard preconditions, optional preparation paths, costs, consequences, information scope and soft assumptions separately. Never omit a hard predicate to make an event eligible. Preparation steps are proposals, not completed facts. Use explicit local: names for intra-batch dependencies; never invent accepted event IDs. Honor all frozen search and planning bounds. Return an evidence-based NO_OP or DEFER when advancement is unnecessary. OFF_CAMERA and UNDERCURRENT proposals must not grant Reader or character knowledge.
````

## C070 world_candidates.generate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Generate only bounded candidate world transitions from the supplied frozen Foundation, Intent and accepted Reality. Copy all Authority references exactly. Propose hard preconditions, optional preparation paths, costs, consequences, information scope and soft assumptions separately. Never omit a hard predicate to make an event eligible. Preparation steps are proposals, not completed facts. Use explicit local: names for intra-batch dependencies; never invent accepted event IDs. Honor all frozen search and planning bounds. Return an evidence-based NO_OP or DEFER when advancement is unnecessary. OFF_CAMERA and UNDERCURRENT proposals must not grant Reader or character knowledge.
````

## C071 world_candidates.evaluate / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
Evaluate every supplied candidate exactly once against the frozen Director dimensions. Give reasons grounded in the supplied Foundation, Intent and Reality; compare the supplied preparation paths without inventing new paths, scores from third parties, facts or Authority identifiers. A high narrative score never overrides hard preconditions. This result recommends plans only.
````

## C072 world_candidates.evaluate / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
Evaluate every supplied candidate exactly once against the frozen Director dimensions. Give reasons grounded in the supplied Foundation, Intent and Reality; compare the supplied preparation paths without inventing new paths, scores from third parties, facts or Authority identifiers. A high narrative score never overrides hard preconditions. This result recommends plans only.
````

## C073 world_candidates.actor_0 / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C074 world_candidates.actor_0 / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C075 world_candidates.actor_1 / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C076 world_candidates.actor_1 / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C077 world_candidates.actor_2 / compact_v3_v4_v5

Symbol: _stage_semantic_contract_v3; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## C078 world_candidates.actor_2 / legacy_or_domain

Symbol: _stage_semantic_contract; final selected variant follows frozen template version.

````text
The governed reader-facing language is zh-CN. Write reader-facing titles, synopses, chapter prose, revision prose, and explanatory review evidence primarily in Simplified Chinese. Keep schema keys and stable identifiers unchanged, and do not translate identifiers. Return only the stage result defined by the frozen output schema.
````

## D001 _required_language_from_context

```json
{
  "id": "D001",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_required_language_from_context",
  "line": 3652,
  "end_line": 3681,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _required_language_from_context(value: Any) -> str | None:

    languages: set[str] = set()

    def visit(item: Any) -> None:
        if isinstance(item, Mapping):
            contract = item.get("language_contract")
            if isinstance(contract, Mapping):
                required = str(contract.get("required_language") or "").strip()
                if required:
                    languages.add(required)
            if item.get("key") == "language_contract":
                nested = item.get("value")
                if isinstance(nested, Mapping):
                    required = str(nested.get("required_language") or "").strip()
                    if required:
                        languages.add(required)
            for nested in item.values():
                visit(nested)
        elif isinstance(item, (list, tuple)):
            for nested in item:
                visit(nested)

    visit(value)
    if len(languages) > 1:
        raise KernelError(
            "CHAPTER_LANGUAGE_CONTRACT_CONFLICT",
            "governed Context contains conflicting reader-facing languages",
        )
    return next(iter(languages), None)
````

## D002 _language_semantic_contract

```json
{
  "id": "D002",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_language_semantic_contract",
  "line": 3684,
  "end_line": 3697,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _language_semantic_contract(required_language: str | None) -> str:
    if not required_language:
        return ""
    if required_language != "zh-CN":
        raise KernelError(
            "CHAPTER_LANGUAGE_CONTRACT_UNSUPPORTED",
            f"unsupported governed reader-facing language: {required_language}",
        )
    return (
        "The governed reader-facing language is zh-CN. Write reader-facing titles, "
        "synopses, chapter prose, revision prose, and explanatory review evidence "
        "primarily in Simplified Chinese. Keep schema keys and stable identifiers "
        "unchanged, and do not translate identifiers."
    )
````

## D003 _stage_semantic_contract_v3

```json
{
  "id": "D003",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_stage_semantic_contract_v3",
  "line": 3700,
  "end_line": 3785,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _stage_semantic_contract_v3(
    stage: str, *, required_language: str | None = None,
    embedding_output_contract: Mapping[str, Any] | None = None,
) -> str:
    if stage == "memo":
        return (
            "Suggest concrete creative guidance for the frozen Chapter mission and Scene roles. "
            "A choice, cost, emotional turn, reward, reversal, or hook is applicable only when "
            "the chapter function, author intent, Arc or due obligation calls for it. Use null "
            "for an inapplicable optional guidance field and [] when no character choice is needed. "
            "Provide at least one task-relevant retrieval query for accepted history. "
            "Accepted facts and explicit author constraints remain binding. Do not claim an "
            "outcome occurred or that the Memo changed the active Plan."
        )
    if stage in {"draft", "revision"}:
        instruction = (
            "Return one JSON result with scene_artifacts in exact frozen Slot order. "
            "Each Slot has one reader-facing prose text and only the in-scope used_fact_ids. "
            "Do not return a second chapter text, Markdown, self-check, change log, or "
            "approval claim. The host joins Slot text and binds identities and receipts. "
            "Respect actor, POV, source and knowledge boundaries, accepted facts, explicit "
            "author constraints, and due obligations. Use optional craft techniques only "
            "where relevant to this Chapter."
        )
        if stage == "revision":
            instruction += (
                " Preserve every unaffected Slot and the chapter's narrative scale. "
                "Address evidenced blocking issues; report a resolved code only when "
                "the revised prose actually addresses it. For targeted edits, quote the "
                "exact old passage; the host locates it and enforces frozen ranges."
            )
        return _bind_language_contract(instruction, required_language)
    if stage in {"review", "rereview"}:
        instruction = (
            "Judge this exact candidate against applicable author, accepted-state, "
            "knowledge, Scene and due-obligation constraints. For evidence return a "
            "literal quote only; the host locates Unicode spans against the frozen "
            "candidate and rejects missing or ambiguous quotes. A quote alone is not "
            "semantic support. Separate conflicts, uncertainty, and taste; do not "
            "penalize omitted cost, growth, reversal, reward or hook techniques when "
            "they are not required by this Chapter. Never claim human approval."
        )
        if stage == "rereview":
            instruction += " Check every prior diagnosis against revised prose and preserve successful content."
        return _bind_language_contract(instruction, required_language)
    if stage.startswith("quality_"):
        return _stage_semantic_contract(stage, required_language=required_language).replace(
            "Every returned dimension must include at least one concrete evidence location, including policy-compliance dimensions.",
            "PASSED and FAILED dimensions require literal candidate-prose quotes. "
            "For other statuses return [] when no prose supports a location. Explain "
            "policy and context support in claim. The host binds Unicode positions "
            "and candidate identity; a literal match alone is not semantic support."
        )
    if stage == "canon_extraction":
        contract = _stage_semantic_contract(stage, required_language=required_language)
        contract = contract.replace(
            "FULFILLED requires a typed payoff_evidence object.",
            "FULFILLED requires a supported payoff: null for a prose payoff that the host binds, or a typed accepted prerequisite for CAUSAL_DEBT.",
        )
        contract = contract.replace("accepted revision visibly executes", "selected candidate visibly executes")
        contract = contract.replace(
            "For a prose payoff use the literal "
            "asset_version_id=$FINAL_CANDIDATE and event_id=$CURRENT_CLAIM; the Authority "
            "binds these to this final candidate and grounded claim. Never invent an "
            "AssetVersion or accepted event identity.",
            "For a non-CAUSAL_DEBT prose payoff set payoff_evidence to null; the host "
            "binds this candidate and grounded claim. For CAUSAL_DEBT select only an "
            "exact accepted prerequisite source and event from governed context."
        )
        contract = contract.replace(
            "An OBSERVED Arc item must include at least one resolution_evidence string "
            "encoded as chars:<start>-<end>:<summary>, where start and end are valid "
            "Unicode code-point offsets into final_candidate; otherwise return zero ",
            "An OBSERVED Arc item must include at least one unique literal final-candidate "
            "prose quote in resolution_evidence; the host binds its location. Otherwise return zero ",
        )
        return contract.replace(
            "accepted_prose_evidence list with valid final_candidate Unicode code-point "
            "offsets plus the observed event identity",
            "accepted_prose_evidence list with unique literal final-candidate quotes "
            "plus the observed event identity",
        )
    return _stage_semantic_contract(
        stage, required_language=required_language,
        embedding_output_contract=embedding_output_contract,
    )
````

## D004 _stage_semantic_contract

```json
{
  "id": "D004",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_stage_semantic_contract",
  "line": 3788,
  "end_line": 4260,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _stage_semantic_contract(
    stage: str,
    *,
    required_language: str | None = None,
    embedding_output_contract: Mapping[str, Any] | None = None,
) -> str:
    if stage == "retrieval":
        if embedding_output_contract is None:
            return (
                "Return exactly one numeric embedding vector for each frozen input "
                "text, in the same order. Return the actual embedding model identity "
                "and vector dimensions. Do not add facts, summarize, retrieve, or "
                "mutate Authority state."
            )
        expected_model = str(embedding_output_contract.get("embedding_model") or "")
        try:
            expected_dimensions = int(
                embedding_output_contract.get("embedding_dimensions") or 0
            )
        except (TypeError, ValueError) as exc:
            raise KernelError(
                "RETRIEVAL_EMBEDDING_OUTPUT_CONTRACT_INVALID",
                "frozen retrieval embedding dimensions are invalid",
            ) from exc
        if (
            not expected_model
            or not 1 <= expected_dimensions <= 8192
            or embedding_output_contract.get("vector_normalization") != "L2_UNIT"
            or embedding_output_contract.get("placeholder_vectors_allowed") is not False
        ):
            raise KernelError(
                "RETRIEVAL_EMBEDDING_OUTPUT_CONTRACT_INVALID",
                "frozen retrieval embedding model, dimensions, or vector policy is invalid",
            )
        return (
            "Return exactly one numeric embedding vector for each frozen input text, "
            "in the same order. The frozen output identity is exact: set embedding_model "
            f"to {_canonical(expected_model)} and embedding_dimensions to "
            f"{expected_dimensions}. Every vector must have exactly "
            f"{expected_dimensions} finite numeric entries and non-zero L2 norm; normalize "
            "each vector to unit length. Produce a genuine dense semantic representation "
            "whose latent axes remain consistent across calls under this exact contract, "
            "so meaningfully similar passages remain close without lexical, entity, Arc, "
            "or obligation overlap. Never emit a placeholder, sentinel, all-zero vector, "
            "provider-unavailable identity, summary, or invented fact. Do not retrieve or "
            "mutate Authority state."
        )
    if stage == "context_compress":
        return (
            "Select exact unit_id values from this bounded chunk that retain the task relevant "
            "causal meaning. Preserve every required unit and the subject, time, negation, "
            "condition, exception, uncertainty, and distinction between fact, belief, suspicion "
            "and plan. Keep task important voice, humor, relationship subtext and promise wording. "
            "Return unit IDs only; do not rewrite text, invent units, emit source hashes or "
            "positions, or decide fidelity. This is a derived extract proposal, never Canon. "
            "If required information cannot fit, preserve it and let the host block. "
        )
    if stage == "context_fidelity":
        return (
            "Independently inspect the proposed extract against this original source chunk "
            "and frozen task. Check forward source support and reverse required meaning coverage. "
            "Check subject, time, negation, conditions, exceptions, uncertainty, epistemic "
            "status, causal prerequisites, voice, relationship subtext and promises. A legal ID "
            "alone is not fidelity proof. Report unsupported or distorted selected IDs and "
            "missing original IDs. Fail closed on uncertainty and give a concrete reason. "
            "Do not rewrite extracts, mutate story state or rely on a compressor verdict. "
        )
    if stage == "retrieval_query_expansion":
        return (
            "Return only a bounded retrieval query proposal matching the strict schema. "
            "Every query must target one supplied deterministic evidence gap and stay "
            "within the frozen accepted chapter boundary and allowed selector dimensions. "
            "Never emit SQL, database identifiers, arbitrary AssetVersion identifiers, "
            "future-state selectors, retrieved records, sufficiency decisions, or Authority "
            "mutations. Deterministic policy validates the proposal and alone decides whether "
            "another governed retrieval round executes."
        )
    if stage == "agent_session":
        return (
            "Reason only over the frozen accepted boundary, committed transcript, "
            "observations, and server Tool snapshot. Choose exactly one action: "
            "request one Tool by copying its exact tool_name, or return one final "
            "candidate/proposal response. Encode Tool arguments and final response as one JSON "
            "object string in the required payload_json envelope. The outer response "
            "must still match the strict schema exactly. A Skill supplies method only and never "
            "adds permission. Never claim to mutate Canon, Accepted Narrative State, "
            "Arc Actual, Narrative Obligation lifecycle, active Plan pointers, or "
            "Chapter acceptance. Authority Commands submit proposals only; the owning "
            "Authority decides them."
        )
    realization_instruction = (
        (
            "Produce candidate prose within the frozen Scene realization contract. "
            "Each selected specialist slot must appear exactly once in contract order. "
            "Use only its accessible fact references; report used_fact_ids explicitly. "
            "Do not give a character reader-only knowledge. Keep every factual commitment "
            "inside the approved Scene scope and declared voice contracts. The text field "
            "must equal slot texts joined with two newlines, or the exact frozen scene_separators "
            "when supplied for an author candidate. Preserve those separators. For Revision, preserve unaffected "
            "slots and amend only slots needed by the frozen review issues; Quality and Actual "
            "reconciliation will run again. If no Scene slots exist, return scene_artifacts=[]. "
            "Candidate generation never changes Canon or accepted Narrative Reality."
        )
        if stage in {"draft", "revision"}
        else ""
    )
    if stage == "narrative_semantic_evaluation":
        return (
            "Independently evaluate the immutable candidate against every frozen "
            "qualification profile and criterion. The frozen Provider Context is the "
            "complete evidence boundary. For EXACT_CANDIDATE_ONLY, use only the first "
            "selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the "
            "first selected input as the sole candidate under evaluation and consume "
            "each remaining exact qualified dependency's semantic_payload as evidence "
            "for that "
            "candidate's cross-layer claims. A reference-only BookDesign field is not "
            "missing evidence when its exact referenced dependency supplies the "
            "semantics. Do not consume prior qualification verdicts, demand downstream "
            "plans that cannot legally exist at the candidate's stage, or infer anything "
            "outside the frozen candidate-and-dependency envelope. Copy layer, profile_id, "
            "profile_version, profile_hash, capability_id, skill_ref, criterion, and "
            "candidate evidence identities exactly. Return one verdict per criterion. "
            "A non-PASS verdict must include a concrete repair_directive; PASS must "
            "leave repair_directive empty. Do not activate, revise, or replace the "
            "candidate, and do not infer evidence outside the frozen candidate."
        )
    if stage == "world_candidates.generate":
        return (
            "Generate only bounded candidate world transitions from the supplied frozen Foundation, Intent and accepted Reality. "
            "Copy all Authority references exactly. Propose hard preconditions, optional preparation paths, costs, "
            "consequences, information scope and soft assumptions separately. Never omit a hard predicate to make "
            "an event eligible. Preparation steps are proposals, not completed facts. Use explicit local: names "
            "for intra-batch dependencies; never invent accepted event IDs. Honor all frozen search and planning "
            "bounds. Return an evidence-based NO_OP or DEFER when advancement is unnecessary. "
            "OFF_CAMERA and UNDERCURRENT proposals must not grant Reader or character knowledge."
        )
    if stage == "world_candidates.evaluate":
        return (
            "Evaluate every supplied candidate exactly once against the frozen Director dimensions. "
            "Give reasons grounded in the supplied Foundation, Intent and Reality; compare the supplied preparation "
            "paths without inventing new paths, scores from third parties, facts or Authority identifiers. "
            "A high narrative score never overrides hard preconditions. This result recommends plans only."
        )
    if stage in _PLANNING_STAGES:
        contract = (
            "Return only the planning candidate defined by the frozen output schema. "
            "Every field ending in _version_id, _version_ids, _ref, or _refs is an "
            "immutable Authority reference: copy the exact supplied identifier "
            "verbatim and never replace it with a logical label, ordinal, title, or "
            "newly invented identifier. Keep Timeline containers and cross-cutting "
            "Narrative Arcs orthogonal. "
        )
        if stage == "book_plan.generate":
            contract += (
                "For world_realization and character_realization, every CURRENT "
                "entity's realization_level must be at least the top-level "
                "realization_level using ANCHOR < DEFINED < DETAILED < ACTIVE. "
                "Every knowledge_disclosure_obligations.obligation_windows[]."
                "obligation_id must copy one exact identity declared in story_truth_ids, "
                "mystery_ids, promise_ids, or foreshadow_ids, and each window must "
                "satisfy setup_chapter <= payoff_not_before <= payoff_due_by inside "
                "the bounded Book. "
            )
        elif stage == "arc_plan.generate":
            contract += (
                "Set cross_volume_scope to exactly the ordered VolumePlan Authority "
                "version identifiers supplied by planning_command.input_versions."
                "volume_plan followed by planning_command."
                "arc_scope_volume_plan_version_ids. Each arc_segments[]."
                "volume_plan_version_id must copy one identifier from that exact "
                "scope, and each narrative_segment_id must copy a Narrative Segment "
                "identifier from the corresponding supplied VolumePlan. Never use a "
                "logical label such as volume:1 in cross_volume_scope or a "
                "volume_plan_version_id. Thread -> Arc -> Arc Segment is the "
                "cross-volume graph; Volume -> Narrative Segment remains the "
                "Timeline plan."
            )
        elif stage == "chapter_group_plan.generate":
            contract += (
                "Copy planning_command.narrative_search_planning_horizon."
                "chapter_range exactly into chapter_range. Produce one ordered "
                "chapter_function_matrix row for every Chapter in that frozen range, "
                "and make narrative_event_chain cover every Chapter without placing "
                "an event outside the range. The frozen desired transformation, hard "
                "constraints, and branch strategy directive are simultaneous; the "
                "branch cannot relax the exact range or accepted boundary. Every "
                "narrative_event_chain[].disclosures value must exactly copy a value "
                "from the same event's knowledge_boundary.reader_may_learn and must "
                "not occur in forbidden_disclosures."
            )
        elif stage == "chapter_plan.generate":
            contract += (
                "Produce an executable Chapter plan: bind its exact Timeline and Arc "
                "references, declare Primary/Secondary/Touch/Hold Arc work, knowledge "
                "boundaries, disclosures, causal character and state transitions, "
                "scene or scene-group execution units, reader experience, and the "
                "expected exit state. Every required_state_transitions[].state_kind "
                "must use the schema's canonical Narrative State vocabulary. Use exact "
                "stable identities in entity_key: character_id for character_state; "
                "source_id:target_id for relationship_state; character_id:arc_id for "
                "character_arc; character_id:fact_id for character_knowledge; and "
                "the state kind's stable Authority identifier. Do not put Reader "
                "Knowledge or Disclosure in required_state_transitions: Reader "
                "Knowledge is fulfilled only by a planned Disclosure whose mode "
                "deterministically yields the knowledge boundary status: HINT -> "
                "HINTED, PARTIAL -> SUSPECTED, MISDIRECT -> MISDIRECTED, CONFIRM -> "
                "KNOWN, WITHHOLD -> WITHHELD. WITHHOLD does not advance accepted "
                "Reader Knowledge. Use audience "
                "READER or ALL for reader-facing disclosure; represent a mixed audience "
                "as separate Disclosure events with stable identities. Commit only "
                "state transitions that this chapter can visibly execute and Canon "
                "extraction can type. Use resource_state only for a quantifiable "
                "balance with a stable entity/resource identity; object custody, "
                "location, ownership, or protection belongs in Canon facts or another "
                "typed state."
            )
        return _bind_language_contract(contract, required_language)
    if stage == "revision":
        revision_language = (
            "Revise the reader-facing prose into the governed language even when the "
            "input draft uses another language. Do not preserve a conflicting input "
            "language. "
            if required_language
            else (
                "Preserve the reader-facing language of the input chapter and do not "
                "introduce unexplained code-switching. "
            )
        )
        return _bind_language_contract(
            realization_instruction
            + "Return text as final reader-facing revised chapter prose only. "
            "Resolve every supplied review issue in the prose, prioritizing blocking and "
            "major issues; list a code in resolved_issue_codes only after the edit is "
            "actually present. For a governed Quality revision task, make the smallest "
            "bounded edit that resolves the supplied task, preserve all unrelated scenes, "
            "causal links, established facts, and already-passing quality dimensions, and "
            "retain the complete reader-facing chapter at its original narrative scale "
            "unless chapter_length is itself the supplied task. Never replace the full "
            "chapter with a summary or excerpt. "
            f"{revision_language}Do not put a serialized "
            "JSON object inside text. Do not include analysis, self-checks, change logs, "
            "revision evidence, or operator-facing appendices in text.",
            required_language,
        )
    if stage == "review":
        return _bind_language_contract(
            "Diagnose the actual candidate against frozen constraints and creative guidance. "
            "Every issue requires category, judgment_kind, literal evidence with Unicode code-point "
            "start/end offsets, violated_constraint, revision_goal, preserve and acceptance_criteria. "
            "Separate semantic conflicts, uncertain judgments and aesthetic suggestions. Provider opinions "
            "are not deterministic proof; taste preferences alone are minor. Do not invent defects from "
            "a plan target that prose deliberately leaves unfulfilled. Return resolution_checks=[] on "
            "initial review. Evidence must identify a concrete defect and an observable repair condition. "
            "For every knowledge_review_target return a knowledge_check using its exact card version. "
            "Check mechanism, prerequisites, exceptions, cost and consequences in actual prose, including "
            "knowledge/disclosure boundaries, future leakage and false payoff. VERIFIED_IN_PROSE needs "
            "literal evidence and explicit conditions_checked/ exceptions_checked; terminology or Writer "
            "used_fact_ids is insufficient. Unused inspiration is NOT_USED, uncertainty is UNKNOWN. "
            "MISAPPLIED requires linked actionable issue_codes; unresolved CONSTRAINT requires a blocking issue. "
            "Return knowledge_checks=[] if no targets. Never call this formal proof or human approval.",
            required_language,
        )
    if stage == "rereview":
        return _bind_language_contract(
            "Independently verify the revised chapter against the supplied review. "
            "Report in issues only defects that remain acceptance-blocking: an unresolved "
            "blocking or major issue, or a material regression that prevents acceptance. "
            "Do not report optional minor polish or taste preferences in issues. If no "
            "acceptance-blocking defect remains, return issues=[] and an evidence-based "
            "score. Never suppress an actual blocking or major defect. "
            "For EVERY prior diagnosis return a resolution_check tied to its acceptance criteria, with "
            "a literal revised-prose evidence location and preservation assessment. SATISFIED requires "
            "the repair to be present and required content preserved. A claimed fix, issue omission, "
            "or a higher score never establishes resolution; report UNRESOLVED/UNCERTAIN when needed. "
            "Recheck every knowledge_review_target against this revised prose in knowledge_checks. "
            "Use its exact card version and literal evidence; check mechanisms, prerequisites, exceptions "
            "and narrative consequences. MISAPPLIED requires linked actionable issue_codes; unresolved "
            "CONSTRAINT requires a blocking issue. Prior verification never transfers to changed prose. "
            "Unused inspiration may be NOT_USED; report UNKNOWN for uncertainty; no targets means [].",
            required_language,
        )
    if stage == "memo":
        return (
            "Turn the frozen Chapter mission into specific creative guidance rather than paraphrasing it. "
            "Explain each character choice through motivation and cost, scene conflict, emotional movement, "
            "information release and continuity, reader promise and ending change. Respect POV and voice. "
            "Use exact Scene/Arc/character identities. Accepted boundary is fact provenance; scene targets "
            "are author plans; your choices are suggestions. Never introduce Canon or undisclosed secrets. "
            "Keep the plan and accepted boundary unchanged; propose craft decisions within their constraints."
        )
    if stage == "canon_support":
        return (
            "Independently check each candidate claim against final prose and exact accepted references. "
            "A matching quote is necessary, never sufficient. Distinguish objective events from dialogue, "
            "belief, hearsay, plans and intentions. Knowledge belongs only to the evidenced recipient. "
            "GROUNDED_FINAL_CANDIDATE_CLAIM payoff citations identify this candidate's claim, "
            "not a historical event; check the actual fulfillment against the final prose. "
            "Return UNSUPPORTED or UNCERTAIN when entailment is missing. Do not repair claims or supply "
            "events from plans. Review NARRATIVE_OBSERVATION claims against prose as well; a plan is only the comparison target. Check extraction coverage; approve NO_CHANGE only when prose supports no "
            "new canonical change. You provide evidence only; Book acceptance remains Authority."
        )
    if stage == "canon_extraction":
        return _bind_language_contract(
            "Extract only facts and state changes supported by the revised chapter. "
            "Treat from_status, from_state, from_stance, and from_tier only as compare-and-set "
            "preconditions against the exact accepted Story State supplied in the "
            "governed context. For a first occurrence with no accepted entity baseline, "
            "leave from_status, from_state, from_stance, and from_tier null; never infer them from prose, "
            "Story Design assets, plans, or ordinary background conditions. "
            "For canon_facts, compare each (subject, predicate) slot with the accepted "
            "Canon facts supplied in the governed context. If the chapter does not "
            "materially change an accepted fact, omit the redundant fact or reuse its "
            "object exactly. If the chapter changes, refines, or replaces that fact, "
            "copy the accepted fact's exact source_event_id into supersedes_event_id. "
            "Never paraphrase an unchanged accepted fact into a different object, and "
            "never invent a supersession identity. "
            "Treat requires_fact_ids as character-specific epistemic preconditions. "
            "Every required fact must already appear in that character's accepted "
            "known facts in the governed context, or the chapter must first establish "
            "it through an atomic character_knowledge_changes item with fact_id and "
            "chapter evidence. World-rule "
            "availability is not automatically character knowledge. If the prose and "
            "governed context do not establish the knowledge, omit the unsupported "
            "action or requirement; never add unsupported knowledge merely to satisfy "
            "validation. Keep Story Truth, Character Knowledge, Character Belief, "
            "Reader Knowledge, and presentation separate: a Canon fact does not by "
            "itself make any character or the reader aware of it; a belief may be "
            "false. In character_knowledge_changes, emit one item per "
            "character_id plus fact_id or proposition_id; never bundle multiple newly "
            "learned facts into one Character Knowledge event. Use only the status "
            "field with UNKNOWN, SUSPECTED, KNOWN, or FORGOTTEN; leave the generic "
            "state field null. "
            "In character_belief_changes, use only stance with BELIEVES, DOUBTS, "
            "DISBELIEVES, or UNCERTAIN plus belief_confidence from zero to one; use "
            "from_stance only for an exact accepted baseline and leave generic state, "
            "status, from_state, and from_status null. "
            "In relationship_changes, always copy both directed graph endpoints into "
            "source_id and target_id; entity_id cannot replace an endpoint, and the "
            "generic character_id field must remain null. "
            "Use obligation_changes for the unified accepted Narrative Obligation "
            "lifecycle. Copy obligation_id, obligation_type, priority, target_window, "
            "and linked Arc identities from governed context. FULFILLED requires a "
            "typed payoff_evidence object. For a prose payoff use the literal "
            "asset_version_id=$FINAL_CANDIDATE and event_id=$CURRENT_CLAIM; the Authority "
            "binds these to this final candidate and grounded claim. Never invent an "
            "AssetVersion or accepted event identity. Arc evidence alone never silently closes an "
            "obligation. "
            "For CAUSAL_DEBT, preserve causal_plan_asset_version_id and the exact "
            "causal_requirement.payload_json predicate from its planning origin. "
            "A plan cannot repay debt: FULFILLED requires a satisfied condition and "
            "its accepted source event as payoff_evidence.event_id. Other obligation "
            "types use null for these two causal fields. "
            "World, faction, location, consequence and conflict state changes require "
            "world_transition.payload_json: transition_id, actor_id, camera (ON_CAMERA, "
            "OFF_CAMERA or UNDERCURRENT), native StoryTime, action, state_kind, exact "
            "entity_key, changes, requirements, cause_refs and epistemic_basis. "
            "Causes must resolve to accepted source events. Observe only events "
            "supported by the final prose, including explicitly narrated off-camera "
            "events; a proposed future is not an occurrence. "
            "Every typed change must copy its exact stable Authority identity: "
            "character_id for character and power state, event_id for timeline, "
            "thread_id for foreshadow and plot thread, promise_id, reward_id, rule_id, "
            "entity_id plus resource_id for resource balances, fingerprint_id, "
            "antagonist_id, character_id plus arc_id for character trajectory, arc_id "
            "for narrative Arc state, and disclosure_id for presentation. A generic "
            "entity_id never substitutes for another domain's identity. If no stable "
            "identity is available in governed context, omit the unsupported change. "
            "Emit every supported "
            "planned non-WITHHOLD presentation as a "
            "disclosure_event, including character-facing events; accepted "
            "reader-facing Disclosure alone is deterministically projected into "
            "Reader Knowledge. Record how the "
            "information was presented "
            "through disclosure_mode, audience, and presentation_channel rather than "
            "copying Truth into every epistemic layer. "
            "Reconcile the frozen execution_expectations exactly. For every required "
            "state transition supported by the chapter, emit one change in the "
            "corresponding typed array with the exact planned identity and to_state; "
            "do not paraphrase either. Omit from_* only when the governed context has "
            "no accepted baseline. For every planned disclosure, copy disclosure_id, "
            "fact_id, audience, and mode exactly; do not expand the audience. Reader "
            "Knowledge will be derived after the Disclosure is accepted. "
            "Arc and Narrative Realization evidence describes final candidate prose, "
            "never Plan or Future Intent. Return exactly one arc_evidence item for "
            "each frozen expected Arc contribution. Use observation_status OBSERVED "
            "only when the accepted revision visibly executes that contribution. An "
            "OBSERVED Arc item must include at least one resolution_evidence string "
            "encoded as chars:<start>-<end>:<summary>, where start and end are valid "
            "Unicode code-point offsets into final_candidate; otherwise return zero "
            "progress_units and an empty resolution_evidence list. Return one "
            "realization_evidence item for every frozen Narrative Realization event. "
            "OBSERVED realization evidence requires a non-empty "
            "accepted_prose_evidence list with valid final_candidate Unicode code-point "
            "offsets plus the observed event identity, action, decision, consequence, "
            "and state deltas. Planning context alone never proves observation. "
            "Within canon_facts, each (subject, predicate, impact_type) tuple may occur "
            "at most once. When one subject has multiple objects for a broad relation, "
            "either combine them into one object when they are one bundled fact, or use "
            "precise relation-specific predicates. For example, encode separate consent "
            "facts as authorizes_testimony and authorizes_public_identification instead "
            "of repeating authorizes with two objects. Never emit two different objects "
            "for the same semantic tuple. "
            "Use resource_state_changes only for quantifiable resource balances. An "
            "initial resource baseline must set balance_after; a later transition must "
            "set balance_before, delta, and balance_after with exact arithmetic. Do not "
            "encode custody, location, protection, ownership, or other qualitative "
            "object status as a Resource State merely because the object is a story "
            "resource; represent supported qualitative changes as precise canon_facts "
            "or timeline_events instead. If the prose supplies no numeric balance, "
            "leave resource_state_changes empty.",
            required_language,
        )
    if stage.startswith("quality_"):
        contract = (
            "Evaluate only the requested dimensions. Every returned dimension must "
            "include at least one concrete evidence location, including policy-"
            "compliance dimensions. Use PASSED only when the supplied chapter or "
            "governed context directly supports the claim; otherwise use "
            "INSUFFICIENT_EVIDENCE, REQUIRES_HUMAN_REVIEW, or FAILED as appropriate."
        )
        if stage == "quality_source_originality":
            contract += (
                " Judge originality as differentiated execution within the supplied "
                "project-owned task and the governed source boundary. Universal "
                "comparison against every published work is not required and its "
                "absence alone is not a reason for REQUIRES_HUMAN_REVIEW. When source "
                "isolation is clear, no reference expression or suspicious overlap is "
                "present, and the prose contains concrete project-specific causal "
                "choices, originality may PASS with provider-uncalibrated evidence. "
                "Use REQUIRES_HUMAN_REVIEW only for an identified similarity, lineage, "
                "or attribution ambiguity that cannot be resolved from the governed "
                "inputs; name that specific risk in the evidence."
            )
        if stage == "quality_longform":
            contract += (
                " For world_rule_conflict and power_state_conflict, distinguish a "
                "proven no-op from missing comparison state: when the chapter directly "
                "shows no state-changing use or claim and current state candidates "
                "contain no transition, return PASSED with concrete no-op evidence; "
                "do not require the chapter to exercise the rule or power. When the "
                "chapter claims a state or transition but the governed comparison "
                "baseline is unavailable, return INSUFFICIENT_EVIDENCE."
            )
            contract += (
                " Treat canon_conflicts as the authoritative deterministic continuity "
                "result: when it is empty, do not invent a Canon conflict. Compare "
                "world-rule usages against governed_world_rules in the Quality Context; "
                "when the exact rule and its limits are present and the chapter stays "
                "within them, return PASSED with concrete rule-and-prose evidence."
            )
        if stage == "quality_platform":
            contract += (
                " Evaluate ai_content_policy only against the exact "
                "compiled_platform_policy and its release_scope. When governed assisted "
                "content is allowed for internal Provider validation and the chapter "
                "meets the listed content requirements, return PASSED with concrete "
                "policy and prose evidence. Do not duplicate source-lineage, copyright, "
                "or originality review in ai_content_policy; those are independently "
                "governed dimensions. A separate human approval required for external "
                "publication is not a defect in an internal validation release."
            )
        if required_language:
            contract += (
                " For a requested language, platform, or format dimension, treat prose "
                "that is not primarily Simplified Chinese as FAILED; Authority "
                "acceptance alone is not evidence of language compliance."
            )
        return _bind_language_contract(contract, required_language)
    return _bind_language_contract(
        realization_instruction
        + "Return only the stage result defined by the frozen output schema.",
        required_language,
    )
````

## D005 _bind_language_contract

```json
{
  "id": "D005",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_bind_language_contract",
  "line": 4263,
  "end_line": 4265,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _bind_language_contract(contract: str, required_language: str | None) -> str:
    language_contract = _language_semantic_contract(required_language)
    return f"{language_contract} {contract}" if language_contract else contract
````

## D006 _project_prose_skill

```json
{
  "id": "D006",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_project_prose_skill",
  "line": 4268,
  "end_line": 4278,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _project_prose_skill(text: str, *, stage: str, targeted: bool) -> str:
    sections = {}
    for part in text.split("\n## ")[1:]:
        heading, separator, body = part.partition("\n")
        if not separator or heading in sections:
            raise KernelError("PROSE_SKILL_PROJECTION_INVALID", "The frozen method sections must be distinct")
        sections[heading] = body.strip()
    selected = "Targeted revision" if targeted else "Draft and full revision"
    if stage not in {"draft", "revision"} or "Shared rules" not in sections or selected not in sections:
        raise KernelError("PROSE_SKILL_PROJECTION_INVALID", "Prose method requires the declared Draft or Revision task")
    return "# Prose Generation\n\n" + sections["Shared rules"] + "\n\n" + sections[selected]
````

## D007 _materialize_production_codex_prompt

```json
{
  "id": "D007",
  "file": "src/novel_forge/modules/chapter_authority/execution_gateway.py",
  "symbol": "_materialize_production_codex_prompt",
  "line": 4282,
  "end_line": 4582,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _materialize_production_codex_prompt(
    *,
    request: ExecutionRequest | None = None,
    target_scope: Mapping[str, Any] | None = None,
    stage: str,
    inputs: Mapping[str, Any],
    materialization: Mapping[str, Any],
) -> tuple[str, dict[str, Any]]:
    if request is not None:
        resolved_target_scope = request.target_scope.to_dict()
    elif target_scope is not None:
        resolved_target_scope = TargetScope.from_dict(target_scope).to_dict()
    else:
        raise KernelError(
            "CHAPTER_PROVIDER_TARGET_SCOPE_MISSING",
            "Provider prompt requires a frozen target scope",
        )
    pack_artifacts = materialization.get("pack_artifacts")
    if not isinstance(pack_artifacts, Mapping):
        raise KernelError(
            "CAPABILITY_PACK_ASSET_CONTENT_MISSING",
            "Capability materialization has no Pack Artifact content",
        )

    def required_text(key: str) -> tuple[str, Mapping[str, Any]]:
        artifact = pack_artifacts.get(key)
        content = artifact.get("content") if isinstance(artifact, Mapping) else None
        text = content.get("text") if isinstance(content, Mapping) else None
        if not isinstance(text, str) or not text.strip():
            raise KernelError(
                "CAPABILITY_PACK_ASSET_CONTENT_MISSING",
                f"Capability {key} has no exact text content",
            )
        return text, artifact

    from novel_forge.modules.worldbuilding.actor_isolation import ACTOR_STAGES, validate_actor_task
    if stage in ACTOR_STAGES:
        validate_actor_task(inputs.get("world_preparation") or {})

    system_text, system = required_text("system_instruction")
    template_text, template = required_text("prompt_template")
    skill_text, skill = required_text("skill")
    compact_contract = str(template.get("version") or "") in {"v3", "v4", "v5"}
    context = materialization.get("context_selection")
    knowledge = materialization.get("knowledge_selection")
    tools = materialization.get("tool_permissions")
    schema = materialization.get("output_schema")
    if (
        not isinstance(context, list)
        or len(context) != 1
        or not isinstance(context[0], Mapping)
        or not isinstance(knowledge, list)
        or (
            not knowledge
            and stage not in {"agent_session", "retrieval", "retrieval_query_expansion", *CONTEXT_MODEL_STAGES, *ACTOR_STAGES}
        )
        or not isinstance(tools, Mapping)
        or not isinstance(schema, Mapping)
        or not isinstance(schema.get("content"), Mapping)
    ):
        raise KernelError(
            "CHAPTER_CAPABILITY_MATERIALIZATION_INVALID",
            "Capability Context, Knowledge, Tool, or Schema selection is incomplete",
        )
    context_content = context[0].get("content")
    if not isinstance(context_content, Mapping):
        raise KernelError(
            "CHAPTER_CAPABILITY_MATERIALIZATION_INVALID",
            "Capability Context selection has no ContextBundle content",
        )
    from .provider_output_contracts import is_targeted_revision_schema_ref
    targeted_edits_only = stage == "revision" and is_targeted_revision_schema_ref(
        str(schema.get("ref") or "")
    )
    project_methods = str(template.get("version") or "") == "v5"
    if skill.get("ref") == "prose-generation" and skill.get("version") == "prose-generation-v3":
        skill_text = _project_prose_skill(skill_text, stage=stage, targeted=targeted_edits_only)
    task_view = build_provider_task_view(
        stage, inputs, compact_contract=compact_contract,
        targeted_edits_only=targeted_edits_only,
        project_methods=project_methods,
    )
    context_view = build_provider_context_view(stage, context_content, task_view)
    context_manifest = context_content.get("context_manifest")
    if isinstance(context_manifest, Mapping):
        frozen_provider_view = context_manifest.get("provider_context_view")
        if isinstance(frozen_provider_view, Mapping):
            expected_view_hash = str(frozen_provider_view.get("content_hash") or "")
            if (
                not expected_view_hash
                or canonical_hash(context_view) != expected_view_hash
            ):
                raise KernelError(
                    "PROVIDER_CONTEXT_VIEW_IDENTITY_MISMATCH",
                    "materialized Provider Context differs from its frozen Manifest",
                )
    knowledge_view = build_provider_knowledge_view(
        item for item in knowledge if isinstance(item, Mapping)
    )
    if not knowledge_view and stage not in {
        "agent_session", "retrieval", "retrieval_query_expansion", *CONTEXT_MODEL_STAGES, *ACTOR_STAGES,
    }:
        raise KernelError(
            "CHAPTER_CAPABILITY_MATERIALIZATION_INVALID",
            "Provider Knowledge projection is empty",
        )
    replacements = {
        "{{stage}}": stage,
        "{{target_scope}}": _canonical(resolved_target_scope),
        "{{input_manifest}}": _canonical(task_view),
        "{{context_bundle}}": _canonical(context_view),
        "{{output_schema_ref}}": str(schema.get("ref") or ""),
    }
    rendered_template = template_text
    for marker, value in replacements.items():
        rendered_template = rendered_template.replace(marker, value)
    if re.search(r"\{\{[a-zA-Z0-9_]+\}\}", rendered_template):
        raise KernelError(
            "CHAPTER_CAPABILITY_TEMPLATE_INVALID",
            "frozen Prompt Template contains unresolved placeholders",
        )
    allowed = tuple(str(item) for item in tools.get("allowed") or ())
    agent_tool_names = {
        str(item.get("tool_name") or "")
        for item in inputs.get("tools") or ()
        if isinstance(item, Mapping)
    }
    required_allowed = (
        {"model.provider.invoke", *agent_tool_names}
        if stage == "agent_session"
        else {"model.provider.invoke"}
    )
    if set(allowed) != required_allowed:
        raise KernelError(
            "CHAPTER_CAPABILITY_TOOL_UNAUTHORIZED",
            "Codex execution differs from the governed Provider/Agent Tool set",
        )
    required_language = _required_language_from_context(context_content)
    embedding_output_contract = materialization.get("embedding_output_contract")
    if stage == "retrieval" and not isinstance(embedding_output_contract, Mapping):
        raise KernelError(
            "RETRIEVAL_EMBEDDING_OUTPUT_CONTRACT_MISSING",
            "controlled retrieval prompt requires a frozen embedding output contract",
        )
    stage_semantic_contract = (_stage_semantic_contract_v3 if compact_contract else _stage_semantic_contract)(
        stage,
        required_language=required_language,
        embedding_output_contract=(
            embedding_output_contract
            if isinstance(embedding_output_contract, Mapping)
            else None
        ),
    )
    if targeted_edits_only:
        stage_semantic_contract = _bind_language_contract(
            "Return only ordered non-overlapping edits with exact old quotes, replacement prose and linked issue codes. "
            "Do not return Scene Slot texts or a second complete chapter. The host locates each quote against the frozen "
            "candidate, enforces diagnosed ranges and Slot boundaries, and derives unchanged prose byte-for-byte. "
            "Preserve actor, POV, knowledge, accepted facts and due obligations; read adjacent passages for continuity. "
            "A Slot boundary only locates prose and does not prove narrative coherence.",
            required_language,
        )
    grounding_observations = [
        item
        for item in inputs.get("observations") or ()
        if isinstance(item, Mapping)
        and str(item.get("tool_name") or "") != "skill.activate"
    ]
    if (
        stage == "agent_session"
        and int(inputs.get("turn_number") or 0) == 1
        and not grounding_observations
        and "narrative.query_accepted" in agent_tool_names
    ):
        stage_semantic_contract += (
            " This is the first ungrounded Agent turn. You MUST return action "
            "TOOL_CALL with tool_name narrative.query_accepted and arguments "
            'payload_json set to a JSON object string (use "{}" when no narrower '
            "query is needed). Returning FINAL before this governed accepted-boundary "
            "query is semantically invalid."
        )
    prompt_sections = [
            "<system_instruction>\n" + system_text + "\n</system_instruction>",
            "<governed_skill>\n" + skill_text + "\n</governed_skill>",
            "<required_knowledge>\n"
            + _canonical(knowledge_view)
            + "\n</required_knowledge>",
    ]
    if not compact_contract or stage == "agent_session":
        prompt_sections.append(
            "<tool_policy>\n"
            + _canonical(tools)
            + "\nDo not invoke shell, file, MCP, web, or any other tool.\n</tool_policy>"
        )
    prompt_sections.extend((
            "<prompt_template>\n" + rendered_template + "\n</prompt_template>",
            "<stage_semantic_contract>\n"
            + stage_semantic_contract
            + "\n</stage_semantic_contract>",
            "<output_schema>\n" + _canonical(schema["content"]) + "\n</output_schema>",
    ))
    prompt = "\n\n".join(prompt_sections)
    prompt_hash = "sha256:" + hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    prompt_bytes = len(prompt.encode("utf-8"))
    prompt_estimated_tokens = max(1, (prompt_bytes + 2) // 3)
    component_text = {
        "system_instruction": system_text,
        "governed_skill": skill_text,
        "provider_knowledge": _canonical(knowledge_view),
        "provider_task_view": _canonical(task_view),
        "provider_context_view": _canonical(context_view),
        "tool_policy": _canonical(tools) if not compact_contract or stage == "agent_session" else "",
        "stage_semantic_contract": stage_semantic_contract,
        "output_schema": _canonical(schema["content"]),
        "fully_rendered_prompt": prompt,
    }
    component_characters = {key: len(value) for key, value in component_text.items()}
    component_bytes = {
        key: len(value.encode("utf-8")) for key, value in component_text.items()
    }
    component_hashes = {
        key: "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()
        for key, value in component_text.items()
    }
    from novel_forge.modules.chapter_quality_authority.context_views import ConservativeTokenEstimator

    component_estimator = ConservativeTokenEstimator()
    component_tokens = {
        key: component_estimator.estimate(value) for key, value in component_text.items()
    }
    authority_context_tokens = int(context_content.get("estimated_tokens") or 0)
    provider_context_tokens = component_tokens["provider_context_view"]
    semantic_input_tokens = max(
        1,
        provider_context_tokens
        + component_tokens["provider_task_view"]
        + component_tokens["provider_knowledge"],
    )
    evidence = {
        "materialization_hash": str(materialization.get("materialization_hash") or ""),
        "reusable_prefix_bytes": len(prompt.split("</governed_skill>", 1)[0].encode())
        + len("</governed_skill>".encode()),
        "fully_rendered_prompt_hash": prompt_hash,
        "required_reader_facing_language": required_language,
        "provider_prompt_projection_version": "authority-projection-task-provider-v3" if project_methods else "authority-projection-task-provider-v2" if compact_contract else "authority-projection-task-provider-v1",
        "rendered_prompt_bytes": prompt_bytes,
        "rendered_prompt_estimated_tokens": prompt_estimated_tokens,
        "system_instruction": {
            key: system.get(key) for key in ("ref", "version", "content_hash")
        },
        "prompt_template": {
            key: template.get(key) for key in ("ref", "version", "content_hash")
        },
        "skill": {key: skill.get(key) for key in ("ref", "version", "content_hash")},
        "context_asset_version_ids": [
            str(item.get("asset_version_id") or "") for item in context
        ],
        "knowledge_content_hashes": [
            str(item.get("content_hash") or "")
            for item in knowledge
            if isinstance(item, Mapping)
        ],
        "allowed_tools": list(allowed),
        "output_schema_ref": str(schema.get("ref") or ""),
        "output_schema_hash": str(schema.get("content_hash") or ""),
        "embedding_output_contract": (
            dict(embedding_output_contract)
            if isinstance(embedding_output_contract, Mapping)
            else None
        ),
        "provider_view": {
            "task_contract_version": task_view["contract_version"],
            "context_contract_version": context_view["contract_version"],
            "selection_explanation": context_view.get(
                "selection_explanation",
                {
                    "policy": "accepted-boundary-only",
                    "selected_count": 1,
                    "omitted_count": 0,
                },
            ),
            "component_characters": component_characters,
            "component_estimated_tokens": component_tokens,
            "component_utf8_byte_upper_bounds": component_bytes,
            "component_hashes": component_hashes,
            "component_accounting_precision": "OBSERVABILITY_ONLY_ESTIMATE",
            "component_estimator": "ConservativeTokenEstimator:utf8-third-ceiling.v1",
            "provider_admission_uses_component_estimates": False,
            "authority_context_estimated_tokens": authority_context_tokens,
            "provider_context_estimated_tokens": provider_context_tokens,
            "context_projection_ratio": round(
                provider_context_tokens / max(1, authority_context_tokens), 6
            ),
            "rendered_prompt_to_semantic_input_ratio": round(
                component_tokens["fully_rendered_prompt"] / semantic_input_tokens,
                6,
            ),
            "representation_policy": "authority-projection-task-provider-v2" if compact_contract else "authority-projection-task-provider-v1",
        },
    }
    return prompt, evidence
````

## D008 build_provider_task_view

```json
{
  "id": "D008",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "build_provider_task_view",
  "line": 357,
  "end_line": 819,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def build_provider_task_view(
    stage: str, inputs: Mapping[str, Any], *, compact_contract: bool = False,
    targeted_edits_only: bool = False,
    project_methods: bool = False,
) -> dict[str, Any]:

    if stage in {"context_compress", "context_fidelity"}:
        from .context_compression_provider import context_compression_task_view

        return context_compression_task_view(stage, inputs)
    if stage == "retrieval_query_expansion":
        boundary = inputs.get("accepted_boundary")
        coverage = inputs.get("coverage")
        policy = inputs.get("policy")
        prior_rounds = inputs.get("prior_rounds")
        allowed_selectors = inputs.get("allowed_retrieval_selectors")
        if (
            not isinstance(boundary, Mapping)
            or not isinstance(coverage, Mapping)
            or coverage.get("sufficient") is not False
            or not isinstance(policy, Mapping)
            or not isinstance(prior_rounds, list)
            or len(prior_rounds) > 3
            or not isinstance(allowed_selectors, Mapping)
            or any(key not in _RETRIEVAL_SELECTOR_KEYS for key in allowed_selectors)
            or any(
                not isinstance(values, list) or len(values) > 256
                for values in allowed_selectors.values()
            )
        ):
            raise KernelError(
                "RETRIEVAL_EXPANSION_PROVIDER_TASK_INVALID",
                "query expansion requires bounded frozen coverage and campaign policy",
            )
        return _task(
            stage,
            accepted_boundary=_compact(boundary),
            intent_fingerprint=str(inputs.get("intent_fingerprint") or ""),
            memo_fingerprint=str(inputs.get("memo_fingerprint") or ""),
            mission=_compact(inputs.get("mission") or {}),
            memo=_compact(inputs.get("memo") or {}),
            coverage=_compact(coverage),
            policy=_compact(policy),
            prior_rounds=_compact(prior_rounds),
            allowed_retrieval_dimensions=_compact(
                inputs.get("allowed_retrieval_dimensions") or []
            ),
            allowed_retrieval_selectors=_compact(allowed_selectors),
        )
    if stage == "retrieval":
        texts = inputs.get("texts")
        if (
            not isinstance(texts, list)
            or not texts
            or len(texts) > 32
            or any(not isinstance(item, str) or not item.strip() for item in texts)
        ):
            raise KernelError(
                "RETRIEVAL_PROVIDER_TASK_INVALID",
                "retrieval embedding requires a bounded non-empty text batch",
            )
        return _task(
            stage,
            texts=_compact(texts),
            purpose=str(inputs.get("purpose") or ""),
            query_plan_fingerprint=str(inputs.get("query_plan_fingerprint") or ""),
        )
    if stage in {"world_candidates.actor_0", "world_candidates.actor_1", "world_candidates.actor_2"}:
        from novel_forge.modules.worldbuilding.actor_isolation import validate_actor_task
        task = inputs.get("world_preparation")
        if not isinstance(task, Mapping):
            raise KernelError("WORLD_ACTOR_CONTEXT_LEAK", "exact actor projection required")
        validate_actor_task(task)
        return _task(stage, world_preparation=deepcopy(dict(task)))
    if stage in {"world_candidates.generate", "world_candidates.evaluate"}:
        task = inputs.get("world_preparation")
        if not isinstance(task, Mapping) or task.get("contract_version") not in {"world-provider-task.v1", "world-provider-task.v2"} or task.get("fact_mutation_allowed") is not False:
            raise KernelError("WORLD_PROVIDER_TASK_INVALID", "world stages require their exact frozen role projection")
        expected_role = "WORLD_REASONER" if stage == "world_candidates.generate" else "DIRECTOR"
        if task.get("role") != expected_role:
            raise KernelError("WORLD_PROVIDER_ROLE_INVALID", "world stage cannot consume another role's context")
        projected_task = deepcopy(dict(task))
        for index, segment in enumerate(projected_task.get("planning_window") or []):
            if "loss_records" not in segment:
                continue
            source_ref = projected_task.get("source_ref")
            if not isinstance(source_ref, Mapping) or not source_ref.get("asset_version_id") or not source_ref.get("content_hash"):
                raise KernelError("WORLD_PROVIDER_LOSS_SOURCE_REQUIRED", "World projection loss records require their frozen source asset")
            audit = {key: segment.pop(key) for key in ("loss_records", "loss_sources") if key in segment}
            segment["selection_loss_receipt"] = {
                "source_ref": deepcopy(dict(source_ref)),
                "json_pointer": f"/contract/planning_window/{index}",
                "audit_hash": _projection_hash(audit),
                "loss_record_count": len(audit["loss_records"]),
            }
        if projected_task["contract_version"] == "world-provider-task.v2":
            projection = projected_task["context_projection"]
            audit = {key: projection.pop(key) for key in ("policy", "rejections", "estimated_tokens", "token_accounting", "provider_admission", "task_workset") if key in projection}
            state_provenance = {}
            for index, item in enumerate(projection.get("selection", [])):
                state = item.get("state")
                if not isinstance(state, dict):
                    continue
                provenance = {key: state.pop(key) for key in (
                    "model_id", "provider_id", "extractor_type", "prompt_version",
                    "approval_resolution", "approval_requirement", "lifecycle_migration",
                ) if key in state}
                if provenance:
                    state_provenance[str(index)] = provenance
            if state_provenance:
                projection["state_provenance_receipt"] = {
                    "frozen_source_pointer": "/contract/context_projection/selection",
                    "audit_hash": _projection_hash(state_provenance),
                    "omitted_fields_by_index": {index: sorted(values) for index, values in state_provenance.items()},
                }
            if audit:
                projection["governance_receipt"] = {
                    "contract_version": "world-role-governance-receipt.v1",
                    "source_ref": projected_task["source_ref"], "audit_hash": _projection_hash(audit),
                    "context_digest": projected_task["projection_identity"],
                    "omitted_fields": sorted(audit),
                    "rejected_source_count": len(audit.get("rejections", [])),
                }
        for proposal in projected_task.get("actor_proposals", []):
            if "intent_plan" not in proposal or "intent_state" not in proposal:
                continue
            # WHY: The validated state contains the complete private plan plus acceptance status; deliver it once.
            plan = proposal.pop("intent_plan")
            state = proposal["intent_state"]
            if any(state.get(key) != value for key, value in plan.items() if key != "steps") or any(
                any(actual.get(key) != value and not (key in {"decision", "reason"} and expected.get("decision") == "PRESERVE" and actual.get("status") in {"COMPLETED", "ABANDONED"})
                    for key, value in expected.items())
                for expected, actual in zip(plan["steps"], state["steps"], strict=True)
            ):
                raise KernelError("WORLD_ACTOR_INTENT_PROJECTION_DRIFT", "Validated intent state must retain every field of its proposed plan")
            proposal["intent_plan_receipt"] = {"contract_version": "world-actor-intent-plan-reference.v1",
                "proposal_hash": proposal["proposal_hash"], "plan_hash": _projection_hash(plan),
                "equivalent_state_pointer": "/intent_state", "authority": "PROPOSAL_NOT_ACCEPTANCE",
                "proposed_step_dispositions": {step["step_id"]: {"decision": step["decision"], "reason": step["reason"]} for step in plan["steps"]}}
        if "narrative_intelligence" in projected_task:
            projected_task["narrative_intelligence"] = _project_selected_world_selection(projected_task["narrative_intelligence"])
        return _task(stage, world_preparation=_compact(projected_task))
    from novel_forge.modules.story_planning_runtime.foundation_generation import FOUNDATION_GENERATORS, FOUNDATION_INPUT_ROLES, foundation_task

    if stage in FOUNDATION_GENERATORS:
        command = inputs.get("planning_command")
        frozen = inputs.get("frozen_inputs")
        task = inputs.get("foundation_task")
        if not isinstance(command, Mapping) or command.get("planning_scope") != "NOT_APPLICABLE" or not isinstance(frozen, list) or {item.get("role") for item in frozen if isinstance(item, Mapping)} != set(FOUNDATION_INPUT_ROLES[stage]) or task != foundation_task(stage):
            raise KernelError("FOUNDATION_PROVIDER_TASK_INVALID", "Foundation Provider task requires exact frozen roles and stage instructions")
        return _task(stage, planning_command=_compact(command), frozen_inputs=_compact(frozen), foundation_task=_compact(task), narrative_intelligence=_compact(inputs.get("narrative_intelligence")))
    if stage in _PLANNING_STAGES:
        command = inputs.get("planning_command")
        if not isinstance(command, Mapping):
            raise KernelError(
                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
                "Planning Provider Task View requires the frozen planning command",
            )
        frozen_inputs = inputs.get("frozen_inputs")
        authoritative_load = inputs.get("authoritative_narrative_load")
        arc_working_set = inputs.get("arc_working_set")
        narrative_intelligence = inputs.get("narrative_intelligence")
        if not isinstance(frozen_inputs, list) or not frozen_inputs:
            raise KernelError(
                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
                "Planning Provider Task View requires frozen input lineage",
            )
        if (
            not isinstance(authoritative_load, Mapping)
            or not isinstance(authoritative_load.get("narrative_load_policy"), Mapping)
            or not isinstance(
                authoritative_load.get("narrative_load_projection"), Mapping
            )
        ):
            raise KernelError(
                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
                "Planning Provider Task View requires authoritative Narrative Load constraints",
            )
        if not isinstance(arc_working_set, Mapping):
            raise KernelError(
                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
                "Planning Provider Task View requires the governed Arc Working Set",
            )
        selected_intelligence = (
            narrative_intelligence.get("selected")
            if isinstance(narrative_intelligence, Mapping)
            else None
        )
        intelligence_boundary = (
            narrative_intelligence.get("authority_boundary")
            if isinstance(narrative_intelligence, Mapping)
            else None
        )
        if (
            not isinstance(narrative_intelligence, Mapping)
            or narrative_intelligence.get("schema_version")
            != "mkaos-narrative-intelligence-selection.v1"
            or not isinstance(selected_intelligence, list)
            or len(selected_intelligence) > 12
            or not isinstance(intelligence_boundary, Mapping)
            or intelligence_boundary.get("semantic_role") != "POSSIBILITY_ONLY"
            or intelligence_boundary.get("may_mutate_story_authority") is not False
        ):
            raise KernelError(
                "PLANNING_PROVIDER_TASK_VIEW_INVALID",
                "Planning Provider Task View requires governed Narrative Intelligence possibilities",
            )
        from novel_forge.modules.mkaos_authority.craft_context_projection import project_planning_craft_histories
        projection_version = inputs.get("craft_history_projection_version")
        if projection_version not in (None, "planning-craft-history-projection.v1"):
            raise KernelError("CRAFT_CONTEXT_PROJECTION_DRIFT", "Planning history projection requires an explicitly supported frozen version")
        projected_selection = _compact(_project_denied_planning_selection(narrative_intelligence))
        if projection_version:
            projected_selection = project_planning_craft_histories(projected_selection)
        task = _task(
            stage,
            planning_command=_compact(command),
            world_preparation=_compact(inputs.get("world_preparation") or {}),
            frozen_inputs=_compact(frozen_inputs),
            authoritative_narrative_load=_compact(authoritative_load),
            arc_working_set=_compact(arc_working_set),
            narrative_intelligence=projected_selection,
        )
        if projection_version:
            task["contract_version"] = "provider-task-view-v2"
            task["craft_history_projection_version"] = projection_version
        return task
    if stage == "narrative_semantic_evaluation":
        profiles = inputs.get("qualification_profiles")
        target = inputs.get("evaluation_target")
        if (
            not isinstance(profiles, list)
            or not profiles
            or not isinstance(target, Mapping)
        ):
            raise KernelError(
                "NARRATIVE_EVALUATION_PROVIDER_TASK_INVALID",
                "Semantic Evaluation requires frozen profiles and target lineage",
            )
        return _task(
            stage,
            evaluation_target=_compact(target),
            qualification_profiles=_compact(profiles),
        )
    if stage == "agent_session":
        boundary = inputs.get("accepted_boundary")
        tools = inputs.get("tools")
        if (
            not isinstance(boundary, Mapping)
            or not isinstance(tools, list)
            or not tools
        ):
            raise KernelError(
                "AGENT_PROVIDER_TASK_INVALID",
                "Agent turn requires a frozen accepted boundary and Tool snapshot",
            )
        return _task(
            stage,
            agent_session_id=str(inputs.get("agent_session_id") or ""),
            operation_id=str(inputs.get("operation_id") or ""),
            instruction=str(inputs.get("instruction") or ""),
            accepted_boundary=_compact(boundary),
            execution_contract_hash=str(inputs.get("execution_contract_hash") or ""),
            execution_contract_summary=_compact(
                inputs.get("execution_contract_summary")
            ),
            tools=_compact(tools),
            skills=_compact(inputs.get("skills")),
            active_skill_activations=_compact(inputs.get("active_skill_activations")),
            committed_transcript=_compact(inputs.get("committed_transcript")),
            observations=_compact(inputs.get("observations")),
            turn_number=int(inputs.get("turn_number") or 0),
        )
    if stage == "memo":
        from novel_forge.modules.canon_graph.background import without_private_world
        source = dict(inputs.get("execution_intent") or {})
        intent = {key: source[key] for key in (
            "project_id", "chapter", "contract_version", "intent_fingerprint", "source_chapter_plan",
            "accepted_boundary", "chapter_objective", "required_arc_contributions",
            "previous_ending", "scene_plans", "chapter_mission", "required_beats", "craft_strategy",
        ) if key in source}
        return _task(stage, frozen_intent=without_private_world(intent), authority="CREATIVE_SUGGESTION_ONLY",
                     source_layers={"accepted_facts": "REFERENCED_BY_ACCEPTED_BOUNDARY",
                                    "character_knowledge": "SCENE_KNOWLEDGE_BOUNDARIES",
                                    "planned_outcomes": "INTENT_ONLY_NOT_OBSERVED",
                                    "creative_guidance": "CANDIDATE_SUGGESTIONS"})
    if stage == "draft":
        from novel_forge.modules.canon_graph.background import without_private_world
        from novel_forge.modules.story_design_authority.author_input import without_author_private
        memo_view = {
            "guidance": deepcopy((inputs.get("chapter_memo") or {}).get("creative_guidance") or {}),
            "scene_directives": deepcopy((inputs.get("chapter_memo") or {}).get("scene_directives") or []),
            **({} if compact_contract else {
                "source_memo_fingerprint": str((inputs.get("chapter_memo") or {}).get("memo_fingerprint") or ""),
                **({"craft_strategy_digest": inputs["chapter_memo"]["craft_strategy"]["strategy_digest"]} if (inputs.get("chapter_memo") or {}).get("craft_strategy") else {}),
                "authority": "CREATIVE_SUGGESTION_ONLY",
            }),
        }
        realization = deepcopy(inputs.get("realization_contract"))
        return _task(
            stage,
            chapter_plan=_compact(without_private_world(without_author_private(inputs.get("plan")))),
            style=_compact(inputs.get("style")),
            creative_memo=memo_view,
            realization_contract=realization,
        )
    if stage == "review":
        from novel_forge.modules.review.craft import craft_provider_task
        return _task(stage, **craft_provider_task(inputs.get("draft") or {}), **_cross_chapter_task(inputs), chapter=_prose(inputs.get("draft")), creative_execution=deepcopy((inputs.get("draft") or {}).get("creative_execution") or {}), knowledge_review_targets=deepcopy(inputs.get("knowledge_review_targets") or []), author_design_review_targets=deepcopy(inputs.get("author_design_review_targets") or {}))
    if stage == "revision":
        source = dict(inputs.get("draft") or {})
        payload: dict[str, Any] = {"chapter": _prose(source), "creative_execution": deepcopy(source.get("creative_execution") or {}), "knowledge_checks": deepcopy((inputs.get("review") or {}).get("knowledge_checks") or [])}
        if source.get("author_design_guidance"):
            payload["author_design_review_targets"] = deepcopy(source["author_design_guidance"])
        if source.get("realization_contract"):
            payload["chapter"].pop("text", None)
            payload["realization_contract"] = deepcopy(source["realization_contract"])
            payload["scene_artifacts"] = deepcopy(source["scene_artifacts"])
            if "scene_separators" in source:
                payload["scene_separators"] = list(source["scene_separators"])
            if not compact_contract:
                payload["composition_digest"] = source["composition_digest"]
        if inputs.get("required_actions") is not None:
            payload["required_actions"] = _compact(inputs.get("required_actions"))
            payload["quality_decision"] = _compact(inputs.get("quality"))
            if inputs.get("quality_edit_contract") is not None:
                observations = {item.get("observation") for item in inputs["required_actions"]}
                decision = inputs.get("quality") or {}
                payload["quality_decision"] = {"gate": decision.get("gate"),
                    "blocking_dimensions": decision.get("blocking_dimensions", []),
                    "required_actions": deepcopy(decision.get("required_actions", [])),
                    "evidence_reports": [deepcopy(item) for item in decision.get("evidence_reports", []) if item.get("dimension") in observations]}
                payload["quality_targeted_repair"] = deepcopy(inputs["quality_edit_contract"])
                if not compact_contract:
                    payload["chapter"]["text"] = str(source.get("text") or "")
        else:
            from novel_forge.modules.review.diagnostics import open_diagnoses
            diagnoses = open_diagnoses(dict(inputs.get("review") or {}))
            payload["review_issues"] = (
                [
                    {key: issue[key] for key in ("code", "severity", "category", "judgment_kind", "revision_goal", "preserve", "acceptance_criteria") if key in issue}
                    | {"evidence_quote": str((issue.get("evidence_locator") or {}).get("quote") or "")}
                    for issue in diagnoses
                ] if compact_contract else _compact(diagnoses)
            )
            if (source.get("realization_contract") or {}).get("contract_version") == "scene-realization-composition.v2":
                payload["targeted_editing"] = {
                    "mode": "DIAGNOSIS_DIRECTED_ONLY",
                    "tasks": [{key: issue[key] for key in ("code", "category", "judgment_kind", "evidence_locator", "revision_goal", "preserve", "acceptance_criteria") if key in issue} for issue in open_diagnoses(dict(inputs.get("review") or {}))],
                    "instructions": "Repair each evidenced problem using its stated criterion. Keep unaffected choices, information boundaries, and voice. An aesthetic suggestion is optional; unknown or unresolved blockers remain open. Read adjacent passages for continuity after a local edit.",
                }
        review = dict(inputs.get("review") or {})
        if inputs.get("required_actions") is not None and review:
            payload["review_preservation_context"] = {
                "contract_version": "quality-correction-review-preservation.v1",
                "cross_chapter_window": deepcopy(review.get("cross_chapter_window")),
                "prior_diagnoses": deepcopy(review.get("issues", []) + review.get("unresolved_issues", [])),
                "craft_targets": deepcopy(review.get("craft_targets", [])),
                "craft_checks": deepcopy(review.get("craft_checks", [])),
                "knowledge_checks": deepcopy(review.get("knowledge_checks", [])),
                "instructions": (
                    "Correct only the frozen Quality tasks. Return exact old quotes, replacements and issue codes; the host derives Slot prose. Accepted history is read-only. Preserve adopted Craft, resolved diagnoses, voice, facts and information boundaries. The same historical window and before/after comparison are reviewed again before any acceptance."
                    if targeted_edits_only else
                    "Correct only the frozen Quality tasks. Accepted history is read-only. Preserve adopted Craft, resolved diagnoses, voice, facts and information boundaries. Return exact scene artifacts consistent with prose; the same historical window and before/after comparison are reviewed again before any acceptance."
                ),
            }
        if review.get("cross_chapter_window") and inputs.get("required_actions") is None:
            payload["targeted_repair"] = {
                "contract_version": "cross-chapter-targeted-repair.v1",
                "source_window_hash": review["cross_chapter_window"]["source_window_hash"],
                "accepted_source_window": deepcopy(review["cross_chapter_window"]),
                "preservation_requirements": deepcopy(review["cross_chapter_window"]["preservation_requirements"]),
                "instructions": (
                    "Return ordered non-overlapping edits inside diagnosed target spans, their exact old quote, replacement and issue_codes. The host verifies that the joined Scene Slot prose equals applying those edits. Historical support is read-only. Keep other prose byte-for-byte. Do not mechanically paraphrase intentional repetition."
                    if compact_contract and not targeted_edits_only else
                    "Return ordered non-overlapping edits inside diagnosed target spans, their exact old quote, replacement and issue_codes. The host derives revised Slot prose from these edits. Historical support is read-only. Keep other prose byte-for-byte. Do not mechanically paraphrase intentional repetition."
                    if targeted_edits_only else
                    "Return ordered non-overlapping edits inside diagnosed target spans, their exact old quote, replacement and issue_codes. Return text equal to applying those edits only. Historical support is read-only. Keep other prose byte-for-byte. Do not mechanically paraphrase intentional repetition."
                ),
            }
            if not compact_contract:
                payload["chapter"]["text"] = str(source.get("text") or "")
        if review.get("craft_targets") and inputs.get("required_actions") is None:
            from novel_forge.modules.review.craft import craft_revision_contract
            payload["craft_targeted_repair"] = craft_revision_contract(source, review, compact_contract=compact_contract, targeted_edits_only=targeted_edits_only and project_methods)
            payload["craft_checks"] = deepcopy(review["craft_checks"])
            if not compact_contract:
                payload["chapter"]["text"] = str(source.get("text") or "")
        return _task(stage, **payload)
    if stage == "rereview":
        from novel_forge.modules.review.craft import craft_provider_task
        from novel_forge.modules.review.diagnostics import open_diagnoses
        from novel_forge.modules.review.prose_comparison import prose_comparison
        revision = inputs.get("revision") or inputs.get("draft")
        issues = [
            _compact(item)
            for item in open_diagnoses(dict(inputs.get("review") or {}))
        ]
        return _task(
            stage,
            **craft_provider_task(revision or {}, inputs.get("review") or {}),
            **_cross_chapter_task(inputs),
            revised_chapter=_prose(revision),
            **({"quality_action_reassessment": {"source_edit_contract": deepcopy(revision["quality_edit_contract"]),
                "observations": deepcopy(revision["quality_action_observations"]),
                "instructions": "Return a separate quality_resolution_checks entry for every frozen Quality observation. Cite exact revised prose and explicitly assess preservation. Do not fabricate a Review issue or treat an increased score as resolving Quality. This is model evidence; native Quality gates must reevaluate before acceptance."}}
               if (revision or {}).get("quality_edit_contract") else {}),
            **({"prose_comparison": prose_comparison(inputs["original_draft"], revision or {},
                original_id=str(inputs.get("original_draft_asset_version_id") or (inputs.get("review") or {}).get("target_asset_version_id") or ""),
                revised_id=str(inputs.get("target_candidate_asset_version_id") or (revision or {}).get("asset_version_id") or ""))}
               if "original_draft_asset_version_id" in inputs else {}),
            creative_execution=deepcopy((revision or {}).get("creative_execution") or {}),
            prior_diagnoses=issues,
            knowledge_review_targets=deepcopy(inputs.get("knowledge_review_targets") or []),
            author_design_review_targets=deepcopy(inputs.get("author_design_review_targets") or {}),
        )
    if stage == "canon_support":
        task = _task(stage, final_candidate=_prose(inputs.get("revision")),
                     grounding=deepcopy(inputs.get("grounding")), claims=deepcopy(inputs.get("claims")))
        comparisons = [item["claim"]["actor_step_execution"] for item in inputs.get("claims") or []
                       if isinstance(item, Mapping) and isinstance(item.get("claim"), Mapping) and "actor_step_execution" in item["claim"]]
        if comparisons:
            if any(not isinstance(item, Mapping) or item.get("contract_version") != "actor-step-execution-comparison.v1" for item in comparisons):
                raise KernelError("WORLD_ACTOR_EXECUTION_CONTRACT_INVALID", "Canon support requires an explicit current-step comparison contract")
            task["contract_version"] = "provider-task-view-v2"
            task["actor_step_support_contract"] = "actor-step-execution-comparison.v1"
        return task
    if stage == "canon_extraction":
        from novel_forge.modules.canon_graph.background import without_private_world
        return _task(
            stage,
            final_candidate=_prose(inputs.get("revision")),
            execution_expectations=_compact(without_private_world(inputs.get("execution_expectations"))),
        )
    if stage.startswith("quality_"):
        return _task(
            stage,
            chapter=_prose(inputs.get("revision")),
            quality_context=_compact(inputs.get("quality_context")),
            dimensions=_compact(inputs.get("dimensions")),
        )
    if stage in {"screenplay_generate", "screenplay_review", "screenplay_revision"}:
        return _task(stage, source_digest=inputs.get("source_digest"), candidate_digest=inputs.get("candidate_digest", ""),
                     **({"screenplay_source_contract": inputs["screenplay_source_contract"]} if inputs.get("screenplay_source_contract") else {}))
    if stage == "longform_prose_review":
        return _task(stage, manifest_digest=inputs.get("manifest_digest"), window_id=inputs.get("window_id"))
    if stage == "reader_outcome":
        return _task(
            stage,
            chapter=int(inputs.get("chapter") or 0),
            book_id=str(inputs.get("book_id") or ""),
            reader_contract_version=str(inputs.get("reader_contract_version") or ""),
            evaluation_profile_version=str(
                inputs.get("evaluation_profile_version") or ""
            ),
            reader_judge_execution_snapshot=_compact(
                inputs.get("reader_judge_execution_snapshot")
            ),
        )
    raise KernelError(
        "CHAPTER_PROVIDER_TASK_VIEW_UNSUPPORTED",
        f"Provider Task View is not defined for stage {stage}",
    )
````

## D009 build_provider_context_view

```json
{
  "id": "D009",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "build_provider_context_view",
  "line": 1068,
  "end_line": 1508,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def build_provider_context_view(
    stage: str,
    context_bundle: Mapping[str, Any],
    task_view: Mapping[str, Any],
) -> dict[str, Any]:

    if stage in {"context_compress", "context_fidelity"}:
        from .context_compression_provider import compression_boundary_identity

        if (
            compression_boundary_identity(context_bundle.get("accepted_boundary") or {})
            != compression_boundary_identity(task_view.get("accepted_boundary") or {})
            or str(context_bundle.get("memo_fingerprint") or "") != str(task_view.get("memo_fingerprint") or "")
        ):
            raise KernelError("CONTEXT_COMPRESSION_BOUNDARY_DRIFT", "compression must use the frozen Memo boundary")
        return {
            "contract_version": "provider-context-view-v4", "stage": stage,
            "accepted_boundary": deepcopy(context_bundle["accepted_boundary"]),
            "memo_fingerprint": context_bundle["memo_fingerprint"],
            "source_isolation": "FROZEN_TASK_CHUNK_ONLY", "protected": True,
        }
    if stage == "memo":
        intent = task_view.get("frozen_intent") or {}
        if intent.get("intent_fingerprint") != context_bundle.get("intent_fingerprint"):
            raise KernelError("CHAPTER_MEMO_INTENT_DRIFT", "Memo Context differs from frozen Intent")
        return {"contract_version": "provider-context-view-v2", "stage": stage,
                "accepted_boundary": deepcopy(context_bundle.get("accepted_boundary")),
                "source_isolation": "FROZEN_INTENT_ONLY", "protected": True}
    if stage == "retrieval_query_expansion":
        boundary = context_bundle.get("accepted_boundary")
        if (
            not isinstance(boundary, Mapping)
            or dict(boundary) != dict(task_view.get("accepted_boundary") or {})
            or str(context_bundle.get("memo_fingerprint") or "")
            != str(task_view.get("memo_fingerprint") or "")
        ):
            raise KernelError(
                "RETRIEVAL_EXPANSION_PROVIDER_CONTEXT_INVALID",
                "query expansion context must be the exact frozen ChapterMemo boundary",
            )
        return {
            "contract_version": "provider-context-view-v2",
            "schema_version": "novelos.retrieval_expansion_context.v1",
            "stage": stage,
            "source_isolation": "FROZEN_MISSION_MEMO_COVERAGE_ONLY",
            "accepted_boundary": _compact(boundary),
            "memo_fingerprint": str(context_bundle.get("memo_fingerprint") or ""),
            "protected": True,
        }
    if stage == "retrieval":
        return {
            "contract_version": "provider-context-view-v2",
            "schema_version": "novelos.retrieval_input_context.v1",
            "stage": stage,
            "source_isolation": "FROZEN_RETRIEVAL_TEXT_ONLY",
            "protected": True,
            "query_plan_fingerprint": str(
                task_view.get("query_plan_fingerprint") or ""
            ),
        }
    if stage in {"world_candidates.generate", "world_candidates.evaluate", "world_candidates.actor_0", "world_candidates.actor_1", "world_candidates.actor_2"}:
        task = task_view.get("world_preparation") or {}
        task_capacity = dict(task.get("policy") or {}).get("version") == "world-production-policy.v4"
        if context_bundle.get("world_preparation") != task:
            raise KernelError(
                "WORLD_CONTEXT_IDENTITY_MISMATCH",
                "world task differs from its frozen role Context",
            )
        selection = task.get("narrative_intelligence") or {}
        if selection.get("world_selection_receipt") is not None:
            original = context_bundle.get("narrative_intelligence")
            if not isinstance(original, Mapping) or selection != _compact(_project_selected_world_selection(original)):
                raise KernelError("WORLD_SELECTION_RECEIPT_DRIFT", "Selected World knowledge must resolve to the complete immutable selection")
        if (selection.get("need") or {}).get("condition_sources_receipt") is not None:
            original = context_bundle.get("narrative_intelligence")
            policy = original.get("knowledge_access_policy") if isinstance(original, Mapping) else None
            if (not isinstance(original, Mapping) or not isinstance(policy, Mapping)
                or policy.get("project_id") != context_bundle["project_id"]
                or policy.get("book_id") != context_bundle["book_id"]
                or selection != _compact(_project_empty_world_selection(original,
                    project_query_directory=(selection.get("need") or {}).get("query_directory_receipt") is not None))):
                raise KernelError("WORLD_SELECTION_RECEIPT_DRIFT", "World source omission must resolve to its exact complete selection in the frozen Context")
        view = {
            "contract_version": "provider-context-view-v2",
            "stage": stage,
            "source_isolation": "FROZEN_WORLD_ROLE_PROJECTION_ONLY",
            "protected": True,
            "accepted_state_boundary": {
                "project_id": context_bundle["project_id"],
                "book_id": context_bundle["book_id"],
                "accepted_through_chapter": task["accepted_through_chapter"],
                "baseline_id": task["baseline_id"],
                "baseline_kind": task["baseline_kind"],
            },
            "segments": [
                {
                    "asset_version_id": task["source_ref"]["asset_version_id"],
                    "role": task["role"],
                    "content": {
                        "source_ref": task["source_ref"],
                        "context_projection_hash": task["projection_identity"],
                    },
                }
            ],
        }
        author = context_bundle.get("author_design_projection") if task.get("role") != "ACTOR" else None
        if author is not None:
            chapter = _planning_chapter(context_bundle)
            fragments = author.get("fragments") if isinstance(author, Mapping) else None
            if (
                not isinstance(author, Mapping)
                or set(author) != {"contract_version", "target", "brief_asset_version_id", "brief_content_hash", "design_version", "binding_digest", "evidence_class", "authority", "chapter_range", "fragments", "exclusions"}
                or author.get("contract_version") != "author-design-projection.v1"
                or author.get("target") != "CHAPTER"
                or author.get("authority") != "AUTHOR_INTENT_NOT_CANON"
                or chapter != int(task["accepted_through_chapter"]) + 1
                or author.get("chapter_range") != [chapter, chapter]
                or not isinstance(fragments, list)
                or not all(
                    isinstance(item, Mapping)
                    and set(item) == {"fragment_id", "source_path", "start", "end", "content_hash", "targets", "chapter_range", "visibility", "strength", "text", "source_document_hash"}
                    and item.get("visibility") == "SCENE_INTENT"
                    and "CHAPTER" in (item.get("targets") or [])
                    and isinstance(item.get("chapter_range"), list)
                    and len(item["chapter_range"]) == 2
                    and all(type(value) is int for value in item["chapter_range"])
                    and item["chapter_range"][0] <= chapter <= item["chapter_range"][1]
                    and isinstance(item.get("text"), str)
                    and "sha256:" + hashlib.sha256(item["text"].encode("utf-8")).hexdigest() == item.get("content_hash")
                    for item in fragments
                )
                or not isinstance(author.get("exclusions"), list)
                or not all(isinstance(item, Mapping) and set(item) == {"fragment_id", "content_hash", "reason"} for item in author["exclusions"])
            ):
                raise KernelError(
                    "WORLD_AUTHOR_CONTEXT_INVALID",
                    "World preparation requires exact current-chapter scene intent, without private author sources",
                )
            from novel_forge.modules.story_design_authority.author_input import compile_provider_author_projection
            view["author_design_projection"] = compile_provider_author_projection(author)
            token_budget = context_bundle.get("token_budget")
            if type(token_budget) is not int or token_budget <= 0:
                raise KernelError("WORLD_PROVIDER_CONTEXT_BUDGET_INVALID", "World author context requires its frozen token budget")
            if not task_capacity and _serialized_character_count(view) > min(_MAX_PROVIDER_CONTEXT_CHARACTERS, token_budget * 4):
                raise KernelError("WORLD_PROVIDER_CONTEXT_BUDGET_EXCEEDED", "Protected World author context exceeds its frozen budget; narrow the governed scope")
        if task_capacity:
            token_budget = context_bundle.get("token_budget")
            if type(token_budget) is not int or not 0 < token_budget <= 512_000 or token_budget != task["policy"].get("context_token_budget"):
                raise KernelError("WORLD_PROVIDER_CONTEXT_BUDGET_INVALID", "World task capacity requires its exact frozen token budget")
            view["contract_version"] = "provider-context-view-v4"
            view["capacity_policy"] = {"version": "world-production-policy.v4", "task_target_tokens": token_budget,
                                       "token_accounting": "utf8-byte-upper-bound.v1", "maximum_serialized_bytes": _TASK_PROVIDER_SERIALIZATION_BYTES}
            measured = _serialized_byte_count(view)
            if measured > _TASK_PROVIDER_SERIALIZATION_BYTES or measured > token_budget:
                raise KernelError("WORLD_PROVIDER_CONTEXT_BUDGET_EXCEEDED", "Required World Provider view exceeds its serialized byte guard or conservative task token budget")
        frozen = (context_bundle.get("context_manifest") or {}).get("provider_context_view")
        if isinstance(frozen, Mapping) and isinstance(frozen.get("compiled_view"), Mapping) and frozen["compiled_view"].get("stage") == stage:
            if frozen["compiled_view"] != view or frozen.get("content_hash") != _projection_hash(view) or frozen.get("source_input_hash") != planning_context_source_hash(context_bundle):
                raise KernelError("WORLD_CONTEXT_IDENTITY_MISMATCH", "World Provider view differs from its frozen semantic inputs and projection receipt")
        return view
    from novel_forge.modules.story_planning_runtime.foundation_generation import FOUNDATION_GENERATORS

    if stage in _PLANNING_STAGES or stage in FOUNDATION_GENERATORS:
        projected_selection = task_view.get("narrative_intelligence", {})
        projection_version = context_bundle.get("craft_history_projection_version")
        if projection_version or task_view.get("craft_history_projection_version") or "planning_history_projection" in projected_selection:
            from novel_forge.modules.mkaos_authority.craft_context_projection import project_planning_craft_histories
            expected = project_planning_craft_histories(_compact(_project_denied_planning_selection(context_bundle.get("narrative_intelligence", {}))))
            if (projection_version != "planning-craft-history-projection.v1"
                or task_view.get("craft_history_projection_version") != projection_version
                or projected_selection != expected):
                raise KernelError("CRAFT_CONTEXT_PROJECTION_DRIFT", "Planning task history must match its exact frozen Context selection")
        return _build_planning_context_view(stage, context_bundle)
    if stage == "narrative_semantic_evaluation":
        return _build_narrative_evaluation_context_view(context_bundle)
    if stage == "agent_session":
        boundary = context_bundle.get("accepted_boundary")
        if (
            context_bundle.get("protected") is not True
            or context_bundle.get("source_authority") != "POSTGRESQL_ACCEPTED_BOUNDARY"
            or not isinstance(boundary, Mapping)
            or dict(boundary) != dict(task_view.get("accepted_boundary") or {})
        ):
            raise KernelError(
                "AGENT_PROVIDER_CONTEXT_INVALID",
                "Agent context must preserve the exact accepted boundary",
            )
        return {
            "contract_version": "provider-context-view-v2",
            "schema_version": "novelos.agent_harness_context_view.v1",
            "stage": stage,
            "source_isolation": "ACCEPTED_BOUNDARY_ONLY",
            "accepted_boundary": _compact(boundary),
            "protected": True,
        }
    if stage == "longform_prose_review":
        return _build_longform_prose_review_context_view(context_bundle)
    if stage in {"screenplay_generate", "screenplay_review", "screenplay_revision"}:
        from novel_forge.modules.book_followup_authority.screenplay_execution import screenplay_context_view
        return screenplay_context_view(stage, context_bundle)
    if stage == "reader_outcome":
        return _build_reader_outcome_context_view(context_bundle)
    correctness = context_bundle.get("context_correctness")
    if context_bundle.get("context_contract_version") in {
        "authority-context-bundle-v5",
        "authority-context-bundle-v6",
        "authority-context-bundle-v7",
        "authority-context-bundle-v8",
    }:
        if not isinstance(correctness, Mapping):
            raise KernelError(
                "CHAPTER_PROVIDER_CONTEXT_CORRECTNESS_REQUIRED",
                "Authority ContextBundle requires a Context Correctness receipt",
            )
        checks = correctness.get("checks")
        required_checks = {
            "NO_FUTURE_FACT",
            "NO_HIDDEN_KNOWLEDGE_LEAK",
            "NO_STALE_VERSION",
            "NO_DUPLICATE_SEMANTIC_REPRESENTATION",
            "NO_IRRELEVANT_FULL_ASSET",
            "REQUIRED_LONG_DISTANCE_FACT_PRESENT",
        }
        if (
            correctness.get("contract_version") != "context-correctness-receipt-v1"
            or correctness.get("overall_status") != "PASS"
            or not isinstance(checks, Mapping)
            or set(checks) != required_checks
            or any(
                not isinstance(item, Mapping)
                or item.get("status") not in {"PASS", "NOT_APPLICABLE"}
                for item in checks.values()
            )
            or str(correctness.get("receipt_hash") or "")
            != "sha256:"
            + hashlib.sha256(
                json.dumps(
                    {
                        key: value
                        for key, value in correctness.items()
                        if key != "receipt_hash"
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode()
            ).hexdigest()
        ):
            raise KernelError(
                "CHAPTER_PROVIDER_CONTEXT_CORRECTNESS_BLOCKED",
                "Provider admission requires all six Context Correctness checks",
            )
    segments = context_bundle.get("context_segments")
    if not isinstance(segments, list):
        raise KernelError(
            "CHAPTER_PROVIDER_CONTEXT_VIEW_INVALID",
            "ContextBundle requires canonical context_segments",
        )
    projection = context_bundle.get("task_narrative_projection") or {}
    if not isinstance(projection, Mapping):
        raise KernelError(
            "CHAPTER_PROVIDER_CONTEXT_VIEW_INVALID",
            "task_narrative_projection must be an object",
        )
    selectors = _selectors(projection, task_view)
    if (
        not projection
        and any(
            isinstance(item, Mapping)
            and str(item.get("asset_type") or "") in _STATE_ASSET_TYPES
            and list(item.get("structured_facts") or ())
            for item in segments
        )
        and not selectors
    ):
        raise KernelError(
            "CHAPTER_PROVIDER_CONTEXT_PROJECTION_REQUIRED",
            "state-bearing ContextBundle requires a task narrative projection; "
            "rebuild Context from the accepted checkpoint",
        )
    task_scoped_context = context_bundle.get("context_profile_version") == "draft-context-profile-v4"
    extended_context = task_scoped_context or context_bundle.get("context_profile_version") == "draft-context-profile-v3"
    maximum_characters = _MAX_PROVIDER_CONTEXT_CHARACTERS
    if extended_context:
        budget = context_bundle.get("token_budget")
        if type(budget) is not int or not 0 < budget <= (512_000 if task_scoped_context else 24_000):
            raise KernelError("CHAPTER_PROVIDER_CONTEXT_BUDGET_INVALID", "Draft Context v3 requires its exact bounded frozen token budget")
        maximum_characters = 8_192_000 if task_scoped_context else budget * 4
    rendered: list[dict[str, Any]] = []
    omitted_facts = 0
    omitted_segments = 0
    duplicate_state_summaries = 0
    for raw in segments:
        if not isinstance(raw, Mapping) or raw.get("allowed_use") == "evidence_only":
            omitted_segments += 1
            continue
        asset_type = str(raw.get("asset_type") or "")
        if stage == "draft" and asset_type in {"chapter_plan", "style_policy"}:
            omitted_segments += 1
            omitted_facts += len(raw.get("structured_facts") or ())
            continue
        if stage.startswith("quality_"):
            # WHY: QualityContext already bounds each dimension; rendering Context again duplicates its evidence.
            omitted_segments += 1
            omitted_facts += len(raw.get("structured_facts") or ())
            continue
        facts = [
            item
            for item in raw.get("structured_facts") or []
            if isinstance(item, Mapping)
        ]
        selected_facts = facts
        if asset_type in _STATE_ASSET_TYPES:
            bounded_facts = (
                project_narrative_state_facts(
                    facts,
                    projection=projection,
                    chapter=int(
                        (context_bundle.get("context_manifest") or {})
                        .get("narrative_position", {})
                        .get("chapter")
                        or 0
                    ),
                )
                if task_scoped_context or "disclosure_field_projections" in projection
                else facts
            )
            selected_facts = [
                item
                for item in bounded_facts
                if item.get("provider_visibility") != "INTERNAL_QUALITY_ONLY"
                if task_scoped_context or _state_fact_relevant(
                    item,
                    selectors,
                    int(
                        dict(context_bundle.get("context_manifest") or {})
                        .get("narrative_position", {})
                        .get("chapter", 0)
                        or 0
                    ),
                )
            ]
        if not task_scoped_context and len(selected_facts) > _MAX_FACTS_PER_SEGMENT:
            raise KernelError(
                "CHAPTER_PROVIDER_CONTEXT_PROJECTION_TOO_BROAD",
                "relevant accepted facts exceed the Provider segment budget; "
                "rebuild the governed task projection before dispatch",
            )
        omitted_facts += len(facts) - len(selected_facts)
        summary = str(raw.get("safe_summary") or "").strip()
        if (
            asset_type in _STATE_ASSET_TYPES
            and "disclosure_field_projections" in projection
        ):
            # WHY: v3 carries projected facts once; their generated JSON summary duplicates the same evidence.
            if extended_context:
                summary = ""
                duplicate_state_summaries += bool(selected_facts)
            else:
                summary = (
                    json.dumps(selected_facts, ensure_ascii=False, sort_keys=True)
                    if selected_facts
                    else ""
                )
        if not summary and not selected_facts:
            omitted_segments += 1
            continue
        if not task_scoped_context and len(rendered) >= _MAX_SEGMENTS:
            raise KernelError(
                "CHAPTER_PROVIDER_CONTEXT_PROJECTION_TOO_BROAD",
                "eligible Context segments exceed the Provider budget; "
                "rebuild the governed selection before dispatch",
            )
        rendered.append(
            {
                "asset_version_id": str(raw.get("asset_version_id") or ""),
                "asset_type": asset_type,
                "narrative_function": str(raw.get("narrative_function") or ""),
                "safe_summary": summary,
                "structured_facts": [deepcopy(dict(item)) for item in selected_facts],
            }
        )
    manifest = context_bundle.get("context_manifest") or {}
    position = (
        dict(manifest.get("narrative_position") or {})
        if isinstance(manifest, Mapping)
        else {}
    )
    boundary = (
        dict(manifest.get("authority_state_boundary") or {})
        if isinstance(manifest, Mapping)
        else {}
    )
    view = {
        "contract_version": "provider-context-view-v4" if task_scoped_context else "provider-context-view-v3" if extended_context else "provider-context-view-v2",
        "stage": stage,
        "narrative_position": {
            key: position[key]
            for key in (
                "book_id",
                "volume_id",
                "chapter",
                "sequence_id",
                "sequence_ordinal",
            )
            if key in position
        },
        "accepted_state_boundary": {
            "accepted_through_chapter": int(
                boundary.get("accepted_through_chapter") or 0
            )
        },
        "task_narrative_projection": _compact(dict(projection)),
        "segments": rendered,
        "selection_explanation": {
            "policy": "task-scoped-context.v1" if task_scoped_context else "minimum-sufficient-context-v4" if extended_context else "minimum-sufficient-context-v3",
            "included_segment_count": len(rendered),
            "included_fact_count": sum(
                len(item["structured_facts"]) for item in rendered
            ),
            "omitted_segment_count": omitted_segments,
            "omitted_fact_count": omitted_facts,
            "maximum_segments": None if task_scoped_context else _MAX_SEGMENTS,
            "maximum_facts_per_segment": None if task_scoped_context else _MAX_FACTS_PER_SEGMENT,
            **({"maximum_serialized_bytes": 8_388_608} if task_scoped_context else {"maximum_serialized_characters": maximum_characters}),
            **({"context_profile_version": context_bundle["context_profile_version"],
                "frozen_context_token_budget": context_bundle["token_budget"],
                "duplicate_state_summary_count": duplicate_state_summaries} if extended_context else {}),
        },
        "context_correctness_receipt_hash": str(
            (correctness or {}).get("receipt_hash") or ""
        ),
    }
    serialized_size = len(json.dumps(view, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")) if task_scoped_context else _serialized_character_count(view)
    serialization_limit = 8_388_608 if task_scoped_context else maximum_characters
    if serialized_size > serialization_limit:
        raise KernelError(
            "CHAPTER_PROVIDER_CONTEXT_BUDGET_EXCEEDED",
            "projected Provider Context exceeds its deterministic size boundary; "
            "rebuild the task projection with fewer accepted facts",
        )
    return view
````

## D010 _build_narrative_evaluation_context_view

```json
{
  "id": "D010",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "_build_narrative_evaluation_context_view",
  "line": 1511,
  "end_line": 1669,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _build_narrative_evaluation_context_view(
    context_bundle: Mapping[str, Any],
) -> dict[str, Any]:
    selected = context_bundle.get("selected_inputs")
    isolation = str(context_bundle.get("source_isolation") or "")
    dependency_resolution = str(context_bundle.get("dependency_resolution") or "")
    lineage = context_bundle.get("dependency_lineage")
    if not isinstance(selected, list) or not selected:
        raise KernelError(
            "NARRATIVE_EVALUATION_PROVIDER_CONTEXT_INVALID",
            "Semantic Evaluation requires a frozen candidate projection",
        )
    candidate = selected[0] if isinstance(selected[0], Mapping) else {}
    candidate_content = candidate.get("candidate")
    candidate_valid = (
        candidate.get("asset_type") in {"book_design", "planning_generation_candidate"}
        and bool(candidate.get("asset_version_id"))
        and _is_exact_sha256(candidate.get("content_hash"))
        and isinstance(candidate_content, Mapping)
        and "dependency_role" not in candidate
    )
    projected_selected: list[dict[str, Any]] | None = None
    if isolation == "EXACT_CANDIDATE_ONLY":
        valid = (
            candidate_valid
            and len(selected) == 1
            and dependency_resolution in {"", "NOT_APPLICABLE"}
        )
        policy = "exact-immutable-candidate-only"
    elif isolation == "EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES":
        valid = (
            candidate_valid
            and candidate.get("asset_type") == "book_design"
            and candidate_content.get("schema_version") == "book-design.v5"
            and dependency_resolution == "EVALUATOR_RESOLVED_FROM_CANDIDATE_LINEAGE"
            and len(selected) == 1 + len(_NARRATIVE_FOUNDATION_DEPENDENCY_TYPES)
            and isinstance(lineage, list)
            and len(lineage) == len(_NARRATIVE_FOUNDATION_DEPENDENCY_TYPES)
        )
        selected_by_role = {
            str(item.get("dependency_role") or ""): item
            for item in selected[1:]
            if isinstance(item, Mapping)
        }
        lineage_by_role = {
            str(item.get("role") or ""): item
            for item in lineage
            if isinstance(item, Mapping)
        }
        valid = valid and (
            set(selected_by_role) == set(_NARRATIVE_FOUNDATION_DEPENDENCY_TYPES)
            and set(lineage_by_role) == set(_NARRATIVE_FOUNDATION_DEPENDENCY_TYPES)
            and len(selected_by_role) == len(selected) - 1
            and len(lineage_by_role) == len(lineage)
        )
        if valid:
            projected_selected = [
                {
                    "asset_version_id": candidate["asset_version_id"],
                    "asset_type": candidate["asset_type"],
                    "content_hash": candidate["content_hash"],
                    "candidate": _compact(candidate_content),
                }
            ]
            for (
                role,
                expected_asset_type,
            ) in _NARRATIVE_FOUNDATION_DEPENDENCY_TYPES.items():
                item = selected_by_role[role]
                binding = lineage_by_role[role]
                qualification_hash = str(binding.get("qualification_hash") or "")
                source_content = item.get("candidate")
                semantic_payload = (
                    source_content.get("candidate_payload")
                    if isinstance(source_content, Mapping)
                    else None
                )
                from novel_forge.modules.story_design_authority.domain import matches_generated_foundation_source

                source_kind_matches = item.get("asset_type") == expected_asset_type
                if item.get("asset_type") == "planning_generation_candidate":
                    source_kind_matches = isinstance(source_content, Mapping) and matches_generated_foundation_source(
                        source_content, role=role,
                        project_id=context_bundle.get("project_id"),
                        book_id=context_bundle.get("book_id"),
                    )
                valid = valid and (
                    source_kind_matches
                    and isinstance(source_content, Mapping)
                    and source_content.get("schema_version")
                    == "story_design.authority.v1"
                    and source_content.get("generator_operation_name")
                    == _NARRATIVE_FOUNDATION_GENERATORS[role]
                    and isinstance(semantic_payload, Mapping)
                    and bool(semantic_payload)
                    and item.get("asset_version_id") == binding.get("asset_version_id")
                    and item.get("content_hash") == binding.get("content_hash")
                    and _is_exact_sha256(item.get("content_hash"))
                    and bool(binding.get("qualification_evidence_asset_version_id"))
                    and _is_exact_sha256(qualification_hash)
                )
                if valid:
                    projected_selected.append(
                        {
                            "asset_version_id": item["asset_version_id"],
                            "asset_type": item["asset_type"],
                            "content_hash": item["content_hash"],
                            "dependency_role": role,
                            "semantic_payload": _compact(semantic_payload),
                        }
                    )
        policy = "exact-candidate-and-canonical-foundation-semantic-closure-v2"
    else:
        valid = False
        policy = "invalid"
    if not valid:
        raise KernelError(
            "NARRATIVE_EVALUATION_PROVIDER_CONTEXT_INVALID",
            "Semantic Evaluation context is outside its exact source-isolation contract",
        )
    if projected_selected is None:
        projected_selected = _compact(selected)
    from novel_forge.modules.story_design_authority.author_input import evaluation_author_view, compile_provider_author_projection
    exact_sources = {item["asset_version_id"]: (index, item["candidate"]) for index, item in enumerate(selected)}
    for item in projected_selected:
        key = "semantic_payload" if "semantic_payload" in item else "candidate"
        source_index, source = exact_sources[item["asset_version_id"]]
        source_pointer = f"/selected_inputs/{source_index}/candidate"
        if isinstance(source.get("candidate_payload"), Mapping):
            source_pointer += "/candidate_payload"
        if key == "semantic_payload":
            source = source["candidate_payload"]
        author_view = evaluation_author_view(source, generator=_NARRATIVE_FOUNDATION_GENERATORS.get(str(item.get("dependency_role") or ""), ""))
        if author_view.get("author_design_projection"):
            author_view["author_design_projection"] = compile_provider_author_projection(author_view["author_design_projection"], frozen_context_pointer=source_pointer + "/constraint_envelope/author_design_projection")
        item[key] = _compact(author_view)
    view = {
        "contract_version": "provider-context-view-v2",
        "schema_version": "novelos.narrative_evaluation_context_view.v2",
        "stage": "narrative_semantic_evaluation",
        "source_isolation": isolation,
        "selected_inputs": projected_selected,
        "selection_explanation": {
            "policy": policy,
            "selected_count": len(selected),
            "omitted_count": 0,
        },
    }
    maximum_characters = (
        _MAX_FOUNDATION_EVALUATION_CONTEXT_CHARACTERS
        if isolation == "EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES"
        else _MAX_PROVIDER_CONTEXT_CHARACTERS
    )
    if _serialized_character_count(view) > maximum_characters:
        raise KernelError(
            "NARRATIVE_EVALUATION_PROVIDER_CONTEXT_BUDGET_EXCEEDED",
            "Semantic Evaluation context exceeds the bounded Provider projection",
        )
    return view
````

## D011 _build_planning_context_view

```json
{
  "id": "D011",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "_build_planning_context_view",
  "line": 1855,
  "end_line": 2070,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _build_planning_context_view(
    stage: str, context_bundle: Mapping[str, Any], *, projection_audit: dict[str, Any] | None = None,
) -> dict[str, Any]:

    from novel_forge.modules.story_design_authority.author_input import compile_provider_author_projection
    if context_bundle.get("schema_version") != "novelos.planning_context_bundle.v1":
        raise KernelError(
            "PLANNING_PROVIDER_CONTEXT_VIEW_INVALID",
            "Planning Provider Context requires the canonical Planning ContextBundle",
        )
    capacity_policy = context_bundle.get("planning_context_policy_version")
    if capacity_policy is not None and capacity_policy != _PLANNING_TASK_CAPACITY_POLICY:
        raise KernelError("PLANNING_PROVIDER_CONTEXT_BUDGET_INVALID", "Planning capacity requires a supported frozen policy version")
    task_capacity = capacity_policy == _PLANNING_TASK_CAPACITY_POLICY
    frozen = (context_bundle.get("context_manifest") or {}).get("provider_context_view")
    if isinstance(frozen, Mapping) and "compiled_view" in frozen:
        view = frozen["compiled_view"]
        loss_receipt = view.get("selection_explanation", {}).get("loss_receipt") if isinstance(view, Mapping) else None
        audit = (context_bundle.get("context_manifest") or {}).get("projection_audit")
        if (
            not isinstance(view, Mapping)
            or view.get("stage") != stage
            or _projection_hash(view) != frozen.get("content_hash")
            or planning_context_source_hash(context_bundle) != frozen.get("source_input_hash")
            or (loss_receipt is not None and (
                not isinstance(audit, Mapping)
                or _projection_hash(audit) != loss_receipt.get("audit_hash")
                or loss_receipt.get("source_input_hash") != frozen.get("source_input_hash")
                or loss_receipt.get("json_pointer") != "/context_manifest/projection_audit"
            ))
        ):
            raise KernelError(
                "PROVIDER_CONTEXT_VIEW_IDENTITY_MISMATCH",
                "frozen Planning projection or its semantic inputs changed",
            )
        if context_bundle.get("author_design_projection"):
            compile_provider_author_projection(view.get("author_design_projection") or {}, source_projection=context_bundle["author_design_projection"])
        return deepcopy(dict(view))
    raw_inputs = context_bundle.get("input_versions")
    if not isinstance(raw_inputs, list) or not raw_inputs:
        raise KernelError(
            "PLANNING_PROVIDER_CONTEXT_VIEW_INVALID",
            "Planning Provider Context requires frozen input versions",
        )
    if len(raw_inputs) > _MAX_SEGMENTS:
        raise KernelError(
            "PLANNING_PROVIDER_CONTEXT_PROJECTION_TOO_BROAD",
            "Planning frozen inputs exceed the bounded segment limit",
        )
    chapter = _planning_chapter(context_bundle)
    selectors = _planning_selectors(raw_inputs, chapter=chapter, stage=stage, task_capacity=task_capacity)
    repair_context = context_bundle.get("repair_context")
    if repair_context is not None and not isinstance(repair_context, Mapping):
        raise KernelError(
            "PLANNING_PROVIDER_CONTEXT_VIEW_INVALID",
            "Planning repair context must be an object",
        )
    projected: list[dict[str, Any]] = []
    omitted_items = 0
    truncated_characters = 0
    losses: list[dict[str, Any]] = []
    for raw in raw_inputs:
        if not isinstance(raw, Mapping) or not isinstance(raw.get("content"), Mapping):
            raise KernelError(
                "PLANNING_PROVIDER_CONTEXT_VIEW_INVALID",
                "Planning frozen inputs require typed provider-safe content",
            )
        content, omitted, truncated = _project_planning_content(
            stage=stage,
            role=str(raw.get("role") or ""),
            content=raw["content"],
            chapter=chapter,
            selectors=selectors,
            loss_records=losses,
            source=raw,
            task_capacity=task_capacity,
        )
        omitted_items += omitted
        truncated_characters += truncated
        projected.append(
            {
                "role": str(raw.get("role") or ""),
                "asset_version_id": str(raw.get("asset_version_id") or ""),
                "asset_type": str(raw.get("asset_type") or ""),
                "content_hash": str(raw.get("content_hash") or ""),
                "content": content,
            }
        )
    accepted_through_chapter = _planning_accepted_through_chapter(
        context_bundle, raw_inputs
    )
    view = {
        "contract_version": "provider-context-view-v4" if task_capacity else "provider-context-view-v2",
        "stage": stage,
        "narrative_position": {
            "book_id": str(context_bundle.get("book_id") or ""),
            "logical_key": str(context_bundle.get("logical_key") or ""),
            "planning_scope": str(context_bundle.get("planning_scope") or ""),
        },
        "accepted_state_boundary": {
            "accepted_through_chapter": accepted_through_chapter
        },
        "segments": projected,
        "selection_explanation": {
            "policy": (
                "minimum-sufficient-planning-repair-context-v1"
                if repair_context is not None
                else "minimum-sufficient-planning-context-v2"
            ),
            "included_segment_count": len(projected),
            "included_fact_count": 0,
            "omitted_segment_count": (
                len(raw_inputs) - len(projected)
            ),
            "omitted_fact_count": 0,
            "omitted_item_count": omitted_items,
            "truncated_character_count": truncated_characters,
            "compiler_version": "scope-preserving-planning-context-v1",
            "field_classes": {**_REQUIRED_PLANNING_FIELDS, **{field: "OPTIONAL_GUIDANCE" for field in sorted(_OPTIONAL_PLANNING_FIELDS)}},
            "loss_records": losses,
            "maximum_segments": _MAX_SEGMENTS,
            "maximum_facts_per_segment": None if task_capacity else _MAX_FACTS_PER_SEGMENT,
            **({"capacity_policy_version": capacity_policy, "maximum_serialized_bytes": _TASK_PROVIDER_SERIALIZATION_BYTES,
                "token_accounting": "utf8-byte-upper-bound.v1"} if task_capacity else {"maximum_serialized_characters": _MAX_PROVIDER_CONTEXT_CHARACTERS}),
        },
    }
    if context_bundle.get("author_design_projection"):
        view["author_design_projection"] = compile_provider_author_projection(context_bundle["author_design_projection"])
    input_projection = context_bundle.get("planning_input_projection_version")
    if input_projection is not None:
        if input_projection != "planning-input-role-references.v1":
            raise KernelError("PLANNING_PROVIDER_CONTEXT_VIEW_INVALID", "Planning input references require an explicit supported frozen version")
        _reference_planning_matrix_source(view, sources=raw_inputs, chapter=chapter)
        view["contract_version"] = "provider-context-view-v4" if task_capacity else "provider-context-view-v3"
        view["selection_explanation"]["compiler_version"] = "scope-preserving-planning-context-v2"
    if context_bundle.get("edition_execution"):
        view["edition_execution"] = deepcopy(context_bundle["edition_execution"])
        view["edition_execution_instruction"] = "This is a new manuscript edition, not a mutation of its source. Implement the exact target_scene_ids and order where supplied; source_scene_plan is provenance, and source_ranges retain the original mapping for splits, merges and reorder; bind new World and accepted-state evidence in this run. Source plans remain plans, not proof that edited prose realized them. Return a failed qualification when source structure cannot satisfy the current world or mission."
    reference_contract = context_bundle.get("realization_reference_contract")
    if reference_contract is not None:
        if not isinstance(reference_contract, Mapping):
            raise KernelError(
                "PLANNING_PROVIDER_CONTEXT_VIEW_INVALID",
                "Planning realization reference contract must be an object",
            )
        view["realization_reference_contract"] = _compact(reference_contract)
    if repair_context is not None and repair_context.get("contract_version") == "planning-result-repair-context.v1":
        source = repair_context.get("source_result")
        if not isinstance(source, Mapping) or "content" not in source or not source.get("operation_id"):
            raise KernelError("PLANNING_PROVIDER_CONTEXT_VIEW_INVALID", "result repair context requires its immutable raw result and failed Operation")
        view["repair_context"] = dict(repair_context)
    elif repair_context is not None:
        source = repair_context.get("source_candidate")
        if not isinstance(source, Mapping) or not isinstance(
            source.get("content"), Mapping
        ):
            raise KernelError(
                "PLANNING_PROVIDER_CONTEXT_VIEW_INVALID",
                "Planning repair context requires its immutable source candidate",
            )
        projected_source, omitted, truncated = _project_planning_content(
            stage=stage,
            role="repair_source_candidate",
            content=source["content"],
            chapter=chapter,
            selectors=selectors,
            loss_records=losses,
            source=source,
            task_capacity=task_capacity,
        )
        repair_view = {
            "contract_version": str(repair_context.get("contract_version") or ""),
            "source_candidate": {
                "asset_version_id": str(source.get("asset_version_id") or ""),
                "content_hash": str(source.get("content_hash") or ""),
                "content": projected_source,
            },
            "validation_failure": _compact(
                repair_context.get("validation_failure") or {}
            ),
            "failed_narrative_qualifications": _compact(
                repair_context.get("failed_narrative_qualifications") or []
            ),
        }
        view["repair_context"] = repair_view
        view["selection_explanation"]["omitted_item_count"] += omitted
        view["selection_explanation"]["truncated_character_count"] += truncated
    token_budget = context_bundle.get("token_budget")
    if token_budget is not None and (not isinstance(token_budget, int) or isinstance(token_budget, bool) or token_budget <= 0):
        raise KernelError("PLANNING_PROVIDER_CONTEXT_BUDGET_INVALID", "Planning token budget must be a positive integer")
    if task_capacity and (type(token_budget) is not int or not 0 < token_budget <= 512_000):
        raise KernelError("PLANNING_PROVIDER_CONTEXT_BUDGET_INVALID", "Planning task capacity requires a frozen target within system support")
    if task_capacity:
        view["selection_explanation"]["task_target_tokens"] = token_budget
    character_budget = min(_MAX_PROVIDER_CONTEXT_CHARACTERS, token_budget * 4) if token_budget is not None else _MAX_PROVIDER_CONTEXT_CHARACTERS
    _compact_qualified_foundation_planning(view, sources=raw_inputs, stage=stage, project_id=str(context_bundle.get("project_id") or ""))
    _compact_planning_loss_sources(view)
    source_hash = planning_context_source_hash(context_bundle) if projection_audit is not None else ""
    _prune_optional_planning_context(view, sources=raw_inputs, character_budget=character_budget,
                                    task_token_budget=token_budget if task_capacity else None, audit_source_hash=source_hash)
    if input_projection:
        _reference_planning_matrix_source(view, sources=raw_inputs, chapter=chapter)
    if projection_audit is not None:
        view, audit = _planning_view_with_audit_receipt(view, source_input_hash=source_hash)
        projection_audit.update(audit)
    if task_capacity:
        measured = _serialized_byte_count(view)
        if measured > _TASK_PROVIDER_SERIALIZATION_BYTES or measured > token_budget:
            raise KernelError("PLANNING_PROVIDER_CONTEXT_BUDGET_EXCEEDED", "required Planning Provider Context exceeds its conservative task token budget or serialized byte guard")
    elif _serialized_character_count(view) > character_budget:
        raise KernelError(
            "PLANNING_PROVIDER_CONTEXT_BUDGET_EXCEEDED",
            "required Planning Provider Context exceeds its budget boundary; narrow the governed scope before sending: "
            + json.dumps({"total": _serialized_character_count(view), "segments": [{"role": item["role"], "characters": _serialized_character_count(item)} for item in projected], "repair": _serialized_character_count(view.get("repair_context", {})), "references": _serialized_character_count(view.get("realization_reference_contract", {}))}, sort_keys=True),
        )
    return view
````

## D012 build_provider_knowledge_view

```json
{
  "id": "D012",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "build_provider_knowledge_view",
  "line": 2532,
  "end_line": 2572,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def build_provider_knowledge_view(
    knowledge: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:

    selected: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in knowledge:
        content = item.get("content")
        if not isinstance(content, (Mapping, list, str)):
            raise KernelError(
                "CHAPTER_PROVIDER_KNOWLEDGE_VIEW_INVALID",
                "selected Knowledge requires provider-safe content",
            )
        identity = str(
            item.get("content_hash")
            or item.get("ref")
            or item.get("artifact_ref")
            or ""
        )
        if not identity:
            raise KernelError(
                "CHAPTER_PROVIDER_KNOWLEDGE_VIEW_INVALID",
                "selected Knowledge requires immutable identity",
            )
        if identity in seen:
            continue
        seen.add(identity)
        selected.append(
            {
                "ref": str(item.get("ref") or item.get("artifact_ref") or ""),
                "version": str(item.get("version") or ""),
                "content": _compact(content),
            }
        )
        if _serialized_character_count(selected) > _MAX_PROVIDER_KNOWLEDGE_CHARACTERS:
            raise KernelError(
                "CHAPTER_PROVIDER_KNOWLEDGE_BUDGET_EXCEEDED",
                "task-selected Knowledge exceeds its deterministic size boundary; "
                "retrieve a smaller MKAOS projection",
            )
    return selected
````

## D013 _cross_chapter_task

```json
{
  "id": "D013",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "_cross_chapter_task",
  "line": 2766,
  "end_line": 2779,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _cross_chapter_task(inputs: Mapping[str, Any]) -> dict[str, Any]:
    window = inputs.get("cross_chapter_window")
    if window is None:
        return {}
    from novel_forge.modules.review.prose_window import CROSS_CHAPTER_CATEGORIES, validate_window
    from novel_forge.modules.review.diagnostics import prose_hash
    validate_window(window)
    candidate = inputs.get("revision") or inputs.get("draft") or {}
    return {
        "cross_chapter_window": deepcopy(window),
        "cross_chapter_categories": sorted(CROSS_CHAPTER_CATEGORIES),
        "target_identity": {"asset_version_id": inputs["target_candidate_asset_version_id"], "text_hash": prose_hash(str(candidate.get("text") or ""))},
        "review_objective": "Diagnose cross-chapter continuity using only covered accepted prose. Sources are read-only; never repair history or turn a Review into Canon. Locate literal target and source Unicode spans with exact identities. Assess retelling, action/space, causal cost, motivation, relationship and voice. Distinguish intentional recap, motif, reinterpretation, new POV, information gain and motivated change. Aesthetic or uncertain judgment cannot block. No issue is a valid result. Return structured evidence, not chain-of-thought. ReReview must disposition every prior code and preservation dimension; reuse lineage_code only for that same problem. No claims about excluded prose.",
    }
````

## D014 _build_longform_prose_review_context_view

```json
{
  "id": "D014",
  "file": "src/novel_forge/modules/chapter_authority/provider_views.py",
  "symbol": "_build_longform_prose_review_context_view",
  "line": 2788,
  "end_line": 2794,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _build_longform_prose_review_context_view(context_bundle: Mapping[str, Any]) -> dict[str, Any]:
    if context_bundle.get("schema_version") != "novelos.longform_prose_review_context_bundle.v2":
        raise KernelError("LONGFORM_PROSE_CONTEXT_INVALID", "typed longform prose context is required")
    inputs = context_bundle.get("selected_inputs") or []
    if len(inputs) != 1 or inputs[0].get("asset_type") != "longform_prose_review_window":
        raise KernelError("LONGFORM_PROSE_CONTEXT_INVALID", "exactly one bounded prose window is required")
    return {"contract_version": "provider-context-view-v2", "stage": "longform_prose_review", "frozen_prose": inputs[0]["projection"], "instruction": "审读实际提供的中文玄幻/武侠正文。逐项检查结构与冲突模式重复、人物目标和关系停滞、铺垫推进兑现、声线表达、弧级节奏、动机与代价。合理变化、有意重复、未到兑现期和证据不足必须区分。只引用给定原文 Unicode code-point 坐标和精确 quote；不把摘要或未提供正文视为已读。同一问题沿证据复用 lineage_id，不能按 category 合并。若窗口含 relation_hypothesis，它只是文本锚点检索得到的未核验关系假设；ISSUE 或 INTENTIONAL 关系判断必须分别引用两个给定片段，区分因果、人物认知、承诺、伏笔与偶然重词，无法核验时输出 INSUFFICIENT_EVIDENCE。所有结论只是待确认审稿意见。不得修改正文、Canon 或计划。"}
````

## D015 _legacy_scene_craft_tasks

```json
{
  "id": "D015",
  "file": "src/novel_forge/modules/chapter_authority/realization_composition.py",
  "symbol": "_legacy_scene_craft_tasks",
  "line": 406,
  "end_line": 422,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _legacy_scene_craft_tasks(scenes, slots, voices):
    by_scene = {scene["scene_id"]: scene for scene in scenes}
    tasks = []
    for slot in slots:
        goal, checks = _CRAFT_OBJECTIVES[slot["capability"]]
        scene = by_scene[slot["scene_id"]]
        tasks.append({
            "slot_id": slot["slot_id"], "specialism": slot["capability"],
            "objective": goal, "scene_goal": scene.get("goal", ""),
            "beat_ids": slot["beat_ids"], "actor_ids": slot["character_ids"],
            "available_fact_ids": slot["accessible_knowledge"], "craft_checks": checks,
            "voice_sources": [{key: voice[key] for key in ("asset_version_id", "voice_id", "layer", "character_id", "guidance") if key in voice} for voice in voices if not voice.get("character_id") or voice["character_id"] in slot["character_ids"]],
            "output_use": "A passage within the continuous final chapter, subject to grounded review; no state mutation",
        })
    return {"contract_version": "scene-craft-tasks.v1", "tasks": tasks,
            "chapter_edit": ["Assess scene junctions together", "Retain causal and epistemic sequence", "Remove redundant recaps", "Preserve unresolved uncertainty"],
            "semantic_proof": "NOT_CLAIMED_BY_SLOT_COVERAGE_OR_DECLARED_FACT_IDS"}
````

## D016 _scene_craft_tasks

```json
{
  "id": "D016",
  "file": "src/novel_forge/modules/chapter_authority/realization_composition.py",
  "symbol": "_scene_craft_tasks",
  "line": 436,
  "end_line": 459,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def _scene_craft_tasks(scenes, slots, voices, *, version="scene-craft-tasks.v2", plan=None):
    if version == "scene-craft-tasks.v1":
        return _legacy_scene_craft_tasks(scenes, slots, voices)
    if version != "scene-craft-tasks.v2":
        raise KernelError("REALIZATION_CRAFT_POLICY_INVALID", "Unknown frozen Scene Craft method")
    result = _legacy_scene_craft_tasks(scenes, slots, voices)
    result["contract_version"] = version
    plan = plan or {}
    result["applicability"] = {
        "classification": "CONFIGURABLE_POLICY",
        "sources": {key: plan[key] for key in (
            "objective", "chapter_intent", "reader_experience", "required_arc_contributions",
        ) if key in plan},
        "instruction": (
            "Apply cost, pressured choice, growth, reversal, reward and hook only when the frozen chapter function, "
            "Scene, actor, author intent, Arc or due accepted obligation calls for them. Use the delivered accepted "
            "Context for obligations. Do not add a technique or penalize its absence merely to fill a template. "
            "An explicit author requirement, accepted fact or due obligation remains binding and cannot be declared inapplicable."
        ),
    }
    for task in result["tasks"]:
        goal, checks = _APPLICABLE_CRAFT_OBJECTIVES[task["specialism"]]
        task["objective"], task["craft_checks"] = goal, list(checks)
    return result
````

## D017 craft_provider_task

```json
{
  "id": "D017",
  "file": "src/novel_forge/modules/review/craft.py",
  "symbol": "craft_provider_task",
  "line": 135,
  "end_line": 168,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def craft_provider_task(
    draft: Mapping[str, Any], prior: Mapping[str, Any] | None = None
) -> dict[str, Any]:
    targets = craft_review_targets(draft)
    if not targets:
        return {}
    task = {
        "craft_review_targets": targets,
        "craft_review_contract": "narrative-craft-review.v2" if any(item.get("usage", {}).get("type_policy", {}).get("transition_policy") for item in targets) else CRAFT_REVIEW_CONTRACT,
        "craft_side_effect_dimensions": list(SIDE_EFFECTS),
        "craft_review_instruction": (
            "Assess each frozen use at its specific scene and intended reader effect. Technique names are not evidence. "
            "Return one craft_check per use with ACHIEVED, UNCERTAIN or FAILED, literal Unicode code-point evidence, "
            "signals_checked and reason. Check every side-effect dimension as CLEAR, PRESENT or UNCERTAIN with "
            "located evidence. Failed effects or present side effects need linked actionable issue_codes. "
            "Aesthetic and uncertain judgments cannot be blockers. Model judgments are not actual reader evidence. "
            "Do not modify Canon, character knowledge, voice or the accepted plan to make a technique work."
        ),
    }
    if any(item.get("usage", {}).get("type_policy", {}).get("transition_policy") for item in targets):
        task["craft_review_instruction"] += " Separately evaluate the exact proposed phase_transition action, phase, condition and progress at a literal location. Return SUPPORTED, FAILED or UNCERTAIN. A achieved stylistic effect does not itself establish phase advancement. DEFER must preserve the phase and justify delay; END must have located closure evidence. Do not infer success from the plan."
    if prior is not None:
        task.update(
            {
                "prior_craft_checks": deepcopy(prior.get("craft_checks") or []),
                "craft_preservation_dimensions": list(PRESERVATION_DIMENSIONS),
                "craft_rereview_instruction": (
                    "Recheck every frozen use including previously achieved uses; disposition every prior diagnosis. "
                    "Return craft_preservation_checks for all dimensions with located evidence and a reason. "
                    "A claimed resolution cannot override regressed or uncertain preservation."
                ),
            }
        )
    return task
````

## D018 craft_revision_contract

```json
{
  "id": "D018",
  "file": "src/novel_forge/modules/review/craft.py",
  "symbol": "craft_revision_contract",
  "line": 340,
  "end_line": 393,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def craft_revision_contract(
    draft: Mapping[str, Any], review: Mapping[str, Any], *, compact_contract: bool = False,
    targeted_edits_only: bool = False,
) -> dict[str, Any]:
    targets = craft_review_targets(draft)
    if not targets:
        return {}
    if targets != review.get("craft_targets") or review.get(
        "target_text_hash"
    ) != prose_hash(str(draft.get("text") or "")):
        raise KernelError(
            "CRAFT_REVISION_SELECTION_CHANGED",
            "revision must retain the originally reviewed frozen Craft strategy",
        )
    if targeted_edits_only:
        instructions = (
            "Return only ordered non-overlapping edits inside diagnosed spans with exact old quotes, replacement prose "
            "and issue codes. The host derives Slot and chapter prose, preserving unaffected text exactly. "
            "Keep Canon, POV, voice, character knowledge, causal sequence, accepted planning and previously achieved Craft. "
            "Do not force optional aesthetic suggestions or add facts. ReReview decides resolution."
        )
    elif compact_contract:
        instructions = (
            "Return ordered non-overlapping edits inside existing diagnosed Unicode spans with the exact old quote, replacement and issue_codes. The host verifies the joined Scene Slot prose equals applying those edits; preserve all other prose exactly. Keep Canon, POV, voice, character knowledge, causal sequence, accepted planning and previously achieved Craft. Do not force optional aesthetic suggestions or add new story facts. ReReview decides resolution."
        )
    else:
        instructions = (
            "Return ordered non-overlapping edits inside existing diagnosed Unicode spans with the exact old quote, "
            "replacement and issue_codes. Returned text must equal applying those edits; preserve all other prose exactly. "
            "Keep Canon, POV, voice, character knowledge, causal sequence, accepted planning and previously achieved Craft. "
            "Do not force optional aesthetic suggestions or add new story facts. ReReview decides resolution."
        )
    return {
        "contract_version": "narrative-craft-targeted-repair.v2" if targeted_edits_only else "narrative-craft-targeted-repair.v1",
        "selection_digest": targets[0]["selection_digest"],
        "source_text_hash": review["target_text_hash"],
        "preservation_dimensions": list(PRESERVATION_DIMENSIONS),
        "satisfied_use_ids": [
            item["use_id"]
            for item in review.get("craft_checks", [])
            if item["effect_status"] == "ACHIEVED"
        ],
        "use_preservation_requirements": [
            {
                "use_id": item["use_id"],
                "requirements": deepcopy(item.get("preservation_requirements", [])),
                "repair_strategies": deepcopy(
                    item["mechanism"].get("repair_strategies", [])
                ),
            }
            for item in targets
        ],
        "instructions": instructions,
    }
````

## D019 foundation_output_schema

```json
{
  "id": "D019",
  "file": "src/novel_forge/modules/story_planning_runtime/foundation_generation.py",
  "symbol": "foundation_output_schema",
  "line": 57,
  "end_line": 157,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def foundation_output_schema(generator: str) -> dict[str, Any]:
    role = FOUNDATION_GENERATORS[generator]
    properties: dict[str, Any] = {
        "objective": _text(),
        "constraints": _texts(),
        "prohibited_outcomes": _texts(),
    }
    if role is FoundationRole.CREATIVE_FOUNDATION:
        properties.update(
            {
                field: _text()
                for field in (
                    "target_reader why_worth_writing genre subgenre core_desire core_fear "
                    "core_conflict narrative_engine differentiation emotional_contract serialization_potential"
                ).split()
            }
        )
        properties["style_profile"] = _object(
            {
                "narrator": _text(),
                "pov": _text(),
                "genre_conventions": _texts(),
                "constraints": _texts(),
                "original_examples": _records("purpose example explanation", maximum=6),
            }
        )
    elif role is FoundationRole.THEME_CONTRACT:
        properties.update(
            {
                "thematic_question": _text(),
                "opposing_answers": _texts(),
                "choice_tests": _records("choice cost thematic_pressure"),
            }
        )
    elif role is FoundationRole.ENDING_INTENT:
        properties.update(
            {
                "ending_direction": _text(),
                "protagonist_cost": _text(),
                "closure_conditions": _texts(),
                "unacceptable_shortcuts": _texts(),
            }
        )
    elif role is FoundationRole.READER_PROMISE:
        properties.update(
            {
                "reader_promise": _text(),
                "setup_progress_payoff": _records("promise setup progress payoff"),
                "disappointment_risks": _texts(),
            }
        )
    elif role is FoundationRole.WORLD_BIBLE:
        properties.update(
            {
                "rules": _records("rule cost exception consequence narrative_function"),
                "world_foundation_json": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 24000,
                    "description": "JSON encoded world-foundation.v1 object conforming to foundation_task.world_contract.schema. compiled_scope is exactly the frozen single string, never an array of enum choices. Decoded inner fields are strictly validated before candidate persistence.",
                },
                "dimensions": _records(
                    "dimension scope current_need definition constraints extension_trigger",
                    maximum=20,
                ),
                "factions": _records(
                    "faction_id goal resources pressure information_access", minimum=0
                ),
                "deferred_dimensions": _records("dimension reason trigger", minimum=0),
            }
        )
    else:
        character_fields = (
            "character_id name narrative_function desire need fear wound false_belief "
            "moral_boundary agency capability weakness voice private_history relationship_function arc_direction "
            "background contradiction behavioral_pattern risk_preference"
        )
        character = _object({field: _text() for field in character_fields.split()})
        character["properties"].update(
            {
                "aliases": _texts(),
                "pronouns": _texts(),
                "values": _texts(),
                "voice_anchors": _records("situation utterance motivation", maximum=4),
            }
        )
        character["required"] = list(character["properties"])
        properties["characters"] = {
            "type": "array",
            "items": character,
            "minItems": 1,
            "maxItems": 12,
        }
        properties["relationships"] = _records(
            "source_character_id target_character_id tension dependency change_pressure",
            minimum=0,
        )
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        **_object(properties),
    }
````

## D020 foundation_task

```json
{
  "id": "D020",
  "file": "src/novel_forge/modules/story_planning_runtime/foundation_generation.py",
  "symbol": "foundation_task",
  "line": 160,
  "end_line": 182,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def foundation_task(generator: str) -> dict[str, Any]:
    role = FOUNDATION_GENERATORS[generator]
    tasks = {
        FoundationRole.CREATIVE_FOUNDATION: "Develop a distinctive, sustainable conflict from the brief. Explain reader value, choices and costs; create original operational style examples, never imitate reference prose.",
        FoundationRole.THEME_CONTRACT: "Turn the approved premise into opposing thematic answers tested by costly character decisions; avoid a moral slogan.",
        FoundationRole.ENDING_INTENT: "Design an earned ending direction with irreversible costs, required closures and forbidden shortcuts; this is future intent, not a predetermined accepted event.",
        FoundationRole.READER_PROMISE: "Specify what readers may expect, observable preparation, escalation and payoff; distinguish promise from fact and leave timing to Planning.",
        FoundationRole.WORLD_BIBLE: "Compile only world depth needed by the approved conflict. Consider laws, geography/time, resources, power, history/culture, existence and information; explain deferred dimensions and extension triggers. Rules need costs, exceptions and story consequences.",
        FoundationRole.CHARACTER_CAST: "Build a cast with distinct narrative functions, then deepen each through desire, fear, contradiction, beliefs and choices. Derive voice anchors from biography and motives. Ground relationships and capabilities in the approved world, never invent accepted history.",
    }
    return {
        "contract_version": "foundation-generation.v1",
        "role": role.value,
        "task": tasks[role],
        "parent_roles": [parent.value for parent in role.required_parents],
        "authority_boundary": "Generate a candidate only. Upstream versions are immutable. No Canon, knowledge or accepted-history writes. Independent diagnosis and activation follow.",
        **(
            {"world_contract": world_generation_contract()}
            if role is FoundationRole.WORLD_BIBLE
            else {}
        ),
        "repair_contract": "When repair evidence is present, address each unresolved diagnosis, preserve unaffected constraints and explain uncertainty through the candidate rather than silently replacing upstream decisions.",
    }
````

## D021 world_generation_contract

```json
{
  "id": "D021",
  "file": "src/novel_forge/modules/story_planning_runtime/foundation_generation.py",
  "symbol": "world_generation_contract",
  "line": 270,
  "end_line": 298,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def world_generation_contract(*, compiled_scope: str = "BOOK") -> dict[str, Any]:
    from novel_forge.modules.worldbuilding.foundation import CORE_WORLD_ONTOLOGY
    from novel_forge.modules.worldbuilding.foundation_schema import (
        world_foundation_example,
        world_foundation_schema,
    )

    return {
        "contract_version": "world-foundation.v1",
        "compiled_scope": compiled_scope,
        "schema": world_foundation_schema(compiled_scope=compiled_scope),
        "example": world_foundation_example(compiled_scope=compiled_scope),
        "enum_contract": "Every enum is one scalar string. Schema enum arrays list choices; they are never the field's returned value. compiled_scope is fixed by this task.",
        "sections": {
            "key_rule": "core_laws is required; include only needed ontology dimensions or genre:/book: extensions",
            "ontology": sorted(CORE_WORLD_ONTOLOGY),
            "content": "concrete approved initial conditions, rules and limits",
        },
        "rules": {
            "category": "one compiled section key",
            "applicability_and_consequences": "nonempty string arrays",
            "predicate": {
                "required_for": "every enforcement except SOFT_CAUSAL",
                "value": "typed scalar; only EXISTS may omit value",
            },
            "mechanism": "Use MECHANISM only when the existing typed WorldMechanism contract can express the rule; otherwise request explicit design clarification. Do not replace a hard rule with soft reasoning.",
        },
        "entities": "nonempty array of unique entity_id and kind records; references must resolve; approved initial conditions are not accepted events",
    }
````

## D022 generation_stage

```json
{
  "id": "D022",
  "file": "src/novel_forge/modules/story_planning_runtime/world_preparation.py",
  "symbol": "generation_stage",
  "line": 337,
  "end_line": 360,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
    def generation_stage(cls, source, source_ref, knowledge_selection, *, actor_proposals=None):
        from .knowledge_translation import add_translation_contract

        if source.get("actor_experiment") is not None and not actor_proposals:
            raise KernelError("WORLD_ACTOR_PROPOSAL_REQUIRED", "Actor intervention requires its frozen independent proposals; unified sampling cannot substitute for them")
        task = {**cls._task(source, source_ref, "WORLD_REASONER"), "narrative_intelligence": knowledge_selection}
        schema = add_translation_contract(world_generation_schema(
            WorldProductionPolicy(**source["policy"]),
            audience_scoped=source["contract_version"] == "world-preparation-source.v2",
        ), knowledge_selection)
        if actor_proposals:
            from novel_forge.modules.worldbuilding.actor_isolation import actor_judge_schema
            schema = actor_judge_schema(schema, actor_proposals)
            task["actor_proposals"] = actor_proposals
            task["actor_judgment_contract"] = "Adjudicate every exact proposal hash. Accept or reject each action and determine conflicts and consequences. Preserve actor_id and intended action verbatim in an executable transition. Do not replace intentions to satisfy the outline. No preparation branches, new actors or missing adjudications. Director may select or reorder feasible proposals but cannot change them."
            if source.get("provider_projection_version") in {"world-role-delivery.v2", "world-role-delivery.v3"}:
                task["actor_judgment_contract"] += " For every CONTINUE commitment disposition, retain source_event_id in transition cause_refs and obligation_id in candidate obligation_refs. DEFER preserves the accepted commitment; it cannot cancel or fulfill it."
            if source.get("actor_experiment", {}).get("version") == "world-actor-experiment.v2":
                task["actor_judgment_contract"] += " Future intent steps are private proposals, not facts or executable prerequisites. Judge only the selected current action and do not mark intention steps complete. A deferred or abandoned intent with no selected_step_id must be REJECTED and cannot produce a transition."
        return PlanningProviderStage(
            "world_candidates.generate",
            task,
            schema,
        )
````

## D023 evaluation_stage

```json
{
  "id": "D023",
  "file": "src/novel_forge/modules/story_planning_runtime/world_preparation.py",
  "symbol": "evaluation_stage",
  "line": 363,
  "end_line": 379,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
    def evaluation_stage(cls, source, source_ref, generation, generation_ref, knowledge_selection, *, actor_proposals=None):
        if generation["source"] != source_ref:
            raise KernelError("WORLD_PREPARATION_RECEIPT_DRIFT", "evaluation must retain the generation's frozen World source")
        if source.get("actor_experiment") is not None and not actor_proposals:
            raise KernelError("WORLD_ACTOR_PROPOSAL_REQUIRED", "Director requires the frozen actor proposals and their world adjudications")
        if actor_proposals:
            from novel_forge.modules.worldbuilding.actor_isolation import require_actor_judgments
            require_actor_judgments(generation["output"], actor_proposals)
        decoded = decode_world_generation({key: value for key, value in generation["output"].items() if key not in {"knowledge_translations", "actor_adjudications"}})
        return PlanningProviderStage(
            "world_candidates.evaluate",
            {**cls._task(source, source_ref, "DIRECTOR"), "generated_portfolio": decoded,
             "generation_ref": generation_ref, "narrative_intelligence": knowledge_selection,
             "knowledge_translations": generation["output"].get("knowledge_translations", []),
             **({"actor_proposals": actor_proposals, "actor_adjudications": generation["output"]["actor_adjudications"]} if actor_proposals else {})},
            world_evaluation_schema(decoded),
        )
````

## D024 _task

```json
{
  "id": "D024",
  "file": "src/novel_forge/modules/story_planning_runtime/world_preparation.py",
  "symbol": "_task",
  "line": 382,
  "end_line": 460,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
    def _task(
        source: Mapping[str, Any], source_ref: Mapping[str, str], role: str
    ) -> dict[str, Any]:
        from novel_forge.modules.context_builder.task_context import world_task_scope

        projection = project_role_context(
            reality=source["reality"],
            role=role,
            token_budget=source["policy"]["context_token_budget"],
            task=world_task_scope(chapter=int(source["reality"]["chapter_number"]) + 1, intent=source["intent"], planning_window=source["planning_window"], world_foundation=source["world_foundation"]) if source.get("provider_projection_version") == "world-role-delivery.v3" else None,
            required_event_ids=tuple(sorted({entry["source_event_id"] for kind, entries in source["reality"]["current_state"].items() if kind in ROLE_STATE_KINDS.get(role, ()) for entry in entries})) if source.get("provider_projection_version") == "world-role-delivery.v2" else (),
        )
        return {
            "contract_version": "world-provider-task.v2" if source.get("provider_projection_version") in {"world-role-delivery.v2", "world-role-delivery.v3"} else "world-provider-task.v1",
            "role": role,
            "source_ref": dict(source_ref),
            "baseline_id": source["reality"]["revision_id"],
            "baseline_kind": source["reality"]["baseline_kind"],
            "accepted_through_chapter": source["reality"]["chapter_number"],
            "context_projection": projection,
            "projection_identity": projection["context_digest"],
            **(
                {
                    "accepted_history": [
                        {
                            "event_id": event["event_id"],
                            "state_kind": event["state_kind"],
                            "entity_key": event["identity"]["entity_key"],
                            "accepted_chapter": event["coordinate"]["source_chapter"],
                            "story_time": event.get("story_time"),
                            "fields": {
                                key: value
                                for key, value in event["mutation"]["payload"].items()
                                if isinstance(value, (str, int, float, bool))
                                and key
                                not in {
                                    "coverage",
                                    "approval_requirement",
                                    "entity_id",
                                    "confidence",
                                    "visibility",
                                }
                            },
                        }
                        for event in source["reality"].get("events", [])
                        if (source.get("provider_projection_version") != "world-role-delivery.v3" or event["event_id"] in {row["source_event_id"] for row in projection["selection"]})
                        and event.get("mutation", {})
                        .get("payload", {})
                        .get("world_transition")
                    ]
                }
                if source["contract_version"] == "world-preparation-source.v2"
                else {}
            ),
            "intent": source["intent"],
            "world_foundation": source["world_foundation"],
            "character_definitions": source["character_definitions"],
            "planning_window": source["planning_window"],
            "policy": source["policy"],
            "world_clock": source["reality"].get("world_clock", {}),
            "approved_entity_ids": source["entity_ids"],
            "foundation_cause_refs": source["reality"]["foundation_cause_refs"],
            **(
                {"disclosure_contract": "world-information-scope.v2"}
                if source["contract_version"] == "world-preparation-source.v2"
                else {}
            ),
            "transition_contract": {
                "fields": list(WorldTransition.__dataclass_fields__),
                "state_kinds": [kind.value for kind in NarrativeStateKind],
                "requirement_operators": [
                    operator.value for operator in RequirementOperator
                ],
                "camera": ["ON_CAMERA", "OFF_CAMERA", "UNDERCURRENT"],
                "explanation_status": "UNVERIFIED_CAUSAL_HYPOTHESIS",
                "required_conditions": "All compiled hard predicates and actor epistemic bases remain mandatory regardless of score.",
            },
            "fact_mutation_allowed": False,
        }
````

## D025 actor_task

```json
{
  "id": "D025",
  "file": "src/novel_forge/modules/worldbuilding/actor_isolation.py",
  "symbol": "actor_task",
  "line": 60,
  "end_line": 95,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def actor_task(source: Mapping[str, Any], source_ref: Mapping[str, str], actor_id: str) -> dict[str, Any]:
    cast = next((item for item in source["character_definitions"] if item["character_id"] == actor_id), None)
    if cast is None or not str(cast.get("desire") or "").strip():
        raise KernelError("WORLD_ACTOR_GOAL_UNAVAILABLE", "actor needs its own approved desire before any dispatch")
    traits = {key: cast[key] for key in ACTOR_TRAITS if isinstance(cast.get(key), str)}
    persistent = source.get("actor_experiment", {}).get("version") == "world-actor-experiment.v2"
    continuous = source.get("provider_projection_version") in {"world-role-delivery.v2", "world-role-delivery.v3"}
    if persistent and not continuous:
        raise KernelError("WORLD_ACTOR_POLICY_INVALID", "multi-step intentions require the current accepted private projection")
    knowledge_fields = CURRENT_KNOWLEDGE_FIELDS if continuous else KNOWLEDGE_FIELDS
    observations = []
    for kind in ("character_knowledge", "character_belief"):
        for entry in source["reality"]["current_state"].get(kind, []):
            state = entry.get("state") or {}
            if state.get("character_id") != actor_id or (kind == "character_knowledge" and state.get("status") not in {"KNOWN", "SUSPECTED"}):
                continue
            projected = {key: state[key] for key in knowledge_fields if isinstance(state.get(key), (str, int, float, bool))}
            observations.append({"source_event_id": entry["source_event_id"], "kind": kind, "content": projected})
    if not observations:
        raise KernelError(
            "WORLD_ACTOR_KNOWLEDGE_UNAVAILABLE",
            "an actor needs its own frozen initial or accepted knowledge/belief before any dispatch",
        )
    private = {"actor_id": actor_id, "traits": traits, "observations": observations}
    if continuous:
        private["accepted_self_state"] = accepted_self_state(source, actor_id)
    if persistent:
        from .actor_intents import intent_context
        private["intent_context"] = intent_context(source, actor_id)
    return {
        "contract_version": "world-actor-task.v3" if persistent else "world-actor-task.v2" if continuous else "world-actor-task.v1", "role": "ACTOR", "source_ref": dict(source_ref),
        "baseline_id": source["reality"]["revision_id"], "baseline_kind": source["reality"]["baseline_kind"],
        "accepted_through_chapter": source["reality"]["chapter_number"], "private_observation": private,
        "projection_identity": narrative_hash(private), "policy": dict(source["policy"]), "fact_mutation_allowed": False,
        "instructions": ("Maintain the bounded stable intent, goal and step identities. Reevaluate every pending step against current own knowledge, beliefs, resources, relations and obligations, explicitly continuing, deferring, reordering, renegotiating or abandoning with reasons and current trigger refs. Preserve terminal steps. Completed steps come only from the supplied accepted predecessor, never from simulation or a judge. Select a step only when its dependencies are completed, and preserve its action verbatim. Deferred or abandoned intention may select no step; any accompanying action remains a proposal. An abandoned intention never cancels an accepted commitment. " if persistent else "") + ("Explicitly CONTINUE or DEFER every supplied open own commitment, preserving its obligation and accepted source identity; continuation must cite that source in the judged transition. A deferred commitment remains open, and only observed prose accepted by Book may change it. " if continuous else "") + "Choose one intended action from your own desire and supplied knowledge or beliefs. Other characters, global secrets, the outline and future events are unavailable. Beliefs are not objective facts. Do not invent acquired knowledge. Supply only a short action-basis summary and listed source IDs; never provide internal reasoning or a chain of thought. A judge determines feasibility and consequences, and cannot rewrite your intention.",
    }
````

## D026 add_translation_contract

```json
{
  "id": "D026",
  "file": "src/novel_forge/modules/story_planning_runtime/knowledge_translation.py",
  "symbol": "add_translation_contract",
  "line": 48,
  "end_line": 141,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def add_translation_contract(
    schema: Mapping[str, Any], selection: Mapping[str, Any]
) -> dict[str, Any]:
    selected = list(selection.get("selected") or ())
    if (
        not selected
        or selection.get("policy_version") != "knowledge-grounded-selection-v2"
    ):
        return dict(schema)
    text = {"type": "string", "minLength": 1}
    texts = {"type": "array", "items": text, "minItems": 1}

    def obj(properties: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": properties,
            "required": list(properties),
            "additionalProperties": False,
        }

    instructions = "Account for every selected exact KnowledgeCard. ADOPT, ADAPT or REJECT it. A non-rejection must locate actual text in this candidate and preserve prerequisites/exception checks; uncertain mechanisms require ADAPT with explicit prerequisite resolution. Card IDs alone are insufficient. This is a planning claim, not prose or Canon proof."
    contract = {
        "type": "array",
        "minItems": len(selected),
        "maxItems": len(selected),
        "description": instructions,
        "items": obj(
            {
                "knowledge_card_asset_version_id": {
                    "type": "string",
                    "enum": [
                        item["knowledge_card_asset_version_id"] for item in selected
                    ],
                },
                "content_hash": {
                    "type": "string",
                    "enum": [item["content_hash"] for item in selected],
                },
                "decision": {"type": "string", "enum": ["ADOPT", "ADAPT", "REJECT"]},
                "usage_role": {"type": "string", "enum": sorted(USAGE_ROLES)},
                "rationale": text,
                "prerequisite_resolution": text,
                "use_sites": {
                    "type": "array",
                    "items": obj(
                        {
                            "target_pointer": text,
                            "realization_excerpt": {"type": "string", "minLength": 8},
                            "expected_application": text,
                            "preservation_requirements": texts,
                            "verification_checks": texts,
                        }
                    ),
                },
            }
        ),
    }
    if any(item.get("selected_content", {}).get("craft_mechanism") for item in selected) and selection.get("need", {}).get("target_stage") == "chapter_plan.generate":
        site = contract["items"]["properties"]["use_sites"]["items"]
        site["properties"].update({
            "craft_role": {"type": "string", "enum": ["PRIMARY", "SECONDARY"]},
            "craft_sequence": {"type": "integer", "minimum": 1},
            "intended_reader_effect": text,
        })
        site["required"].extend(["craft_role", "craft_sequence", "intended_reader_effect"])
        if selection.get("craft_policy", {}).get("schema_version") in {"narrative-craft-budget.v3", "narrative-craft-budget.v4"}:
            site["properties"]["craft_usage"] = obj({"instance_id": {"type": "string", "maxLength": 256}, "phase": text, "predecessor_use_id": {"type": "string", "maxLength": 256}, "scope_id": text})
            if selection.get("craft_policy", {}).get("schema_version") == "narrative-craft-budget.v4":
                usage = site["properties"]["craft_usage"]
                usage["properties"]["transition"] = obj({
                    "action": {"type": "string", "enum": ["START", "CONTINUE", "ADVANCE", "DEFER", "END"]},
                    "condition": {"type": "string", "minLength": 1, "maxLength": 512},
                    "progress": {"type": "string", "minLength": 1, "maxLength": 512},
                })
                usage["required"].append("transition")
                fields = contract["items"]["properties"]
                fields["rejected_scene_ids"] = {"type": "array", "items": text}
                fields["failure_condition"] = {"type": "string", "maxLength": 512}
                contract["items"]["required"].extend(["rejected_scene_ids", "failure_condition"])
                contract["description"] += " Explicit transition policy: START first phase; CONTINUE sustains the same phase; ADVANCE moves exactly one declared phase when its condition holds; DEFER preserves phase while explaining delay; END closes an existing instance. Describe proposed progress, never claim accepted progress. A final located review and Book acceptance decide realization. A REJECT must identify rejected_scene_ids and failure_condition; other decisions use an empty rejection list and condition. Preserve scene identities during a repair, obey exact scoped exclusions, and freshly explain every new combination."
            site["required"].append("craft_usage")
            site["properties"]["craft_combination"] = obj({key: {"type": "string", "minLength": 1, "maxLength": 512} for key in (
                "narrative_problem", "selection_reason", "role_and_order_reason", "combined_effect", "interference_risk", "preservation_constraint", "abstain_condition")})
            site["required"].append("craft_combination")
            contract["description"] += " Typed Craft usage must follow the frozen usage type and ordered phases. A new instance uses empty instance_id and predecessor_use_id and the first phase. A continuation cites its latest successful accepted use and instance; planned or failed uses are not predecessors, and later uncertainty blocks continuation. Read need.craft_context.usage_scope_context: scope_id must be the exact scene ID, chapter:<chapter_number>, a frozen arc_plan_version_id, or book_id according to the usage type. All new instances jointly consume the remaining frequency allowance."

        contract["description"] += " Craft mechanisms require concrete /scene_plan/<index>/<field> locations, one primary per scene, distinct sequence positions, contextual prerequisite/contraindication judgment, and the frozen Craft density/composition policy. Reject any Craft that cannot be realized within current Canon, POV, voice, knowledge, scene causality and active planning constraints. Never supply replacement mechanisms."
    result = dict(schema)
    result["properties"] = {
        **dict(schema["properties"]),
        "knowledge_translations": contract,
    }
    result["required"] = [*schema.get("required", ()), "knowledge_translations"]
    return result
````

## D027 project_planning_craft_histories

```json
{
  "id": "D027",
  "file": "src/novel_forge/modules/mkaos_authority/craft_context_projection.py",
  "symbol": "project_planning_craft_histories",
  "line": 15,
  "end_line": 52,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def project_planning_craft_histories(selection: dict[str, Any]) -> dict[str, Any]:
    from .craft_selection import _hash

    if selection.get("craft_policy", {}).get("schema_version") != "narrative-craft-budget.v4":
        return selection
    history = selection.get("need", {}).get("recent_craft_usage")
    if not isinstance(history, list) or not history:
        return selection
    result = deepcopy(selection)
    by_hash = {_hash(row): index for index, row in enumerate(history)}
    changed = False
    for card in [*result.get("selected", []), *result.get("rejected", [])]:
        budget = card.get("craft_assessment", {}).get("budget_assessment", {})
        for field in _HISTORY_FIELDS:
            rows = budget.get(field)
            if not isinstance(rows, list) or not rows:
                continue
            indices = [by_hash.get(_hash(row)) for row in rows]
            if any(index is None or history[index] != row for row, index in zip(rows, indices)):
                continue
            reference = {"contract_version": "planning-craft-history-reference.v1",
                "json_pointer": _HISTORY_POINTER, "indices": indices, "content_hash": _hash(rows)}
            if len(json.dumps(reference, ensure_ascii=False)) >= len(json.dumps(rows, ensure_ascii=False)):
                continue
            del budget[field]
            budget[field + "_reference"] = reference
            changed = True
    if not changed:
        return selection
    result["planning_history_projection"] = {
        "contract_version": "planning-craft-history-projection.v1",
        "source_selection_digest": selection["selection_digest"],
        "source_view_hash": _hash(selection),
        "instruction": "Each *_reference replaces only an identical accepted-history list. Read its zero-based indices at json_pointer in this same task view, in order. The full observations, evidence, phases and predecessors remain there; no observation is omitted or upgraded.",
    }
    if resolve_planning_craft_histories(result) != selection:
        raise KernelError("CRAFT_CONTEXT_PROJECTION_DRIFT", "Planning references must reconstruct the complete frozen selection")
    return result if len(json.dumps(result, ensure_ascii=False)) < len(json.dumps(selection, ensure_ascii=False)) else selection
````

## D028 screenplay_context_view

```json
{
  "id": "D028",
  "file": "src/novel_forge/modules/book_followup_authority/screenplay_execution.py",
  "symbol": "screenplay_context_view",
  "line": 55,
  "end_line": 65,
  "runtime_reachable": true,
  "classification": "DYNAMIC_INSTRUCTION_BUILDER",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": true
}
```

完整构造原文：
````python
def screenplay_context_view(stage: str, context: Mapping[str, Any]) -> dict[str, Any]:
    if context.get("schema_version") != "novelos." + stage + "_context_bundle.v1":
        raise KernelError("SCREENPLAY_CONTEXT_INVALID", "The Provider needs its exact stage context contract")
    from .screenplay_sample_execution import expand_sample_inputs
    selected = expand_sample_inputs(context.get("selected_inputs", []))
    expected = {SOURCE_TYPE} | ({CANDIDATE_TYPE} if stage != "screenplay_generate" else set()) | ({REVIEW_TYPE} if stage == "screenplay_revision" else set())
    if len(selected) != len(expected) or {item.get("asset_type") for item in selected} != expected:
        raise KernelError("SCREENPLAY_CONTEXT_INVALID", "A stage cannot omit required inputs or admit unrelated manuscript facts")
    return {"contract_version": "provider-context-view-v2", "stage": stage,
            "inputs": {item["asset_type"]: item["projection"] for item in selected},
            "instruction": "以冻结的同书精确稿件版本改编中文场景剧本。遵循逐场结构计划，区分可表演动作和人物对白。保留指定因果与承诺，改编仅限批准范围。对白不得泄露角色未知信息，动作不得泄露读者不可知信息。审稿独立检查来源保真、人物知识、戏剧行动、对白和可表演性，保留不确定或否定结果；修订只修具体定位问题并保留合法部分。所有派生差异仅属于此剧本，不能修改小说 Canon。"}
````

## D029 execute_candidate

```json
{
  "id": "D029",
  "file": "src/novel_forge/modules/agent_runtime/coordinator.py",
  "symbol": "execute_candidate",
  "line": 314,
  "end_line": 338,
  "runtime_reachable": false,
  "classification": "WIRE_INPUT_ONLY_NOT_FINAL_PROMPT",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": false
}
```

完整构造原文：
````python
    def execute_candidate(
        self, work_order: AgentWorkOrder, execution_port: DomainExecutionPort
    ) -> TurnProcessingResult:
        candidate = execute_domain_candidate(
            capability=work_order.execution_capability,
            operation="analyze",
            candidate_kind=CandidateKind.AGENT_RESULT,
            prompt=(
                "Execute the frozen Agent work order and return only a candidate "
                "AgentOutputEnvelope. Domain Authority owns commit."
            ),
            context={
                "agent_work_order": work_order.to_context(),
                "commit_authority": "domain_authority_only",
            },
            execution_port=execution_port,
        )
        try:
            envelope = AgentOutputEnvelope.from_mapping(
                candidate.raw_output,
                execution_evidence_ref=candidate.evidence.validation_manifest_ref,
            )
        except (TypeError, ValueError) as exc:
            raise KernelError("AGENT_OUTPUT_SCHEMA_INVALID", str(exc)) from exc
        return self.accept_envelope(work_order, envelope, candidate.evidence)
````

## D030 execute_turn

```json
{
  "id": "D030",
  "file": "src/novel_forge/modules/agent_collaboration/application.py",
  "symbol": "execute_turn",
  "line": 191,
  "end_line": 249,
  "runtime_reachable": false,
  "classification": "WIRE_INPUT_ONLY_NOT_FINAL_PROMPT",
  "caller": "PostgresChapterExecutionContractBinder / StoryPlanning execution / phase-specific ProviderTask or Schema builder",
  "downstream": "_materialize_production_codex_prompt -> ProviderRequestEnvelope",
  "stage": "see complete conditional branches in source",
  "dynamic": true,
  "dynamic_variables": "function signature and all conditional source branches reproduced verbatim",
  "skills": "exact selected Pack Skill, one per stage",
  "context": "task-scoped authorized projection",
  "memory": "accepted Context; Agent observations only in agent_session",
  "historical_review": "stage conditional; see inputs review,prior_diagnoses and L0 accepted artifact paths",
  "logs": "conditional inherited nested artifact; no filesystem log scanning",
  "other_prompts": "this builder composes or contributes to System/Skill/Task/Schema",
  "enters_llm": false
}
```

完整构造原文：
````python
    def execute_turn(
        self,
        work_order: AgentWorkOrder,
        execution_port: DomainExecutionPort,
    ) -> TurnProcessingResult:

        replay = self.repository.find_processing_result(work_order.turn_id)
        if replay is not None:
            return replay
        self.schedule_next_turn(work_order)
        candidate = execute_domain_candidate(
            capability=work_order.execution_capability,
            operation="analyze",
            candidate_kind=CandidateKind.AGENT_RESULT,
            prompt=(
                "Execute the frozen Agent collaboration work order. Return only "
                "an AgentOutputEnvelope candidate; do not claim Authority commit."
            ),
            context={
                "agent_work_order": work_order.to_context(),
                "commit_authority": "domain_authority_only",
                "scope_is_frozen": True,
                "participant_set_is_frozen": True,
            },
            execution_port=execution_port,
        )
        if candidate.candidate_kind is not CandidateKind.AGENT_RESULT:
            raise ValueError("PEP returned the wrong candidate kind for Agent turn")
        self._validate_execution_evidence(work_order, candidate.evidence)
        try:
            envelope = AgentOutputEnvelope.from_mapping(
                candidate.raw_output,
                execution_evidence_ref=candidate.evidence.validation_manifest_ref,
            )
        except (TypeError, ValueError) as exc:
            result = TurnProcessingResult(
                turn_id=work_order.turn_id,
                backend_success=True,
                output_received=True,
                schema_validation_passed=False,
                scope_validation_passed=False,
                domain_acceptance=DomainAcceptance.REPAIR_REQUIRED,
                conversation_message_accepted=False,
                message_id="",
                candidate_version_id="",
                conflict_ids=(),
                authority_decision_ref="",
                authority_commit_ref="",
                attempt_completion_allowed=False,
                violations=(f"output_schema:{exc}",),
            )
            return self.repository.save_processing_result(
                work_order.turn_id, result
            )
        return self.accept_agent_output(
            work_order,
            envelope,
            execution_evidence=candidate.evidence,
        )
````

# Output Schemas

```json
{
  "memo": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "execution_strategy": {
        "type": "string",
        "minLength": 1,
        "maxLength": 2000
      },
      "tension_strategy": {
        "type": "string",
        "minLength": 1,
        "maxLength": 2000
      },
      "composition_strategy": {
        "type": "string",
        "minLength": 1,
        "maxLength": 2000
      },
      "creative_guidance": {
        "type": "object",
        "properties": {
          "chapter_goal": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2000
          },
          "pov": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2000
          },
          "voice": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2000
          },
          "emotional_turn": {
            "type": [
              "string",
              "null"
            ]
          },
          "reader_promise": {
            "type": [
              "string",
              "null"
            ]
          },
          "ending_change": {
            "type": [
              "string",
              "null"
            ]
          },
          "character_choices": {
            "type": "array",
            "maxItems": 32,
            "items": {
              "type": "object",
              "properties": {
                "character_id": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "choice": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "motivation": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "cost": {
                  "type": [
                    "string",
                    "null"
                  ]
                }
              },
              "required": [
                "character_id",
                "choice",
                "motivation",
                "cost"
              ],
              "additionalProperties": false
            }
          },
          "constraints": {
            "type": "array",
            "maxItems": 32,
            "items": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            }
          }
        },
        "required": [
          "chapter_goal",
          "pov",
          "voice",
          "emotional_turn",
          "reader_promise",
          "ending_change",
          "character_choices",
          "constraints"
        ],
        "additionalProperties": false
      },
      "scene_directives": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "scene_id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "directive": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "conflict_progression": {
              "type": [
                "string",
                "null"
              ]
            },
            "information_release": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "emotional_change": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            }
          },
          "required": [
            "scene_id",
            "directive",
            "conflict_progression",
            "information_release",
            "emotional_change",
            "transition"
          ],
          "additionalProperties": false
        }
      },
      "retrieval_queries": {
        "type": "array",
        "minItems": 1,
        "maxItems": 8,
        "items": {
          "type": "string",
          "minLength": 1,
          "maxLength": 2000
        }
      },
      "obligation_actions": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "obligation_id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "action": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            }
          },
          "required": [
            "obligation_id",
            "action"
          ],
          "additionalProperties": false
        }
      },
      "arc_actions": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "arc_plan_version_id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "action": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            }
          },
          "required": [
            "arc_plan_version_id",
            "action"
          ],
          "additionalProperties": false
        }
      },
      "stop_conditions": {
        "type": "array",
        "maxItems": 16,
        "items": {
          "type": "string",
          "minLength": 1,
          "maxLength": 2000
        }
      }
    },
    "required": [
      "execution_strategy",
      "tension_strategy",
      "composition_strategy",
      "creative_guidance",
      "scene_directives",
      "retrieval_queries",
      "obligation_actions",
      "arc_actions",
      "stop_conditions"
    ],
    "additionalProperties": false
  },
  "draft": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "scene_artifacts": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "slot_id": {
              "type": "string",
              "minLength": 1
            },
            "text": {
              "type": "string",
              "minLength": 1
            },
            "used_fact_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            }
          },
          "required": [
            "slot_id",
            "text",
            "used_fact_ids"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      }
    },
    "required": [
      "scene_artifacts"
    ],
    "additionalProperties": false
  },
  "review": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "score": {
        "type": "number",
        "minimum": 0,
        "maximum": 100
      },
      "issues": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "code": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "severity": {
              "enum": [
                "blocking",
                "major",
                "minor"
              ]
            },
            "message": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "category": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "judgment_kind": {
              "enum": [
                "SEMANTIC_CONFLICT",
                "AESTHETIC_SUGGESTION",
                "UNCERTAIN"
              ]
            },
            "evidence": {
              "type": "object",
              "properties": {
                "quote": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                }
              },
              "required": [
                "quote"
              ],
              "additionalProperties": false
            },
            "violated_constraint": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "revision_goal": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "preserve": {
              "type": "array",
              "minItems": 1,
              "maxItems": 16,
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            },
            "acceptance_criteria": {
              "type": "array",
              "minItems": 1,
              "maxItems": 16,
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            }
          },
          "required": [
            "code",
            "severity",
            "message",
            "category",
            "judgment_kind",
            "evidence",
            "violated_constraint",
            "revision_goal",
            "preserve",
            "acceptance_criteria"
          ],
          "additionalProperties": false,
          "anyOf": [
            {
              "type": "object",
              "properties": {
                "code": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "blocking",
                    "major",
                    "minor"
                  ]
                },
                "message": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "category": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "judgment_kind": {
                  "type": "string",
                  "enum": [
                    "SEMANTIC_CONFLICT"
                  ]
                },
                "evidence": {
                  "type": "object",
                  "properties": {
                    "quote": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 2000
                    }
                  },
                  "required": [
                    "quote"
                  ],
                  "additionalProperties": false
                },
                "violated_constraint": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "revision_goal": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "preserve": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                },
                "acceptance_criteria": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                }
              },
              "required": [
                "code",
                "severity",
                "message",
                "category",
                "judgment_kind",
                "evidence",
                "violated_constraint",
                "revision_goal",
                "preserve",
                "acceptance_criteria"
              ],
              "additionalProperties": false
            },
            {
              "type": "object",
              "properties": {
                "code": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "minor"
                  ]
                },
                "message": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "category": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "judgment_kind": {
                  "type": "string",
                  "enum": [
                    "AESTHETIC_SUGGESTION"
                  ]
                },
                "evidence": {
                  "type": "object",
                  "properties": {
                    "quote": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 2000
                    }
                  },
                  "required": [
                    "quote"
                  ],
                  "additionalProperties": false
                },
                "violated_constraint": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "revision_goal": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "preserve": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                },
                "acceptance_criteria": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                }
              },
              "required": [
                "code",
                "severity",
                "message",
                "category",
                "judgment_kind",
                "evidence",
                "violated_constraint",
                "revision_goal",
                "preserve",
                "acceptance_criteria"
              ],
              "additionalProperties": false
            },
            {
              "type": "object",
              "properties": {
                "code": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "major",
                    "minor"
                  ]
                },
                "message": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "category": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "judgment_kind": {
                  "type": "string",
                  "enum": [
                    "UNCERTAIN"
                  ]
                },
                "evidence": {
                  "type": "object",
                  "properties": {
                    "quote": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 2000
                    }
                  },
                  "required": [
                    "quote"
                  ],
                  "additionalProperties": false
                },
                "violated_constraint": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "revision_goal": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "preserve": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                },
                "acceptance_criteria": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                }
              },
              "required": [
                "code",
                "severity",
                "message",
                "category",
                "judgment_kind",
                "evidence",
                "violated_constraint",
                "revision_goal",
                "preserve",
                "acceptance_criteria"
              ],
              "additionalProperties": false
            }
          ]
        }
      },
      "resolution_checks": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "code": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "status": {
              "enum": [
                "SATISFIED",
                "UNRESOLVED",
                "UNCERTAIN"
              ]
            },
            "preservation": {
              "enum": [
                "PRESERVED",
                "REGRESSED",
                "UNCERTAIN"
              ]
            },
            "evidence": {
              "type": "object",
              "properties": {
                "quote": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                }
              },
              "required": [
                "quote"
              ],
              "additionalProperties": false
            },
            "reason": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            }
          },
          "required": [
            "code",
            "status",
            "preservation",
            "evidence",
            "reason"
          ],
          "additionalProperties": false
        }
      },
      "knowledge_checks": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "knowledge_card_asset_version_id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "status": {
              "enum": [
                "VERIFIED_IN_PROSE",
                "MISAPPLIED",
                "NOT_OBSERVED",
                "NOT_USED",
                "UNKNOWN"
              ]
            },
            "evidence": {
              "type": [
                "object",
                "null"
              ],
              "properties": {
                "quote": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                }
              },
              "required": [
                "quote"
              ],
              "additionalProperties": false
            },
            "reason": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "conditions_checked": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            },
            "exceptions_checked": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            }
          },
          "required": [
            "knowledge_card_asset_version_id",
            "status",
            "evidence",
            "reason",
            "conditions_checked",
            "exceptions_checked",
            "issue_codes"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "score",
      "issues",
      "resolution_checks",
      "knowledge_checks"
    ],
    "additionalProperties": false
  },
  "revision": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "scene_artifacts": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "slot_id": {
              "type": "string",
              "minLength": 1
            },
            "text": {
              "type": "string",
              "minLength": 1
            },
            "used_fact_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            }
          },
          "required": [
            "slot_id",
            "text",
            "used_fact_ids"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      },
      "resolved_issue_codes": {
        "type": "array",
        "minItems": 0,
        "items": {
          "type": "string",
          "minLength": 1
        }
      }
    },
    "required": [
      "resolved_issue_codes",
      "scene_artifacts"
    ],
    "additionalProperties": false
  },
  "rereview": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "score": {
        "type": "number",
        "minimum": 0,
        "maximum": 100
      },
      "issues": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "code": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "severity": {
              "enum": [
                "blocking",
                "major",
                "minor"
              ]
            },
            "message": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "category": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "judgment_kind": {
              "enum": [
                "SEMANTIC_CONFLICT",
                "AESTHETIC_SUGGESTION",
                "UNCERTAIN"
              ]
            },
            "evidence": {
              "type": "object",
              "properties": {
                "quote": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                }
              },
              "required": [
                "quote"
              ],
              "additionalProperties": false
            },
            "violated_constraint": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "revision_goal": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "preserve": {
              "type": "array",
              "minItems": 1,
              "maxItems": 16,
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            },
            "acceptance_criteria": {
              "type": "array",
              "minItems": 1,
              "maxItems": 16,
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            }
          },
          "required": [
            "code",
            "severity",
            "message",
            "category",
            "judgment_kind",
            "evidence",
            "violated_constraint",
            "revision_goal",
            "preserve",
            "acceptance_criteria"
          ],
          "additionalProperties": false,
          "anyOf": [
            {
              "type": "object",
              "properties": {
                "code": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "blocking",
                    "major",
                    "minor"
                  ]
                },
                "message": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "category": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "judgment_kind": {
                  "type": "string",
                  "enum": [
                    "SEMANTIC_CONFLICT"
                  ]
                },
                "evidence": {
                  "type": "object",
                  "properties": {
                    "quote": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 2000
                    }
                  },
                  "required": [
                    "quote"
                  ],
                  "additionalProperties": false
                },
                "violated_constraint": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "revision_goal": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "preserve": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                },
                "acceptance_criteria": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                }
              },
              "required": [
                "code",
                "severity",
                "message",
                "category",
                "judgment_kind",
                "evidence",
                "violated_constraint",
                "revision_goal",
                "preserve",
                "acceptance_criteria"
              ],
              "additionalProperties": false
            },
            {
              "type": "object",
              "properties": {
                "code": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "minor"
                  ]
                },
                "message": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "category": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "judgment_kind": {
                  "type": "string",
                  "enum": [
                    "AESTHETIC_SUGGESTION"
                  ]
                },
                "evidence": {
                  "type": "object",
                  "properties": {
                    "quote": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 2000
                    }
                  },
                  "required": [
                    "quote"
                  ],
                  "additionalProperties": false
                },
                "violated_constraint": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "revision_goal": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "preserve": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                },
                "acceptance_criteria": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                }
              },
              "required": [
                "code",
                "severity",
                "message",
                "category",
                "judgment_kind",
                "evidence",
                "violated_constraint",
                "revision_goal",
                "preserve",
                "acceptance_criteria"
              ],
              "additionalProperties": false
            },
            {
              "type": "object",
              "properties": {
                "code": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "major",
                    "minor"
                  ]
                },
                "message": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "category": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "judgment_kind": {
                  "type": "string",
                  "enum": [
                    "UNCERTAIN"
                  ]
                },
                "evidence": {
                  "type": "object",
                  "properties": {
                    "quote": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 2000
                    }
                  },
                  "required": [
                    "quote"
                  ],
                  "additionalProperties": false
                },
                "violated_constraint": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "revision_goal": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                },
                "preserve": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                },
                "acceptance_criteria": {
                  "type": "array",
                  "minItems": 1,
                  "maxItems": 16,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 2000
                  }
                }
              },
              "required": [
                "code",
                "severity",
                "message",
                "category",
                "judgment_kind",
                "evidence",
                "violated_constraint",
                "revision_goal",
                "preserve",
                "acceptance_criteria"
              ],
              "additionalProperties": false
            }
          ]
        }
      },
      "resolution_checks": {
        "type": "array",
        "maxItems": 32,
        "items": {
          "type": "object",
          "properties": {
            "code": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "status": {
              "enum": [
                "SATISFIED",
                "UNRESOLVED",
                "UNCERTAIN"
              ]
            },
            "preservation": {
              "enum": [
                "PRESERVED",
                "REGRESSED",
                "UNCERTAIN"
              ]
            },
            "evidence": {
              "type": "object",
              "properties": {
                "quote": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                }
              },
              "required": [
                "quote"
              ],
              "additionalProperties": false
            },
            "reason": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            }
          },
          "required": [
            "code",
            "status",
            "preservation",
            "evidence",
            "reason"
          ],
          "additionalProperties": false
        }
      },
      "knowledge_checks": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "knowledge_card_asset_version_id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "status": {
              "enum": [
                "VERIFIED_IN_PROSE",
                "MISAPPLIED",
                "NOT_OBSERVED",
                "NOT_USED",
                "UNKNOWN"
              ]
            },
            "evidence": {
              "type": [
                "object",
                "null"
              ],
              "properties": {
                "quote": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 2000
                }
              },
              "required": [
                "quote"
              ],
              "additionalProperties": false
            },
            "reason": {
              "type": "string",
              "minLength": 1,
              "maxLength": 2000
            },
            "conditions_checked": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            },
            "exceptions_checked": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            }
          },
          "required": [
            "knowledge_card_asset_version_id",
            "status",
            "evidence",
            "reason",
            "conditions_checked",
            "exceptions_checked",
            "issue_codes"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "score",
      "issues",
      "resolution_checks",
      "knowledge_checks"
    ],
    "additionalProperties": false
  },
  "canon_extraction": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "world_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            },
            "world_state_id": {
              "type": "string",
              "minLength": 1
            },
            "world_transition": {
              "type": "object",
              "properties": {
                "payload_json": {
                  "type": "string",
                  "minLength": 2
                }
              },
              "required": [
                "payload_json"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type",
            "world_state_id",
            "world_transition"
          ],
          "additionalProperties": false
        }
      },
      "faction_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            },
            "faction_id": {
              "type": "string",
              "minLength": 1
            },
            "world_transition": {
              "type": "object",
              "properties": {
                "payload_json": {
                  "type": "string",
                  "minLength": 2
                }
              },
              "required": [
                "payload_json"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type",
            "faction_id",
            "world_transition"
          ],
          "additionalProperties": false
        }
      },
      "location_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            },
            "location_id": {
              "type": "string",
              "minLength": 1
            },
            "world_transition": {
              "type": "object",
              "properties": {
                "payload_json": {
                  "type": "string",
                  "minLength": 2
                }
              },
              "required": [
                "payload_json"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type",
            "location_id",
            "world_transition"
          ],
          "additionalProperties": false
        }
      },
      "consequence_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            },
            "consequence_id": {
              "type": "string",
              "minLength": 1
            },
            "world_transition": {
              "type": "object",
              "properties": {
                "payload_json": {
                  "type": "string",
                  "minLength": 2
                }
              },
              "required": [
                "payload_json"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type",
            "consequence_id",
            "world_transition"
          ],
          "additionalProperties": false
        }
      },
      "conflict_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            },
            "conflict_id": {
              "type": "string",
              "minLength": 1
            },
            "world_transition": {
              "type": "object",
              "properties": {
                "payload_json": {
                  "type": "string",
                  "minLength": 2
                }
              },
              "required": [
                "payload_json"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type",
            "conflict_id",
            "world_transition"
          ],
          "additionalProperties": false
        }
      },
      "canon_facts": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "subject": {
              "type": "string",
              "minLength": 1
            },
            "predicate": {
              "type": "string",
              "minLength": 1
            },
            "object": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": "number",
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "subject",
            "predicate",
            "object",
            "effective_from_chapter",
            "supersedes_event_id",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false,
          "description": "Canonical facts only. Emit at most one item for each subject/predicate/impact_type semantic slot. For multiple objects, combine a bundled fact or use precise relation-specific predicates; never emit different objects in the same semantic slot."
        }
      },
      "character_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": "string",
              "minLength": 1
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "relationship_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                null
              ]
            },
            "source_id": {
              "type": "string",
              "minLength": 1
            },
            "target_id": {
              "type": "string",
              "minLength": 1
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        },
        "description": "Typed directed relationship transitions. Copy the exact source_id and target_id endpoints; entity_id is descriptive only and cannot replace either graph endpoint. Leave the generic character_id field null."
      },
      "timeline_events": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": "string",
              "minLength": 1
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "foreshadow_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": "string",
              "minLength": 1
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "promise_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": "string",
              "minLength": 1
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "obligation_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "obligation_id": {
              "type": "string",
              "minLength": 1
            },
            "obligation_type": {
              "type": "string",
              "enum": [
                "SETUP_PAYOFF",
                "EMOTIONAL_DEBT",
                "INFORMATION_GAP",
                "UNRESOLVED_CONFLICT",
                "THEMATIC_PROMISE",
                "CAUSAL_DEBT",
                "PROMISE",
                "FORESHADOWING",
                "MYSTERY",
                "CONFLICT",
                "OPEN_LOOP",
                "HOOK",
                "CHARACTER_COMMITMENT",
                "READER_EXPECTATION",
                "NARRATIVE_DEBT"
              ]
            },
            "causal_requirement": {
              "type": [
                "object",
                "null"
              ],
              "properties": {
                "payload_json": {
                  "type": "string",
                  "minLength": 2
                }
              },
              "required": [
                "payload_json"
              ],
              "additionalProperties": false
            },
            "causal_plan_asset_version_id": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": "string",
              "enum": [
                "PROPOSED",
                "OPEN",
                "DEVELOPING",
                "DUE",
                "FULFILLED",
                "CANCELLED"
              ]
            },
            "priority": {
              "type": "string",
              "enum": [
                "LOW",
                "MEDIUM",
                "HIGH",
                "CRITICAL"
              ]
            },
            "target_window": {
              "type": "object",
              "properties": {
                "status": {
                  "type": "string",
                  "enum": [
                    "SCHEDULED",
                    "UNSCHEDULED"
                  ]
                },
                "from_chapter": {
                  "type": "integer",
                  "minimum": 0
                },
                "to_chapter": {
                  "type": "integer",
                  "minimum": 0
                }
              },
              "required": [
                "status",
                "from_chapter",
                "to_chapter"
              ],
              "additionalProperties": false
            },
            "payoff_evidence": {
              "type": [
                "object",
                "null"
              ],
              "properties": {
                "asset_version_id": {
                  "type": "string",
                  "minLength": 1,
                  "description": "For CAUSAL_DEBT only: select the accepted prerequisite draft."
                },
                "event_id": {
                  "type": "string",
                  "minLength": 1,
                  "description": "For CAUSAL_DEBT only: select the accepted prerequisite event."
                }
              },
              "required": [
                "asset_version_id",
                "event_id"
              ],
              "additionalProperties": false
            },
            "linked_arc_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "obligation_id",
            "obligation_type",
            "causal_requirement",
            "causal_plan_asset_version_id",
            "from_status",
            "status",
            "priority",
            "target_window",
            "payoff_evidence",
            "linked_arc_ids",
            "summary",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "reward_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": "string",
              "minLength": 1
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "world_rule_usages": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": "string",
              "minLength": 1
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "power_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": "string",
              "minLength": 1
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "plot_thread_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": "string",
              "minLength": 1
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "resource_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": "string",
              "minLength": 1
            },
            "resource_id": {
              "type": "string",
              "minLength": 1
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "narrative_pattern_fingerprints": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": "string",
              "minLength": 1
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "theme_movements": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": "string",
              "minLength": 1
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "antagonist_pressure_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": "string",
              "minLength": 1
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "character_knowledge_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": "string",
              "minLength": 1
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": "string",
              "enum": [
                "UNKNOWN",
                "SUSPECTED",
                "KNOWN",
                "FORGOTTEN"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                null
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        },
        "description": "Atomic Character Knowledge events. Emit one item per character and fact or proposition identity; set status to UNKNOWN, SUSPECTED, KNOWN, or FORGOTTEN; leave the generic state field null; do not bundle multiple acquired_fact_ids."
      },
      "character_belief_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": "string",
              "minLength": 1
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                null
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                null
              ]
            },
            "stance": {
              "type": "string",
              "enum": [
                "BELIEVES",
                "DOUBTS",
                "DISBELIEVES",
                "UNCERTAIN"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                "BELIEVES",
                "DOUBTS",
                "DISBELIEVES",
                "UNCERTAIN",
                null
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                null
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                null
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        },
        "description": "Typed Character Belief events. Emit one item per character and fact or proposition identity; set stance to BELIEVES, DOUBTS, DISBELIEVES, or UNCERTAIN and belief_confidence from zero to one. Use from_stance only for an accepted compare-and-set baseline; leave generic state/status null."
      },
      "character_arc_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": "string",
              "minLength": 1
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": "string",
              "minLength": 1
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "arc_state_changes": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "arc_id": {
              "type": "string",
              "minLength": 1
            },
            "audience": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_mode": {
              "type": [
                "string",
                "null"
              ]
            },
            "presentation_channel": {
              "type": [
                "string",
                "null"
              ]
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        }
      },
      "disclosure_events": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "summary": {
              "type": "string",
              "minLength": 1
            },
            "effective_from_chapter": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 1
            },
            "supersedes_event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "event_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "reward_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "fingerprint_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "antagonist_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "character_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "source_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "target_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "thread_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "promise_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "rule_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "entity_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "resource_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "status": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stance": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "from_stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "life_status": {
              "type": [
                "string",
                "null"
              ]
            },
            "action_state": {
              "type": [
                "string",
                "null"
              ]
            },
            "canonical_name": {
              "type": [
                "string",
                "null"
              ]
            },
            "transition_kind": {
              "type": [
                "string",
                "null"
              ]
            },
            "state": {
              "type": [
                "string",
                "null"
              ]
            },
            "stage": {
              "type": [
                "string",
                "null"
              ]
            },
            "tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "from_tier": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_before": {
              "type": [
                "number",
                "null"
              ]
            },
            "delta": {
              "type": [
                "number",
                "null"
              ]
            },
            "balance_after": {
              "type": [
                "number",
                "null"
              ]
            },
            "exception": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "resurrection_authorized": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "allow_negative_balance": {
              "type": [
                "boolean",
                "null"
              ]
            },
            "payoff_evidence": {
              "type": [
                "string",
                "null"
              ]
            },
            "cost": {
              "type": [
                "string",
                "null"
              ]
            },
            "requires_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "acquired_fact_ids": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "change_reasons": {
              "type": [
                "array",
                "null"
              ],
              "items": {
                "type": "string"
              }
            },
            "fact_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "proposition_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "disclosure_id": {
              "type": "string",
              "minLength": 1
            },
            "arc_id": {
              "type": [
                "string",
                "null"
              ]
            },
            "audience": {
              "type": "string",
              "minLength": 1
            },
            "disclosure_mode": {
              "type": "string",
              "enum": [
                "HINT",
                "PARTIAL",
                "MISDIRECT",
                "CONFIRM",
                "WITHHOLD"
              ]
            },
            "presentation_channel": {
              "type": "string",
              "minLength": 1
            },
            "belief_confidence": {
              "type": [
                "number",
                "null"
              ],
              "minimum": 0,
              "maximum": 1
            },
            "evidence_quote": {
              "type": "string",
              "minLength": 1
            },
            "claim_kind": {
              "enum": [
                "OBJECTIVE_EVENT",
                "OBJECTIVE_STATE",
                "KNOWLEDGE_ACQUISITION",
                "BELIEF",
                "SUSPICION",
                "HEARSAY",
                "DIALOGUE_ASSERTION",
                "READER_DISCLOSURE"
              ]
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "impact_type": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "summary",
            "effective_from_chapter",
            "supersedes_event_id",
            "event_id",
            "reward_id",
            "fingerprint_id",
            "antagonist_id",
            "character_id",
            "source_id",
            "target_id",
            "thread_id",
            "promise_id",
            "rule_id",
            "entity_id",
            "resource_id",
            "status",
            "from_status",
            "stance",
            "from_stance",
            "from_state",
            "from_stage",
            "life_status",
            "action_state",
            "canonical_name",
            "transition_kind",
            "state",
            "stage",
            "tier",
            "from_tier",
            "balance_before",
            "delta",
            "balance_after",
            "exception",
            "resurrection_authorized",
            "allow_negative_balance",
            "payoff_evidence",
            "cost",
            "requires_fact_ids",
            "acquired_fact_ids",
            "change_reasons",
            "fact_id",
            "proposition_id",
            "disclosure_id",
            "arc_id",
            "audience",
            "disclosure_mode",
            "presentation_channel",
            "belief_confidence",
            "evidence_quote",
            "claim_kind",
            "confidence",
            "impact_type"
          ],
          "additionalProperties": false
        },
        "description": "Typed presentation events. Copy a stable disclosure_id, one fact or proposition identity, the exact audience, disclosure mode, and presentation channel. Disclosure is presentation evidence, not Reader Knowledge input."
      },
      "arc_evidence": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "arc_plan_version_id": {
              "type": "string",
              "minLength": 1
            },
            "observation_status": {
              "type": "string",
              "enum": [
                "OBSERVED",
                "NOT_OBSERVED",
                "NOT_MATERIALIZED",
                "UNKNOWN"
              ]
            },
            "contribution_kind": {
              "type": "string",
              "minLength": 1
            },
            "progress_units": {
              "type": "integer",
              "minimum": 0
            },
            "effect_dimensions": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "milestone_ids": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "actual_consequences": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "obligation_ids": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "resolution_evidence": {
              "type": "array",
              "items": {
                "type": "string"
              },
              "description": "For OBSERVED only: literal final-candidate prose quotes; empty otherwise."
            },
            "completion_criterion_ids": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "phase_to": {
              "type": [
                "string",
                "null"
              ]
            },
            "claim_kind": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                "NARRATIVE_OBSERVATION",
                null
              ]
            },
            "evidence_quote": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            }
          },
          "required": [
            "arc_plan_version_id",
            "observation_status",
            "contribution_kind",
            "progress_units",
            "effect_dimensions",
            "milestone_ids",
            "actual_consequences",
            "obligation_ids",
            "resolution_evidence",
            "completion_criterion_ids",
            "phase_to",
            "claim_kind",
            "evidence_quote"
          ],
          "additionalProperties": false
        }
      },
      "realization_evidence": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "planned_event_id": {
              "type": "string",
              "minLength": 1
            },
            "observed_event_id": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            },
            "observation_status": {
              "type": "string",
              "enum": [
                "OBSERVED",
                "NOT_OBSERVED"
              ]
            },
            "accepted_prose_evidence": {
              "type": "array",
              "items": {
                "type": "object",
                "properties": {
                  "quote": {
                    "type": "string",
                    "minLength": 1
                  },
                  "summary": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "quote",
                  "summary"
                ],
                "additionalProperties": false
              }
            },
            "observed_consequence": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            },
            "observed_action": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            },
            "observed_decision": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            },
            "observed_cause_event_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "observed_disclosures": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "observed_state_deltas": {
              "type": "array",
              "items": {
                "type": "object",
                "properties": {
                  "state_kind": {
                    "type": "string",
                    "minLength": 1
                  },
                  "entity_id": {
                    "type": "string",
                    "minLength": 1
                  },
                  "from_state": {
                    "type": "string",
                    "minLength": 1
                  },
                  "to_state": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "state_kind",
                  "entity_id",
                  "from_state",
                  "to_state"
                ],
                "additionalProperties": false
              }
            },
            "observed_state_event_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "claim_kind": {
              "type": [
                "string",
                "null"
              ],
              "enum": [
                "NARRATIVE_OBSERVATION",
                null
              ]
            },
            "evidence_quote": {
              "type": [
                "string",
                "null"
              ],
              "minLength": 1
            }
          },
          "required": [
            "planned_event_id",
            "observed_event_id",
            "observation_status",
            "accepted_prose_evidence",
            "observed_consequence",
            "observed_action",
            "observed_decision",
            "observed_cause_event_ids",
            "observed_disclosures",
            "observed_state_deltas",
            "observed_state_event_ids",
            "claim_kind",
            "evidence_quote"
          ],
          "additionalProperties": false
        }
      },
      "extraction_status": {
        "enum": [
          "EXTRACTED",
          "NO_CHANGE"
        ]
      },
      "no_change_reason": {
        "type": "string"
      }
    },
    "required": [
      "world_state_changes",
      "faction_state_changes",
      "location_state_changes",
      "consequence_changes",
      "conflict_state_changes",
      "canon_facts",
      "character_state_changes",
      "relationship_changes",
      "timeline_events",
      "foreshadow_changes",
      "promise_changes",
      "obligation_changes",
      "reward_changes",
      "world_rule_usages",
      "power_state_changes",
      "plot_thread_changes",
      "resource_state_changes",
      "narrative_pattern_fingerprints",
      "theme_movements",
      "antagonist_pressure_changes",
      "character_knowledge_changes",
      "character_belief_changes",
      "character_arc_changes",
      "arc_state_changes",
      "disclosure_events",
      "arc_evidence",
      "realization_evidence",
      "extraction_status",
      "no_change_reason"
    ],
    "additionalProperties": false
  },
  "canon_support": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "coverage": {
        "enum": [
          "COMPLETE",
          "INCOMPLETE"
        ]
      },
      "no_change_supported": {
        "type": "boolean"
      },
      "claims": {
        "type": "array",
        "maxItems": 256,
        "items": {
          "type": "object",
          "properties": {
            "claim_id": {
              "type": "string",
              "minLength": 1
            },
            "assessment": {
              "enum": [
                "SUPPORTED",
                "UNSUPPORTED",
                "UNCERTAIN"
              ]
            },
            "observed_kind": {
              "type": "string",
              "minLength": 1
            },
            "reason": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "claim_id",
            "assessment",
            "observed_kind",
            "reason"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "coverage",
      "no_change_supported",
      "claims"
    ],
    "additionalProperties": false
  },
  "quality_structural": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "dimensions": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "dimension": {
              "type": "string",
              "minLength": 1
            },
            "gate_status": {
              "type": "string",
              "enum": [
                "PASSED",
                "PASSED_WITH_WARNINGS",
                "FAILED",
                "INSUFFICIENT_EVIDENCE",
                "REQUIRES_HUMAN_REVIEW"
              ]
            },
            "score": {
              "type": "number",
              "minimum": 0,
              "maximum": 100
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "evidence_locations": {
              "type": "array",
              "minItems": 0,
              "items": {
                "type": "object",
                "properties": {
                  "quote": {
                    "type": "string",
                    "minLength": 1
                  },
                  "claim": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "quote",
                  "claim"
                ],
                "additionalProperties": false
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "revision_strategies": {
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          },
          "required": [
            "dimension",
            "gate_status",
            "score",
            "confidence",
            "evidence_locations",
            "issue_codes",
            "revision_strategies"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      }
    },
    "required": [
      "dimensions"
    ],
    "additionalProperties": false
  },
  "quality_commercial": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "dimensions": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "dimension": {
              "type": "string",
              "minLength": 1
            },
            "gate_status": {
              "type": "string",
              "enum": [
                "PASSED",
                "PASSED_WITH_WARNINGS",
                "FAILED",
                "INSUFFICIENT_EVIDENCE",
                "REQUIRES_HUMAN_REVIEW"
              ]
            },
            "score": {
              "type": "number",
              "minimum": 0,
              "maximum": 100
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "evidence_locations": {
              "type": "array",
              "minItems": 0,
              "items": {
                "type": "object",
                "properties": {
                  "quote": {
                    "type": "string",
                    "minLength": 1
                  },
                  "claim": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "quote",
                  "claim"
                ],
                "additionalProperties": false
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "revision_strategies": {
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          },
          "required": [
            "dimension",
            "gate_status",
            "score",
            "confidence",
            "evidence_locations",
            "issue_codes",
            "revision_strategies"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      }
    },
    "required": [
      "dimensions"
    ],
    "additionalProperties": false
  },
  "quality_source_originality": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "dimensions": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "dimension": {
              "type": "string",
              "minLength": 1
            },
            "gate_status": {
              "type": "string",
              "enum": [
                "PASSED",
                "PASSED_WITH_WARNINGS",
                "FAILED",
                "INSUFFICIENT_EVIDENCE",
                "REQUIRES_HUMAN_REVIEW"
              ]
            },
            "score": {
              "type": "number",
              "minimum": 0,
              "maximum": 100
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "evidence_locations": {
              "type": "array",
              "minItems": 0,
              "items": {
                "type": "object",
                "properties": {
                  "quote": {
                    "type": "string",
                    "minLength": 1
                  },
                  "claim": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "quote",
                  "claim"
                ],
                "additionalProperties": false
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "revision_strategies": {
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          },
          "required": [
            "dimension",
            "gate_status",
            "score",
            "confidence",
            "evidence_locations",
            "issue_codes",
            "revision_strategies"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      }
    },
    "required": [
      "dimensions"
    ],
    "additionalProperties": false
  },
  "quality_longform": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "dimensions": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "dimension": {
              "type": "string",
              "minLength": 1
            },
            "gate_status": {
              "type": "string",
              "enum": [
                "PASSED",
                "PASSED_WITH_WARNINGS",
                "FAILED",
                "INSUFFICIENT_EVIDENCE",
                "REQUIRES_HUMAN_REVIEW"
              ]
            },
            "score": {
              "type": "number",
              "minimum": 0,
              "maximum": 100
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "evidence_locations": {
              "type": "array",
              "minItems": 0,
              "items": {
                "type": "object",
                "properties": {
                  "quote": {
                    "type": "string",
                    "minLength": 1
                  },
                  "claim": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "quote",
                  "claim"
                ],
                "additionalProperties": false
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "revision_strategies": {
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          },
          "required": [
            "dimension",
            "gate_status",
            "score",
            "confidence",
            "evidence_locations",
            "issue_codes",
            "revision_strategies"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      }
    },
    "required": [
      "dimensions"
    ],
    "additionalProperties": false
  },
  "quality_platform": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "dimensions": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "dimension": {
              "type": "string",
              "minLength": 1
            },
            "gate_status": {
              "type": "string",
              "enum": [
                "PASSED",
                "PASSED_WITH_WARNINGS",
                "FAILED",
                "INSUFFICIENT_EVIDENCE",
                "REQUIRES_HUMAN_REVIEW"
              ]
            },
            "score": {
              "type": "number",
              "minimum": 0,
              "maximum": 100
            },
            "confidence": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "evidence_locations": {
              "type": "array",
              "minItems": 0,
              "items": {
                "type": "object",
                "properties": {
                  "quote": {
                    "type": "string",
                    "minLength": 1
                  },
                  "claim": {
                    "type": "string",
                    "minLength": 1
                  }
                },
                "required": [
                  "quote",
                  "claim"
                ],
                "additionalProperties": false
              }
            },
            "issue_codes": {
              "type": "array",
              "items": {
                "type": "string"
              }
            },
            "revision_strategies": {
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          },
          "required": [
            "dimension",
            "gate_status",
            "score",
            "confidence",
            "evidence_locations",
            "issue_codes",
            "revision_strategies"
          ],
          "additionalProperties": false
        },
        "minItems": 1
      }
    },
    "required": [
      "dimensions"
    ],
    "additionalProperties": false
  },
  "retrieval": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "vectors": {
        "type": "array",
        "minItems": 1,
        "maxItems": 32,
        "items": {
          "type": "array",
          "minItems": 1,
          "maxItems": 8192,
          "items": {
            "type": "number"
          }
        }
      },
      "embedding_model": {
        "type": "string",
        "minLength": 1
      },
      "embedding_dimensions": {
        "type": "integer",
        "minimum": 1
      }
    },
    "required": [
      "vectors",
      "embedding_model",
      "embedding_dimensions"
    ],
    "additionalProperties": false
  },
  "retrieval_query_expansion": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "contract_version": {
        "type": "string",
        "const": "retrieval-expansion-plan-v1"
      },
      "queries": {
        "type": "array",
        "minItems": 1,
        "maxItems": 4,
        "items": {
          "type": "object",
          "properties": {
            "query_id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 160
            },
            "text": {
              "type": "string",
              "minLength": 1,
              "maxLength": 512
            },
            "reason": {
              "type": "string",
              "minLength": 1,
              "maxLength": 512
            },
            "targets": {
              "type": "array",
              "maxItems": 32,
              "uniqueItems": true,
              "items": {
                "type": "string",
                "minLength": 1,
                "maxLength": 200
              },
              "minItems": 1
            },
            "selectors": {
              "type": "object",
              "properties": {
                "entity_ids": {
                  "type": "array",
                  "maxItems": 32,
                  "uniqueItems": true,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200
                  }
                },
                "character_ids": {
                  "type": "array",
                  "maxItems": 32,
                  "uniqueItems": true,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200
                  }
                },
                "relationship_ids": {
                  "type": "array",
                  "maxItems": 32,
                  "uniqueItems": true,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200
                  }
                },
                "arc_plan_version_ids": {
                  "type": "array",
                  "maxItems": 32,
                  "uniqueItems": true,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200
                  }
                },
                "obligation_ids": {
                  "type": "array",
                  "maxItems": 32,
                  "uniqueItems": true,
                  "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200
                  }
                }
              },
              "required": [],
              "additionalProperties": false
            },
            "temporal_range": {
              "type": "object",
              "properties": {
                "from_chapter": {
                  "type": "integer",
                  "minimum": 0
                },
                "to_chapter": {
                  "type": "integer",
                  "minimum": 0
                }
              },
              "required": [
                "from_chapter",
                "to_chapter"
              ],
              "additionalProperties": false
            }
          },
          "required": [
            "query_id",
            "text",
            "reason",
            "targets",
            "selectors",
            "temporal_range"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "contract_version",
      "queries"
    ],
    "additionalProperties": false
  },
  "context_compress": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "selected_unit_ids": {
        "type": "array",
        "maxItems": 256,
        "uniqueItems": true,
        "items": {
          "type": "string",
          "minLength": 1,
          "maxLength": 200
        }
      }
    },
    "required": [
      "selected_unit_ids"
    ],
    "additionalProperties": false
  },
  "context_fidelity": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "supported": {
        "type": "boolean"
      },
      "coverage_complete": {
        "type": "boolean"
      },
      "missing_unit_ids": {
        "type": "array",
        "maxItems": 256,
        "uniqueItems": true,
        "items": {
          "type": "string",
          "minLength": 1,
          "maxLength": 200
        }
      },
      "distorted_unit_ids": {
        "type": "array",
        "maxItems": 256,
        "uniqueItems": true,
        "items": {
          "type": "string",
          "minLength": 1,
          "maxLength": 200
        }
      },
      "reason": {
        "type": "string",
        "minLength": 1,
        "maxLength": 4000
      }
    },
    "required": [
      "supported",
      "coverage_complete",
      "missing_unit_ids",
      "distorted_unit_ids",
      "reason"
    ],
    "additionalProperties": false
  },
  "agent_session": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "message": {
        "type": "string",
        "minLength": 1
      },
      "action": {
        "type": "string",
        "enum": [
          "TOOL_CALL",
          "FINAL"
        ]
      },
      "tool_call": {
        "type": [
          "object",
          "null"
        ],
        "properties": {
          "tool_name": {
            "type": "string",
            "minLength": 1
          },
          "arguments": {
            "type": "object",
            "properties": {
              "payload_json": {
                "type": "string",
                "minLength": 2
              }
            },
            "required": [
              "payload_json"
            ],
            "additionalProperties": false
          },
          "reason": {
            "type": "string",
            "minLength": 1
          }
        },
        "required": [
          "tool_name",
          "arguments",
          "reason"
        ],
        "additionalProperties": false
      },
      "final_response": {
        "type": [
          "object",
          "null"
        ],
        "properties": {
          "payload_json": {
            "type": "string",
            "minLength": 2
          }
        },
        "required": [
          "payload_json"
        ],
        "additionalProperties": false
      }
    },
    "required": [
      "message",
      "action",
      "tool_call",
      "final_response"
    ],
    "additionalProperties": false
  },
  "longform_prose_review": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "schema_version": {
        "type": "string",
        "enum": [
          "longform-prose-review.v1"
        ]
      },
      "manifest_digest": {
        "type": "string",
        "minLength": 1
      },
      "window_id": {
        "type": "string",
        "minLength": 1
      },
      "reviewed_dimensions": {
        "type": "array",
        "items": {
          "type": "string",
          "enum": [
            "structure_conflict_repetition",
            "goals_relationships",
            "setup_progress_payoff",
            "voice_expression",
            "arc_pacing",
            "motivation_cost"
          ]
        },
        "uniqueItems": true,
        "minItems": 6,
        "maxItems": 6
      },
      "findings": {
        "type": "array",
        "items": {
          "anyOf": [
            {
              "type": "object",
              "properties": {
                "lineage_id": {
                  "type": "string",
                  "minLength": 1
                },
                "dimension": {
                  "type": "string",
                  "enum": [
                    "structure_conflict_repetition",
                    "goals_relationships",
                    "setup_progress_payoff",
                    "voice_expression",
                    "arc_pacing",
                    "motivation_cost"
                  ]
                },
                "judgment": {
                  "type": "string",
                  "enum": [
                    "ISSUE"
                  ]
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "BLOCKING",
                    "MAJOR",
                    "MINOR"
                  ]
                },
                "confidence": {
                  "type": "number",
                  "minimum": 0,
                  "maximum": 1
                },
                "claim": {
                  "type": "string",
                  "minLength": 1
                },
                "rationale": {
                  "type": "string",
                  "minLength": 1
                },
                "evidence": {
                  "type": "array",
                  "items": {
                    "type": "object",
                    "properties": {
                      "asset_version_id": {
                        "type": "string",
                        "minLength": 1
                      },
                      "text_hash": {
                        "type": "string",
                        "minLength": 1
                      },
                      "start": {
                        "type": "integer",
                        "minimum": 0
                      },
                      "end": {
                        "type": "integer",
                        "minimum": 1
                      },
                      "quote": {
                        "type": "string",
                        "minLength": 1
                      }
                    },
                    "required": [
                      "asset_version_id",
                      "text_hash",
                      "start",
                      "end",
                      "quote"
                    ],
                    "additionalProperties": false
                  },
                  "minItems": 1
                }
              },
              "required": [
                "lineage_id",
                "dimension",
                "judgment",
                "severity",
                "confidence",
                "claim",
                "rationale",
                "evidence"
              ],
              "additionalProperties": false
            },
            {
              "type": "object",
              "properties": {
                "lineage_id": {
                  "type": "string",
                  "minLength": 1
                },
                "dimension": {
                  "type": "string",
                  "enum": [
                    "structure_conflict_repetition",
                    "goals_relationships",
                    "setup_progress_payoff",
                    "voice_expression",
                    "arc_pacing",
                    "motivation_cost"
                  ]
                },
                "judgment": {
                  "type": "string",
                  "enum": [
                    "INTENTIONAL",
                    "INSUFFICIENT_EVIDENCE"
                  ]
                },
                "severity": {
                  "type": "string",
                  "enum": [
                    "NONE"
                  ]
                },
                "confidence": {
                  "type": "number",
                  "minimum": 0,
                  "maximum": 1
                },
                "claim": {
                  "type": "string",
                  "minLength": 1
                },
                "rationale": {
                  "type": "string",
                  "minLength": 1
                },
                "evidence": {
                  "type": "array",
                  "items": {
                    "type": "object",
                    "properties": {
                      "asset_version_id": {
                        "type": "string",
                        "minLength": 1
                      },
                      "text_hash": {
                        "type": "string",
                        "minLength": 1
                      },
                      "start": {
                        "type": "integer",
                        "minimum": 0
                      },
                      "end": {
                        "type": "integer",
                        "minimum": 1
                      },
                      "quote": {
                        "type": "string",
                        "minLength": 1
                      }
                    },
                    "required": [
                      "asset_version_id",
                      "text_hash",
                      "start",
                      "end",
                      "quote"
                    ],
                    "additionalProperties": false
                  },
                  "minItems": 1
                }
              },
              "required": [
                "lineage_id",
                "dimension",
                "judgment",
                "severity",
                "confidence",
                "claim",
                "rationale",
                "evidence"
              ],
              "additionalProperties": false
            }
          ]
        }
      }
    },
    "required": [
      "schema_version",
      "manifest_digest",
      "window_id",
      "reviewed_dimensions",
      "findings"
    ],
    "additionalProperties": false
  },
  "reader_outcome": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "reader_state": {
        "type": "object",
        "properties": {
          "continue_intent": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "curiosity": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "satisfaction": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "confusion": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "trust": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "character_attachment": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "antagonist_pressure": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "promise_expectation": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "payoff_satisfaction": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "drop_risk": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "repetition_fatigue": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          }
        },
        "required": [
          "continue_intent",
          "curiosity",
          "satisfaction",
          "confusion",
          "trust",
          "character_attachment",
          "antagonist_pressure",
          "promise_expectation",
          "payoff_satisfaction",
          "drop_risk",
          "repetition_fatigue"
        ],
        "additionalProperties": false
      },
      "evidence": {
        "type": "array",
        "minItems": 1,
        "items": {
          "type": "object",
          "properties": {
            "asset_version_id": {
              "type": "string",
              "minLength": 1
            },
            "location": {
              "type": "string",
              "minLength": 1
            },
            "claim": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "asset_version_id",
            "location",
            "claim"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "reader_state",
      "evidence"
    ],
    "additionalProperties": false
  },
  "screenplay_generate": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "schema_version": {
        "const": "scene-screenplay.v2"
      },
      "source_digest": {
        "type": "string",
        "minLength": 1
      },
      "scenes": {
        "type": "array",
        "minItems": 1,
        "maxItems": 100,
        "items": {
          "type": "object",
          "properties": {
            "scene_id": {
              "type": "string",
              "minLength": 1
            },
            "source_unit_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "location": {
              "type": "string",
              "minLength": 1
            },
            "time": {
              "type": "string",
              "minLength": 1
            },
            "participants": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "retained_fact_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "adaptation_changes": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "beats": {
              "type": "array",
              "minItems": 1,
              "maxItems": 500,
              "items": {
                "type": "object",
                "properties": {
                  "beat_id": {
                    "type": "string",
                    "minLength": 1
                  },
                  "kind": {
                    "enum": [
                      "ACTION",
                      "DIALOGUE"
                    ]
                  },
                  "character_id": {
                    "type": "string"
                  },
                  "text": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 10000
                  },
                  "fact_ids": {
                    "type": "array",
                    "items": {
                      "type": "string",
                      "minLength": 1
                    }
                  }
                },
                "required": [
                  "beat_id",
                  "kind",
                  "character_id",
                  "text",
                  "fact_ids"
                ],
                "additionalProperties": false
              }
            }
          },
          "required": [
            "scene_id",
            "source_unit_ids",
            "location",
            "time",
            "participants",
            "retained_fact_ids",
            "adaptation_changes",
            "beats"
          ],
          "additionalProperties": false
        }
      },
      "craft_realizations": {
        "type": "array",
        "maxItems": 100,
        "items": {
          "type": "object",
          "properties": {
            "use_id": {
              "type": "string",
              "minLength": 1
            },
            "scene_id": {
              "type": "string",
              "minLength": 1
            },
            "beat_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "uniqueItems": true
            },
            "reason": {
              "type": "string",
              "minLength": 1
            },
            "decision": {
              "enum": [
                "ADOPT",
                "OMIT"
              ]
            }
          },
          "required": [
            "use_id",
            "scene_id",
            "beat_ids",
            "reason",
            "decision"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "schema_version",
      "source_digest",
      "scenes",
      "craft_realizations"
    ],
    "additionalProperties": false
  },
  "screenplay_review": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "schema_version": {
        "const": "screenplay-review.v2"
      },
      "source_digest": {
        "type": "string",
        "minLength": 1
      },
      "candidate_digest": {
        "type": "string",
        "minLength": 1
      },
      "verdict": {
        "enum": [
          "APPROVE",
          "REVISE",
          "REJECT",
          "INDETERMINATE"
        ]
      },
      "reviewed_dimensions": {
        "type": "array",
        "items": {
          "enum": [
            "SOURCE_FIDELITY",
            "CHARACTER_KNOWLEDGE",
            "DRAMATIC_ACTION",
            "DIALOGUE",
            "PERFORMABILITY"
          ]
        },
        "uniqueItems": true
      },
      "findings": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "finding_id": {
              "type": "string",
              "minLength": 1
            },
            "scene_id": {
              "type": "string",
              "minLength": 1
            },
            "beat_id": {
              "type": "string"
            },
            "dimension": {
              "enum": [
                "SOURCE_FIDELITY",
                "CHARACTER_KNOWLEDGE",
                "DRAMATIC_ACTION",
                "DIALOGUE",
                "PERFORMABILITY"
              ]
            },
            "severity": {
              "enum": [
                "MINOR",
                "MAJOR",
                "CRITICAL"
              ]
            },
            "description": {
              "type": "string",
              "minLength": 1
            },
            "preservation_requirement": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": [
            "finding_id",
            "scene_id",
            "beat_id",
            "dimension",
            "severity",
            "description",
            "preservation_requirement"
          ],
          "additionalProperties": false
        }
      },
      "rationale": {
        "type": "string",
        "minLength": 1
      },
      "craft_checks": {
        "type": "array",
        "maxItems": 100,
        "items": {
          "type": "object",
          "properties": {
            "use_id": {
              "type": "string",
              "minLength": 1
            },
            "scene_id": {
              "type": "string",
              "minLength": 1
            },
            "beat_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "uniqueItems": true
            },
            "reason": {
              "type": "string",
              "minLength": 1
            },
            "status": {
              "enum": [
                "ACHIEVED",
                "FAILED",
                "UNCERTAIN",
                "REJECT",
                "NOT_USED"
              ]
            },
            "interference": {
              "enum": [
                "CLEAR",
                "PRESENT",
                "UNCERTAIN"
              ]
            }
          },
          "required": [
            "use_id",
            "scene_id",
            "beat_ids",
            "reason",
            "status",
            "interference"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "schema_version",
      "source_digest",
      "candidate_digest",
      "verdict",
      "reviewed_dimensions",
      "findings",
      "rationale",
      "craft_checks"
    ],
    "additionalProperties": false
  },
  "screenplay_revision": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "schema_version": {
        "const": "scene-screenplay.v2"
      },
      "source_digest": {
        "type": "string",
        "minLength": 1
      },
      "scenes": {
        "type": "array",
        "minItems": 1,
        "maxItems": 100,
        "items": {
          "type": "object",
          "properties": {
            "scene_id": {
              "type": "string",
              "minLength": 1
            },
            "source_unit_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "location": {
              "type": "string",
              "minLength": 1
            },
            "time": {
              "type": "string",
              "minLength": 1
            },
            "participants": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "retained_fact_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "adaptation_changes": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            },
            "beats": {
              "type": "array",
              "minItems": 1,
              "maxItems": 500,
              "items": {
                "type": "object",
                "properties": {
                  "beat_id": {
                    "type": "string",
                    "minLength": 1
                  },
                  "kind": {
                    "enum": [
                      "ACTION",
                      "DIALOGUE"
                    ]
                  },
                  "character_id": {
                    "type": "string"
                  },
                  "text": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 10000
                  },
                  "fact_ids": {
                    "type": "array",
                    "items": {
                      "type": "string",
                      "minLength": 1
                    }
                  }
                },
                "required": [
                  "beat_id",
                  "kind",
                  "character_id",
                  "text",
                  "fact_ids"
                ],
                "additionalProperties": false
              }
            }
          },
          "required": [
            "scene_id",
            "source_unit_ids",
            "location",
            "time",
            "participants",
            "retained_fact_ids",
            "adaptation_changes",
            "beats"
          ],
          "additionalProperties": false
        }
      },
      "craft_realizations": {
        "type": "array",
        "maxItems": 100,
        "items": {
          "type": "object",
          "properties": {
            "use_id": {
              "type": "string",
              "minLength": 1
            },
            "scene_id": {
              "type": "string",
              "minLength": 1
            },
            "beat_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              },
              "uniqueItems": true
            },
            "reason": {
              "type": "string",
              "minLength": 1
            },
            "decision": {
              "enum": [
                "ADOPT",
                "OMIT"
              ]
            }
          },
          "required": [
            "use_id",
            "scene_id",
            "beat_ids",
            "reason",
            "decision"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "schema_version",
      "source_digest",
      "scenes",
      "craft_realizations"
    ],
    "additionalProperties": false
  },
  "targeted_revision": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "resolved_issue_codes": {
        "type": "array",
        "items": {
          "type": "string",
          "minLength": 1
        }
      },
      "edits": {
        "type": "array",
        "minItems": 1,
        "items": {
          "type": "object",
          "properties": {
            "quote": {
              "type": "string",
              "minLength": 1
            },
            "replacement": {
              "type": "string"
            },
            "issue_codes": {
              "type": "array",
              "minItems": 1,
              "items": {
                "type": "string",
                "minLength": 1
              }
            }
          },
          "required": [
            "quote",
            "replacement",
            "issue_codes"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "resolved_issue_codes",
      "edits"
    ],
    "additionalProperties": false
  },
  "legacy_draft": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
      "text": {
        "type": "string",
        "minLength": 1
      },
      "scene_artifacts": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "slot_id": {
              "type": "string",
              "minLength": 1
            },
            "text": {
              "type": "string",
              "minLength": 1
            },
            "used_fact_ids": {
              "type": "array",
              "items": {
                "type": "string",
                "minLength": 1
              }
            }
          },
          "required": [
            "slot_id",
            "text",
            "used_fact_ids"
          ],
          "additionalProperties": false
        }
      }
    },
    "required": [
      "text",
      "scene_artifacts"
    ],
    "additionalProperties": false
  }
}
```
