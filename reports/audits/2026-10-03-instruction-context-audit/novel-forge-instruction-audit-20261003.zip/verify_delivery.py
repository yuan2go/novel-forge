from pathlib import Path
import json,subprocess,hashlib,re,datetime,zipfile
BASE=Path('/Users/yuan/Documents/Codex/audits/novel-forge-instructions-20261003');ROOT=BASE/'snapshot';ORIGINAL=Path('/Volumes/DevSSD/Development/Workspace/projects/novel-forge')
def git(path,*args):return subprocess.check_output(['git',*args],cwd=path).decode().strip()
expected='4bfe3a26df00656a1d36271e29f8170d45a972dd'
head=git(ROOT,'rev-parse','HEAD');snapshot_status=git(ROOT,'status','--porcelain=v1');original_head=git(ORIGINAL,'rev-parse','HEAD');original_status=git(ORIGINAL,'status','--porcelain=v1')
assert head==expected
assert not snapshot_status
assert original_head=='ceb69fa2ff1c56f07005154bb5797616e933e8c2'
assert all(line.startswith('?? ') for line in original_status.splitlines())
json_files=list(BASE.glob('*.json'))
for path in json_files:json.loads(path.read_text())
ps=json.loads((BASE/'prompt-inventory.json').read_text());ss=json.loads((BASE/'skill-inventory.json').read_text());cs=json.loads((BASE/'emitted-semantic-contracts.json').read_text());sources=json.loads((BASE/'instruction-source-index.json').read_text())
assert len({p['id'] for p in ps})==len(ps)==27
assert len({s['id'] for s in ss})==len(ss)==38
assert len(cs)==78 and not any(c['text'].startswith('DYNAMIC_ARGUMENT_REQUIRED') for c in cs)
for p in ps:assert p['text'] in (BASE/'02-complete-prompt-inventory.md').read_text()
for s in ss:assert s['text'] in (BASE/'04-complete-skill-inventory.md').read_text()
for p in ['02-complete-prompt-inventory.md','03-dynamic-instructions.md','04-complete-skill-inventory.md','05-static-effective-writer-context.txt','06-instruction-source-corpus.md','07-targeted-git-history.md']:
 assert (BASE/p).read_text() in (BASE/'00-full-forensic-report.md').read_text()
original_tracked_diff=git(ORIGINAL,'diff','--stat')
integrity={'audit_kind':'READ_ONLY_FORENSIC','expected_main_sha':expected,'snapshot_head':head,'snapshot_git_status':snapshot_status,'remote_main_rechecked_sha':expected,'remote_recheck_method':'git ls-remote origin refs/heads/main, read-only; returned before final delivery','original_head':original_head,'original_branch':git(ORIGINAL,'branch','--show-current'),'original_tracked_diff_stat':original_tracked_diff,'original_untracked_paths_retained':[line[3:] for line in original_status.splitlines()],'original_untracked_initial_hash_baseline_recorded':False,'source_tree_mutations_performed':False,'provider_calls':0,'database_connections':0,'novel_generations':0,'tests_matrix':'NOT_RUN','git_push_pr_merge':'NOT_RUN','pure_validation':'four focused families; v2/v3/v4 correctness PASS/replay MATCH with contamination markers; not production qualification','counts':{'prompt_records':27,'stage_contract_variants':78,'dynamic_top_level_builders':30,'source_exports':len(sources),'skill_files':38},'validation_time':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(BASE/'audit-integrity.json').write_text(json.dumps(integrity,ensure_ascii=False,indent=2)+'\n')
report=(BASE/'01-audit-report.md').read_text()
for target in re.findall(r'\]\(([^\)]+)\)',report):
 if not target.startswith(('https:','http:','#')):assert (BASE/target).exists(),target
manifest=[]
for p in sorted(BASE.iterdir()):
 if p.is_file() and p.name not in {'delivery-manifest.json','novel-forge-instruction-audit-20261003.zip'}:manifest.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(BASE/'delivery-manifest.json').write_text(json.dumps({'main_sha':expected,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(BASE/'novel-forge-instruction-audit-20261003.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(BASE.iterdir()):
  if p.is_file() and p.suffix in {'.md','.json','.txt','.py'}:z.write(p,arcname=p.name)
print(json.dumps({'snapshot_clean':True,'original_tracked_tree_clean':not original_tracked_diff,'original_branch_preserved':integrity['original_branch'],'all_full_originals_embedded':True,'local_report_links_exist':True,'json_files_validated':len(json_files),'source_exports':len(sources),'archive_bytes':(BASE/'novel-forge-instruction-audit-20261003.zip').stat().st_size},ensure_ascii=False))
