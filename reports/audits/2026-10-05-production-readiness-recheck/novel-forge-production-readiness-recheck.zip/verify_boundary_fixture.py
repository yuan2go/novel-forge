import json,os,socket,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/yuan/.codex/worktrees/work-intent-residual-fixes/novel-forge')
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
sys.dont_write_bytecode=True
for k in tuple(os.environ):
 if any(w in k.upper() for w in ('API_KEY','DATABASE_URL','TOKEN','SECRET','DSN')):os.environ.pop(k,None)
def deny(*a,**k):raise RuntimeError('READINESS_EXTERNAL_IO_FORBIDDEN')
socket.socket.connect=deny;socket.create_connection=deny;socket.socket.connect_ex=deny;subprocess.Popen=deny
import psycopg
psycopg.connect=deny
import pytest
import tests.unit.test_task_context_admission as tests
from novel_forge.modules.chapter_authority import orchestrator
BOUNDARY={'accepted_through_chapter':8,'canon_snapshot_asset_version_id':'canon:v8','story_state_asset_version_id':'state:v8'}
intent, memo, request=tests._intent,tests._memo,orchestrator.SingleChapterRequest
with pytest.MonkeyPatch.context() as patch:
 patch.setattr(tests,'_intent',lambda:{**intent(),'accepted_boundary':dict(BOUNDARY)})
 patch.setattr(tests,'_memo',lambda:{**memo(),'accepted_boundary':dict(BOUNDARY)})
 def full_request(**values):
  values['context_candidates']=tuple({**c,'accepted_boundary':dict(BOUNDARY)} for c in values['context_candidates'])
  return request(**values)
 patch.setattr(orchestrator,'SingleChapterRequest',full_request)
 tests.test_task_dependency_admission_is_wired_only_for_the_frozen_v4_profile(patch)
result={'evidence_type':'OFFLINE','status':'PASS_WITH_COMPLETE_FIXTURE','original_repository_test_status':'FAIL_INCOMPLETE_ACCEPTED_BOUNDARY','scope':'Only external fixture adaptation adds required Canon and Narrative State IDs to both candidate/intent boundaries. All original test assertions retained. No source or repository test changed.','replacement_boundary':BOUNDARY,'real_provider_calls':0,'production_database_connections':0}
(OUT/'evidence/boundary-fixture.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
