import os, sys, socket, json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/yuan/.codex/worktrees/work-intent-residual-fixes/novel-forge')
from snapshot_identity import identity
SNAPSHOT, _ = identity(ROOT)
RUN = os.environ.get('REPAIR_RUN_LABEL', 'final')
os.chdir(ROOT)
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
sys.dont_write_bytecode=True
for key in tuple(os.environ):
    if any(word in key.upper() for word in ('API_KEY','DATABASE_URL','TOKEN','SECRET','DSN')):
        os.environ.pop(key,None)
blocked=[]
def deny(*a,**kw):
    blocked.append('external_io_blocked')
    raise RuntimeError('REPAIR_EXTERNAL_IO_FORBIDDEN')
socket.create_connection=deny
socket.socket.connect=deny
socket.socket.connect_ex=deny
import psycopg
psycopg.connect=deny
import subprocess
original_popen=subprocess.Popen
def guarded_popen(args,*a,**kw):
    if isinstance(args,(list,tuple)) and str(args[0])==sys.executable and len(args)>2 and args[1]=='-c' and 'synthetic process receipt' in str(args[2]):
        return original_popen(args,*a,**kw)
    raise RuntimeError('REPAIR_PROCESS_FORBIDDEN: '+str(args)[:160])
subprocess.Popen=guarded_popen
import pytest
paths=['tests/unit/test_work_intent_residuals.py','tests/unit/test_work_intent_consistency.py','tests/unit/test_work_foundation_contract.py','tests/unit/test_work_realization_contract.py','tests/unit/test_chapter_legacy_contract_recovery.py','tests/unit/test_cross_chapter_prose_review.py','tests/unit/test_longform_prose_editorial.py','tests/unit/test_book_design_authority_domain.py']
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(OUT/('pytest-temp-'+RUN)),'--junitxml',str(OUT/('focused-'+RUN+'.xml')),*(sys.argv[1:] or paths)])
(OUT/('focused-'+RUN+'-meta.json')).write_text(json.dumps({'snapshot_identity':SNAPSHOT,'evidence_type':'OFFLINE','base_sha':'f34eee742e93598db887afddf0f121f4e99e1fd7','snapshot':'uncommitted managed worktree','exit_code':code,'tests':sys.argv[1:] or paths,'real_provider_calls':0,'production_database_connections':0,'blocked_attempts':blocked},indent=2))
sys.exit(code)
