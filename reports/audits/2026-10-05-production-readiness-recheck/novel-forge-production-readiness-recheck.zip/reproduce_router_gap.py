import hashlib,json,os,socket,subprocess,sys
from dataclasses import replace
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/yuan/.codex/worktrees/work-intent-residual-fixes/novel-forge')
from snapshot_identity import identity
SNAPSHOT,_=identity(ROOT)
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
for key in tuple(os.environ):
 if any(word in key.upper() for word in ('API_KEY','DATABASE_URL','TOKEN','SECRET','DSN')):os.environ.pop(key,None)
def deny(*a,**k):raise RuntimeError('READINESS_EXTERNAL_IO_FORBIDDEN')
socket.socket.connect=deny;socket.create_connection=deny;socket.socket.connect_ex=deny;subprocess.Popen=deny
import psycopg
psycopg.connect=deny
from novel_forge.modules.provider_control.composition import configured_router_provider_ids
from novel_forge.modules.production_execution.cost_routing import CostAwareRouter,task_policy,TASK_TAXONOMY
from tests.unit.test_cost_aware_routing import task,candidate,samples,NOW
records=[]
for stage in ['draft','context_compress','context_fidelity']:
 current=task(task_type=stage)
 try:
  result=CostAwareRouter().explain(current,[candidate()],{'flash':samples()},now=NOW).to_dict()
  records.append({'stage':stage,'registered':stage in TASK_TAXONOMY,'status':result['status'],'error':None})
 except ValueError as e:
  records.append({'stage':stage,'registered':stage in TASK_TAXONOMY,'status':'REPRODUCED_FAILURE','error':str(e)})
from tests.unit.test_task_scoped_context import candidate as context_candidate, TASK
from novel_forge.modules.context_builder.story_projection import STORY_PROJECTION_VERSION
from novel_forge.modules.context_builder.task_compression import compile_task_context
branch_records=[]
for fail_stage in ('context_compress','context_fidelity'):
 source=replace(context_candidate(text=json.dumps({'summary':'You owe me one joke.'+chr(10)+chr(10)+'Banquet. '*500,'candidate_comparison':{'instruction':'OLD-REVIEW'},'unknown_metadata':'unneeded'})),provenance={'writer_projection_version':STORY_PROJECTION_VERSION})
 stages=[]
 def callback(stage,payload):
  stages.append(stage)
  if stage==fail_stage:
   return CostAwareRouter().explain(task(task_type=stage),[candidate()],{'flash':samples()},now=NOW).to_dict()
  return {'selected_unit_ids':['json:summary:0']}
 try:
  compile_task_context([source],task={**TASK,'writer_projection_version':STORY_PROJECTION_VERSION},token_budget=160,required_asset_types=(),model_call=callback,compression_input_tokens=8192)
  raise AssertionError('missing router failure')
 except ValueError as e:
  assert str(e)=='ROUTING_TASK_POLICY_REQUIRED:'+fail_stage
  branch_records.append({'pipeline':'actual compile_task_context with Router callback','failing_stage':fail_stage,'observed_stages':stages,'error':str(e),'compression_output_before_fidelity':'synthetic selected_unit_ids' if fail_stage=='context_fidelity' else None})
assert records[0]['error'] is None
assert [r['error'] for r in records[1:]]==['ROUTING_TASK_POLICY_REQUIRED:context_compress','ROUTING_TASK_POLICY_REQUIRED:context_fidelity']
data={'evidence_type':'OFFLINE','snapshot_identity':SNAPSHOT,'production_default_router_providers':sorted(configured_router_provider_ids('production',{})),'test_default_router_providers':sorted(configured_router_provider_ids('test',{})),'results':records,'overflow_branch_results':branch_records,'real_provider_calls':0,'production_database_connections':0,'scope':'Actual CostAwareRouter; synthetic task/candidate/benchmarks. Production Gateway call reachability separately STATIC; no database or dispatch in this reproduction.'}
(OUT/'evidence/router-gap.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
print(json.dumps({k:data[k] for k in ('evidence_type','production_default_router_providers','test_default_router_providers','results','real_provider_calls')},ensure_ascii=False))
