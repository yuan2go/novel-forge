import hashlib, json, subprocess
from pathlib import Path
def identity(root):
    root = Path(root)
    base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    tracked = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
    files = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sorted(set(tracked + untracked))}
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=root)
    for name in untracked:
        result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, stdout=subprocess.PIPE)
        assert result.returncode == 1
        patch += result.stdout
    return {
        'base_sha': base, 'diff_sha256': hashlib.sha256(patch).hexdigest(),
        'file_manifest_sha256': hashlib.sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'files': files,
    }, patch
