from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timedelta, timezone
import hashlib
import os
from time import monotonic
from typing import Any, Callable

from novel_forge.modules.command_kernel.errors import KernelError
from novel_forge.modules.runtime_job import RuntimeJobAuthority, RuntimeJobSpec
from novel_forge.storage.authority_asset_store import AuthorityAssetQuery
from novel_forge.storage.authority_uow import AuthorityUnitOfWork

from .production import StartBookProductionCommand


def resolved_book_command(snapshot: Any, *, actor: str, run_key: str, chapters: int) -> StartBookProductionCommand:
    return StartBookProductionCommand(
        project_id=snapshot.project_id, workspace_id=snapshot.workspace_id, book_id=snapshot.book_id,
        actor_id=actor, trace_id=f"trace:{run_key}", correlation_id=run_key, stable_idempotency_key=run_key,
        book_design_version=snapshot.book_design_version, book_plan_version=snapshot.book_plan_version,
        production_profile_version=snapshot.production_profile_version,
        longform_context_versions={"volume_plan_version": snapshot.current_volume_plan_version,
            "arc_plan_versions": list(snapshot.current_relevant_arc_plan_versions),
            **{key: getattr(snapshot, key) for key in (
                "character_state_version", "foreshadowing_state_version", "quality_trend_version",
                "reward_ledger_version", "promise_ledger_version", "reader_segment_version",
                "reader_contract_version", "platform_profile_version")}},
        target_chapter_count=chapters, input_mode="RESOLVED_AUTHORITY_INPUT", input_snapshot_id=snapshot.snapshot_id,
    )


def drive_book(*, composition: Any, chapter: Any, book_run_id: str, worker: Any,
               maximum_ticks: int, deadline: float, continuation_live: Callable[[], bool] = lambda: True, execution_probe: Callable[[], object] = lambda: None, events: Callable[[dict[str, Any]], None] = lambda _: None) -> str:
    from novel_forge.workers.book_authority import schedule_book_coordination_jobs, execute_book_coordination_claim

    jobs = RuntimeJobAuthority(composition.authority.database_url)
    for _ in range(maximum_ticks):
        execution_probe()
        if not continuation_live():
            composition.authority.cancel(book_run_id, reason="Original creation cancellation", principal=composition.principal)
            return "CANCELLED"
        book = composition.authority.require(book_run_id)
        worker.require("book.authority.execute", book["project_id"])
        if book["state"] == "COMPLETED":
            return "COMPLETED"
        if book["state"] in {"ABORTED", "CANCELLED"}:
            return "BOOK_PRODUCTION_TERMINAL_FAILURE" if book.get("failure_classification") == "CHAPTER_TERMINAL_FAILURE" else "CANCELLED"
        if composition.query.unresolved_chapter_effects(book_run_id=book_run_id):
            return "WAIT_EXTERNAL_RECONCILIATION"
        if monotonic() >= deadline:
            return "YIELDED_CHECKPOINT"
        from novel_forge.modules.chapter_authority.receipt_recovery import recover_known_draft_receipt
        from novel_forge.modules.chapter_authority.canon_contract_recovery import recover_canon_contract, recover_completed_canon_window
        recover_completed_canon_window(composition.authority, book_run_id=book_run_id, principal=composition.principal)
        recover_canon_contract(composition.authority, book_run_id=book_run_id, principal=composition.principal)
        recover_known_draft_receipt(composition.authority, book_run_id=book_run_id, principal=composition.principal)
        from novel_forge.modules.chapter_authority.contract_recovery import recover_realization_frontier
        recover_realization_frontier(composition.authority, book_run_id=book_run_id,
                                     principal=composition.principal)
        from novel_forge.modules.chapter_authority.publication_recovery import recover_publication_contract
        recover_publication_contract(composition.authority, book_run_id=book_run_id, principal=composition.principal)
        from .execution_recovery import recover_timeout
        if recover_timeout(composition.authority, book_run_id=book_run_id,
                           principal=composition.principal):
            events({"kind": "CHAPTER_EXECUTION_SUCCESSOR", "book_run_id": book_run_id})
        schedule_book_coordination_jobs(composition.query, jobs, limit=1, book_run_id=book_run_id)
        claim = jobs.claim(runtime_group="book", worker_id=worker.principal_id, lease_seconds=30,
            job_kinds=("BOOK_COORDINATION_TICK",), subject_kind="BOOK_RUN", subject_id=book_run_id)
        if claim is None:
            return "WAITING_LEASE_OR_DEPENDENCY"
        tick = execute_book_coordination_claim(jobs, composition, claim)
        events({"kind": "BOOK_TICK", "result": tick})
        progress = composition.query.progress(book_run_id=book_run_id)
        active = str(tick.get("operation_id") or "") if tick["action"] == "DISPATCH_CHAPTER" else progress.active_operation_id
        if active and progress.active_operation_status not in {"SUCCEEDED", "FAILED_TERMINAL", "CANCELLED"}:
            scheduler = chapter.scheduler(principal=worker)
            for _ in range(80):
                execution_probe()
                if not continuation_live():
                    composition.authority.cancel(book_run_id, reason="Original creation cancellation", principal=composition.principal)
                    return "CANCELLED"
                if monotonic() >= deadline:
                    return "YIELDED_CHECKPOINT"
                try:
                    result = scheduler.tick(project_id=book["project_id"], root_operation_id=active)
                except KernelError as error:
                    events({"kind": "CHAPTER_CHECKPOINT", "operation_id": active, "reason_code": error.code})
                    if scheduler.has_ready_quality_work(project_id=book["project_id"], root_operation_id=active):
                        continue
                    return error.code
                events({"kind": "CHAPTER_TICK", "result": asdict(result)})
                if result.saga_status == "SUCCEEDED":
                    break
                if result.operation_status in {"WAITING_RETRY", "UNKNOWN", "FAILED_FINAL", "FAILED_TERMINAL"}:
                    if scheduler.has_ready_quality_work(project_id=book["project_id"], root_operation_id=active):
                        continue
                    return "WAITING_CHAPTER_DEPENDENCY"
        elif tick["action"].startswith(("BLOCK", "WAIT", "APPROVAL", "REQUEST_REPLAN")):
            return str(tick["action"])
    return "YIELDED_CHECKPOINT"


def continue_creation(*, composition: Any, content: Any, chapter: Any, formation_run_id: str,
                      formation_worker: Any, book_worker: Any, maximum_ticks: int,
                      deadline: float, creation_policy: dict[str, Any] | None = None, execution_probe: Callable[[], object] = lambda: None) -> dict[str, Any]:
    from novel_forge.workers.book_authority import execute_story_formation_claim, execute_book_opening_claim
    from .creation_inputs import prepare_creation_inputs
    from .opening import OpenBookProductionRequest, _OPENING_INPUT_ROLES

    formation = composition.formation
    if formation is None or composition.opening is None:
        raise KernelError("CREATION_RUNTIME_REQUIRED", "Native Formation and Opening must be configured")
    execution_probe()
    run = formation.require(formation_run_id)
    project, book = run["project_id"], run["book_id"]
    composition.principal.require("book.authority.execute", project)
    if reconcile_creation_cancellation(composition, formation_run_id):
        return {"formation_run_id": formation_run_id, "stop_reason": "CANCELLED"}
    frozen = formation.frozen_input(formation_run_id)
    policy = dict(frozen.generation_policy or {})
    profiles = policy.get("creation_input_policy") or creation_policy
    if profiles is None:
        raise KernelError("CREATION_PROFILES_REQUIRED", "Historical Formation requires its original creation policy")
    if run["lifecycle"] == "FAILED":
        reason = _formation_resume_blocker(composition, run, policy)
        if reason:
            return {"formation_run_id": formation_run_id, "stop_reason": reason, "checkpoint": run}
        formation.resume(formation_run_id, expected_version=run["version"], principal=composition.principal)
    if (run["lifecycle"] == "WAITING_APPROVAL"
            and policy.get("contract_version") in {"formation-generation.v5", "formation-generation.v6"}
            and run.get("recovery_instruction", {}).get("author_selection", {}).get("decision") == "APPROVE"):
        formation.resume(formation_run_id, expected_version=run["version"], principal=composition.principal)
    jobs = RuntimeJobAuthority(composition.authority.database_url)
    for _ in range(maximum_ticks):
        execution_probe()
        if reconcile_creation_cancellation(composition, formation_run_id):
            return {"formation_run_id": formation_run_id, "stop_reason": "CANCELLED"}
        run = formation.require(formation_run_id)
        if run["lifecycle"] == "READY":
            break
        if run["lifecycle"] not in {"ADMITTED", "RUNNING"}:
            return {"formation_run_id": formation_run_id, "stop_reason": run["lifecycle"], "checkpoint": run}
        if monotonic() >= deadline:
            return {"formation_run_id": formation_run_id, "stop_reason": "YIELDED_CHECKPOINT"}
        formation.schedule_candidates(limit=1, project_id=project, formation_run_id=formation_run_id)
        claim = jobs.claim(runtime_group="story_formation", worker_id=formation_worker.principal_id,
            lease_seconds=60, job_kinds=("STORY_FORMATION_ADVANCE",),
            subject_kind="STORY_FORMATION_RUN", subject_id=formation_run_id)
        if claim is None:
            return {"formation_run_id": formation_run_id, "stop_reason": "WAITING_LEASE_OR_DEPENDENCY"}
        try:
            execute_story_formation_claim(jobs, formation, formation_worker, claim, lease_seconds=60)
        except Exception as error:
            checkpoint = formation.require(formation_run_id)
            if checkpoint["lifecycle"] != "FAILED":
                raise
            blocked = _formation_resume_blocker(composition, checkpoint, policy)
            return {"formation_run_id": formation_run_id, "stop_reason": blocked or "FORMATION_FAILED",
                    "reason_code": str(getattr(error, "code", type(error).__name__)), "checkpoint": checkpoint}
    if formation.require(formation_run_id)["lifecycle"] != "READY":
        return {"formation_run_id": formation_run_id, "stop_reason": "YIELDED_CHECKPOINT"}
    run_key, opening_key = formation_run_id + ":production", formation_run_id + ":opening"
    with AuthorityUnitOfWork(composition.authority.database_url) as uow:
        uow.cursor.execute("SELECT book_run_id FROM authority_book_production WHERE project_id=%s AND stable_idempotency_key=%s", [project, run_key])
        existing = uow.cursor.fetchone()
        uow.cursor.execute("SELECT opening_run_id FROM authority_book_opening_run WHERE project_id=%s AND stable_idempotency_key=%s", [project, opening_key])
        opening = uow.cursor.fetchone()
    if existing is None:
        execution_probe()
        if opening is None:
            prepared = prepare_creation_inputs(composition=composition, content=content,
                formation_run_id=formation_run_id, policy=profiles)
            versions = prepared["versions"]
            portfolio = AuthorityAssetQuery(content.database_url).require(project_id=project,
                asset_version_id=versions["character_arc_portfolio"])
            arc_keys = tuple(dict.fromkeys(("book:" + book,
                *("character:" + row["character_id"] for row in portfolio.content["trajectories"]))))
            admitted = composition.open_book(OpenBookProductionRequest(project_id=project,
                workspace_id=run["workspace_id"], book_id=book, actor_id=composition.principal.principal_id,
                expected_book_version=prepared["book_version"], production_profile=versions["production_profile"],
                planning_input_versions={role: versions[role] for role in _OPENING_INPUT_ROLES},
                arc_logical_keys=arc_keys, idempotency_key=opening_key, trace_id="trace:" + opening_key,
                correlation_id=formation_run_id, initial_story_state_version=versions["story_state"],
                initial_canon_snapshot_version=versions["canon_snapshot"]))
            opening = (admitted.opening_run_id,)
        opened = composition.opening.require(opening[0])
        if opened["lifecycle"] == "ABORTED":
            return {"formation_run_id": formation_run_id, "opening_run_id": opening[0], "stop_reason": "CANCELLED"}
        with AuthorityUnitOfWork(composition.authority.database_url) as uow:
            uow.cursor.execute("SELECT policy_snapshot FROM authority_provider_budget_scope WHERE budget_scope_id=%s", [opened["budget_scope_id"]])
            scope_policy = uow.cursor.fetchone()
        if (opened["lifecycle"] != "COMPLETE" and scope_policy
                and scope_policy[0].get("resource_control_version") != "billing-channel-resources.v1"
                and composition.opening.provider_budget_policy.get("resource_control_version") == "billing-channel-resources.v1"):
            from .resource_succession import adopt_resource_policy
            try:
                adopt_resource_policy(composition.opening, opening_run_id=opening[0], principal=composition.principal,
                    expected_version=opened["version"], idempotency_key=opening[0] + ":resource-successor")
            except KernelError as error:
                return {"opening_run_id": opening[0], "stop_reason": error.code, "reason": error.message, "checkpoint": opened}
        if opened["lifecycle"] == "FAILED":
            try:
                assessment = composition.opening.recovery.assess_recovery(opening[0],
                    idempotency_key=opening[0] + ":creation-recovery:" + str(opened["version"]), principal=composition.principal)
                composition.opening.recovery.recover(assessment.recovery_assessment_id,
                    idempotency_key=opening[0] + ":creation-recover:" + str(opened["version"]),
                    reason="continue exact native creation checkpoint", principal=composition.principal)
            except KernelError as error:
                return {"opening_run_id": opening[0], "stop_reason": error.code, "reason": error.message, "checkpoint": opened}
        for _ in range(maximum_ticks):
            execution_probe()
            if reconcile_creation_cancellation(composition, formation_run_id):
                return {"formation_run_id": formation_run_id, "stop_reason": "CANCELLED"}
            opened = composition.opening.require(opening[0])
            if opened["lifecycle"] == "COMPLETE":
                break
            if monotonic() >= deadline:
                return {"formation_run_id": formation_run_id, "opening_run_id": opening[0], "stop_reason": "YIELDED_CHECKPOINT"}
            claim = composition.opening.claim_next_execution(worker_id=book_worker.principal_id,
                lease_seconds=60, project_id=project, expected_opening_run_id=opening[0])
            if claim is None or claim.subject_id != opening[0]:
                return {"opening_run_id": opening[0], "stop_reason": "WAITING_OPENING_DEPENDENCY"}
            try:
                execute_book_opening_claim(jobs, composition.opening, composition.principal, claim, lease_seconds=60)
            except KernelError as error:
                return {"opening_run_id": opening[0], "stop_reason": error.code, "reason": error.message,
                        "checkpoint": composition.opening.require(opening[0])}
        opened = composition.opening.require(opening[0])
        if opened["lifecycle"] != "COMPLETE":
            return {"opening_run_id": opening[0], "stop_reason": opened["lifecycle"], "checkpoint": opened}
        execution_probe()
        snapshot = composition.input_resolver.require(opened["result"]["input_snapshot_id"])
        design = AuthorityAssetQuery(content.database_url).require(project_id=project, asset_version_id=snapshot.book_design_version)
        started = composition.authority.start(resolved_book_command(snapshot,
            actor=composition.principal.principal_id, run_key=run_key, chapters=int(design.content["target_chapters"])), principal=composition.principal)
        existing = (started.book_run_id,)
    stop = drive_book(composition=composition, chapter=chapter, book_run_id=existing[0], worker=book_worker,
        maximum_ticks=maximum_ticks, deadline=deadline,
        continuation_live=lambda: not creation_cancellation(composition.authority.database_url, formation_run_id), execution_probe=execution_probe)
    return {"formation_run_id": formation_run_id, "book_run_id": existing[0], "stop_reason": stop,
            "checkpoint": composition.authority.require(existing[0])}


def creation_cancellation(database_url: str, formation_run_id: str) -> dict[str, str] | None:
    from novel_forge.storage.story_formation_repositories import StoryFormationRepository
    with AuthorityUnitOfWork(database_url) as uow:
        return StoryFormationRepository(uow.cursor).cancellation(formation_run_id)


def reconcile_creation_cancellation(composition: Any, formation_run_id: str) -> bool:
    intent = creation_cancellation(composition.authority.database_url, formation_run_id)
    if not intent:
        return False
    run = composition.formation.require(formation_run_id)
    with AuthorityUnitOfWork(composition.authority.database_url) as uow:
        uow.cursor.execute("SELECT book_run_id FROM authority_book_production WHERE project_id=%s AND stable_idempotency_key=%s", [run["project_id"], formation_run_id + ":production"])
        book = uow.cursor.fetchone()
        uow.cursor.execute("SELECT opening_run_id,lifecycle,version FROM authority_book_opening_run WHERE project_id=%s AND stable_idempotency_key=%s", [run["project_id"], formation_run_id + ":opening"])
        opening = uow.cursor.fetchone()
    if book:
        composition.authority.cancel(book[0], reason=intent["reason"], principal=composition.principal)
    elif opening and opening[1] not in {"COMPLETE", "ABORTED"}:
        composition.opening.abort(opening[0], expected_version=opening[2], principal=composition.principal)
    elif run["lifecycle"] not in {"READY", "ABORTED"}:
        composition.formation.abort(formation_run_id, expected_version=run["version"], principal=composition.principal)
    return True


def _formation_resume_blocker(composition: Any, run: dict[str, Any], policy: dict[str, Any]) -> str:
    from novel_forge.modules.production_execution.execution_template import selected_book_template

    authorization = policy.get("auto_authorization") or {}
    if (policy.get("approval_mode") != "AUTO"
            or any(authorization.get(key) != value for key, value in {
                "formation_run_id": run["formation_run_id"], "project_id": run["project_id"],
                "book_id": run["book_id"], "authorized_by_principal_id": composition.principal.principal_id}.items())
            or run.get("recovery_instruction", {}).get("action") != "RESUME_WITH_SAME_FROZEN_INPUTS"):
        return "FORMATION_OWNER_RECOVERY_REQUIRED"
    failure_code = str(run.get("failure", {}).get("code") or "")
    if not failure_code.startswith("MODEL_EFFECT_RETRYABLE_") and failure_code not in {
        "RuntimeError", "EFFECT_REQUEST_TIMEOUT_BEFORE_SEND", "EFFECT_REQUEST_FAILED_RETRYABLE",
        "EFFECT_BUDGET_EXECUTION_ASSERTION_FAILED", "RESOURCE_ROUTE_RESELECT_REQUIRED"}:
        return "FORMATION_OWNER_RECOVERY_REQUIRED"
    with AuthorityUnitOfWork(composition.authority.database_url) as uow:
        if selected_book_template(uow.cursor, project_id=run["project_id"], book_id=run["book_id"]) is None:
            return "FORMATION_OWNER_RECOVERY_REQUIRED"
        uow.cursor.execute("""SELECT count(DISTINCT job.input_snapshot->>'observed_version') FROM authority_runtime_job_attempt attempt
            JOIN authority_runtime_job job USING(runtime_job_id)
            WHERE job.subject_kind='STORY_FORMATION_RUN' AND job.subject_id=%s
              AND job.project_id=%s AND job.input_snapshot->>'observed_stage'=%s
              AND attempt.status IN ('FAILED','ABANDONED')
              AND (attempt.error->>'code' LIKE 'MODEL_EFFECT_RETRYABLE_%%' OR attempt.error->>'code' IN
                ('RuntimeError','EFFECT_REQUEST_TIMEOUT_BEFORE_SEND','EFFECT_REQUEST_FAILED_RETRYABLE','EFFECT_BUDGET_EXECUTION_ASSERTION_FAILED','RESOURCE_ROUTE_RESELECT_REQUIRED'))""",
            [run["formation_run_id"], run["project_id"], run["current_stage"]])
        if int(uow.cursor.fetchone()[0]) >= 3:
            return "FORMATION_NO_PROGRESS_LIMIT"
        uow.cursor.execute("""SELECT EXISTS(SELECT 1 FROM authority_external_effect
            WHERE project_id=%s AND request_payload #>> '{_production_execution,book_id}'=%s
              AND status IN ('DISPATCHING','UNKNOWN','RECONCILIATION_REQUIRED','FAILED_FINAL'))
            OR EXISTS(SELECT 1 FROM authority_runtime_job_lease lease
                JOIN authority_runtime_job job USING(runtime_job_id)
                WHERE job.subject_kind='STORY_FORMATION_RUN' AND job.subject_id=%s
                  AND lease.status='HELD' AND lease.lease_expires_at>NOW())""",
            [run["project_id"], run["book_id"], run["formation_run_id"]])
        if uow.cursor.fetchone()[0]:
            return "FORMATION_RECONCILIATION_OR_LEASE_REQUIRED"
    return ""



def ensure_creation_reader_pack(settings: Any, *, formation_run_id: str, principal: Any,
                                repository_root: Any, values: dict[str, str],
                                application_build_id: str, commit_sha: str) -> None:
    from novel_forge.modules.capability_packs.validation_deployment import (
        install_longform_validation_pack, register_validation_runtime_definitions,
    )
    from novel_forge.modules.capability_packs.longform_profiles import build_reader_outcome_pack_profile

    pack_id = values["NOVEL_FORGE_READER_OUTCOME_CAPABILITY_PACK_ID"]
    with AuthorityUnitOfWork(settings.database_url) as uow:
        uow.cursor.execute("SELECT project_id,workspace_id,book_id FROM authority_story_formation_run WHERE formation_run_id=%s", [formation_run_id])
        scope = uow.cursor.fetchone()
        if scope is None:
            raise KernelError("CREATION_CHECKPOINT_NOT_FOUND", formation_run_id)
        uow.cursor.execute("SELECT activation.activation_version,deployment.pack_version FROM authority_capability_pack_activation activation JOIN authority_capability_pack_deployment deployment ON deployment.deployment_id=activation.active_deployment_id WHERE activation.project_id=%s AND activation.workspace_id=%s AND activation.book_id=%s AND activation.pack_id=%s AND activation.environment=%s AND activation.workflow_definition_ref='book_followup_reader_outcome@1.3.0'", [*scope, pack_id, settings.environment])
        active = uow.cursor.fetchone()
        if active and str(active[1]) == "1.5.0":
            return
        if active and str(active[1]) not in {"1.3.0", "1.4.0"}:
            raise KernelError("CREATION_READER_PACK_CONTRACT_DRIFT", "Reader Pack needs an explicitly compatible deployment")
        activation_version = int(active[0]) if active else 0
        uow.cursor.execute("SELECT COALESCE(MAX(activation_version),0) FROM authority_capability_pack_activation WHERE project_id=%s AND workspace_id=%s AND book_id=%s AND pack_id=%s AND environment=%s", [*scope, pack_id, settings.environment])
        agent_generation = max(activation_version, int(uow.cursor.fetchone()[0])) + 1
    principal.require("book.authority.execute", str(scope[0]))
    hashes = register_validation_runtime_definitions(settings.database_url,
        application_build_id=application_build_id, commit_sha=commit_sha)
    profile = build_reader_outcome_pack_profile(repository_root,
        operation_definition_hash=hashes["reader_proxy"], pack_id=pack_id)
    install_longform_validation_pack(settings.database_url, profile=profile,
        pack_version=str(profile.manifest["identity"]["version"]), agent_generation=agent_generation,
        expected_activation_version=activation_version, project_id=str(scope[0]), workspace_id=str(scope[1]),
        book_id=str(scope[2]), application_build_id=application_build_id, commit_sha=commit_sha,
        compiler=principal, approver=principal, agent_admin=principal,
        agent_domain="book_followup", agent_scope_type="BOOK", runtime_environment=settings.environment)


def creation_runtime_environment(project_id: str, values: dict[str, str] | None = None) -> dict[str, str]:
    result = dict(os.environ if values is None else values)
    scope = hashlib.sha256(project_id.encode()).hexdigest()[:24]
    result.setdefault("NOVEL_FORGE_CHAPTER_CAPABILITY_PACK_ID", "chapter_generation_pack.creative." + scope)
    result.setdefault("NOVEL_FORGE_PLANNING_CAPABILITY_PACK_ID", "story_planning_pack.creative." + scope)
    result.setdefault("NOVEL_FORGE_READER_OUTCOME_CAPABILITY_PACK_ID", "reader_outcome_pack.creative." + scope)
    return result


_CREATION_PROGRESS_COLUMNS = """run.current_stage,run.lifecycle,run.version,
            (SELECT count(*) FROM authority_external_effect effect WHERE effect.project_id=run.project_id
                AND effect.request_payload #>> '{_production_execution,book_id}'=run.book_id AND effect.status='SUCCEEDED'),
            (SELECT count(*) FROM authority_book_opening_node_receipt receipt
                JOIN authority_book_opening_run opening USING(opening_run_id)
                WHERE opening.project_id=run.project_id AND opening.stable_idempotency_key=run.formation_run_id || ':opening'),
            (SELECT COALESCE(jsonb_build_array(production.state,production.accepted_through_chapter,production.version),'[]'::jsonb)
                FROM authority_book_production production WHERE production.project_id=run.project_id
                  AND production.stable_idempotency_key=run.formation_run_id || ':production'),
            jsonb_build_object('cancel_requested',EXISTS(SELECT 1 FROM authority_story_creation_cancellation cancellation WHERE cancellation.formation_run_id=run.formation_run_id),
                'opening',(SELECT jsonb_build_array(opening.lifecycle,opening.version) FROM authority_book_opening_run opening
                    WHERE opening.project_id=run.project_id AND opening.stable_idempotency_key=run.formation_run_id || ':opening'),
                'chapter',(SELECT jsonb_build_array(operation.status,operation.version) FROM authority_book_production production
                    JOIN authority_book_chapter_request request ON request.chapter_request_id=production.active_chapter_request_id
                    JOIN authority_operation operation ON operation.operation_id=request.chapter_root_operation_id
                    WHERE production.project_id=run.project_id AND production.stable_idempotency_key=run.formation_run_id || ':production'))
"""


def creation_progress(database_url: str, *, project_id: str, formation_run_id: str) -> tuple[Any, ...]:
    with AuthorityUnitOfWork(database_url) as uow:
        uow.cursor.execute(f"SELECT {_CREATION_PROGRESS_COLUMNS} FROM authority_story_formation_run run WHERE run.formation_run_id=%s AND run.project_id=%s",
            [formation_run_id, project_id])
        row = uow.cursor.fetchone()
    if row is None:
        raise KernelError("CREATION_CHECKPOINT_NOT_FOUND", formation_run_id)
    return tuple(row)


def creation_wait_class(reason: str) -> str:
    if reason == "COMPLETED":
        return "COMPLETED"
    if reason in {"CANCELLED", "ABORTED"}:
        return "CANCELLED"
    if reason == "BOOK_PRODUCTION_TERMINAL_FAILURE":
        return "FINAL_FAILURE"
    if reason in {"TASK_CONTEXT_MODEL_OUTPUT_CAPACITY_UNKNOWN", "TASK_CONTEXT_MODEL_CAPACITY_UNKNOWN"}:
        return "OWNER_RECOVERY_REQUIRED"
    if "RECONCILIATION" in reason or "UNKNOWN" in reason:
        return "RECONCILIATION_REQUIRED"
    if reason in {"YIELDED_CHECKPOINT", "WAITING_LEASE_OR_DEPENDENCY", "WAITING_OPENING_DEPENDENCY",
                  "WAITING_CHAPTER_DEPENDENCY", "FORMATION_FAILED"}:
        return "TECHNICAL_WAIT"
    if reason in {"WAITING_APPROVAL", "WAIT_PLAN_APPROVAL", "WAIT_REPLAN_APPROVAL", "WAIT_CONTROL_DECISION"}:
        return "AUTHOR_DECISION"
    return "OWNER_RECOVERY_REQUIRED"


def creation_recovery_record(database_url: str, formation_run_id: str, reason: str, key: str) -> dict[str, Any] | None:
    dedupe = f"{formation_run_id}:creation:recover:{key or hashlib.sha256(reason.encode()).hexdigest()}"
    with AuthorityUnitOfWork(database_url) as uow:
        uow.cursor.execute("SELECT runtime_job_id,status,input_snapshot FROM authority_runtime_job WHERE dedupe_key=%s AND job_kind='BOOK_CREATION_ADVANCE' AND subject_id=%s", [dedupe,formation_run_id])
        row = uow.cursor.fetchone()
    if not row:
        return None
    if row[2].get("owner_recovery_reason") != reason:
        raise KernelError("CREATION_RECOVERY_REQUEST_DRIFT", "Recovery key already binds a different reason")
    return {"runtime_job_id":row[0],"status":row[1],"deduplicated":True}


def schedule_creation_jobs(database_url: str, *, limit: int = 10, formation_run_id: str = "", recovery_reason: str = "", recovery_key: str = "") -> tuple[dict[str, Any], ...]:
    if limit <= 0:
        raise ValueError("creation scheduling limit must be positive")
    if recovery_reason and not formation_run_id:
        raise ValueError("Explicit recovery must name the original creation")
    jobs = RuntimeJobAuthority(database_url)
    with AuthorityUnitOfWork(database_url) as uow:
        recovery_dedupe = f"{formation_run_id}:creation:recover:{recovery_key or hashlib.sha256(recovery_reason.encode()).hexdigest()}" if recovery_reason else ""
        if recovery_dedupe:
            uow.cursor.execute("SELECT runtime_job_id,status,input_snapshot FROM authority_runtime_job WHERE dedupe_key=%s AND job_kind='BOOK_CREATION_ADVANCE' AND subject_id=%s", [recovery_dedupe,formation_run_id])
            recovered = uow.cursor.fetchone()
            if recovered:
                if recovered[2].get("owner_recovery_reason") != recovery_reason:
                    raise KernelError("CREATION_RECOVERY_REQUEST_DRIFT", "Recovery key already binds a different reason")
                return ({"runtime_job_id":recovered[0],"status":recovered[1],"deduplicated":True},)
        uow.cursor.execute(f"""SELECT run.formation_run_id,run.project_id,run.frozen_input_digest,
                run.frozen_stage_inputs #>> '{{generation_policy,auto_authorization,authorized_by_principal_id}}',
                latest.input_snapshot,latest.result,latest.status
            FROM authority_story_formation_run run
            LEFT JOIN LATERAL (
                SELECT job.input_snapshot,receipt.result,job.status FROM authority_runtime_job job
                LEFT JOIN LATERAL (SELECT result FROM authority_runtime_job_result
                    WHERE runtime_job_id=job.runtime_job_id ORDER BY created_at DESC,result_id DESC LIMIT 1) receipt ON TRUE
                WHERE job.job_kind='BOOK_CREATION_ADVANCE' AND job.subject_id=run.formation_run_id
                  AND job.project_id=run.project_id ORDER BY job.created_at DESC,job.runtime_job_id DESC LIMIT 1
            ) latest ON TRUE
            WHERE run.frozen_stage_inputs #>> '{{generation_policy,contract_version}}' IN ('formation-generation.v5','formation-generation.v6')
              AND run.lifecycle<>'ABORTED' AND (%s='' OR run.formation_run_id=%s)
              AND COALESCE(latest.status,'')<>'CANCELLED'
              AND COALESCE(latest.result->>'wait_class','') NOT IN ('COMPLETED','CANCELLED','FINAL_FAILURE')
              AND (%s OR COALESCE(latest.status,'')<>'DEAD_LETTER' OR latest.input_snapshot->'progress' IS DISTINCT FROM jsonb_build_array({_CREATION_PROGRESS_COLUMNS}))
              AND (%s OR latest.result IS NULL OR latest.result->'progress' IS DISTINCT FROM jsonb_build_array({_CREATION_PROGRESS_COLUMNS}))
              AND NOT EXISTS (SELECT 1 FROM authority_runtime_job job WHERE job.job_kind='BOOK_CREATION_ADVANCE'
                AND job.project_id=run.project_id AND job.subject_id=run.formation_run_id
                AND job.status IN ('READY','RETRY_WAIT','CLAIMED','RUNNING','CHECKPOINTED'))
            ORDER BY run.updated_at,run.formation_run_id LIMIT %s FOR UPDATE OF run SKIP LOCKED""", [formation_run_id, formation_run_id, bool(recovery_reason), bool(recovery_reason), limit])
        candidates = tuple(uow.cursor.fetchall())
        scheduled = []
        for identity, project, digest, actor, previous, result, status in candidates:
            progress = list(creation_progress(database_url, project_id=project, formation_run_id=identity))
            if status == "CANCELLED" or (not recovery_reason and status == "DEAD_LETTER" and progress == (previous or {}).get("progress")):
                continue
            if result and (result.get("wait_class") in {"COMPLETED", "CANCELLED", "FINAL_FAILURE"}
                           or not recovery_reason and result.get("progress") == progress):
                continue
            sequence = int((previous or {}).get("sequence", -1)) + 1
            scheduled.append(jobs.schedule_in_uow(uow, RuntimeJobSpec(job_kind="BOOK_CREATION_ADVANCE", runtime_group="book_creation",
                subject_kind="STORY_FORMATION_RUN", subject_id=identity, project_id=project,
                dedupe_key=recovery_dedupe or f"{identity}:creation:{sequence}", input_snapshot={"contract_version": "creation-coordination.v1",
                    "formation_run_id": identity, "frozen_input_digest": digest, "operator_id": actor,
                    "sequence": sequence, "stagnant_windows": 0, "progress": progress,
                    **({"owner_recovery_reason": recovery_reason} if recovery_reason else {})}, max_attempts=3)))
        uow.commit()
    return tuple(scheduled)


def execute_creation_claim(jobs: RuntimeJobAuthority, claim: Any, *, composition: Any, content: Any,
                           chapter: Any, formation_worker: Any, book_worker: Any,
                           maximum_ticks: int = 20, work_window_seconds: int = 30) -> dict[str, Any]:
    from novel_forge.modules.command_kernel.lease_heartbeat import LeaseHeartbeatGuard

    if (claim.job_kind, claim.runtime_group, claim.subject_kind) != (
            "BOOK_CREATION_ADVANCE", "book_creation", "STORY_FORMATION_RUN"):
        raise ValueError("Creation worker requires its governed Formation envelope")
    jobs.start(claim)
    handed_off = False
    try:
        run = composition.formation.require(claim.subject_id)
        if (run["project_id"] != claim.project_id or run["frozen_input_digest"] != claim.input_snapshot["frozen_input_digest"]
                or composition.principal.principal_id != claim.input_snapshot["operator_id"]):
            raise KernelError("CREATION_EXECUTOR_BINDING_CONFLICT", "Configured operator or frozen Formation changed")
        composition.principal.require("book.authority.execute", claim.project_id)
        with LeaseHeartbeatGuard(lambda: jobs.heartbeat(claim, lease_seconds=60), lease_seconds=60,
                                 label=f"creation:{claim.attempt_id}"):
            try:
                result = continue_creation(composition=composition, content=content, chapter=chapter,
                    formation_run_id=claim.subject_id, formation_worker=formation_worker, book_worker=book_worker,
                    maximum_ticks=maximum_ticks, deadline=monotonic() + work_window_seconds, execution_probe=lambda: jobs.assert_live(claim))
            except KernelError as error:
                if error.code not in {"PLANNING_RESULT_REPAIR_BOUND_EXCEEDED", "PLANNING_REPAIR_BOUND_EXCEEDED"}:
                    raise
                result = {"formation_run_id": claim.subject_id, "stop_reason": error.code,
                    "failure": {"code": error.code, "message": str(error)},
                    "recovery_instruction": "Inspect retained failed proposals and exact diagnostics. A new author decision or approved future input change must resolve the cause; repeating recovery cannot expand the repair allowance."}
        progress = list(creation_progress(jobs.database_url, project_id=claim.project_id, formation_run_id=claim.subject_id))
        stagnant = int(claim.input_snapshot.get("stagnant_windows", 0)) + 1 if progress == claim.input_snapshot.get("progress") else 0
        reason = result["stop_reason"]
        waiting = creation_wait_class(reason)
        if stagnant >= 12 and waiting in {"TECHNICAL_WAIT", "RECONCILIATION_REQUIRED"}:
            waiting = "OWNER_RECOVERY_REQUIRED"
            reason = "CREATION_NO_PROGRESS"
        receipt = {key: value for key, value in result.items() if key != "checkpoint"}
        receipt.update(stop_reason=reason, wait_class=waiting, progress=progress,
                       executor="book-authority-worker", next_action="INSPECT_OWNER_EVIDENCE",
                       checkpoint_ref=claim.subject_id)
        if waiting in {"TECHNICAL_WAIT", "RECONCILIATION_REQUIRED"}:
            delay = min(300, 5 * 2 ** min(stagnant, 6))
            sequence = int(claim.input_snapshot["sequence"]) + 1
            receipt.update(next_action="RECONCILE_SAME_IDENTITIES" if waiting == "RECONCILIATION_REQUIRED" else "RESUME_SAME_FROZEN_INPUTS",
                           retry_after_seconds=delay)
            next_job = RuntimeJobSpec(job_kind=claim.job_kind, runtime_group=claim.runtime_group,
                subject_kind=claim.subject_kind, subject_id=claim.subject_id, project_id=claim.project_id,
                dedupe_key=f"{claim.subject_id}:creation:{sequence}",
                input_snapshot={**claim.input_snapshot, "sequence": sequence, "progress": progress, "stagnant_windows": stagnant},
                available_at=datetime.now(timezone.utc) + timedelta(seconds=delay), max_attempts=3)
            handoff = jobs.complete_and_schedule_continuation(claim, receipt, next_job)
            handed_off = True
            return {**receipt, **handoff}
        jobs.complete(claim, receipt)
        handed_off = True
        return receipt
    except Exception as error:
        if not handed_off and jobs.get(claim.runtime_job_id)["status"] == "SUCCEEDED":
            with AuthorityUnitOfWork(jobs.database_url) as uow:
                uow.cursor.execute("SELECT result FROM authority_runtime_job_result WHERE runtime_job_id=%s AND attempt_id=%s", [claim.runtime_job_id, claim.attempt_id])
                committed = uow.cursor.fetchone()
            if committed:
                return committed[0]
        if not handed_off:
            jobs.fail(claim, {"code": getattr(error, "code", type(error).__name__), "message": str(error),
                             "formation_run_id": claim.subject_id}, retry_delay_seconds=30, cause=error)
        raise


def creation_status(database_url: str, *, project_id: str, formation_run_id: str, principal: Any) -> dict[str, Any]:
    from novel_forge.storage.story_formation_repositories import StoryFormationRepository

    principal.require("book.authority.query", project_id)
    with AuthorityUnitOfWork(database_url) as uow:
        run = StoryFormationRepository(uow.cursor).require(formation_run_id)
        if run["project_id"] != project_id:
            raise PermissionError("Formation is outside the requested Project")
        uow.cursor.execute("""SELECT job.runtime_job_id,job.status,job.available_at,job.last_error,receipt.result
            FROM authority_runtime_job job LEFT JOIN LATERAL (SELECT result FROM authority_runtime_job_result
                WHERE runtime_job_id=job.runtime_job_id ORDER BY created_at DESC,result_id DESC LIMIT 1) receipt ON TRUE
            WHERE job.job_kind='BOOK_CREATION_ADVANCE' AND job.subject_id=%s AND job.project_id=%s
            ORDER BY job.created_at DESC,job.runtime_job_id DESC LIMIT 1""", [formation_run_id, project_id])
        latest = uow.cursor.fetchone()
        cancellation = StoryFormationRepository(uow.cursor).cancellation(formation_run_id)
        uow.cursor.execute("SELECT book_run_id,state,accepted_through_chapter,target_chapter_count,version FROM authority_book_production WHERE project_id=%s AND stable_idempotency_key=%s", [project_id, formation_run_id + ":production"])
        production_row = uow.cursor.fetchone()
        production = dict(zip(("book_run_id", "state", "accepted_chapters", "target_chapters", "version"), production_row, strict=True)) if production_row else None
        candidates = []
        candidate_ids = run["recovery_instruction"].get("candidate_asset_version_ids") or StoryFormationRepository(uow.cursor).approval_wait(formation_run_id, "CREATIVE_SEARCH").get("candidate_asset_version_ids", [])
        for ordinal, identity in enumerate(candidate_ids, 1):
            asset = AuthorityAssetQuery(database_url).require(project_id=project_id, asset_version_id=identity)
            uow.cursor.execute("SELECT schema_version FROM authority_asset_version WHERE asset_version_id=%s", [identity])
            schema_version = uow.cursor.fetchone()[0]
            candidates.append({"number": ordinal, "asset_version_id": identity, "content_hash": asset.content_hash,
                "schema_version": schema_version, "content": asset.content})
    state = "INTERNAL_ACCEPTANCE_COMPLETE" if production and production["state"] == "COMPLETED" else "CANCELLATION_REQUESTED" if cancellation else "AUTHOR_DECISION" if run["lifecycle"] == "WAITING_APPROVAL" else "PRODUCING"
    if latest and latest[1] == "DEAD_LETTER" and state == "PRODUCING":
        state = "OWNER_RECOVERY_REQUIRED"
    if latest and latest[1] == "SUCCEEDED" and state == "PRODUCING":
        state = str((latest[4] or {}).get("wait_class") or state)
        if state == "COMPLETED":
            state = "INTERNAL_ACCEPTANCE_COMPLETE" if production and production["state"] == "COMPLETED" else "OWNER_RECOVERY_REQUIRED"
    from .queries import PostgresBookProductionQuery
    unresolved = PostgresBookProductionQuery(database_url).unresolved_chapter_effects(book_run_id=production["book_run_id"]) if production and not cancellation else []
    if unresolved:
        state = "RECONCILIATION_REQUIRED"
    return {
        "formation_run_id": formation_run_id,
        "production": production,
        "author_state": state,
        "unresolved_external_effects": unresolved,
        "next_action": "RECONCILE_ORIGINAL_EXTERNAL_EFFECTS"
        if state == "RECONCILIATION_REQUIRED"
        else "RECOVER_ORIGINAL_CREATION_AFTER_RESOLVING_RETAINED_FAILURE"
        if state == "OWNER_RECOVERY_REQUIRED"
        else "WAIT_FOR_NATIVE_EXECUTOR"
        if state == "PRODUCING"
        else state,
        "responsible_party": "RUNTIME_OWNER"
        if state in {"OWNER_RECOVERY_REQUIRED", "RECONCILIATION_REQUIRED"}
        else "AUTHOR"
        if state == "AUTHOR_DECISION"
        else "BOOK_AUTHORITY_WORKER",
        "delivery": {
            "required_action": "SELECT_EXACT_EDITION_AND_EXPORT",
            "export_status": "QUERY_EDITION_AUTHORITY",
            "literary_quality": "NOT_PROVEN",
        },
        "formation_lifecycle": run["lifecycle"],
        "stage": run["current_stage"],
        "version": run["version"],
        "cancellation": cancellation,
        "candidates": candidates,
        "failure": run["failure"] or ((latest[4] or {}).get("failure", {}) if latest else {}),
        "recovery_instruction": run["recovery_instruction"] or ((latest[4] or {}).get("recovery_instruction", {}) if latest else {}),
        "coordination": dict(
            zip(
                ("runtime_job_id", "status", "next_attempt_at", "error", "result"),
                latest,
            )
        )
        if latest
        else None,
        "progress": list(
            creation_progress(
                database_url, project_id=project_id, formation_run_id=formation_run_id
            )
        ),
    }


def execute_creation_command(settings: Any, args: Any, *, request_input: dict[str, Any] | None = None, brief_source: tuple[str, str] | None = None) -> dict[str, Any]:
    from copy import deepcopy
    from dataclasses import replace
    import json
    from types import SimpleNamespace
    from novel_forge.api.authority_dependencies import (authority_release_identity, build_trusted_principal_resolver,
        build_content_authority_application, build_production_execution_composition,
        build_chapter_authority_application, build_book_production_composition)
    from novel_forge.modules.book_design_authority.formation_domain import StoryFormationInput, deterministic_story_formation_run_id
    from novel_forge.modules.book_design_authority.formation import StartStoryFormationCommand
    from novel_forge.modules.book_design_authority.query import BookDesignAuthorityQuery
    from novel_forge.modules.content_authority.application import ContentOperationRequest
    from novel_forge.modules.production_execution.execution_template import selected_book_template
    from novel_forge.modules.capability_packs.validation_deployment import (
        install_chapter_validation_pack, install_longform_validation_pack, register_validation_runtime_definitions)
    from novel_forge.modules.capability_packs.longform_profiles import build_story_planning_pack_profile
    from novel_forge.storage.authority_uow import AuthorityUnitOfWork

    if settings.environment != "validation" or args.maximum_ticks <= 0 or args.work_window_seconds <= 0:
        raise ValueError("Creative creation requires validation runtime and positive execution window")
    args = SimpleNamespace(**vars(args))
    explicit_creation_policy = args.creation_policy_file is not None
    if args.creation_policy_file is None:
        args.creation_policy_file = args.repository_root / "config/execution_templates/creation_inputs.json"
    if args.action == "start" and args.idempotency_key:
        args.idempotency_key = f"creation:{args.project_id}:{args.book_id}:{args.idempotency_key}"
    runtime_values = creation_runtime_environment(args.project_id)
    settings = replace(settings, root=args.repository_root.resolve())
    resolver = build_trusted_principal_resolver()
    principal = resolver.resolve_api_principal()
    principal.require("book.authority.execute", args.project_id)
    if args.action == "status":
        return creation_status(settings.database_url, project_id=args.project_id,
                               formation_run_id=args.formation_run_id, principal=principal)
    build_id, sha = authority_release_identity()
    content = build_content_authority_application(settings)
    formation_id = args.formation_run_id
    existing_formation = None
    if args.action == "start":
        if (request_input is None and not args.input_file) or not all((args.workspace_id, args.book_id, args.idempotency_key)):
            raise ValueError("Start requires current work input, exact Book scope and stable idempotency key")
        inputs = deepcopy(request_input) if request_input is not None else json.loads(args.input_file.read_text())
        required = {"version", "brief", "title", "target_chapters", "language_contract"}
        if not required <= set(inputs) or set(inputs) - required - {"chapter_length", "creative_candidates", "author_creative_foundation", "comparison_policy"} or inputs["version"] != "creation-request.v1":
            raise ValueError("Creation input must declare current brief, title, scope and language")
        if (not isinstance(inputs["target_chapters"], int) or isinstance(inputs["target_chapters"], bool)
                or not 1 <= inputs["target_chapters"] <= 10000 or not isinstance(inputs["brief"], dict)
                or not isinstance(inputs["title"], str) or not inputs["title"].strip()
                or not isinstance(inputs["language_contract"], dict)
                or not isinstance(inputs["language_contract"].get("required_language"), str)
                or not inputs["language_contract"]["required_language"].strip()):
            raise ValueError("Creation requires a typed current work request")
        author_direction = inputs.get("author_creative_foundation")
        automatic_comparison = args.creative_selection == "AUTO_COMPARISON" and not author_direction
        from novel_forge.modules.story_planning_runtime.narrative_search import CREATIVE_INTELLIGENCE_DIMENSIONS, validate_search_selection_policy
        comparison_policy = validate_search_selection_policy(inputs.get("comparison_policy") or {
            "contract_version": "narrative-search-comparison.v2",
            "dimension_weights": {dimension: 1 for dimension in CREATIVE_INTELLIGENCE_DIMENSIONS},
            "uncertainty_margin": 0.05, "tie_break": "STABLE_ID"}) if automatic_comparison else None
        if inputs.get("comparison_policy") and not automatic_comparison:
            raise ValueError("Comparison policy requires automatic direction comparison")
        candidate_count = 1 if author_direction else inputs.get("creative_candidates", 2)
        if not isinstance(candidate_count, int) or isinstance(candidate_count, bool) or not (1 if author_direction else 2) <= candidate_count <= 4:
            raise ValueError("Creative direction comparison requires two to four bounded alternatives")
        from novel_forge.modules.creative.domain import validate_creative_brief
        if brief_source and "project_id" in inputs["brief"]:
            if inputs["brief"]["project_id"] != args.project_id:
                raise ValueError("CREATION_BRIEF_SOURCE_DRIFT")
            inputs["brief"].pop("project_id")
        inputs["brief"] = validate_creative_brief(inputs["brief"])
        replay_identity = deterministic_story_formation_run_id(project_id=args.project_id, book_id=args.book_id,
            stable_idempotency_key=args.idempotency_key)
        with AuthorityUnitOfWork(settings.database_url) as uow:
            uow.cursor.execute("SELECT workspace_id,frozen_stage_inputs FROM authority_story_formation_run WHERE formation_run_id=%s AND project_id=%s", [replay_identity,args.project_id])
            replay = uow.cursor.fetchone()
        if replay:
            original = StoryFormationInput.from_mapping(replay[1])
            policy = original.generation_policy or {}
            original_brief = AuthorityAssetQuery(settings.database_url).require(project_id=args.project_id, asset_version_id=original.creative_brief_asset_version_id)
            profile = policy.get("creation_input_policy", {}).get("profiles", {}).get("production_profile", {}).get("content", {})
            if (replay[0] != args.workspace_id or {"project_id":args.project_id, **inputs["brief"]} != original_brief.content
                    or any(inputs[field] != policy.get(field) for field in ("title", "target_chapters"))
                    or inputs["language_contract"] != profile.get("language_contract")
                    or candidate_count != policy.get("creative_candidates")
                    or author_direction != policy.get("author_creative_foundation")
                    or automatic_comparison != (policy.get("creative_selection") == "AUTO_COMPARISON")
                    or comparison_policy != policy.get("selection_policy")
                    or "chapter_length" in inputs and inputs["chapter_length"] != profile.get("chapter_length")
                    or brief_source and brief_source != (original.creative_brief_asset_version_id, original.creative_brief_content_hash)):
                raise ValueError("CREATION_FROZEN_INPUT_DRIFT")
            args.action, args.formation_run_id = "continue", replay_identity
            return execute_creation_command(settings, args)
        profiles = deepcopy(json.loads(args.creation_policy_file.read_text()))
        from novel_forge.modules.production_execution.codex_model_catalog import parse_codex_model_catalog
        catalog = parse_codex_model_catalog(os.environ.get("NOVEL_FORGE_CODEX_ROUTER_MODELS", ""))
        windows = [model["context_limit"] - model["output_limit"] for model in catalog if model["role"] == "PRIMARY"]
        if not windows or max(windows) <= 0:
            raise ValueError("CREATION_CONTEXT_WINDOW_REQUIRED")
        profile_content = profiles["profiles"]["production_profile"]["content"]
        profile_content.setdefault("chapter_context_policy", {"version": "book-chapter-context.v1",
            "draft_profile": "draft-context-profile-v4", "draft_token_budget": max(windows), "quality_token_budget": max(windows)})
        profile_content.setdefault("world_production_policy", {"version": "world-production-policy.v4",
            "max_provider_stages": 2, "context_token_budget": min(512000, max(windows))})
        profiles["profiles"]["production_profile"]["content"].update(
            target_chapter_count=inputs["target_chapters"], language_contract=inputs["language_contract"])
        if "chapter_length" in inputs:
            length = inputs["chapter_length"]
            if (not isinstance(length, dict) or set(length) != {"minimum", "maximum"}
                    or any(not isinstance(value, int) or isinstance(value, bool) for value in length.values())
                    or not 1 <= length["minimum"] <= length["maximum"] <= 100000):
                raise ValueError("CREATION_CHAPTER_LENGTH_INVALID")
            for fact in profiles["profiles"]["platform_profile"]["content"]["structured_facts"]:
                if fact["key"] == "platform_rules":
                    fact["value"]["chapter_length"] = dict(length)
            profiles["profiles"]["production_profile"]["content"]["chapter_length"] = dict(length)
        formation_id = deterministic_story_formation_run_id(project_id=args.project_id, book_id=args.book_id,
            stable_idempotency_key=args.idempotency_key)
        from novel_forge.modules.production_execution.execution_template import selected_template
        from novel_forge.modules.production_execution.routing_runtime import PostgresRoutingRegistry
        selected = selected_template(PostgresRoutingRegistry(settings.database_url).policy(args.project_id).get("policy", {}), args.book_id)
        if selected and selected["mode"] != "CREATIVE_VALIDATION":
            raise ValueError("CREATION_REQUIRES_EXPLICIT_VALIDATION_TEMPLATE")
        with AuthorityUnitOfWork(settings.database_url) as uow:
            uow.cursor.execute("SELECT formation_run_id FROM authority_story_formation_run WHERE project_id=%s AND book_id=%s AND formation_run_id<>%s", [args.project_id, args.book_id, formation_id])
            if uow.cursor.fetchone():
                raise ValueError("CREATION_ALREADY_ADMITTED_USE_ORIGINAL_FORMATION")
        ensure_creation_scope(settings, args, principal=principal, title=inputs["title"], build_id=build_id, sha=sha)
        from novel_forge.modules.command_kernel.errors import KernelError
        from novel_forge.modules.book_design_authority.application import BookDesignAuthorityApplication, BookDesignAuthorityCommand
        query = BookDesignAuthorityQuery(settings.database_url)
        try:
            book = query.require_book(project_id=args.project_id, book_id=args.book_id)
        except KernelError as error:
            if error.code != "BOOK_NOT_FOUND":
                raise
            native = BookDesignAuthorityApplication(settings.database_url, application_build_id=build_id, commit_sha=sha)
            native.execute(BookDesignAuthorityCommand(definition_name="book.create", project_id=args.project_id,
                workspace_id=args.workspace_id, book_id=args.book_id, actor_id=principal.principal_id,
                service_identity="native-creation", idempotency_key=args.idempotency_key + ":book",
                trace_id="trace:" + args.idempotency_key, correlation_id=formation_id,
                payload={"schema_version": "book-authority.v1", "title": inputs["title"],
                    "production_profile": profiles["profiles"]["production_profile"]["content"],
                    "runtime_policy": {"execution_mode": "CREATIVE_VALIDATION", "template_source": str(args.execution_template_file)},
                    "release_identity": sha}), principal=principal)
            book = query.require_book(project_id=args.project_id, book_id=args.book_id)
        if book["workspace_id"] != args.workspace_id:
            raise ValueError("Creation Book is outside the current workspace")
        if brief_source:
            brief = AuthorityAssetQuery(settings.database_url).require(project_id=args.project_id, asset_version_id=brief_source[0])
            if brief.asset_type != "creative_brief" or brief.content_hash != brief_source[1] or brief.content != {"project_id":args.project_id, **inputs["brief"]}:
                raise KernelError("CREATION_BRIEF_SOURCE_DRIFT", "Creation must bind the exact saved author brief")
        else:
            brief = content.execute(ContentOperationRequest(definition_name="creative.brief.create", project_id=args.project_id,
                workspace_id=args.workspace_id, actor_id=principal.principal_id, trace_id="trace:" + args.idempotency_key,
                correlation_id=formation_id, idempotency_key=args.idempotency_key + ":brief", payload={"brief": inputs["brief"]}), principal=principal)
        frozen = StoryFormationInput(creative_brief_asset_version_id=brief.asset_version_id,
            creative_brief_content_hash=brief.content_hash, generation_policy={
                "contract_version": "formation-generation.v6" if automatic_comparison else "formation-generation.v5" if args.creative_selection == "AUTHOR_COMPARISON" or author_direction else "formation-generation.v4",
                **({"creative_selection": "AUTHOR_DIRECTION" if author_direction else "AUTO_COMPARISON" if automatic_comparison else "AUTHOR_COMPARISON"} if args.creative_selection in {"AUTHOR_COMPARISON", "AUTO_COMPARISON"} or author_direction else {}),
                **({"selection_policy": comparison_policy, "strategy_directives": [
                    "Explore the author's central promise through a coherent causal direction with room for later development",
                    "Explore a distinct direction through character motivations and relationships while respecting the author's constraints",
                    "Explore a distinct conflict mechanism and differentiation suited to the intended length and reader experience",
                    "Explore a distinct pacing and information structure preserving the author's intended tone and future writability",
                ][:candidate_count]} if automatic_comparison else {}),
                **({"author_creative_foundation": author_direction} if author_direction else {}),
                "approval_mode": "AUTO", "creative_candidates": candidate_count,
                "target_chapters": inputs["target_chapters"], "title": inputs["title"], "creation_input_policy": profiles,
                "auto_authorization": {"contract_version": "formation-auto-authorization.v1", "policy_version": "formation-auto-policy.v1",
                    "authorization_ref": "creation:" + args.idempotency_key, "authorized_by_principal_id": principal.principal_id,
                    "project_id": args.project_id, "workspace_id": args.workspace_id, "book_id": args.book_id,
                    "formation_run_id": formation_id, "allowed_actions": ["book_design.candidate.activate",
                        "book_design.candidate.decide", "story_planning.candidate.activate", "story_planning.candidate.approve"]}})
        with AuthorityUnitOfWork(settings.database_url) as uow:
            uow.cursor.execute("SELECT frozen_input_digest,expected_book_version FROM authority_story_formation_run WHERE formation_run_id=%s AND project_id=%s", [formation_id, args.project_id])
            existing_formation = uow.cursor.fetchone()
            if existing_formation and existing_formation[0] != frozen.digest:
                raise ValueError("CREATION_FROZEN_INPUT_DRIFT")
            admission = selected_book_template(uow.cursor, project_id=args.project_id, book_id=args.book_id, allow_literary_required=True)
        if admission is None:
            from novel_forge.modules.production_execution.execution_template import configure_execution_template
            configure_execution_template(settings, SimpleNamespace(project_id=args.project_id,
                workspace_id=args.workspace_id, book_id=args.book_id, policy_version="creation:" + formation_id,
                idempotency_key=args.idempotency_key + ":execution-template", template_file=args.execution_template_file))
        repository_root = args.repository_root.resolve()
        hashes = register_validation_runtime_definitions(settings.database_url, application_build_id=build_id, commit_sha=sha)
        if existing_formation is None:
            install_chapter_validation_pack(settings.database_url, repository_root=repository_root,
            project_id=args.project_id, workspace_id=args.workspace_id, book_id=args.book_id,
            application_build_id=build_id, commit_sha=sha, compiler=principal, approver=principal, agent_admin=principal,
            pack_id_override=runtime_values["NOVEL_FORGE_CHAPTER_CAPABILITY_PACK_ID"])
            profile = build_story_planning_pack_profile(repository_root, operation_definition_hash=hashes["planning"],
            pack_id=runtime_values["NOVEL_FORGE_PLANNING_CAPABILITY_PACK_ID"])
            install_longform_validation_pack(settings.database_url, profile=profile, pack_version="1.1.0", agent_generation=1,
            expected_activation_version=0, project_id=args.project_id, workspace_id=args.workspace_id, book_id=args.book_id,
            application_build_id=build_id, commit_sha=sha, compiler=principal, approver=principal, agent_admin=principal,
            agent_domain="story_planning", agent_scope_type="BOOK")
    elif not formation_id:
        raise ValueError("Continue requires the original Formation identity")
    execution = build_production_execution_composition(settings, env=runtime_values)
    try:
        chapter = build_chapter_authority_application(settings, execution=execution, env=runtime_values)
        composition = build_book_production_composition(settings, principal=principal, execution=execution, chapter_application=chapter, env=runtime_values)
        if args.action == "start":
            composition.formation.admit(StartStoryFormationCommand(project_id=args.project_id, workspace_id=args.workspace_id,
                book_id=args.book_id, actor_id=principal.principal_id, expected_book_version=existing_formation[1] if existing_formation else book["version"],
                stable_idempotency_key=args.idempotency_key, trace_id="trace:" + args.idempotency_key,
                correlation_id=formation_id, frozen_input=frozen), principal=principal)
        run = composition.formation.require(formation_id)
        if run["project_id"] != args.project_id:
            raise PermissionError("Formation is outside authorized project")
        from novel_forge.modules.book_authority.creation_runtime import creation_cancellation, reconcile_creation_cancellation
        if args.action != "cancel" and creation_cancellation(settings.database_url, formation_id):
            reconcile_creation_cancellation(composition, formation_id)
            return {"stop_reason": "CANCELLED", **creation_status(settings.database_url,
                project_id=args.project_id, formation_run_id=formation_id, principal=principal)}
        if args.action == "cancel":
            composition.formation.cancel_continuation(formation_id, principal=principal,
                reason=args.reason, idempotency_key=args.idempotency_key)
            from novel_forge.modules.book_authority.creation_runtime import reconcile_creation_cancellation
            reconcile_creation_cancellation(composition, formation_id)
            schedule_creation_jobs(settings.database_url, limit=1, formation_run_id=formation_id)
            return {"stop_reason": "CANCELLED", **creation_status(settings.database_url,
                project_id=args.project_id, formation_run_id=formation_id, principal=principal)}
        ensure_creation_reader_pack(settings, formation_run_id=formation_id, principal=principal,
            repository_root=args.repository_root.resolve(), values=runtime_values,
            application_build_id=build_id, commit_sha=sha)
        if args.action == "recover":
            if not args.reason.strip():
                raise ValueError("Recovery requires a reason describing the resolved blocker")
            recovered = creation_recovery_record(settings.database_url, formation_id, args.reason, args.idempotency_key)
            if recovered:
                return {"stop_reason":"WORKER_OWNS_CONTINUATION", "scheduled":[recovered],
                    **creation_status(settings.database_url, project_id=args.project_id, formation_run_id=formation_id, principal=principal)}
            if run["lifecycle"] == "FAILED":
                composition.formation.resume(formation_id, expected_version=run["version"], principal=principal)
        if args.action == "choose":
            if args.candidate_number is not None:
                choices = creation_status(settings.database_url, project_id=args.project_id, formation_run_id=formation_id, principal=principal)["candidates"]
                selected = next((candidate for candidate in choices if candidate["number"] == args.candidate_number), None)
                if not selected:
                    raise ValueError("Candidate number is outside the current frozen alternatives")
                args.candidate_version, args.candidate_hash = selected["asset_version_id"], selected["content_hash"]
            if not all((args.candidate_version, args.candidate_hash, args.reason.strip(), args.idempotency_key)):
                raise ValueError("Choose requires the exact candidate/hash, comparison reason and stable decision key")
            with AuthorityUnitOfWork(settings.database_url) as uow:
                uow.cursor.execute("""SELECT command_payload FROM authority_operation
                    WHERE idempotency_scope='book:story-formation' AND idempotency_key=ANY(%s)
                      AND command_payload->>'formation_run_id'=%s ORDER BY created_at LIMIT 1""",
                    [[args.idempotency_key, f"{formation_id}:author-decision:{args.idempotency_key}"],formation_id])
                previous_decision = uow.cursor.fetchone()
            decision_version = previous_decision[0]["expected_version"] if previous_decision else run["version"]
            composition.formation.author_decision(formation_id, expected_version=decision_version,
                candidate_asset_version_id=args.candidate_version, candidate_content_hash=args.candidate_hash,
                decision="APPROVE", reason=args.reason, idempotency_key=args.idempotency_key, principal=principal)
        if (composition.formation.frozen_input(formation_id).generation_policy or {}).get("contract_version") in {"formation-generation.v5", "formation-generation.v6"}:
            scheduled = schedule_creation_jobs(settings.database_url, limit=1, formation_run_id=formation_id,
                recovery_reason=args.reason if args.action == "recover" else "", recovery_key=args.idempotency_key if args.action == "recover" else "")
            if not args.foreground:
                return {"formation_run_id": formation_id, "stop_reason": "WORKER_OWNS_CONTINUATION",
                        "scheduled": list(scheduled), **creation_status(settings.database_url,
                            project_id=args.project_id, formation_run_id=formation_id, principal=principal)}
        progress, stagnant = None, 0
        while True:
            result = continue_creation(composition=composition, content=content, chapter=chapter, formation_run_id=formation_id,
                formation_worker=resolver.resolve_book_formation_worker_principal("creation-formation"),
                book_worker=resolver.resolve_worker_principal("creation-book"), maximum_ticks=args.maximum_ticks,
                deadline=monotonic() + args.work_window_seconds,
                creation_policy=json.loads(args.creation_policy_file.read_text()) if args.action == "continue" and explicit_creation_policy else None)
            if result["stop_reason"] != "YIELDED_CHECKPOINT" or args.yield_after_window:
                return {"formation_run_id": formation_id, **result}
            current = creation_progress(settings.database_url, project_id=args.project_id, formation_run_id=formation_id)
            stagnant = stagnant + 1 if current == progress else 0
            progress = current
            if stagnant >= 3:
                return {"formation_run_id": formation_id, **result, "stop_reason": "CREATION_NO_PROGRESS"}
    finally:
        execution.close()


def ensure_creation_scope(settings: Any, args: Any, *, principal: Any, title: str, build_id: str, sha: str) -> None:
    from novel_forge.modules.command_kernel.errors import KernelError
    from novel_forge.modules.project_authority.application import ProjectAuthorityApplication, ProjectAuthorityCommand
    from novel_forge.modules.project_authority.query import ProjectAuthorityQuery
    from novel_forge.storage.authority_uow import AuthorityUnitOfWork

    application = ProjectAuthorityApplication(settings.database_url, application_build_id=build_id, commit_sha=sha)
    query = ProjectAuthorityQuery(settings.database_url)
    try:
        project = query.require_project(args.project_id)
    except KernelError as error:
        if error.code != "PROJECT_NOT_FOUND":
            raise
        application.execute(ProjectAuthorityCommand(definition_name="project_lifecycle.create", project_id=args.project_id,
            workspace_id=args.workspace_id, actor_id=principal.principal_id, idempotency_key=args.project_id + ":" + args.idempotency_key + ":project",
            trace_id="trace:" + args.idempotency_key, correlation_id=args.book_id, payload={"title": title}), principal=principal)
        project = query.require_project(args.project_id)
    if project["status"] != "ACTIVE":
        raise KernelError("PROJECT_LIFECYCLE_CONFLICT", "Creation requires an active authorized project")
    with AuthorityUnitOfWork(settings.database_url) as uow:
        uow.cursor.execute("SELECT project_id,book_id,status FROM authority_workspace WHERE workspace_id=%s", [args.workspace_id])
        workspace = uow.cursor.fetchone()
    if workspace is None:
        application.execute(ProjectAuthorityCommand(definition_name="project_workspace.create", project_id=args.project_id,
            workspace_id=project["workspace_id"], actor_id=principal.principal_id, idempotency_key=args.idempotency_key + ":workspace",
            trace_id="trace:" + args.idempotency_key, correlation_id=args.book_id,
            expected_version=project["version"], expected_current_asset_version_id=project["asset_version_id"],
            payload={"workspace_id": args.workspace_id}), principal=principal)
    elif workspace[0] != args.project_id or workspace[1] not in (None, "", args.book_id) or workspace[2] != "ACTIVE":
        raise KernelError("CREATION_WORKSPACE_SCOPE_CONFLICT", args.workspace_id)
