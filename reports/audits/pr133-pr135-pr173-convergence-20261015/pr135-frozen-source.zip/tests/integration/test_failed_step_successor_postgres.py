from copy import deepcopy
from datetime import datetime, timedelta, timezone

import psycopg
import pytest

from novel_forge.modules.command_kernel.attempt_runtime import (
    WorkerLeaseCommand,
    WorkerResultCommand,
    acquire_attempt_lease,
    create_attempt,
    queue_attempt,
    start_attempt,
    submit_attempt_result,
)
from novel_forge.modules.command_kernel.errors import KernelError
from novel_forge.modules.command_kernel.operation_graph import (
    GraphCommandContext,
    coordinate_saga,
    register_saga_step,
    start_saga,
)
from novel_forge.modules.command_kernel.runtime import (
    OperationTransitionCommand,
    transition_operation,
)
from novel_forge.modules.command_kernel.service import AdmissionContext, admit_command
from novel_forge.modules.command_kernel.step_successor import replace_failed_step
from novel_forge.storage.authority_uow import AuthorityUnitOfWork
from tests.integration.authority_postgres_support import (
    DATABASE_URL,
    ensure_migrated,
    identifier,
)
from tests.integration.test_command_kernel_definition_postgres import definition_payload


@pytest.fixture
def failed_graph():
    ensure_migrated()
    project = identifier("step-successor")
    original = definition_payload(identifier("local-contract"))
    original["completion_contract"] = {}
    original["timeout_policy"] = {"operation_timeout_seconds": 300}
    target = {**deepcopy(original), "definition_version": "1.0.1"}
    root_definition = {**deepcopy(original), "name": identifier("successor-root")}
    context = AdmissionContext(
        "source-owner",
        frozenset(original["permissions"]),
        frozenset({original["handler_key"]}),
        "test-build-1",
        "a" * 40,
    )
    with AuthorityUnitOfWork(DATABASE_URL) as uow:
        for definition in (root_definition, original, target):
            uow.repositories.definitions.register(definition)
        uow.commit()

    def admit(definition, **relations):
        return admit_command(
            DATABASE_URL,
            {
                "definition_name": definition["name"],
                "definition_version": definition["definition_version"],
                "project_id": project,
                "workspace_id": "workspace:" + project,
                "actor_id": context.actor_id,
                "idempotency_scope": original["idempotency_scope"],
                "idempotency_key": identifier("command"),
                "trace_id": identifier("trace"),
                "span_id": identifier("span"),
                "correlation_id": project,
                "causation_id": "",
                "input": {"value": "frozen"},
                "input_assets": [],
                **relations,
            },
            context=context,
        )["operation_id"]

    root = admit(root_definition)
    for version, source, destination in (
        (0, "ADMITTED", "READY"),
        (1, "READY", "EXECUTING"),
        (2, "EXECUTING", "WAITING_CHILDREN"),
    ):
        transition_operation(
            DATABASE_URL,
            OperationTransitionCommand(
                root,
                project,
                version,
                source,
                destination,
                context.actor_id,
                "native root lifecycle",
                project,
                project,
                "",
            ),
        )
    child = admit(
        original,
        root_operation_id=root,
        parent_operation_id=root,
        causation_operation_id=root,
    )
    graph_context = GraphCommandContext(project, context.actor_id, project, project, "")
    saga = start_saga(DATABASE_URL, graph_context, root_operation_id=root)["saga_id"]
    register_saga_step(DATABASE_URL, graph_context, saga, child, "draft", 1, "")
    coordinate_saga(DATABASE_URL, graph_context, saga)
    attempt = create_attempt(
        DATABASE_URL,
        operation_id=child,
        project_id=project,
        max_attempts=1,
        trace_id=project,
        correlation_id=project,
    )["attempt_id"]
    queue_attempt(
        DATABASE_URL,
        attempt_id=attempt,
        project_id=project,
        trace_id=project,
        correlation_id=project,
    )
    lease = acquire_attempt_lease(
        DATABASE_URL,
        attempt_id=attempt,
        project_id=project,
        worker_id="worker",
        lease_seconds=30,
        trace_id=project,
        correlation_id=project,
    )
    worker = WorkerLeaseCommand(
        attempt, project, "worker", lease["fencing_token"], project, project
    )
    start_attempt(DATABASE_URL, worker)
    submit_attempt_result(
        DATABASE_URL,
        WorkerResultCommand(**worker.__dict__, expected_operation_version=2),
        result={"error_code": "LOCAL_CONTRACT_DEFECT"},
        outcome="final_failure",
    )
    assert (
        coordinate_saga(DATABASE_URL, graph_context, saga)["status"]
        == "MANUAL_INTERVENTION"
    )
    return project, root, child, saga, context


def test_native_step_successor_preserves_failure_and_manual_saga_history(failed_graph):
    project, root, child, saga, context = failed_graph
    options = dict(
        predecessor_id=child,
        target_version="1.0.1",
        context=context,
        policy_evidence={"contract": "controlled-local-contract"},
        expected_failure_code="LOCAL_CONTRACT_DEFECT",
    )
    first = replace_failed_step(DATABASE_URL, **options)
    assert replace_failed_step(DATABASE_URL, **options) == {
        "operation_id": first["operation_id"],
        "replayed": True,
    }
    with AuthorityUnitOfWork(DATABASE_URL) as uow:
        uow.cursor.execute(
            "SELECT status FROM authority_operation WHERE operation_id=%s", [child]
        )
        assert uow.cursor.fetchone()[0] == "FAILED_FINAL"
        uow.cursor.execute(
            "SELECT status,result->>'error_code' FROM authority_attempt WHERE operation_id=%s",
            [child],
        )
        assert uow.cursor.fetchone() == ("FAILED_FINAL", "LOCAL_CONTRACT_DEFECT")
        uow.cursor.execute("SELECT status FROM authority_saga WHERE saga_id=%s", [saga])
        assert uow.cursor.fetchone()[0] == "RUNNING"
        uow.cursor.execute(
            "SELECT source_saga_snapshot->>'status',successor_operation_id FROM authority_saga_step_successor WHERE predecessor_operation_id=%s",
            [child],
        )
        assert uow.cursor.fetchone() == ("MANUAL_INTERVENTION", first["operation_id"])
        uow.cursor.execute(
            "SELECT input_asset_snapshot,command_payload,parent_operation_id,root_operation_id FROM authority_operation WHERE operation_id=ANY(%s) ORDER BY created_at",
            [[child, first["operation_id"]]],
        )
        before, after = uow.cursor.fetchall()
        assert before == after
    with pytest.raises(psycopg.errors.CheckViolation):
        with AuthorityUnitOfWork(DATABASE_URL) as uow:
            uow.cursor.execute(
                "DELETE FROM authority_saga_step_successor WHERE predecessor_operation_id=%s",
                [child],
            )
            uow.commit()


def _window_options(failed_graph):
    project, root, child, saga, context = failed_graph
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("SELECT definition_snapshot FROM authority_operation WHERE operation_id=%s", [child])
        target = deepcopy(u.cursor.fetchone()[0])
        target["definition_version"] = "1.0.2"
        target["policy"]["source_span_contract"] = "controlled-span.v1"
        u.repositories.definitions.register(target)
        u.cursor.execute("UPDATE authority_operation SET business_deadline_at=%s WHERE operation_id=%s", [datetime.now(timezone.utc)-timedelta(seconds=1), root])
        u.commit()
    return dict(predecessor_id=child, target_version="1.0.2", context=context,
        policy_evidence={"contract": "controlled-interface-correction"}, expected_failure_code="LOCAL_CONTRACT_DEFECT",
        window_successor={"contract_version": "kernel-corrected-contract-window.v1", "policy_key": "source_span_contract", "policy_value": "controlled-span.v1"})


def test_corrected_window_preserves_original_root_and_deadline_idempotently(failed_graph):
    project, root, child, saga, context = failed_graph
    options = _window_options(failed_graph)
    first = replace_failed_step(DATABASE_URL, **options)
    assert replace_failed_step(DATABASE_URL, **options)["replayed"]
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("SELECT source_failure_snapshot FROM authority_saga_step_successor WHERE predecessor_operation_id=%s", [child])
        record = u.cursor.fetchone()[0]
        u.cursor.execute("SELECT status,business_deadline_at,command_payload FROM authority_operation WHERE operation_id=%s", [root])
        status, deadline, payload = u.cursor.fetchone()
        assert status == "WAITING_CHILDREN"
        assert deadline > datetime.now(timezone.utc)
        assert record["root"]["command_payload"] == payload
        assert record["execution_window"]["duration_seconds"] == 300
        assert record["execution_window"]["original_deadline"] != deadline.isoformat()
        assert record["operation"]["status"] == "FAILED_FINAL"
        assert first["operation_id"] != child


@pytest.mark.parametrize("boundary", ["unchanged-policy", "author-deadline", "cancelled-root"])
def test_contract_window_cannot_bypass_author_deadline_cancel_or_unchanged_contract(failed_graph, boundary):
    project, root, child, saga, context = failed_graph
    options = _window_options(failed_graph)
    if boundary == "unchanged-policy":
        options["target_version"] = "1.0.1"
    else:
        with AuthorityUnitOfWork(DATABASE_URL) as u:
            if boundary == "author-deadline":
                u.cursor.execute("UPDATE authority_operation SET command_payload=command_payload || '{\"author_deadline_at\":\"2026-01-01\"}'::jsonb WHERE operation_id=%s", [root])
            else:
                u.cursor.execute("UPDATE authority_operation SET status='CANCELLED' WHERE operation_id=%s", [root])
            u.commit()
    with pytest.raises(KernelError) as failure:
        replace_failed_step(DATABASE_URL, **options)
    assert failure.value.code in {"STEP_SUCCESSOR_WINDOW_INVALID", "STEP_SUCCESSOR_SOURCE_INVALID"}


@pytest.mark.parametrize("boundary", ["failure", "permissions", "cancelled-root"])
def test_step_successor_rejects_unowned_cancelled_or_unproven_recovery(
    failed_graph, boundary
):
    project, root, child, saga, context = failed_graph
    if boundary == "permissions":
        context = AdmissionContext(
            context.actor_id,
            frozenset(),
            context.available_handlers,
            context.application_build_id,
            context.commit_sha,
        )
    if boundary == "cancelled-root":
        from novel_forge.modules.command_kernel.cancellation import (
            CancelCommand,
            request_cancellation,
        )

        with AuthorityUnitOfWork(DATABASE_URL) as uow:
            uow.cursor.execute(
                "SELECT version FROM authority_operation WHERE operation_id=%s", [root]
            )
            version = uow.cursor.fetchone()[0]
        request_cancellation(
            DATABASE_URL,
            CancelCommand(
                root,
                project,
                context.actor_id,
                "author cancel",
                version,
                identifier("cancel"),
                project,
                project,
            ),
            settle_undispatched=True,
        )
    with pytest.raises(KernelError):
        replace_failed_step(
            DATABASE_URL,
            predecessor_id=child,
            target_version="1.0.1",
            context=context,
            policy_evidence={"contract": "controlled-local-contract"},
            expected_failure_code="DIFFERENT_FAILURE"
            if boundary == "failure"
            else "LOCAL_CONTRACT_DEFECT",
        )


def test_known_receipt_successor_rejects_unproven_effects(failed_graph):
    project, root, child, saga, context = failed_graph
    with pytest.raises(KernelError, match="STEP_SUCCESSOR_RECEIPT_UNSETTLED"):
        replace_failed_step(
            DATABASE_URL,
            predecessor_id=child,
            target_version="1.0.1",
            context=context,
            policy_evidence={"contract_version": "chapter-known-receipt.v1"},
            expected_failure_code="LOCAL_CONTRACT_DEFECT",
            known_receipt_effects=(("unproven-effect", "unproven-hash"),),
        )


def test_schema_rejection_successor_requires_exact_domain_and_kernel_evidence(failed_graph):
    project, root, child, saga, context = failed_graph
    with pytest.raises(KernelError, match="STEP_SUCCESSOR_REJECTION_UNRECONCILED"):
        replace_failed_step(DATABASE_URL, predecessor_id=child, target_version="1.0.1", context=context,
            policy_evidence={"contract_version": "controlled-rejection"}, expected_failure_code="LOCAL_CONTRACT_DEFECT",
            known_rejected_effects=(("missing-effect", "missing-hash", "missing-receipt", "missing-hash"),))


@pytest.mark.parametrize("invalidate_second", [False, True])
def test_failed_step_group_is_atomic_and_replays_without_rewriting_attempts(failed_graph, invalidate_second):
    from novel_forge.modules.command_kernel.step_successor import replace_failed_steps
    project, root, child, saga, context = failed_graph
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("SELECT definition_name,definition_version FROM authority_operation WHERE operation_id=%s", [child])
        name, version = u.cursor.fetchone()
    second = admit_command(DATABASE_URL, {
        "definition_name": name, "definition_version": version, "project_id": project,
        "workspace_id": "workspace:" + project, "actor_id": context.actor_id,
        "idempotency_scope": "project:operation", "idempotency_key": identifier("parallel"),
        "trace_id": project, "span_id": project, "correlation_id": project, "causation_id": "",
        "input": {"value": "frozen"}, "input_assets": [], "root_operation_id": root,
        "parent_operation_id": root, "causation_operation_id": root}, context=context)["operation_id"]
    register_saga_step(DATABASE_URL, GraphCommandContext(project, context.actor_id, project, project, ""),
        saga, second, "parallel", 2, "")
    transition_operation(DATABASE_URL, OperationTransitionCommand(second, project, 0, "ADMITTED", "READY",
        context.actor_id, "parallel fixture admission", project, project, ""))
    attempt = create_attempt(DATABASE_URL, operation_id=second, project_id=project, max_attempts=1,
        trace_id=project, correlation_id=project)["attempt_id"]
    queue_attempt(DATABASE_URL, attempt_id=attempt, project_id=project, trace_id=project, correlation_id=project)
    lease = acquire_attempt_lease(DATABASE_URL, attempt_id=attempt, project_id=project, worker_id="worker",
        lease_seconds=30, trace_id=project, correlation_id=project)
    worker = WorkerLeaseCommand(attempt, project, "worker", lease["fencing_token"], project, project)
    start_attempt(DATABASE_URL, worker)
    submit_attempt_result(DATABASE_URL, WorkerResultCommand(**worker.__dict__, expected_operation_version=2),
        result={"error_code": "LOCAL_CONTRACT_DEFECT"}, outcome="final_failure")
    corrections = [{"predecessor_id": identity, "target_version": "1.0.1",
        "policy_evidence": {"contract": "parallel-interface-correction"},
        "expected_failure_code": "LOCAL_CONTRACT_DEFECT"} for identity in (child, second)]
    if invalidate_second:
        corrections[1]["expected_failure_code"] = "UNPROVEN_FAILURE"
        with pytest.raises(KernelError):
            replace_failed_steps(DATABASE_URL, corrections=corrections, context=context)
        with AuthorityUnitOfWork(DATABASE_URL) as u:
            u.cursor.execute("SELECT count(*) FROM authority_saga_step_successor WHERE predecessor_operation_id=ANY(%s)", [[child, second]])
            assert u.cursor.fetchone()[0] == 0
            u.cursor.execute("SELECT status FROM authority_saga WHERE saga_id=%s", [saga])
            assert u.cursor.fetchone()[0] == "MANUAL_INTERVENTION"
    else:
        first = replace_failed_steps(DATABASE_URL, corrections=corrections, context=context)
        replay = replace_failed_steps(DATABASE_URL, corrections=corrections, context=context)
        assert [r["operation_id"] for r in first] == [r["operation_id"] for r in replay]
        assert all(r["replayed"] for r in replay)
        from types import SimpleNamespace
        from novel_forge.modules.chapter_authority.scheduler import ChapterAuthorityScheduler
        scheduler = object.__new__(ChapterAuthorityScheduler)
        scheduler.database_url = DATABASE_URL
        with AuthorityUnitOfWork(DATABASE_URL) as u:
            u.cursor.execute("SELECT idempotency_key FROM authority_operation WHERE operation_id=%s", [child])
            original_key = u.cursor.fetchone()[0]
        active = scheduler._initial_operation(root_operation_id=root, project_id=project,
            node=SimpleNamespace(definition_name=name), idempotency_key=original_key)
        assert active["operation_id"] == first[0]["operation_id"]
        assert active["status"] == "ADMITTED"
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("SELECT status,result->>'error_code' FROM authority_attempt WHERE operation_id=ANY(%s)", [[child, second]])
        assert u.cursor.fetchall() == [("FAILED_FINAL", "LOCAL_CONTRACT_DEFECT")] * 2


@pytest.fixture
def completed_contract_graph(failed_graph, request):
    from novel_forge.modules.command_kernel.operation_graph import add_operation_dependency
    project, root, failed, saga, context = failed_graph
    source = replace_failed_step(DATABASE_URL, predecessor_id=failed, target_version="1.0.1", context=context,
        policy_evidence={"contract": "completed-contract-test"}, expected_failure_code="LOCAL_CONTRACT_DEFECT")["operation_id"]
    def complete(operation):
        with AuthorityUnitOfWork(DATABASE_URL) as u:
            u.cursor.execute("SELECT status,version FROM authority_operation WHERE operation_id=%s", [operation])
            status, version = u.cursor.fetchone()
        if status == "ADMITTED":
            transition_operation(DATABASE_URL, OperationTransitionCommand(operation, project, version, status, "READY",
                context.actor_id, "controlled native completion", project, project, ""))
        attempt = create_attempt(DATABASE_URL, operation_id=operation, project_id=project, max_attempts=1,
            trace_id=project, correlation_id=project)["attempt_id"]
        queue_attempt(DATABASE_URL, attempt_id=attempt, project_id=project, trace_id=project, correlation_id=project)
        lease = acquire_attempt_lease(DATABASE_URL, attempt_id=attempt, project_id=project, worker_id="worker",
            lease_seconds=30, trace_id=project, correlation_id=project)
        worker = WorkerLeaseCommand(attempt, project, "worker", lease["fencing_token"], project, project)
        start_attempt(DATABASE_URL, worker)
        with AuthorityUnitOfWork(DATABASE_URL) as u:
            u.cursor.execute("SELECT version FROM authority_operation WHERE operation_id=%s", [operation]);version=u.cursor.fetchone()[0]
        submit_attempt_result(DATABASE_URL, WorkerResultCommand(**worker.__dict__, expected_operation_version=version),
            result={"value": "complete"}, outcome="success")
    complete(source)
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("SELECT definition_snapshot FROM authority_operation WHERE operation_id=%s", [source]);target=deepcopy(u.cursor.fetchone()[0])
        target["definition_version"]="1.0.2";target["policy"]["completed_contract"]="controlled.v1"
        u.repositories.definitions.register(target);u.commit()
    successor = admit_command(DATABASE_URL, {"definition_name": target["name"], "definition_version": "1.0.2",
        "project_id": project, "workspace_id": "workspace:" + project, "actor_id": context.actor_id,
        "idempotency_scope": target["idempotency_scope"], "idempotency_key": identifier("completed-contract"),
        "trace_id": project, "span_id": project, "correlation_id": project, "causation_id": source,
        "input": {"value": "changed" if request.node.callspec.params.get("boundary") == "input-drift" else "frozen"}, "input_assets": [], "root_operation_id": root,
        "parent_operation_id": root, "causation_operation_id": source}, context=context)["operation_id"]
    add_operation_dependency(DATABASE_URL, GraphCommandContext(project,context.actor_id,project,project), successor, source, "ON_SUCCESS")
    complete(successor)
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("UPDATE authority_operation SET business_deadline_at=%s WHERE operation_id=%s", [datetime.now(timezone.utc)-timedelta(seconds=1),root]);u.commit()
    return project,root,source,successor,context


@pytest.mark.parametrize("boundary", ["valid", "permissions", "author-deadline", "missing-link", "input-drift", "cancelled-root"])
def test_completed_contract_window_is_exact_bounded_and_cannot_revive_cancellation(completed_contract_graph, boundary):
    from novel_forge.modules.command_kernel.step_successor import continue_completed_contract_window
    project,root,source,successor,context=completed_contract_graph
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        if boundary=="author-deadline":
            u.cursor.execute("UPDATE authority_operation SET command_payload=command_payload || '{\"author_deadline_at\":\"2026-01-01\"}'::jsonb WHERE operation_id=%s",[root])
        elif boundary=="missing-link":
            u.cursor.execute("DELETE FROM authority_operation_dependency WHERE operation_id=%s",[successor])
        elif boundary=="cancelled-root":
            u.cursor.execute("UPDATE authority_operation SET status='CANCELLED' WHERE operation_id=%s",[root])
        u.commit()
    if boundary=="permissions":
        context=AdmissionContext(context.actor_id,frozenset(),context.available_handlers,context.application_build_id,context.commit_sha)
    options=dict(predecessor_id=source,successor_id=successor,context=context,
        policy={"contract_version":"kernel-corrected-contract-window.v1","policy_key":"completed_contract","policy_value":"controlled.v1"})
    if boundary!="valid":
        with pytest.raises(KernelError):continue_completed_contract_window(DATABASE_URL,**options)
        return
    first=continue_completed_contract_window(DATABASE_URL,**options)
    second=continue_completed_contract_window(DATABASE_URL,**options)
    assert not first["replayed"] and second["replayed"] and first["execution_window"]==second["execution_window"]
    with AuthorityUnitOfWork(DATABASE_URL) as u:
        u.cursor.execute("SELECT status,business_deadline_at FROM authority_operation WHERE operation_id=%s",[root]);status,deadline=u.cursor.fetchone()
        assert status=="WAITING_CHILDREN" and deadline>datetime.now(timezone.utc)
        u.cursor.execute("SELECT count(*) FROM state_event WHERE aggregate_id=%s AND event_type='authority.operation.completed_contract_window_continued'",[root]);assert u.cursor.fetchone()[0]==1
