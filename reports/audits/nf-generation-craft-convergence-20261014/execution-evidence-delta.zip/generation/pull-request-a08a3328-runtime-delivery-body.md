## Summary

纯模型生成曾被本地调用、父级期限及累计额度中止；小说链还遗漏作者篇幅、选定工作经历，并把接纳和协议状态带入人物及事件组织。本分支沿现有 Owner 删除纯生成时间终止和累计 Book 封禁，修复输入、未来规划、工作稿、审稿及完整结果恢复。100 章和文学目标仍未交付，保持 Draft。

```text
Creation → Foundation → Opening → event-first Planning
  frozen Book author scale → Planning request
  selected working prose → World Source v5 / chapter frontier
Chapter → Context → Writer → working Review / Revision / Selection
  frozen visible Platform bounds → Writer / creative baseline
Kernel → durable complete receipt → fenced native recovery
```

当前 HEAD：a08a33280349c9e6c85dbefd99792933faad19eb；最新 main：198a3c12bed4613b470623fa2636bdfeccc516cb。PR166 已关闭且仍标记 Draft，历史 HEAD 5d0ca7447089b89b55230ef0657e5ec255d4d1ff，未盲目合并。

## Evidence

- **Before:** 第 1 章真实完整 Writer 请求没有作者 4000—5000 汉字范围，规划 target_word_count 为空；范围仅保存在 evidence-only Platform profile，Chapter Planning 请求也未携带。
  **After:** 新 Context 将可见冻结 Han 范围绑定到 Writer 和 creative baseline，1.21.0 层级 Planning 从精确 Book record 冻结作者范围并保留来源引用。内部质量规则经过既有可见性过滤；旧冻结请求无新 marker 时原样回放。原生 PostgreSQL 检查实际 Planning 和 Writer stdin，而非仅检查保存的 Context。
- **Before:** 正式接纳游标 0 使 World 继续使用旧前沿与旧输入；新 v4 输出在完整校验路径中被拒绝。
  **After:** World Source v5 单独绑定目标章与已选择工作正文；未审阅工作观察保持认知归属，不成为 Canon。新 generate/Director v4 和合法 intent/actor 后缀仍按完整冻结 Schema 校验，legacy 保留。实际新书第 2 章 Source 已为 target=2、accepted=0，带第 1 章选定工作稿。候选 disclosure 只在当前工作目标章获准；正式 disclosure 保持接纳范围。
- 最终增量定向单元 263 PASS；原生 PostgreSQL 最终 1 PASS，含完整 stdin、候选 baseline、来源、工作稿和 Creation scope。World v4 拒绝、测试取错 input 字段及 Book record 类型错误等中间失败日志均保留。数字有重叠，不与此前检查相加冒充全量覆盖。
- a08a3328 非 editable 安装包核对 986 源码模块、11 实际 console/worker launcher；SDK read/write=None，connect/pool=30；迁移 head0210。同一新书范围 Pack 激活，原 Attempt snapshots 未变，其他任务工作区及原55483实例未改。运行分类为 OWNED_COPIED_RECOVERED_TASK_RUNTIME，PostgreSQL OID1925316/55577。
- f6184d04 安装态历史 121 份完整 Prompt、冻结请求哈希与实际 stdin 全部匹配。Documentation Reality、架构 fitness、定向 lint/diff PASS。完整发布矩阵 NOT_RUN，未把旧失败的大测试算作资格通过。
- 已保存的 World 生成／Director 完整结果因旧前沿检查失败时，v4 恢复沿当前 evaluation→generation→Source 的精确版本查找，包括关联祖先 Owner。0210 核对两份可信回执、原 Creator／Scope／请求及当前选定稿；Action／primary 在 fence、Formation 和 Book 锁内重核，容量后继不能绕过暂停。
- 本增量定向单元190 PASS、PostgreSQL16 PASS（含不同 Owner 与只有 evaluation locator 的自动扫描），两个审阅轴已关闭漏接发现。0209→0210 owned 备份／恢复升级保持原失败／结果／UNKNOWN 及原0209 guard。安装态原生副本经一次零发送容量故障完成真实 Action 与实时前沿检查，0新模型Effect；第一次报告脚本末尾字段名错误保留，第二副本修正报告后通过。
- 运行库同一 Creation 已原生登记 v4，并实际经过零发送容量后继采用原 World Action，0新增 World调用。第2章主 Planning已发送；完整 primary 结果采用及第2章正文尚待实际完成，不能以这个调用记为交付。
- 原已实现 timeout 删除路径保留可控时钟/故障注入、取消/失活/fence/迟到结果和完整结果恢复证据。本次真实修订本地进程 281477ms 跨旧270s完成。CLI0.162.0-alpha.17.2 公开 stream-idle 配置没有可验证禁用值，属于无法控制的上游限制；没有改成超大数值或声称远端限制已删除。

截至 2026-10-14T01:28:29Z 的实际新书交付：

| 项目 | 数量 / 结果 |
|---|---|
| 《炉火照仙途》未润色首稿 | 1/100，3030汉字，不达4000—5000 |
| 原生修订 | 1版，4390汉字，篇幅达标 |
| 当前工作选定 | 1章，4390汉字 |
| 正式接纳 | 0章 |
| 真实新书 Model Effect | 72 SUCCEEDED、10 UNKNOWN，历史与未知用量保留 |
| 真人评价 | NOT_RUN |

原生 Review/ReReview 关闭了篇幅与旧收束重复两项，同时留下 CH1_TRAVEL_DETAIL_01：旅行准备仍显重复。首稿、修订、选定稿分别原生导出，第1章编码助手阅读记录已保存；它不代替前10章跨两个原生组的报告。首稿请求含可空工作记忆字段，但模型未输出记忆，实际 Host 连续状态覆盖仍有缺口。实际账本含74个 gpt-6.1-sol Effect和8个授权备用 gpt-6-sol Effect；不能声称该历史固定模型。严格固定模型、推理、计划及共同前文的 A/B/C 配对、100章、文学目标均 NOT_COMPLETED；混合历史模型的工程样本不充当对照。书已按系统版本分段，不再称单一冻结 release 留出。金额 UNKNOWN_ACCOUNT_ENTITLEMENT，不是零费用。

## Merge Danger

**Door:** two-way for code and Pack activation; published additive migrations and retained execution history are preserved.

**Blast Radius:** generation.

影响正常新 Creation 的规划、World、Context、Writer、工作稿修订/选稿及恢复。新合同版本化，旧冻结请求继续可重放；候选工作进展与正式 Canon 分开。0210 及历史迁移的升级、备份恢复与完整回执复用只在任务 owned 实例/副本验证，不代表原实例或完整发布资格。模型调用或提示生效不能代替文学交付。本 PR 未授权合并；私有数据库、账号配置和原始用量材料未提交。
