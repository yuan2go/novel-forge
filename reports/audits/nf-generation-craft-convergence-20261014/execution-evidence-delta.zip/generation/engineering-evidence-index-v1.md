WP-NOVEL-GENERATION-CAPABILITY-REPAIR-01 — evidence index, in progress

Overall: IN_PROGRESS; novel capability and 100-chapter delivery NOT_PROVEN / NOT_COMPLETED.

Reproducible source and installation

- Main observed: 4b827faef9c5f9f4998a303ce8b4495037f047fb.
- PR #166 observed OPEN Draft: 5d0ca7447089b89b55230ef0657e5ec255d4d1ff; historical 399fc434 is not the execution head. No Draft was merged.
- Isolated code commit: e94973ef970fecb4fdc919a3168ac92334eb6cd1.
- Subsequent documentation-only commit: 2b0286c0f5a2c0cd57ec707d95b1d0786d90c662.
- Own branch: codex/wp-novel-generation-capability-repair-01. Original dirty checkout untouched.
- Runtime is non-editable wheel from e94973ef. See installed-runtime-verification.json for wheel hash, SDK versions, console entrypoints and installed module/source hashes.
- Existing migration chain through 20261013_0204; no new business migration in this delta, published migration bodies unchanged.

Relevant verification, not additive qualification counts

- focused-matrix-02.log: 388 risk-related unit tests passed.
- final-generation-unit.log: 84 focused generation/recovery/reextraction tests passed after final generation classification change.
- generation-postgres-04.log: 11 PostgreSQL checks passed, including real persisted native Chapter definitions before first model child, historical 2000 deadlines, historical attempt counts, scan pagination, result recovery and Canon reextraction.
- native-coordinator-postgres-04.log: native Book/Group past deadlines committed and read back before/after independent Chapter wiring; manual cancellation and mixed/invalid delegation negatives passed.
- native-creation-postgres-10.log: native generated naming and default profile activation passed with interrupted projection/result reuse.
- working-continuity-postgres-02.log: eight native scripted author-first chapters, selected working continuity and interrupted result recovery passed.
- installed-generation-behavior.log: 34 tests ran against installed modules, including silent process completion across injected 270/600/parent time, verified manual cancellation and PID reuse protection.
- final-static.log: architecture manifests, fitness, instruction ownership, generated Skills and documentation reality checks passed.
- Standards and Spec reviews completed; discovered durable deadline test gap and dependency-changed Craft coverage gap were fixed. These reviews are not runtime/literary qualification.
- Full unrelated/release qualification matrix NOT_RUN. Scripted tests remain scripted, and installed tests do not prove literary quality.

Host timer handling and boundaries

- PR #166 already removed host per-attempt subdivision, settlement margin and model process total timeout; Codex backend uses ProcessTimeout(None), OpenAI generation has no read/write timeout, DeepSeek removes socket response timeout after connection. Those repaired paths were verified, not recreated.
- Native empty Book/Group/Chapter coordinator roots now classify before first model child through exact persisted contracts and scoped owner/Saga/delegation evidence. Mixed and irreversible work remains excluded.
- Deadline probe/scanner and native recovery paths ignore historical generation deadlines; scanner keyset pagination prevents exempt generation rows starving infrastructure deadlines.
- Canon reextraction no longer escalates solely on elapsed deadline or cumulative generations. New policy stores no generation deadline/count/cost cap; identical-result/no-progress diagnosis remains controlled and history remains retained.
- Creation healthy waits and unchanged scheduling yields remain backoff observations, not false CREATION_NO_PROGRESS. Scheduling windows yield between work; they do not interrupt a model.
- Cancellation, lease renewal, actual executor loss, fencing, result identity, late-result isolation and unknown usage remain enforced.
- Infrastructure connection, pool, lock/transaction and cancellation signalling protections remain.
- Installed CLI 0.159.2: offline real executable SSE probe shows stream_idle_timeout_ms=0 terminates immediately, 50 ms terminates, 1000 ms permits a 300 ms silent fixture. Public configuration does not provide a disable value. This upstream CLI limitation remains; no huge-number substitute was installed.
- Known actual native call completed at 342202 ms across the old 270-second boundary; this is one real observation, not complete end-to-end timeout qualification.

Narrative implementation and proof limits

- Ordinary fresh Creation now installs Chapter 3.0.3, prose Skill v5 / Template v15, event-first Planning 2.15.0 and long-outline v5. Frozen historical Formation profiles replay unchanged.
- Selected working prose v3, schedule UNASSESSED evidence and soft selected Craft allocation history are separate from formal accepted Canon and realized craft effects.
- Complete/current native prose root-cause evidence can inform only the next unexecuted PLANNED future plan; consumed report IDs enter lineage and idempotency. Frozen/executed plans and author core requirements retain their owners.
- Versioned FROZEN_SELECTED_RANGE currentness accepts append beyond the reviewed range, rejects changed reviewed sources, and leaves old full-manifest contracts unchanged.
- Native naming binds generated title to versioned Foundation task/Schema/recovery, then reads the active Book Design title without rewriting the immutable genesis Book record.
- These establish CODE_EXISTS / WIRED and bounded EXECUTABLE evidence. No assertion of literary improvement, human choice, formal acceptance or PRODUCTION_PROVEN.

Native execution and recovery

- Control A uses the former effective profile on repaired execution, fresh independent contemporary input. Native generated title: 那台机器还在响. No old novel prose was supplied.
- Independent new traditional cultivation work: project:author:a82e253a8edfe1294d71ff6e05cff8bad1c5871a5d15888a16617774ddcc9903; Formation story-formation:22526029247c0518ef4e460a63cb1eef5533c244f5c6d9c1691325b53bcac088.
- New work input: only author-level genre, quality, length and delivery scope; total 600, first 100, 4000–5000 Han/chapter, no hand-written title/world/plot/sample. Default native Pack activations were read back as ACTIVE 2.15.0 / 3.0.3.
- Runtime model/reasoning fixed at gpt-6.1-sol / high. Raw frozen requests, dispatches, stdout, result files, process receipts and UNKNOWN records are retained in private evidence.
- A real response-body stream failure and two workspace discovery failures were retained. Read-only Doctor showed inference endpoint timeout with direct networking and reachability using the already-configured macOS proxy. Task-only HTTP/HTTPS proxy environment was corrected; system configuration untouched. Native successors preserved original IDs/history and resumed the same works.
- Shared port 55483 then crashed on system-disk ENOSPC. No original cluster restart or source data modification was performed. Stopped-source physical copy plus separately copied tablespace recovered on task-owned DevSSD port 55577; DB nf_gen_cap_repair_20261013, OID 1925316 and system identifier retained. Copy is a recovered task runtime, not proof of the unavailable original instance.
- Snapshot pg_amcheck passed; historical NOT VALID constraints were retained rather than forcibly validated. A local complete/VALID model result from the interrupted commit remains available for native recovery before any successor generation.
- One diagnostic search accidentally included private environment credentials. Private files are excluded from further searches and from this report/code/PR. Copy-role credential was rotated; original shared role was not altered.

Actual delivery at this version

- First drafts: 0/100. Native revisions: 0. Selected: 0. Han-length compliant: 0. Formally accepted: 0. Human evaluation: NOT_RUN.
- A/B/C prose comparison: NOT_COMPLETED. B/C paired outputs and randomized model comparison NOT_RUN.
- First ten reading report across native groups: NOT_RUN.
- Current dynamic counts/phase/latency/usage are in append-only delivery-observation-*.json. Neither Foundation assets nor successful calls count as prose delivery.

Current segment, 2026-10-14 CST (supersedes current-state descriptions above; histories retained)

- Installed non-editable release f423b34a; verified source hashes and actual forward migration 0205. Fresh install and previous-head upgrade passed; final DDL native generate/scan/cancel-race: 3 passed. Private backup restored with unchanged Operation/Attempt/Effect/generation fingerprints.
- A original complete Planning result reused by native v2 recovery: original FAILED_RETRYABLE Operation and its one Attempt retained; one original SUCCEEDED Effect, no resend of that request. Current A has progressed to Arc planning.
- Latest main 198a3c12 includes the earlier task commits through 1b312e63 via PR167, plus evidence-only additions. No independent business-code delta to duplicate. This task did not merge PR166 or PR167.
- CLI actual version changed to 0.162.0-alpha.17.2. Its offline SSE probe again shows no public disable value for idle timeout. Host timeout deletion does not remove this upstream limit.
- New book remains the same identity and generated title 炉火照仙途. Current blocker is an immutable unstarted isolated successor registered at old release. The v4 Owner extension is under focused regression and review; not yet installed or qualified. Failed regressions retained, including a missing outbox operation identity and invalid non-live Opening consumer attempt, both corrected for rerun.
- Actual prose stays 0/100; native revision/selection/length compliance/acceptance: 0; human reading and ten-chapter report NOT_RUN; A/B/C paired prose NOT_COMPLETED. Successful Foundation/planning calls are not novel delivery.

Installed recovery segment, 2026-10-14 00:42 CST

- Commit b49c205c72cc948b6becdd325388b674c7d0cd1d is clean and installed as a separate non-editable wheel in venv-releases/b49c205c. Installed-runtime-b49c205c.json binds 14 installed module hashes, actual console entrypoint, SDK configuration and migration head 0205. The active A environment remains f423b34a.
- Existing native continuation Owner v4 appends an authorized deployment binding for an isolated, unstarted pure generation successor. Frozen semantic/runtime fields are compared, original continuation/source/UNKNOWN history is retained, and successor admission locks and rechecks the binding within its UoW. No new parallel recovery framework or migration was introduced.
- pending-deployment-postgres-07.log: controlled connection interruption, two concurrent same-key registrations, stale worker admission rejection before any Operation/Provider call, normal Creation/Opening recovery, one successful successor and post-start replay passed. Earlier failed fixture runs 01–05 remain retained. Relevant 49 unit checks and static/manifests/docs passed; Spec and Standards review findings were closed. This is bounded engineering evidence, not literary qualification or the full release matrix.
- new-book-release-activation-b49c205c.json records scoped native Reader/Planning/Chapter activation. installed-native-pending-deployment-recovery-01.json records actual Owner operation 010075e4-5b70-4c9a-8719-19957d896cfe, unchanged original continuation and UNKNOWN effect, and the successor's actual b49c205c Attempt/Pack snapshot.
- Actual native new-book volume 5 result is now saved; volume 6 is generating. A completed Opening with Book READY and is continuing into its native Chapter path. Neither planning result is counted as prose.
- collect_delivery_evidence_v2.py is a read-only observer. Each Effect is bound to its persisted Attempt/Pack release, complete prose versions are read back without alteration, native effective sources are resolved through the existing Owner reader, and explicit work selection is counted separately from raw default source usage. Its first two schema query errors were corrected before the first successful observation; neither caused a business mutation or model call.
- delivery-observation-v2-2026-10-13T164216-258409+0000.json: 54 SUCCEEDED, 9 UNKNOWN, 2 DISPATCHING model Effects; independent-book first drafts 0/100, revisions/explicit work selections/native deliveries/length compliance 0. Human feedback and ten-chapter report NOT_RUN; paired B/C NOT_RUN. Source and runtime version segments remain disclosed; this is not an untouched single-release holdout.
- CLI 0.162.0-alpha.17.2 idle-limit removal remains unavailable through the verified public configuration. Host timer repair does not establish removal of this upstream restriction. Full 100-chapter delivery and sustained-reading goal remain NOT_COMPLETED / NOT_PROVEN.

Actual invocation correction, 2026-10-14 00:58 CST

- native-cli-actual-argv-2026-10-13T165721-941349+0000.json records live process arguments, not environment secrets. Actual flags include project_doc_max_bytes=0, disabled host Skill/tool/plugin/memory discovery, --ignore-user-config, --ignore-rules, read-only sandbox and the isolated codex-workspace. No claim of remote prompt attestation is made.
- The earlier statement that all runtime calls were fixed to gpt-6.1-sol was inaccurate. Persisted Effect model_id and live argv show gpt-6.1-sol and gpt-6-sol, both high. The native template permits an alternate authorized route only after a stopped original pure invocation is durably isolated; this is present in the run history. Strict paired inference will require its own exact per-stage model binding and disclose these preceding calls rather than treating them as a fixed-model comparison.
- Control A suffered one more real response-body stream disconnection. Original effect eb4c17fd-1441-4b25-9d56-2cf72fb05149 remains UNKNOWN, Attempt CANCELLED with GENERATION_ATTEMPT_ISOLATED and remote cancellation NOT_ESTABLISHED. Its authorized successor 9d89e5ad-0b58-4ad7-92f4-3907437687f9 is running; this is connection-failure recovery, not a wait-time or idle-triggered retry.
- delivery-observation-v2-2026-10-13T165805-158910+0000.json now records actual model IDs alongside releases. There are 58 SUCCEEDED, 10 UNKNOWN, 2 DISPATCHING Effects across the two works. All six new-book volume plans are saved, initial Book/character Arc scope is running, and actual prose remains 0/100.
- Draft PR168 is published and attached to the task: https://github.com/yuan2go/novel-forge/pull/168 . Exact base 198a3c12 and HEAD b49c205c were read back. It contains only f423b34a and b49c205c, was not merged, and reports the incomplete prose/comparison/qualification boundary.

## World contract correction and real capacity counterexample — 2026-10-14

Release 545d7f5309b5de06afc0f7dd889f1f9a683d33a6 introduced native source/task v3 and migration0206. Focused units174PASS; native v3/legacy-result recovery/guard3PASS;205 upgrade/restore1PASS. Actual noneditable wheel982source files and11launchers matched; SDKread/writeNone. Owned database1925316 on55577 upgraded after dump/restore; original failed World and its two complete outputs preserved. Native Creation registered six exact public field resolutions for source31407403, without rewriting its FAILED_FINAL state.

Actual subsequent execution exposed a failure not covered by the first fixture: successor f7cf164b-a3d0-429d-bd1e-9483b007fcd4 failed before World materialization because required65,434serialized bytes exceeded64,000task budget. Capacity successor dd9dacc2-4faf-4a16-86a8-1ae178a3e65f lost the World revalidation reference and invoked World again. Original and new effects are retained. This is a negative actual-Provider result; no claim of installed no-repeat recovery is made. Full records: control-a-world-revalidation-registration-01.json, control-a-world-revalidation-dispatch-observation-01.json, control-a-world-revalidation-successor-observation-01.json. The first filename is actually control-a-native-world-revalidation-registration-01.json.

Release6bbb1cbf19eaf0527fb028dccc895f5f64bc2fa9 repairs proof inheritance through the existing capacity Owner and adds0207source/parent/Creator/Book/proof guards. SourceDrift failure in native-capacity01 is retained; corrected native-capacity02 has5PASS, including complete Creation with two original World calls and zero World resend. Latest upgrade/backup/restore fixture1PASS;62focused unitsPASS;Spec/Standardsstatic reviewsPASS. Installation and original runtime recovery are separate checks.

Four historical coordinated-contract unit failures were reproduced unchanged in isolated b49c205c archive (4FAIL/29PASS); frozen hashes were not changed. A shared disposable-test preflight concurrency deadlock is retained in native02; serial native03 passed3checks. These results are not full release qualification.

Independent new-book prose remains0/100 at the latest saved observation, with no raw/revision/selected/formally accepted chapters. A/B/C strict paired prose, first10report and human reading remain NOT_RUN/NOT_COMPLETED. Earlier mixed gpt-6.1-sol/gpt-6-sol high routes are not a fixed single-model paired baseline.

## cac05640 / 0208 exact-source sibling recovery

Actual control-A DD retained a complete source.v3 generation (0be020f1-b727-4081-a5b1-cb53d2f97867) and an UNKNOWN Director (4d64240e-7fcf-4eb3-8776-31f44f6ff63e). Its isolated successor 21d8c069-d44a-4d80-b9b5-a658f5180879 failed before any send because an older Director belonged to another frozen source. `control-a-complete-world-sibling-failure-01.json` retains that negative evidence.

Commit cac056409abdffec0b818d2e2b823a16a1d5282d filters isolated stage reuse by exact source and appends native `world-isolated-source-correction.v1` for that exact unsent failure. It retains original Creator, current frontier, trusted complete receipt, UNKNOWN and terminal history. Pending deployment and later unsent capacity carry/revalidate correction and isolation; 0208 SQL guards reject marker-only authorization, wrong Creator/receipt/frontier/cancellation and proof loss/drift. Prior published migration bodies remain unchanged.

- Focused source unit checks: 120 PASS; narrow Ruff, documentation reality, migration manifest and architecture fitness PASS. Full release matrix NOT_RUN.
- `world-source-correction-postgres-01.log`: 9 PASS, exact-source SQL guards, capacity inheritance and 0207 upgrade/restore.
- `copied-native-case-world-source-correction-03.json`: source override on captured private copy; native Owner register/idempotence/Kernel admission only, zero calls.
- `copied-native-case-world-source-capacity-04.json`: captured copy zero-send capacity successor admitted, exact complete sibling/isolation proof retained; subsequent repeated injected failure stops at real 226128-token request capacity, no model sends. Complete stage consumption/real Provider recovery NOT_RUN in this copy.
- Earlier copy attempt 01 was stopped by process NO_MODEL_DISPATCH before Attempt. Attempt 02 auto-recovered and admitted capacity successor, then reached real context ceiling; its oracle expected the initial exception and failed. Attempt 03 queried a non-exposed decision field and failed. All logs remain, final 04 uses persisted Owner records and preserves history.
- `installed-runtime-cac05640.json`: actual noneditable wheel, 984 source hashes and 11 actual launchers match; SDK read/write=None, connect/pool=30; uncontrolled upstream CLI idle limit remains.
- `database-0208-install-cac05640.json`: exact owned production OID1925316/cluster7695026994287073315/port55577, pre-upgrade backup, restored copy upgrade and production upgrade PASS; legacy World helper and positive-only depth preserved.
- `control-a-world-source-cac05640-activation-01.json`: scoped Reader/Planning/Chapter activation; original Attempt snapshots unchanged. Native Creation continuation is in progress; no full recovery claim yet.

Latest before-source-release observer at 2026-10-13T19:41:22Z: 86 SUCCEEDED, 12 UNKNOWN, 1 DISPATCHING across both task Books; independent new Book 52 SUCCEEDED/8 UNKNOWN/1 DISPATCHING and first draft 0, revision 0, working selection 0, length-compliant 0, acceptance cursor absent. It remains a versioned engineering recovery book, not an untouched single-release holdout. A/B/C paired prose, 10-chapter reading report and 100-chapter delivery remain NOT_COMPLETED; human evaluation NOT_RUN.

## Actual installed recovery and prompt input proof, 2026-10-14 04:03 CST

- `control-a-installed-world-source-reuse-01.json`: actual installed cac05640 source correction successor 16dd1d9b-4c00-4a26-90ba-e7f998c6cc9c reuses DD's exact complete generation; no additional World generation Effect. One missing Director completes as c216fe58-6d78-4898-8fc1-0e4e60e0d0f2, original 4d64240e... remains UNKNOWN, original 21d8c069... remains FAILED_FINAL. ChapterPlan 4d27de8b... subsequently succeeds (424761ms) and Book becomes READY. This is bounded actual native World reuse/Director/Planning evidence; no prose or literary completion claim.
- New Book Opening finishes all nine Arc scopes and boots Book run 86a75a74-c326-47cc-a857-d983484ed537 with native target 100. `new-book-chapter-cac05640-activation-01.json` activates same-contract normal Reader/Planning/Chapter at the completed Opening checkpoint and preserves original snapshots. Native `authority-creation continue --foreground` now advances this Book's Chapter chain; no new book rebuilt.
- `native-prompt-bindings-index-v2-2026-10-13T200306-964612+0000.json`: 105 actual Effect requests, 105 exact frozen admission prompt hashes match full reconstructions, 105 corresponding process-record stdin hashes match. Full reconstructed Prompt text, frozen materialization (System/Template/Skill/Schema), actual request, admission and provenance retained under native-full-prompts/ and native-prompt-bindings-v2/. Reconstruction checked against actual process input identity is not literal wire capture or literary evaluation. First observer lacked sanitized execution-directory lookup and reported no receipt hashes; its index is retained, superseded by v2.
- Frozen request timeout_seconds=1800 in some legacy identities is compatibility evidence only. Installed ProcessTimeout(None) and generation SDK read/write=None remain the actual execution policy; no larger timer was substituted.

Working-frontier complete-result recovery segment — a08a33280349c9e6c85dbefd99792933faad19eb

- Current main198a3c12 and Draft PR168 HEADa08a3328 read back; original dirty checkout unchanged. Added forward-only0210 wraps the exact0209 guard, preserving old proof versions. New v4 retains current Director→generation→Source references and distinct original native stage Owners; no fabricated locator aliases. Cancellation/fence/current selected snapshot and Book lock guard Action and primary, including paused capacity successors.
- Focused unit190PASS; PostgreSQL16PASS incl automatic scan with ancestor generation Owner and only evaluation locator, two verified receipts and negative frontier/Owner/UNKNOWN cases. Earlier test collection and documentation inventory failures retained; final lint/manifests/fitness/documentation PASS. No broad matrix qualification claim.
- Noneditable wheel986 installed source hashes/11 actual launchers verified; SDKread/writeNone/connect/pool30, current migrations0210. Owned1925316/55577 backup restored to copied OIDs3239279 and3261430, original failure/results/UNKNOWN retained. First copied report script failed only at final missing dictionary key; second copied native run completed exact World adoption via one controlled zero-send capacity fault, live Action fence/frontier,0newModelEffects. Actual primary result and prose were deliberately not run in those copies.
- Main task runtime upgraded209→210 only after copy verification; exact historical rows and legacy guard preserved. Same-book native Creation v4→capacity→WorldAction succeeded with0newWorldCalls; primary Planning effectd63f00ab is active under885cdab3. installed-native-working-frontier-adoption-a08a3328-01.json records this engineering boundary, not Chapter2 prose.
- delivery-observation-v2-2026-10-14T012829-656913+0000.json: new book72SUCCEEDED/10UNKNOWN,74gpt6.1+8gpt6; initial1raw3030Han below length,1revision/selected4390Han compliant,formal0,humanNOT_RUN. Historical model mixture disclosed. Full first10 reading report, strict pairedABC and100chapter goal NOT_COMPLETED. Chapter1 reading report new-book-chapter001-reading-report-v1.md retains exact passages and preparation-density defect. Upstream CLI idle disable still uncontrollable.
