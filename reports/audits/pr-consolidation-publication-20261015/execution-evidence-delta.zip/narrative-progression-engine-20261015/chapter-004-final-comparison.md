# 第 4 章完整模型首稿验证

**真实模型首个完整 final output：4194 汉字，长度 PASS，已保存并整章读回；没有人工改写、追加段落或后续扩写调用。** 本任务读稿确认局部推进明显改善。该证据仍属于重建阶段输入的真实 Provider 实验，不是原 Book 的 native Saga、active Plan Change、selected/accepted 正文或生产资格。

## 原始结果与逐字来源

- [原第 4 章正文](../narrative-progression-engine-20261014/source/chapter-004-effective.txt)：4395 汉字。
- [新完整正文](medium-control/chapter-004-after-v2.txt)，[整合候选与字段](medium-control/chapter-004-after-v2.json)。首场 1123 汉字，第二场 3071 汉字，合计 4194。
- [真实进程回执](medium-control/benchmark-writer-receipt-v2.json)：`progression-writer-medium-d2c9ac05bde249f39734460f94f4ec0c`，SUCCEEDED，221933 ms，原模型 `gpt-6.1-sol`，本次 reasoning=`medium`，不是原 source 的 `high` 路由成功证明。
- [冻结输入](medium-control/benchmark-writer-input-v2.json) 与[实际 stdin 重放证明](medium-control/writer-frozen-input-proof.json)：原 Style、4000–5000 `HAN_CHARACTERS_V1`、第 1–3 章完整有效原文全部保留；原文无 omitted ranges。最终模块重放的 prompt 和进程 receipt input hash 一致。
- [完整独占会话/usage 审计](medium-control/writer-final-audit-ab5ec5ac.json) 和[最终消息对账](medium-control/final-correspondence.json)：完整会话 final_answer 与 task_complete 中的 JSON 逐字对应保存的原始结果；工具调用 0；Schema、连续 Scene composition、角色来源使用合同和正文整合检查通过。正文 SHA256 `188cb86d6db7897fbd58d56e2acf66bfffd641cfcf7e09652cd95c6bc2e139db`。

## 原文对照

| 部分 | 原章 | 新完整首稿 |
|---|---|---|
| 开头继承 | 复述昨日饭食/休息，进入旧工具问答与示范；后续大半章又安排生活收束 | 仅一过桥句交代饭和喘息，立即呈现严述双手被冷装占住、窄锉够不到的难处。已完成的试工、结算、初诊作为条件；只追问第 3 章尚未回答的“改作何用”，没有重新演示原夹具晃动或重新验证已定禁用判断。 |
| 中段行动与代价 | 工具解释之后转吃饭、回客舍、整理、洗手和休息；后半 2357 汉字，占 53.6% | 首次木托受偏压而凹陷，接缝退出已对位置，材料和时间都损失；许照提出让桌面承重，严述削掉木角，夹钳只合拢木托。改变布置后，严述确实腾出手取短销/窄锉，当前工作得到收益。第二场 3071 汉字，占 73.2%，围绕失败、调整、试用收益、工具权益与身体界限展开。该比例是场景字数，不冒充逐句动作统计。 |
| 利益与主动选择 | 对未来求教留问题，当前资源、关系和选项几乎回到原位 | 许照准备取回钳子会使冷装搁置。双方谈定次日午前归还、限冷台、不转借、损伤处理；求教不以借钳为条件。许照主动留下工具，暂时少一个携钳接零活的选项，也明确不能守到晚。对白改变真实使用权、期限和分工。 |
| 结尾情势 | 工具收好，靠稳休息，“今日不必再起身去把它们催定” | 木料已削、短销已截、旧支法已撤；原销被抽动，接合处张开。夹钳仍留作承托，借用截止时间成立。章末停在已经打开的当前工序，不是收包/睡下/等明天归零。 |

新稿开头：“用新得的工钱吃过饭，又歇到气息缓匀……先看见严述一只悬着的手。”此后没有吃饭、洗手、收包、休息的独立 filler 场景。短暂咳嗽和掌心疼痛影响握持与站立选择，属于行动摩擦。

中段关键区别是代价会改变手头工作，而不是换成反复测量或记笔记：“不是柄松，是木头让了”；凹损木条退出用途，原先接缝必须重新对位。许照随后贡献熟悉的搬放经验，未越过器物判断和专业操作边界。

最后实际动作是：“销身上原先藏在里面的一段已经露出，薄边下的缝也随之张开。”末句进一步确认接合已不能原样放回。后续需要承接拆开的工序、暂时失去工具的选项及归还期限。

## 判断与限度

- 首个完整模型输出 4000–5000 汉字：**PASS**。
- 逐字完整继承第 1–3 章输入、继承已发生结果而不重演已完成验证：输入绑定 **PASS**；本任务整章读稿 **PASS**。
- 大段日常收束循环消除、当前行动发生失败/调整/收益和有代价选择：本任务读稿 **PASS**。
- 不可逆的局部情势出口：本任务读稿 **PASS**。这是较温和、局部的前行动力；“普遍起点商业质量”、市场反馈与多章稳定性仍 **NOT_VERIFIED**，不能用单例升级。
- 独立人类文学评价、正式 Plan Change 采纳、原 Book native Saga/Context Retrieval lineage、作者 selection/acceptance：**NOT_DONE / NOT_VERIFIED**。没有伪造这些记录。

[optional working memory 检查](medium-control/candidate-working-memory-check.json) 为 LOCATED_UNREVIEWED，但 entries=[]、semantic_support=NOT_VERIFIED。它不提供新章后果的结构化验证证据；此处后果判断来自实际整章读稿，完整原文仍是后续工作语境的字面来源，不升级 accepted Canon。

本次 measured usage：input 55877、output 5454、total 61331（其中 reasoning_output 442）。会员账号金额不可观测，monetary cost **UNKNOWN**。三个失败 high 调用的最终消耗仍未知，没有以成功样本清零。推理配置同时发生变化，因此不把全体改善因果贡献独归叙事 prompt，也不把一次 medium 成功解释为 high 传输已修复。
