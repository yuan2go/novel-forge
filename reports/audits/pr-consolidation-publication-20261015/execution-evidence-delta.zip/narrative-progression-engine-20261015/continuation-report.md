系统改动、最终回归和真实第 4 章完整模型首稿已交付。最终代码 `ab5ec5ac738d7b0790d7f79770e4a9acc4452417`，隔离分支 `codex/narrative-progression-engine-20261014`，工作树干净；未合并、部署或修改原 Book 的 active plan/选稿/验收。

## 1. 证据归因

[完整原始诊断](../narrative-progression-engine-20261014/diagnosis-and-verification.md) 已读实际第 1–4 章、冻结 Planning/Writer 输入，并将重建 stdin 与原进程回执 hash 对账。此处不把报告摘要当原始证据。

- **Planning 重复/容量不足：主因。** 原第 4 章三场 conflict 全为 null；父级 `ending_hook.const` 固定吃饭、养身、下次再来。原章 4395 汉字中，2357 汉字生活收束，占 53.6%。实际原文、plan 和 schema 均保留。
- **Prior-context handoff：字面缺失已排除，语义导航薄弱为次因。** 原 Ch4 stdin 已完整包含 Ch1–3，有原 receipt hash 证明。selected=1 没有导致 Ch2–3 全文丢失；optional memory 当时为空，不能假称已有验证后的后果摘要。
- **4000–5000 汉字压力：显著放大因素。** 薄任务与强篇幅绑定共同存在；Ch1 首稿 3030→chosen 4390 的扩写及 Ch4 后半生活收束支持这一机制判断，不是单变量因果贡献百分比。
- **Writer 结构/表达重复：次因。** 先文提供了工具问答、吃饭、整理、休息的结构样本；原计划也直接要求这些段落，不能把全部重复单独归因于 in-context contagion。

关键原始证据：[Ch1–4 原文及输入目录](../narrative-progression-engine-20261014/source/inventory.json)、[Ch4 实际冻结请求](../narrative-progression-engine-20261014/source/draft-request.json)、[Planning materialization](../narrative-progression-engine-20261014/source/chapter_plan.generate-materialization.json)、[原 stdin 回执证明](../narrative-progression-engine-20261014/source/original-writer-stdin-proof.json)。

## 2. 系统 diff 与测试

完整[最终 patch](system-upgrade-final.patch)及[叙事链核心 diff 说明](../narrative-progression-engine-20261014/system-diff-and-tests.md)可直接审阅。全部新规则均为书籍/题材无关机制，无单书 lore、无 migration、无 craft 集成、无 routine regex 或新的文学拒绝 gate。

- `working_prose.py` / `manuscript.py`：新增 v4，逐章采用 committed accepted → 有来源的 working/editor selection → 完整 native effective prose，稳定排序并记录原 hash/来源。v4 明示缺章和无法完整覆盖历史的预算问题；不改真实 selection/acceptance。v2/v3 payload、旧 instruction/hash/replay 保持历史兼容。
- Planning / frozen input：本次 correction 不再丢失于 narrative projection；在现有 goals/conflicts/beats/exit fields 约束开场阻力、中段有代价行动与调整、结尾情势改变。保留父级 const；旧静态父级合同需要 owning Plan Change，不能让 Writer 偷改。
- Writer：v4 实际 system overlay 锁定已实现情节为前提，压缩日常桥段，向当前任务的行动/阻力/利益协商分配篇幅，要求开放行动出口。记录 working snapshot、overlay 与 effective system hash，保留原 Pack artifact hash。
- 运行隔离：新增显式 `codex-input-only.v2`，在模型控制层绑定结构化生成职责，并读取该调用自己完整的 durable transcript，补足 stdout 漏掉的 custom tool calls。沿用既有 Tool 授权边界；旧回执是否使用新审计由当时冻结证据决定。实际 CLI 的 `final_answer` 标记已纳入明确终稿兼容，旧 `final` 也保留。没有通过放松文学检查或改写回执取得成功。

验证绑定最终 SHA，见[机器结果](test-results-ab5ec5ac.json)：

| 检查 | 结果 |
|---|---|
| 新运行策略、真实 backend 工具审计、旧结果恢复、continuation focused | **138 passed**，[日志](policy-focused-final-marker.log) |
| 全量 unit/architecture | **5875 passed，28 failed，1508 subtests passed**，[日志](backend-final-ab5ec5ac.log) |
| 与未修改 main 的失败集合比较 | 28 项逐项相同，**新增失败 0**；按用户决定保留叙事链范围 |
| 修改文件 Ruff | **PASS**，[日志](changed-files-ruff-ab5ec5ac.log) |
| P0 source-preflight / documentation-reality | **PASS / PASS**，[完整报告](p0-ab5ec5ac.json) |
| P0 static | **FAIL**：原 main 的 `test_working_manuscript_revision.py E701=18`；[独立基线与逐字文件证明](static-baseline-proof.json) |
| P0 后续依赖关卡 / cleanup | **NOT_RUN / PASS** |

此前叙事链 344 focused +5 subtests，以及原生 scripted PostgreSQL 11 项通过记录保留在原说明中，不冒充本轮 Provider 策略的 native Book 生产验证。中间失败、文档投影更新和 CLI 兼容修正的日志全部保留。

## 3. 原文验证

[新完整第 4 章正文](medium-control/chapter-004-after-v2.txt)为真实 `gpt-6.1-sol` / `medium` 的首个完整 final output，**4194 汉字**，已保存并整章读回，没有人工补写、修改或后续扩写。完整[前后对照与证明](chapter-004-final-comparison.md)包含原句、篇幅落点、schema/整合结果、输入 hash 和独占会话对账。

- 开头：一过桥句处理饭与休息，立即看见严述腾不出手的冷装难处。只问 Ch3 尚未回答的改用途问题；不重演试工、结算、初诊或已完成的原夹具验证。
- 中段：承托失败损耗木料与已花时间；许照提出桌面承重，严述削改木托，调整确实腾出手。随后借钳协商改变使用权限、归还期限及许照携工具接零活的选项，身体界限也参与选择。
- 结尾：木角已削、短销已截、旧支法已撤、原销退出并打开接合。章节停在当前工序及借用期限上，没有收包/睡下归零。本任务读稿判断局部推进目标达到；强度仍偏温和，不宣称单例已证明普遍商业质量或多章稳定性。

实际 stdin 重放完全一致，原 Style 与 4000–5000 Han profile 未改，第 1–3 章全文均在。独占会话工具调用 **0**，final_answer / task_complete 与保存结果对应；Schema、连续 Scene composition、角色来源使用合同和正文整合通过。221933 ms，measured input 55877 / output 5454 / total 61331。会员金额不可观测，cost **UNKNOWN**。

原 `high` 配置两次旧调用及本轮 high 调用仍因流解码中断无 final result。[本轮原 ID 对账](writer-v2-unknown-original-reconciliation.json)、[此前原 ID 对账](original-id-reconciliation-001.json)、[全部本任务调用账](benchmark-invocation-ledger-ab5ec5ac.json)保留三个远端/最终用量未知结果。medium 是明确记录的同模型配置对照，不是生产路由变更；成功不证明 high 传输故障已修复，也不清零失败消耗。

## 审计与资格边界

[最终原库只读复查](original-readonly-sentinel-002.json)：库 `nf_gen_cap_repair_20261013` / OID 1925316 / 端口 55577 身份一致，**selected=1、accepted=0，原 1–4 章有效资产逐字未变**。本任务原库业务写入 0，第 5 章调用 0。

新候选仍属 `RECONSTRUCTED_STAGE_INPUT_REAL_PROVIDER_NOT_NATIVE_SAGA`；其上游计划是 proposal，未 active/adopted。没有虚构 native Operation/Attempt、Context/Retrieval receipt、选稿或验收。optional memory entries=[]、semantic_support=NOT_VERIFIED，后果判断来自实际整章读稿，不升级 Canon。

代码证据为 **EXECUTABLE**。完整 Book native 闭环、正式 Plan Change、独立人类商业评价及生产资格 **NOT_DONE / NOT_VERIFIED**；P0 也受已列明基线阻塞，不能宣告整体 **QUALIFIED** 或 **PRODUCTION_PROVEN**。
