# WP-FRESH-NOVEL-SAME-BOOK-CONTINUITY-02

执行任务说明；PROPOSAL / NOT_RUNTIME_AUTHORITY。当前任务完成的是只读审计与工作包，未执行恢复、Provider 调用、部署、迁移或业务写入。

## 目标与结论

沿同一本书的现有原生链继续，保留全书600章、每章4000—5000正文汉字、首期100章。优先保证恢复边界与正文生产连续性，最终以100份精确选定正文版本、完整读回、汉字统计和导出清单验收；优秀起点网文的持续追读质量另以全文与独立文学/读者证据判断。

最新远端 main：`7da00883935741651f59afbffd39270db4fa8eea`，PR #162 合并于2026-10-11 18:55:59+08。其 src/config/migration-manifest 相对历史部署 `30450f3cc24e1efba95f84e1a24e90d74765cee2` 无差异。28份执行记录加 PUBLICATION.md 共29个新增文件，保存的是中断历史，未恢复运行。

原实例本轮可访问。2026-10-12 00:49:23+08 的只读 REPEATABLE READ 观察：Foundation COMPLETE/READY v12；旧 Opening ABORTED v4；同书修复 Opening RUNNING v7 / execution generation 6 / checkpoint sequence 36；BookRun 0；正文交付0/100。47个成功 model.invoke、4个 UNKNOWN、1个 DISPATCHING。当前调用有 HELD 租约及近期心跳，原执行器正在继续工作。该时间点后状态可继续变化，执行前必须刷新。

## 固定业务身份

- 数据库：`nf_fresh_novel_e2e_20261011`；OID `844792`；cluster `7695026994287073315`。库名一致不足以证明原实例。
- Project：`project:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537`。
- Workspace：`workspace:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537`。
- Book：`book:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537`。
- Formation：`story-formation:758b56a9b8091f0a4d9f94124e29d2e2d9e325333325c2df8a7211eeea78c015`。
- 原 WORLD_BIBLE Operation：`ce6af95d-fd71-425a-bc62-4bcff9da944a`；Effect：`24e92484-187d-4b3a-8e52-cb9335079bd1`；Dispatch：`60b08611-cd8d-4b69-993e-374b3393d77d`；Attempt：`20044721-49a5-49a5-b5a4-8bc32135a20b`；fence=1。
- 原 Effect request hash：`sha256:422ac5c0f81789a05f9f1f9e8eb14a7db19af6bee81875e33f196585f544d59c`；本地 execution request digest：`2d2ffdd609b52b0f7802dd23db20666d3891b57ed85bb8f6d18d40f0b22f769d`。两者属于不同合同，不应强行等同。
- 原 Opening：`book-opening:e45e7981cb3cd4d35389a66099497c32d8c907f9ed520f137559605b177448ab`。
- 当前 Opening：`book-opening:bee80d667d761eb59730fc01187a325d9bd982d28dc12bb05c488d317a82fcee`。
- 当前观察的 DISPATCHING：Operation `deb9cbf2-9b99-4500-a347-5d569d74fc85` / Effect `3a913943-53ef-4c77-b2ec-4a63a199d91a`，logical key `character:character:xuzhao`。这是当前规划调用，不是原世界观调用。

## 原调用的历史结果与账务

发布日志最后停于2026-10-11 17:07:58+08，本地 RUNNING / result_integrity=MISSING。发布的 current-model-accounting.json 只有4对 call-log/cost-ledger，总计109267 measured tokens；较晚世界观快照计数5次成功。第五次成功的完整账务及第六次未决调用不能由这份较早账务导出补齐。

本轮原库核查：原世界观 Operation FAILED_FINAL，Effect/Dispatch UNKNOWN；本地 receipt ORPHANED/MISSING，原 supervisor 不存活。19:20:53+08 原生 isolation `41378a95-6e5e-4598-8b26-d40cbbdf5f85` 与同书 continuation 已保存；后继 `1a7447fb-7545-429e-8c02-42cc60c53481` SUCCEEDED。无需重复隔离或再生世界观。

原 reservation `4d70d1cf-540b-439c-a781-23fee7276093` 仍 HELD_UNKNOWN；estimated_tokens=130380；actual_tokens字段=0；结算成本状态 PENDING。这是缺测量时的保留值，不是零消耗证明。route 为 codex-cli / gpt-6.1-sol / ACCOUNT_ENTITLEMENT，货币成本与 provider_billed 未知。00:47:33+08 已结算46次成功调用共2295329 measured tokens；此后计数已增至47，必须逐-call重新导出，不能沿用旧合计。

隔离撤销旧业务提交/激活权，保留远端结果与用量未知。后继成功不证明原远端取消或未执行，也不保证原调用没有消耗会员额度。迟到原 receipt 只走身份校验、追加证据及幂等账务对账，不恢复旧产物或激活权；账本重复结算防护不等于证明 Provider 从未发生额外消耗。

## 按顺序执行

1. **只读刷新，先对账文档和部署。** 阅读 docs/README.md、current-system.md、runtime-operations.md、development.md，核对 reality-evidence、production/worker/migration manifests。将 PR 历史、当前 DB、当前 installed wheel/Pack/Attempt 分别列明。原现场目录为 `/Volumes/DevSSD/Development/Workspace/evidence/wp-fresh-novel-end-to-end-diagnosis-01`；env.private.json 只作连接配置，不打印或发布凭据，不执行未知辅助脚本。导出新的带时间/身份快照，保留旧文件。
2. **保留当前执行器。** 当前 Opening/规划 Effect 有活租约时只观察原心跳和结果；不并发 recover、drive、重开或部署。若变为成功，复用原完整输出/receipt，交给原 owner 推进。若失联，由原 Kernel/execution loss 路径核实进程身份、lease/fence、完整输出及 durable receipt 后收敛；不得手工 UPDATE 状态或杀进程充当远端取消证明。
3. **收敛现有版本与当前 Opening 的入口。** 现场配置 release=`1b2aa05f8ceab039a01fc8613a0a0ee257d2f85a`，已安装 opening.py、story_planning_runtime/execution.py、generation_isolation.py、service.py 四处字节哈希匹配该提交；完整 wheel、实际 Attempt 的 release/Pack/source/schema 哈希继续核实。200项 migration 的 head 为 `20261011_0199_plan_change_capacity`。该 release 未合入 main，先审查既有 `b5ed4346101fd849073f6fea4395c173121bc3d2` 与 `1b2aa05…` 修复，不以报告合并代替部署收敛，不用 main 覆盖活现场。
   - 现 main 的 creation_runtime 固定查询 `${formation}:opening`，旧 ABORTED 会返回 CANCELLED；status 也可能只显示旧 frontier。修复范围应是以原生 lineage 解析当前 Opening，使 status/continue/recover 显示同一现行 frontier，重复及失联响应仍复用原身份。禁止凭“最新时间”选择任意 Opening。
   - 现场 `repair_unwritten_opening.py` 已审读，编排 existing opening.reopen_unwritten、native recovery/worker 与 Book start；它是私有调用器，不是 main 的公共能力。当前已有 successor Opening，禁止再次 admit/reopen。可继续使用核实后的当前 installed owner 精确 handle；对外入口收敛沿既有 Authority/UoW，不建新调度器、账本或替代 Book。
4. **完成当前 Opening，再启动同书唯一 BookRun。** 继续当前 Opening 的节点/规划前版本及精确 parent/hash，保留已完成 Foundation、非等长六卷范围和旧失效规划历史。RUNNING且有租约等待；失联用 assess-execution-loss→converge；FAILED且 blocker 合法解决后用 assess-recovery→recover，随后原 worker 精确 claim 当前 Opening。COMPLETE 后消费其原生 input_snapshot，经现有 `resolved_book_command`→BookAuthority.start，production key 固定 `${formation}:production`，window=100。响应未知先查原 key，不再 start。600是全书目标，100是一期窗口，不将目标改写为100。
5. **正文先过首章，再连续推进100章。** 原生 Book→Chapter Saga→Draft→manuscript delivery；每章保存、读回并记录精确选稿版本/hash/正文汉字数，完成后精确版本导出。Draft已完整成功但 delivery 失败时恢复交付，不再调用 Writer。持续检查实际 working-prose-projection.v3 输入（历史100章/最近2章完整/40k）、当前前文版本、Intent/Memo/Context一致性及旧书输入隔离；配置存在不等于 Writer 实际消费。正文长度不足、事件重复、人物经验失忆和追读动力不足，定位到最早原生 Foundation/Plan/Scene/Context owner，结构变更走 Plan Change；表达修订走原生编辑/修订。不得让审计或执行治理语言成为人物行动约束。

## 恢复准入分支

DISPATCHING→QUERY_EXISTING，原 Operation/Effect/provider/request/Attempt/fence；query 不能发送新生成调用。缺远端request ID或query能力则明确保留 UNKNOWN。不能将“没有找到文件/本地超时”判为远端未执行。

完整保留结果优先走原生本地结果恢复/最终提交窗口；终态失败用受约束的 linked result recovery，不改终态历史。真正未决且原 writer/dispatch lease 已结束、无可恢复结果、纯生成/tool/权限/身份/预算条件全部成立后，才使用现有 isolation＋bounded continuation；保留 original UNKNOWN/HELD_UNKNOWN，继承整个逻辑任务失败上限，禁止重置计数、另换业务 key 或扩大付费授权。当前会员授权不自动授权新的付费渠道。

## 必要验证与验收

本轮代码测试、构建、hooks、Provider 调用、恢复/部署/迁移：NOT_RUN；实际只读身份/状态/原调用隔离及后继/保留账务检查：PASS（有界事实）。恢复能力不升级为 PRODUCTION_PROVEN；本书文学质量及真人持续追读证据未成立。

如仅复用已验证现有机制，不重跑无关测试或完整资格矩阵。若修改代码，仅覆盖能改变结论的分支：过期 post-send lease 不重复 send；完整结果复用；原 key replay；当前 Opening lineage解析；活租约/跨Book/旧ABORTED误路由拒绝；迟到receipt settle-once/conflict/缺usage保留hold；Book start失联幂等与Draft成功后交付恢复。使用现有单元/受控PostgreSQL用例；实施修改后按 runtime-operations 的完整适用矩阵做精确SHA工程验收，失败基线保留。fixtures与工程PASS不替代原实例receipt、正文或文学证据。

完成条件分开报告：恢复链及用量对账状态；同书第1章真实完整保存读回导出；100/100选定正文且逐章4000—5000汉字；原生连续性与全文文学评价；作者选择；正式接受cursor；独立真人反馈。规划成功、调用次数、Foundation READY或export能力文案均不能计为交付。

若原实例再次不可达：报告 BLOCKED，具体列出缺失的DB/cluster、migration、installed build/Pack、Opening/current node、lease/fence、original/late receipt、reservations和manuscript版本；从原现场/一致性备份补取，不从GitHub JSON bootstrap替代生产实例，不假称已恢复。

## 核查来源

- [PR #162](https://github.com/yuan2go/novel-forge/pull/162)；所有发布证据固定于 `7da00883935741651f59afbffd39270db4fa8eea` 下 `reports/audits/wp-fresh-novel-end-to-end-diagnosis-01/checkpoint-publication/`。
- 主main：`modules/book_authority/creation_runtime.py:288`、`:349`、`:695`；`modules/book_design_authority/formation_generation.py:64`；`modules/command_kernel/external_effect_runtime.py:98`、`:1372`；`generation_isolation.py:231`；`saved_result_recovery.py:12`；`generation_receipt_reconciliation.py:27`（均在 src/novel_forge/）。
- 同书恢复与正文链源码审计：`/tmp/novel-forge-pr162-native-recovery-audit.md`。
- 本轮直接只读记录：`/tmp/novel-forge-pr162-live-readonly-20261012.json`、`/tmp/novel-forge-pr162-live-reconciliation-20261012.json`、`/tmp/novel-forge-pr162-current-summary-20261012.json`。这些是带时间证据，不是常驻运行账本；不包含连接凭据，未经另行审查不发布私有现场内容。
