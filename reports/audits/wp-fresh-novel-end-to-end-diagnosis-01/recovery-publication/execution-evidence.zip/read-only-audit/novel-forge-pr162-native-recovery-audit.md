# 同一本书原生恢复核查

只读源码基线：`7da00883935741651f59afbffd39270db4fa8eea`，源码副本 `/tmp/novel-forge-pr162-audit-20261012`。父审计核实最新 main `30450f3cc24e1efba95f84e1a24e90d74765cee2` 与该基线 src/config/migration manifest 无差异。本文是研究笔记，不是 canonical 文档或生产恢复凭证。本分工未直接连接原数据库，引用下述父审计当前只读事实；本轮均未执行测试、Provider、恢复或业务写入，测试 `NOT_RUN`。

## 当前现场更正

父审计在 `2026-10-12 00:46:47+08` 以只读 RR 验证原库 `nf_fresh_novel_e2e_20261011`、OID `844792`、system identifier `7695026994287073315`。当前 Formation 已 `COMPLETE/READY v12`；旧 WORLD_BIBLE Operation FAILED_FINAL / Effect UNKNOWN，在 `19:20:53` 已原生隔离（isolation `41378a95...`），linked successor `1a7447fb...` SUCCEEDED。原 reservation `4d70...` 仍 HELD_UNKNOWN，estimated tokens `130380`、actual_tokens `0`不是零用量证明。旧 WORLD_BIBLE 已不是当前生产 blocker，但原结果/计费尚未清账。

当前 repaired Opening `bee80d...` RUNNING v7 / execution generation 6，旧 Opening `e45...` ABORTED v4；BookRun尚无，正文尚不可证明。当前有真实 HELD Effect lease，禁止并发recover/drive。现场成功46 / UNKNOWN4 / DISPATCHING1是当前逐时统计，不应混为PR历史5成功/1DISPATCHING。现在最先识别当前 DISPATCHING 的 call identity、lease expiry/owner/process/receipt，再等原 executor收敛；不回到旧世界观反复恢复。

现场安装源码 `1b2aa05f8ceab039a01fc8613a0a0ee257d2f85a` 不在main祖先；父审计核实安装 opening.py/execution.py/generation_isolation.py/service.py读回字节符合1b2提交。原目录 `repair_unwritten_opening.py` 调现场新增 `opening.reopen_unwritten(source=e45...,expected_version=4, stable key=${formation}:opening:range-repair-01)`，然后原生 execution-loss/recovery assessment + converge/recover，`claim_next_execution(expected_opening_run_id=bee...)`；Opening COMPLETE后调用 `resolved_book_command(snapshot,run_key=${formation}:production,chapters=100)`→authority.start。这是现场已存在的同Book修复链，不能将未合并 `reopen_unwritten` 说成 main现有CLI/API能力。

本轮最终工作包应先冻结两份真实 release（main 30450、现场1b2）与current repaired Opening identity，查清 native reopen证据/输入/预算继承与哪一个worker/helper仍持有当前dispatch。只有停止或确认没有活writer后才能按当前node事实恢复；不从Formation continue命中旧 ABORTED Opening，不新建Book、不再次reopen。要在main支持该continuity，先审查/吸收已存在现场实现，而不是重新设计平行driver。

## 先决结论

`DISPATCHING` 不是失败或未执行证明。Kernel `classify_external_effect_recovery` 将其判为 `QUERY_EXISTING`（external_effect_runtime.py:98）。此时不能直接 `ISOLATE_PURE_GENERATION`：隔离准入只接受原 model.invoke 的 `UNKNOWN/RECONCILIATION_REQUIRED` 和符合限定历史 stopped CLI 的 `FAILED_RETRYABLE`，要求 owner 可恢复状态、原 actor、同 Project/Book、原 immutable execution manifests、无 `HELD` writer/dispatch lease、无可恢复 primary/domain output（generation_isolation.py:231-335）。先确认当前运行是否仍在执行并读取 original result，不能人为把历史快照写成当前 UNKNOWN。

原 dispatch 的合法失联收敛已经存在：`ExternalEffectRepository.prepare_dispatch` 在已发起 dispatch 没有活 lease 时，将原 lease EXPIRED、原 dispatch UNKNOWN、Effect RECONCILIATION_REQUIRED；外层 `prepare_effect_dispatch` 提交对账事件后抛 `EFFECT_RECONCILIATION_REQUIRED`，不会继续 Provider send（external_effect_repositories.py:164-235；external_effect_runtime.py:599-658）。活 CREATED/LEASED/DISPATCHING 只复用原 dispatch。未知状态直接拒绝 retry。原 `reconcile_external_effect` 也允许在 DISPATCHING 直接查询，同 Operation、Provider、冻结 capability，gateway 要求有效 recovery Attempt/fence（external_effect_runtime.py:1372-1490）。查询能力不存在或原本无 remote request ID 时不能臆造远端查询成功。

## 原生入口与连续性

依次读取 `docs/README.md`、`docs/current-system.md` 的 Generated Foundation / Persistence and recovery、`docs/runtime-operations.md` 的 Original Codex result recovery / Native continuous creation，并与 `architecture/reality-evidence.json`、production-entry / worker / migration manifests 对照。manifest 列 book-authority worker `novel_forge.workers.book_authority:cli`，执行由现有 story_formation、book_opening、book/Chapter jobs 驱动。Migration chain 包含 0184 original CLI receipt、0185 pure isolation、0187 Chapter isolation、0194 multiple generation accounting、0195 review isolation、0196 stopped CLI timeout；部署必须核对实际完整 migration IDs，不能只看代码 latest。

Formation owner `StoryFormationApplication`（formation.py）在 owning `AuthorityUnitOfWork` 内保存 frozen input/stage/checkpoint 和 versioned Operations，通过 `StoryFormationRepository` 持久化。WORLD_BIBLE 层 `FormationGeneration.prepare_layer` 调 `StoryPlanningGenerationApplication.generate`，业务逻辑 key 为 `${formation_run_id}:WORLD_BIBLE:0`、idempotency key 为 `${key}:generate`；同 brief hash、previous exact layer versions，不能换 key 重做（formation_generation.py:64-175）。Planning `_terminal_generation_replay` 校验 admitted command 完全一致，已存在 active candidate 复用，terminal owner 通过 native result recovery / registered continuation 消费（application.py:1765-1890）。Story Design owns semantics / approval / activation，Book Design Foundation binding 仅是输入就绪，不能表示章节正文已交付。

Planning 执行 `read_external_effect_intent` 复用原 request/provider token contract，`read_succeeded_external_effect` 复用 trusted original response 与原预算；端口没有收到 completion 才走受保护的 `dispatch_external_effect`（execution.py:4734、5153、3761）。`recover_saved_local_results` 会从 immutable `execution_recovery_session` + 原 backend record 复用完整成功结果，以 local receipt 进入 Kernel 并结算，不查询/重发；remote API 仅有 invocation 无 complete provider result 时跳过（saved_result_recovery.py:12-99）。`RemoteProviderExecutionBackend.reconcile` 优先 callback/retained result，only 支持 query 且存在 request ID 的 unknown/ambiguous 才 query_v2；record 无 provider_result 会报错，不能假造結果（backends.py:1231-1330）。

重要范围限制：`creation_runtime.continue_creation` 先完成 Formation，READY 后才进入 Opening；`recover_book_generations` 在 Opening 路段调用，而不是 WORLD_BIBLE 中断前自动调用。FAILED Formation 的自动 resume blocker 明确拦 DISPATCHING、UNKNOWN、RECONCILIATION_REQUIRED、FAILED_FINAL 和 active lease（creation_runtime.py:229-320、349、454-495）。因此不能声称 `authority-creation recover` 单独就能消除这个调用的未知结果。先在原 Kernel / execution owner 完成对应对账，必要时按已 UNKNOWN 的隔离条件 append native isolation + Planning runtime continuation；同 Formation stage 再 replay 固定 key 并沿 registered successor 继续。

只有 Foundation READY，现有 driver 才 `prepare_creation_inputs` → `open_book`，Opening key 固定 `${formation}:opening`，BookRun key 固定 `${formation}:production`；已存在两者直接复用（creation_runtime.py:288-318）。Opening 原 node receipts / execution loss assessment / registered continuation 继续 long planning，Chapter 由 Book coordination + scheduler 执行。Book acceptance `accept_chapter` 校验原 delegated child、current chapter、exact output/grounded Canon/author approvals，调用 ChapterOutcome，再将接受 cursor、state、Canon、projection 通过 owning UoW/transaction command提交（production.py:1200-1650）。正文 saved / selected / accepted / literary assessment 是不同事实，不能升级。

## 对账必须取得的当前记录

在相同原实例只读导出：数据库 name/OID/server start/role/cluster 与 storage root/bucket identity；运行 release/build SHA、进程/worker 心跳；完整 applied migration IDs；Project/Workspace/Book/Formation/root Operation，原 frozen input/policy/template/Pack grant hash，目标 600 与 window 100；当前 Formation version/lifecycle/stage、stage receipts、RuntimeJob/Attempt/lease/fence；Planning generation logical key/Operation/version/Attempt 与全部 Effect dispatch generation/request hashes；原 execution ID/handle、Provider/model/remote request ID、local immutable recovery record/process receipt/API response/callback；primary/domain output 是否已有；reservation ID/status/accounting basis/caps/estimated vs measured tokens/cost与budget-breach；Opening/BookRun/Chapter current cursor/accepted cursor/prose read-back。

历史 5 次 success 不代表所有 usage 成本已结算。必须逐 reservation 核对 receipt 对应关系。reservation/token估计不等于 measured usage；missing result、missing usage、unsettled paid cost 分开保留 UNKNOWN。

## 结果分支

1. 当前 live writer：观察原运行和心跳/receipt；禁止重复 continue/recover workers 抢执行和新模型调用。
2. 当前原结果成功且完整：frozen contract 校验、native receipt、原 reservation settlement；非 terminal owner 原 `resume_operation_from_completed_effect` 只允许 EXECUTING/WAITING_EXTERNAL_RESULT/RECONCILIATION_REQUIRED，terminal owner 用 linked result recovery successor，不能改 terminal history。
3. 当前 query/callback 能证明 terminal failure/no execution：原证据进入 native reconcile/resolve。`RETRY_WITH_NEW_GENERATION` 必须证实 Provider 未执行，不能由 timeout 或没有本地文件推出。普通 manual resolve 拒绝非 UNKNOWN/RECONCILIATION_REQUIRED。
4. 当前 unknown 且无 recoverable result、writers 已停、身份完整、纯生成/权限/预算条件均满足：按现有 `ISOLATE_PURE_GENERATION` revoke 旧 business/activation rights，保留原 UNKNOWN/held accounting，再 `Planning.register_runtime_continuation` 同书 bounded successor。不换 Book/工作key，retry allowance 从整个 dispatch/successor lineage继承，不重置计数或新增预算。
5. 原 API late receipt：resolve endpoint `POST /product/content-authority/external-effects/{id}/resolve` + `external_effect.resolve`，给 same-project execution_evidence `api-original-receipt.v1`，它引用 immutable `api-provider-record.v1`，原 Project/Book/Operation/Effect/dispatch/generation/request/execution/Attempt/fence/input-manifest/provider/model/request ID全部一致。isolated journal仅 append evidence + 原 reservation once settle；旧 Effect/Operation/rights不改，缺 usage/paid cost仍 HELD_UNKNOWN；同 receipt replay、conflict拒绝，跨每个 dispatch汇总需全部 measured usage 和 priced cost齐备，overrun继续 hold（generation_receipt_reconciliation.py:27-390；manual_effect_resolution.py:45-149）。NOT_FOUND 必须 affirmative provider_not_executed + measured zero tokens（不能由检索未找到推出）。

## 已实现 CLI，条件成立后执行

以下为main通用入口，不是当前 repaired Opening执行指令。当前无BookRun，不运行manuscript continuation；当前有活writer，不运行creation recover/continue。main Formation driver对旧key仅可读其冻结历史，不能把repaired Opening自动视为原key endpoint。

```bash
novel-forge authority-runtime-inspect --project-id "$PROJECT" --expected-database "$ORIGINAL_DATABASE"
novel-forge authority-runtime status --project-id "$PROJECT" --expected-database "$ORIGINAL_DATABASE"
novel-forge authority-creation status --project-id "$PROJECT" --formation-run-id "$FORMATION"
# 只有原 blocker 已解决才用 recover，reason必须说明解决了何项。
novel-forge authority-creation recover --project-id "$PROJECT" --formation-run-id "$FORMATION" --reason "$RESOLVED_BLOCKER" --idempotency-key "$STABLE_RECOVERY_KEY"
# 继续原 frozen work；foreground 是有界执行，需要已有原生产授权和预算。
novel-forge authority-creation continue --project-id "$PROJECT" --formation-run-id "$FORMATION" --foreground --maximum-ticks 100 --work-window-seconds 300 --yield-after-window
# BookRun已经建立后，只消费真实返回的原 handle。
novel-forge authority-manuscript read --project-id "$PROJECT" --book-run-id "$BOOK_RUN"
novel-forge authority-manuscript continue --project-id "$PROJECT" --book-run-id "$BOOK_RUN" --stop-after-chapter 100
novel-forge authority-manuscript export --project-id "$PROJECT" --book-run-id "$BOOK_RUN" --output "$NEW_MANUSCRIPT_JSON"
```

`authority-runtime-inspect` 在 READ ONLY REPEATABLE READ 内检验 expected database，仅项目汇总不足以替代逐-call证据。CLI/API运行环境也必须绑定原实例；不要从GitHub快照bootstrap替代库。Creation `continue`保留 frozen policy/template 600目标与100 window；同 native Formation/BookRun 的 window 不应被缩为新全书目标。`MANUSCRIPT_READY` 只表示请求 range 已保存；accepted cursor、优秀起点持续追读质量与100章交付必须以 actual prose/read-back/export及独立文学证据单列。

## 最小必要验证

本次仅研究，无代码变化，测试 `NOT_RUN`。恢复前首要验证是原实例 read-only identities、receipt/output/ledger 对账，不是重跑模型或全矩阵。若证据表明必须改恢复代码，先复现 exact blocker，再选既有最小相关测试：

- `test_external_effect_runtime_postgres.py::ExternalEffectRuntimePostgresTests::test_expired_post_request_lease_requires_query_without_duplicate_execute`。
- `test_native_api_generation_isolation.py` 的 complete-result-reuse 与 identity conflict；`test_isolated_api_receipt_postgres.py` 的 settle-once、missing usage/cost、late paid overrun、multiple dispatch独立结算，仅对实际修改的分支。
- `test_creation_cli_postgres.py::test_native_start_freezes_current_work_and_reuses_original_formation`、`test_creation_recovery_control.py::test_original_unknown_remote_receipt_blocks_all_recovery_hooks`，若改 same-work continuation/控制边界。

适用矩阵按 `docs/runtime-operations.md` 仅在发布代码改变后运行；Scripted PASS不能证明这本书 Provider恢复、正文交付或文学质量。当前第一验收改为原Book当前 repaired Opening完成并仅建一次原 `${formation}:production` BookRun，同时旧 WORLD_BIBLE held usage继续原账本对账；第二验收为第1章4000–5000汉字真实保存、读回、导出，按原生章链递进至首期100章；600总体规划仅为 frozen constraint/目标，不是交付。
