# 《山河有路》作者 Brief

实际创建来源：`authority-output:2e75d6bd-d206-464b-bad4-82767277644d:creative.brief:v1`；哈希：`sha256:f456466c6dc0358e5498fb0dd9c356881231e8e3a358593435bfe444f2f69f21`。

具体书名、人物、世界与情节由原生流程提出。此文件直接导出实际 Brief；旧书诊断材料未并入。

## idea

原创传统修仙长篇：普通出身主角在成长、探索与人物互动中逐步走向广阔世界。具体书名、人物、世界、机缘、冲突、情节及结局由创作流程提出。

## genre

传统修仙商业网文；语言自然，有人情味与适度趣味。

## audience

希望持续追读普通人成长、探索未知、人物关系变化的中文网文读者。

## constraints

```json
[
  "全书600章，每章正文4000—5000汉字；只计正文汉字，不计章名、标点、空白、附录。",
  "总体设计覆盖完整走向、长期人物发展与重要伏笔；首100章有明确阶段目标，近端按事件滚动细化，不机械预写600章细纲。",
  "人物有鲜明欲望与不同反应；事件由选择及后果相连；修行打开新的行动可能；关系随共同经历变化。",
  "篇幅与事件内容相称，普通事件不为固定章数拖延；内容不足时重组事件，不靠复述、解释、记录及重复动作填量。",
  "阶段兑现后自然形成下一步具体期待，连续写作保留已有经验，避免同质任务、人物失忆和重复证明进步。",
  "这些是作品目标，不要求每章固定反转、付出代价或升级。"
]
```

## source_boundaries

```json
[
  "完全从本次作者Brief新建，所有创作设计由本作品原生流程生成。",
  "旧作品正文、人物、规划、Memo、工作记忆及诊断报告不得进入本作品创作输入；不采用外部代写。"
]
```

## creative_input_selection

```json
{
  "book_id": "book:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537",
  "purpose": "WORK_PRODUCTION",
  "intent_ref": "creation:project:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537:book:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537:author-start:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537",
  "project_id": "project:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537",
  "source_kind": "CURRENT_AUTHOR_INPUT",
  "workspace_id": "workspace:author:c3bd8015360dc671dc35ffd6363af11dddc6a2d3a94626b272343c72a4e34537",
  "contract_version": "creative-input-selection.v1",
  "selected_by_actor_id": "author-first-native-operator",
  "selection_operation_id": "2e75d6bd-d206-464b-bad4-82767277644d"
}
```
