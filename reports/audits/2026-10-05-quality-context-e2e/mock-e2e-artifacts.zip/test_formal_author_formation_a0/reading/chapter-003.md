# 第 3 章 Chapter 3: The Door Closes

Chapter 3 forces the protagonist into a witnessed choice. The choice is public, and the irreversible cost is witnessed.

The scene carries its action contribution forward.

The scene carries its interior contribution forward.

The scene carries its integration contribution forward.
