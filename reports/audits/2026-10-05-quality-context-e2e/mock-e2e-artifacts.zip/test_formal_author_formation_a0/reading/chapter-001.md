# 第 1 章 Chapter 1: The Door Closes

Chapter 1 forces the protagonist into a witnessed choice. The choice is public, and the irreversible cost is witnessed.

The scene carries its action contribution forward.

The scene carries its interior contribution forward.

The scene carries its integration contribution forward.
