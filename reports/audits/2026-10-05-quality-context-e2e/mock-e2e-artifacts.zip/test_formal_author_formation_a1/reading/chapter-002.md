# 第 2 章 Chapter 2: The Door Closes

Chapter 2 forces the protagonist into a witnessed choice. The choice is public, and the irreversible cost is witnessed.

The scene carries its action contribution forward.

The scene carries its interior contribution forward.

The scene carries its integration contribution forward. The dated notice confirms that the council inquiry was already open. The protagonist gives up the only safe route home before the witnesses leave.
