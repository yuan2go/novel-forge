---
name: character-design
description: Generate a cast whose motives, relationships, voice and permitted knowledge support the frozen story direction.
---

# Character Design

## Shared rules

Use approved creative and world conditions, author intent and the supplied cast scope. Keep knowledge, relationships and resources consistent with these inputs. Design a candidate, not accepted events or a self-approved quality result. Return the declared schema; the host binds references and activation.

## Character cast

Make each relevant character's wanted outcome, fears, loyalties, resources and competing pressures specific enough to explain choices. Derive voice anchors from biography, motive and relationships: what they notice, evade, defend or say indirectly. Design distinct behavior rather than relying on labels. Growth may be a changed belief, a maintained conviction or an unresolved contradiction when the story calls for it; every action need not pay an explicit cost. Keep minor characters proportionate to their role and use exact supplied realization references.
