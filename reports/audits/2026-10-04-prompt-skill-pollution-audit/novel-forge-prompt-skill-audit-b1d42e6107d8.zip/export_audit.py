from pathlib import Path
import json,hashlib,ast,re,shutil,collections
OUT=Path(__file__).resolve().parent;ROOT=OUT/'snapshot';EV=OUT/'evidence';SHA=json.loads((OUT/'baseline.json').read_text())['sha']
A=json.loads((EV/'generated/catalog-all.json').read_text());G=EV/'generated';S=EV/'source';S.mkdir(exist_ok=True)
entries=[];sections=[];seen={};sourcepaths=set()
def digest(b):return 'sha256:'+hashlib.sha256(b).hexdigest()
def copy_source(rel):
 p=ROOT/rel
 if not p.is_file():return None
 q=S/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);sourcepaths.add(rel);return 'evidence/source/'+rel
def source_line(rel,symbol=None):
 p=ROOT/rel
 if not symbol:return rel
 try:
  tree=ast.parse(p.read_text())
  node=next(n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==symbol)
  return f'{rel}:{node.lineno}'
 except Exception:return rel+'#'+symbol
manifests=[('chapter.default_manifest',json.loads((ROOT/'config/capability_packs/chapter_generation_pack.json').read_text()))]
manifests += [(p.stem.removesuffix('.manifest'),json.loads(p.read_text())) for p in G.glob('*.manifest.json')]
# Every catalog identity includes its hash and Pack scope; equal ref/version may deliberately differ between scoped profile catalogs.
for n,a in enumerate(A,1):
 id=f'A{n:03}';kind=a['kind'];si=a['source_identity'];content=a['content'];refs=[]
 for name,m in manifests:
  pb=m['prompt_binding'];sb=m['skill_binding']['skills']
  if (kind=='PROMPT_SYSTEM_INSTRUCTION' and (a['ref'],a['version'],a['content_hash'])==(pb['system_instruction_ref'],pb['system_instruction_version'],pb['system_instruction_hash'])) or (kind=='PROMPT_TEMPLATE' and (a['ref'],a['version'],a['content_hash'])==(pb['template_ref'],pb['template_version'],pb['template_hash'])) or (kind=='SKILL' and any((a['ref'],a['version'],a['content_hash'])==(s['skill_ref'],s['version'],s['content_hash']) for s in sb)) or (kind=='KNOWLEDGE' and a['ref'] in m['assets']['knowledge']['required_packs']):refs.append(name)
 selected=bool(refs);textkind=kind in ['PROMPT_SYSTEM_INSTRUCTION','PROMPT_TEMPLATE','SKILL'];model_injected=textkind or kind=='KNOWLEDGE'
 legacy=('legacy-' in si or (a['ref']=='knowledge:chapter-causal-cost:v1') or (kind=='PROMPT_TEMPLATE' and a['ref']=='prompt-template:chapter-generation-pack' and a['version']!='v7') or (kind=='PROMPT_SYSTEM_INSTRUCTION' and a['ref']=='prompt-system:chapter-generation-pack' and a['version']!='v3'))
 evaluation='合理';issues=[];reason='通用身份、版本、接口、权限、预算或源隔离合同；不是作品审美。'
 if textkind:reason='按阶段使用当前作者目标和冻结输入；正文不含固定小说人物、时代或全局古风/搞笑要求。'
 if legacy:
  evaluation='有问题' if a['ref'] in ['prose-generation','quality-review','chapter-outline','knowledge:chapter-causal-cost:v1'] else '条件适用'
  reason='历史兼容目录仍可解析；当前默认未选此版本，只有冻结 Pack 精确选择时才注入。旧商业/代价约束不可升级为当前默认。'
  issues=['C01']
 if a['ref']=='knowledge:chapter-causal-cost:v2':reason='当前默认：技法按本章功能/作者目标/到期义务适用；不强求不可逆代价。'
 if a['ref']=='hot-novel-business-deconstruction':evaluation='条件适用';reason='适用于商业参考拆解；资格 profile 引用该 skill identity 不等于评价器注入其全文。当前 reader.promise 生成选择 topic-development。'
 if kind=='SCHEMA' and a['ref']=='schema:chapter-plan:v1':evaluation='有问题';issues=['C02']
 if kind=='SCHEMA':reason='目录中的接口/身份结构；实际阶段 rich output schema 在 G 系列。这里只能证明声明，不将注册等同生产请求。'
 if kind=='CONTEXT_POLICY':reason='可配置预算与资料范围；512K/64K 是输入预算，不是章数、字数或固定风格。'
 condition=('已列仓库默认或 profile，仍须数据库 ACTIVE release、授权 grant 与精确 hash 选择，真实部署选择未观察。' if selected else '目录可解析；须冻结 Pack 精确 ref/version/hash 引用。未发现默认选择不等于无人使用。')
 status='代码可达但缺少真实请求' if selected and model_injected else '条件启用' if model_injected else '条件启用（控制合同；不等同模型注入）'
 if si.startswith('catalog:'):rel=si.split(':',1)[1].split('#',1)[0];raw=copy_source(rel)
 elif (ROOT/si).is_file():rel=si;raw=copy_source(si)
 else:rel=si;raw=None
 fullname=EV/'assets'/f'{id}.json';fullname.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
 key=digest(json.dumps(content,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
 e={'id':id,'sha':SHA,'kind':kind,'ref':a['ref'],'version':a['version'],'content_hash':a['content_hash'],'source':si,'catalog_scopes':a['catalog_routes'],'selected_by':refs,'usage_status':status,'condition':condition,'stage':'由指定 Pack 的 admitted stage 与单一 skill selector 决定；见 methods/selector 全文' if model_injected else '控制面/接口','message_role':'single user input XML section' if model_injected else '非独立消息；仅工具政策/Schema可能被投影','injection_order':{'PROMPT_SYSTEM_INSTRUCTION':1,'SKILL':2,'KNOWLEDGE':3,'PROMPT_TEMPLATE':5}.get(kind),'loader':source_line('src/novel_forge/modules/capability_packs/artifacts.py','default_chapter_artifact_resolver'),'callers':[source_line('src/novel_forge/modules/chapter_authority/execution_gateway.py','_materialize_production_codex_prompt'),'src/novel_forge/modules/capability_pack_authority/runtime.py:655'],'dynamic_variables':'stage,target_scope,input_manifest,context_bundle,output_schema_ref; live values UNAVAILABLE','full_text':'PROMPTS_AND_SKILLS_FULL.md#'+id.lower(),'resolved_content':'evidence/assets/'+id+'.json','source_bytes':raw,'evaluation':evaluation,'evaluation_reason':reason,'issue_ids':issues,'redacted':False,'coverage':'冻结目录完整解析；动态释放状态未核验'};entries.append(e)
 title=f'### {id} · {kind} · {a["ref"]} @ {a["version"]}\n\n来源：`{si}`；内容 hash：`{a["content_hash"]}`。\n\n状态：{status}。选择：{", ".join(refs) or "仅目录注册"}。{condition}\n\n调用：`execution_gateway._materialize_production_codex_prompt`；角色/顺序：{e["message_role"]} / {e["injection_order"]}；投影见 B 层。评价：{evaluation}；{reason}\n\n'
 if key in seen:sections.append(title+f'静态内容与 [{seen[key]}](#{seen[key].lower()}) 完全相同，只保存一份；本身份和调用选择仍单列，最终请求不去重。\n\n')
 else:
  seen[key]=id
  body=content.get('text') if isinstance(content,dict) and 'text' in content else json.dumps(content,ensure_ascii=False,indent=2)
  sections.append(title+'````'+('text' if textkind else 'json')+'\n'+body+('\n' if not body.endswith('\n') else '')+'````\n\n')
# Source analyses are conditional upstream paths, not source prose auto-injection into Writer.
methodologies={'hot-novel-deconstruction':'2.0.0','hot-novel-business-deconstruction':'1.0.0','published-fiction-craft-analysis':'1.0.0','classic-literary-depth-analysis':'1.0.0','multidisciplinary-knowledge':'1.0.0','platform-strategy-os':'1.0.0','anti-copy-abstraction':'1.0.0'}
for n,(skill,version) in enumerate(methodologies.items(),1):
 id=f'S{n:02}';rel=f'skills/{skill}/SKILL.md';text=(ROOT/rel).read_text();raw=copy_source(rel);bad=skill=='multidisciplinary-knowledge'
 entries.append({'id':id,'sha':SHA,'kind':'SOURCE_ANALYSIS_SKILL','ref':skill,'version':version,'content_hash':digest(text.encode()),'source':rel,'usage_status':'条件启用','stage':'source intelligence / governed methodology selection','condition':'用户导入/重处理或源分析任务精确指定 registry Skill；Observation/批准抽象知识再经选择才可能间接服务写作','message_role':'single user input <governed_skill>','injection_order':2,'loader':'src/novel_forge/modules/source_import/methodologies.py:42','callers':['src/novel_forge/modules/source_import/execution.py:2045','src/novel_forge/modules/chapter_authority/execution_gateway.py:4597'],'dynamic_variables':'source immutable identities/evidence spans or Observation; live UNAVAILABLE','full_text':'PROMPTS_AND_SKILLS_FULL.md#'+id.lower(),'source_bytes':raw,'evaluation':'有问题' if bad else '条件适用','evaluation_reason':'对所有专业知识目标要求爽点/追读；应以本次源分析目标条件适用，未证明该文字流入当前 Writer。' if bad else '专用分析方法；禁止保护表达作为正文输入；被文字提及的其他 Skill/文件不自动递归加载。','issue_ids':['P07'] if bad else [],'redacted':False})
 sections.append(f'### {id} · 条件上游 Skill · {skill} @ {version}\n\n来源：`{rel}`；raw text hash：`{digest(text.encode())}`。仅 registry.require 精确选择；source assembler 注入，非 Writer 默认套餐。\n\n````text\n{text}````\n\n')
# Complete assembly implementations (B). No unknown dynamic value is generated here.
modules=['chapter_authority/execution_gateway.py','chapter_authority/provider_views.py','chapter_authority/prompt_methods.py','chapter_authority/chapter_plan_views.py','chapter_authority/provider_output_contracts.py','chapter_authority/creative_memo.py','chapter_authority/handlers.py','chapter_authority/review_window.py','chapter_quality_authority/context_views.py','chapter_quality_authority/domain.py','content_quality_loop/domain.py','creative/domain.py','creative/style_projection.py','content_authority/codecs.py','content_authority/application.py','book_authority/creation_inputs.py','book_authority/author_supervision.py','book_authority/authority.py','book_authority/acceptance.py','book_authority/supervisor.py','book_authority/production.py','book_authority/recovery.py','book_authority/chapter_dispatch.py','book_authority/input_resolver.py','book_design_authority/application.py','book_design_authority/formation_generation.py','content_authority/handlers.py','content_authority/runtime.py','chapter_authority/preparation.py','story_design_authority/evaluation_execution.py','story_design_authority/evaluation_runtime.py','chapter_authority/realization_composition.py','book_design_authority/formation_domain.py','book_design_authority/formation.py','book_design_authority/foundation.py','story_design_authority/author_input.py','story_design_authority/qualification.py','story_design_authority/domain.py','story_design_authority/application.py','story_design_authority/repositories.py','story_planning_runtime/application.py','story_planning_runtime/execution.py','story_planning_runtime/world_preparation.py','story_planning_runtime/world_sampling.py','story_planning_runtime/knowledge_translation.py','story_planning_runtime/binder.py','capability_packs/artifacts.py','capability_packs/longform_profiles.py','capability_packs/screenplay_profiles.py','capability_pack_authority/runtime.py','capability_pack_authority/application.py','agent_runtime/harness.py','production_preparation/service.py','source_import/execution.py','source_import/methodologies.py','source_import/execution_contracts.py','production_execution/backends.py','production_execution/provider_admission.py','production_execution/codex_configuration.py','production_execution/domain_execution.py','production_execution/agent_execution.py','production_execution/longform_execution.py','provider_control/openai_v2.py','provider_control/deepseek.py','agent_collaboration/application.py','agent_runtime/coordinator.py','agent_runtime/chapter_binding.py','story_planning_runtime/foundation_generation.py','hierarchical_planning/domain.py','worldbuilding/actor_isolation.py','worldbuilding/production.py','worldbuilding/world_dynamics.py','book_followup_authority/screenplay.py','book_followup_authority/prose_review.py','book_followup_authority/prose_execution.py']
for rel in modules:copy_source('src/novel_forge/modules/'+rel)
for rel in ['src/novel_forge/api/authority_dependencies.py','src/novel_forge/storage/authority_uow.py','src/novel_forge/storage/authority_repositories.py','src/novel_forge/storage/story_design_repositories.py','src/novel_forge/storage/book_authority_repositories.py','src/novel_forge/storage/story_formation_repositories.py','src/novel_forge/storage/book_design_authority_repositories.py','src/novel_forge/api/routers/content_authority.py','src/novel_forge/api/routers/book_authority.py','src/novel_forge/api/routers/book_design_authority.py','src/novel_forge/api/routers/authoring.py','config/capability_packs/chapter_generation_pack.json','architecture/production-manifest.json','architecture/worker-manifest.json','architecture/migration-manifest.json','architecture/manifests/production-entry-manifest.yaml','architecture/manifests/worker-manifest.yaml','architecture/manifests/migration-manifest.yaml']:
 copy_source(rel)
# Load all nonsecret source files defining world schemas/task descriptions. Narrow to production-world modules.
for p in (ROOT/'src/novel_forge/modules/worldbuilding').glob('*.py'):
 if any(k in p.read_text() for k in ['output_schema','schema(','task(','instruction']):copy_source(str(p.relative_to(ROOT)))
for p in (ROOT/'src/novel_forge/storage/migrations/versions').glob('*.py'):
 if any(t in p.name for t in ['story_design','author_design','creative','book_design','grounded_chapter','capability_pack','hierarchy_closure','chapter_quality','provider_execution','source_import','foundation_generation','author_supervised','command_kernel_authority']):copy_source(str(p.relative_to(ROOT)))
B=[];symbols={}
selected={
'chapter_authority/execution_gateway.py':['_language_semantic_contract','_stage_semantic_contract','_stage_semantic_contract_v3','_project_prose_skill','_materialize_production_codex_prompt','_materialize_source_intelligence_prompt'],
'chapter_authority/provider_views.py':['build_provider_task_view','build_provider_context_view','build_provider_knowledge_view','_render_context_view'],
'capability_pack_authority/application.py':['_select_capability_skill'],
'production_execution/codex_configuration.py':['codex_output_schema'],
'chapter_authority/prompt_methods.py':['project_sections','project_skill_method','project_planning_system'],
'chapter_authority/chapter_plan_views.py':['qualification_profile_for_plan','normalize_authoritative_chapter_plan','build_draft_plan_view','build_draft_style_view'],
'chapter_quality_authority/context_views.py':['compile_quality_policy','compile_platform_policy','build_quality_context_view','_fit_quality_context'],
'chapter_quality_authority/domain.py':['_evaluate'],
'production_execution/provider_admission.py':['deepseek_strict_tools'],
'production_execution/codex_configuration.py':['controlled_codex_config_overrides'],
'source_import/execution.py':['_materialization'],
'story_planning_runtime/foundation_generation.py':['foundation_task','foundation_output_schema','world_generation_contract'],
'story_design_authority/qualification.py':['required_qualification_profiles','validate_narrative_qualification','qualification_provider_schema'],
'agent_runtime/coordinator.py':['execute_turn'],
'agent_collaboration/application.py':['process_with_execution_port']}
for rel in sourcepaths:
 if not rel.endswith('.py'):continue
 text=(ROOT/rel).read_text();tree=ast.parse(text);lines=text.splitlines(keepends=True)
 for node in ast.walk(tree):
  if isinstance(node,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):symbols.setdefault(rel,{})[node.name]={'line':node.lineno,'end_line':node.end_lineno}
 short=rel.removeprefix('src/novel_forge/modules/')
 for symbol in selected.get(short,[]):
  matches=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)) and n.name==symbol]
  for node in matches:
   code=''.join(lines[node.lineno-1:node.end_lineno]);B.append(f'### B · `{rel}:{node.lineno}` · {symbol}\n\n````python\n{code}````\n\n')
(EV/'symbol-index.json').write_text(json.dumps(symbols,ensure_ascii=False,indent=2)+'\n')
for n,p in enumerate(sorted(G.glob('*.json')),1):
 if p.name in ['catalog-all.json'] or p.name.endswith('.manifest.json'):continue
 id=f'G{n:03}';content=p.read_text();issue=[]
 if '.task.json' in p.name or 'ending.intent.generate.schema' in p.name or 'theme.candidates.generate.schema' in p.name:issue=['P01']
 if 'qualification' in p.name or p.name=='VOLUME.planning.schema.json':issue=['P02']
 entry={'id':id,'sha':SHA,'kind':'GENERATED_SCHEMA_OR_TASK_OR_SEMANTIC_CONTRACT','ref':p.stem,'version':'冻结 constructor 当前版本；详见 source function','content_hash':digest(p.read_bytes()),'source':'frozen Python constructor; full source in evidence/source','usage_status':'无法确定（构造失败）' if '.error.' in p.name else '条件启用','stage':p.name.split('.schema')[0].split('.semantic')[0].split('.task')[0],'condition':'相应 admitted stage / frozen output-contract flags；生成实例是 SYNTHETIC，非生产 schema capture','message_role':'single user task/schema/semantic section; transport adds applicable response format/tool schema','injection_order':'task template then stage semantic then output schema','loader':'execution_gateway/_materialize_production_codex_prompt; source assembly source_import','callers':['src/novel_forge/modules/chapter_authority/provider_output_contracts.py:879','src/novel_forge/modules/story_planning_runtime/execution.py:2291'],'dynamic_variables':'基础 schemas 默认分支; dynamic horizons/realization refs UNAVAILABLE; full code exported','full_text':'PROMPTS_AND_SKILLS_FULL.md#'+id.lower(),'resolved_content':str(p.relative_to(OUT)),'evaluation':'待核验' if '.error.' in p.name else '有问题' if issue else '合理','evaluation_reason':'constructor 当前固定分支，原始 field description/enum/const 保留；动态变体由 B 与源文件给出，不声称全变体已渲染。','issue_ids':issue,'redacted':False};entries.append(entry)
 sections.append(f'### {id} · 构造输出 · {p.name}\n\n分类 SYNTHETIC（纯函数输出），来源/调用见 inventory 与 B；顺序/字段描述未去重。字节 hash `{entry["content_hash"]}`。\n\n````json\n{content}````\n\n')
# Unbound historical/demo assets, metadata only; never treat docs/tests as production text.
registered_paths={a['source_identity'] for a in A}
unbound=[]
for p in sorted((ROOT/'config/capability_packs/artifacts').glob('*.md')):
 rel=str(p.relative_to(ROOT))
 if rel not in registered_paths:
  copy_source(rel);unbound.append({'path':rel,'sha256':digest(p.read_bytes()),'status':'无法确定','reason':'冻结默认 resolver/profile 未引用；数据库自定义 Pack 未观察，不能宣称无人使用','production_full_export':False})
for p in sorted((ROOT/'config/production').glob('*.json')):
 rel=str(p.relative_to(ROOT));unbound.append({'path':rel,'sha256':digest(p.read_bytes()),'status':'条件启用（operator配置，不是自动公共 Prompt）','reason':'须命令明确选择此文件；作品名/短章数不据此认定公共默认','production_full_export':False})
(EV/'unbound-and-demo-assets.json').write_text(json.dumps(unbound,ensure_ascii=False,indent=2)+'\n')
unknown=[{'id':'U01','source':'PostgreSQL released CapabilityPack/asset catalog/style_policy/quality_profile/platform_profile/agent instructions & tools','status':'UNAVAILABLE','reason':'未连接真实 DB；仅仓库构造器，不能反推部署状态'},{'id':'U02','source':'same SHA actual request, exact active author objectives and resulting prose','status':'UNAVAILABLE','reason':'未取得同版本同冻结身份请求与正文；不读取不同分支未提交作品证据代替'},{'id':'U03','source':'actual installed CLI version, host fixed_working_directory and launch receipt','status':'UNAVAILABLE','reason':'代码 flags/ignore directives已导出；真实子进程未启动/未观察'},{'id':'U04','source':'world/actor frozen task, dynamic Chapter realization/horizon-specific rich Schema','status':'UNAVAILABLE','reason':'constructor源文件完整；动态对象未造值；Chapter默认schema构造失败已保存原错误'},{'id':'U05','source':'generic DomainExecutionPort downstream deployment wiring/transcripts','status':'UNAVAILABLE','reason':'固定 generic prompt/wrappers CODE_EXISTS；不得当成主章生产请求'}]
(EV/'unavailable.json').write_text(json.dumps(unknown,ensure_ascii=False,indent=2)+'\n')
for u in unknown:entries.append({**u,'sha':SHA,'kind':'ACCESS_GAP','usage_status':'无法确定'})
# Store complete input instances inline in C. Final prompt duplicates preserved.
C=[]
for p in sorted((EV/'inputs').glob('*.json')):
 data=json.loads(p.read_text());prompt=data['ordered_messages'][0]['content'];C.append(f'### C · SYNTHETIC · {p.stem}\n\n完整有序消息、变量和装配身份：[JSON]({p.relative_to(OUT)})。唯一 user 内容如下；XML 标签不是独立 system/developer 消息。\n\n````text\n{prompt}\n````\n\n')
(OUT/'inventory.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in entries))
(OUT/'PROMPTS_AND_SKILLS_FULL.md').write_text('# 冻结 Prompt / Skill 原文汇编\n\n基线：'+SHA+'。A 是源文本/精确目录内容；B 是实际装配逻辑；C 是离线 SYNTHETIC 最终业务输入。所有源文件原字节在 evidence/source，JSON resolved identity 的 content_hash 使用代码 canonical 算法，不能与 raw 文件 SHA 混同。未脱敏：这里未导出真实密钥、真实作者私有素材或参考小说原文。\n\n静态相同文本仅存一份；最终请求保持顺序、重复、原语言。控制合同单列，未误算独立 Prompt。模板变量的真实数据库值 UNAVAILABLE。Skill 的链接/提及不能证明递归加载；已证明加载器读的是匹配的单文件全文再按 stage 投影。\n\n## A · 目录、静态文本与纯构造输出\n\n'+''.join(sections)+'## B · 拼接、路由、投影、预算与覆盖逻辑\n\n'+'完整源文件亦在 evidence/source，world/actor动态Schema分支与 output-contract flag 在源文件完整保留；下面摘录完整相关函数，不用伪造动态值填充。\n\n'+''.join(B)+'## C · 最终输入实例\n\nREAL_CAPTURE=0；RECONSTRUCTED=0；SYNTHETIC='+str(len(C))+'。此处“最终”仅指固定 Python assembler 输出，transport/CLI附加处理按源文件静态核验，非真实发送抓包。未使用真实冻结运行 grant 或 receipts。\n\n'+''.join(C)+'## 未取得 / 未绑定\n\n````json\n'+json.dumps(unknown,ensure_ascii=False,indent=2)+'\n````\n\n未绑定历史与 operator示例仅元数据登记：evidence/unbound-and-demo-assets.json；未把整个文档/测试/小说库混入生产汇编。\n')
counts={'catalog_artifacts':len(A),'catalog_text_identities':sum(a['kind'] in ['PROMPT_SYSTEM_INSTRUCTION','PROMPT_TEMPLATE','SKILL'] for a in A),'catalog_unique_text_sources':len({a['source_identity'] for a in A if a['kind'] in ['PROMPT_SYSTEM_INSTRUCTION','PROMPT_TEMPLATE','SKILL']}),'source_methodology_identities':len(methodologies),'generated_constructed_records':sum(e['id'].startswith('G') for e in entries),'inventory_records':len(entries),'source_files_exported':len(sourcepaths),'synthetic_captures':len(C),'real_captures':0,'reconstructed_captures':0,'offline_checks':41,'prompt_asset_file_evaluations':'45 catalog text identities + 7 conditional source method identities, all source text read; duplicate sources counted once for full text','schema_review_boundary':'完整解析/导出目录81 schemas与构造器源；对会改变创作边界的必填/enum/const/描述重点核验；未声称每个动态schema实例都已渲染/人工逐字段验证'}
(EV/'counts.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2)+'\n')
# Per-identity human judgement table; not only problematic assets.
table=['| ID | 原始身份/版本 | 状态/选择 | 评价 | 理由 |','|---|---|---|---|---|']
for e in entries:
 if e['kind'] in ['ACCESS_GAP']:continue
 table.append('| '+e['id']+' | '+str(e['ref'])+' / '+str(e['version'])+' | '+e['usage_status']+' | '+e['evaluation']+' | '+e['evaluation_reason'].replace('|','/')+' |')
(OUT/'ASSET_EVALUATIONS.md').write_text('# 逐资产评价\n\n完整 SHA：'+SHA+'。动态/历史选择有条件；此表没有将仅注册内容判成已发送。\n\n'+'\n'.join(table)+'\n')
print(json.dumps(counts,ensure_ascii=False))
