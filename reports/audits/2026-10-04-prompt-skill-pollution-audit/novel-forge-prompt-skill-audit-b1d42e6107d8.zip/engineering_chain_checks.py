from pathlib import Path
import copy,json
O=Path(__file__).resolve().parent
# Reuse only the explicit IO guard prefix, never the prior constructor/export workload.
guard=(O/'evidence_build.py').read_text().split('from novel_forge.modules.capability_packs.artifacts')[0]
exec(compile(guard,str(O/'evidence_build.py')+'#guard','exec'))
from novel_forge.modules.hierarchical_planning.realization_domain import NarrativeRealizationEvent,validate_narrative_realization_event_chain
from novel_forge.modules.hierarchical_planning.domain import PlanContractType
from novel_forge.modules.story_planning_runtime.execution import planning_provider_output_schema
from novel_forge.modules.command_kernel.errors import KernelError
event={'event_id':'audit:event1','slice_id':'audit:slice1','chapter_number':1,'causes':[],
 'actor_ref':'audit:observer','motivation':'Observe an ordinary afternoon','preconditions':['ordinary afternoon'],
 'knowledge_boundary':{'actor_knows':['audit:fact1'],'reader_may_learn':['audit:fact1'],'forbidden_disclosures':['audit:fact2']},
 'action':'Observe','decision':'Remain seated','resistance':'Ambient noise','consequence':'The observation continues',
 'state_deltas':[{'state_kind':'observation','entity_id':'audit:observer','from_state':'seated','to_state':'seated'}],
 'disclosures':['audit:fact1'],'obligation_actions':['audit:obligation1'],'arc_contributions':['audit:arc1'],
 'irreversible_change':'Audit constructor baseline only; not a literary or semantic qualification',
 'next_event_ids':[],'required':True}
checks=[]
def record(id,actual,expected,detail):
 checks.append({'id':id,'actual':actual,'expected':expected,'passed':actual==expected,'detail':detail})
record('event_constructor_baseline',NarrativeRealizationEvent.from_mapping(event).event_id,'audit:event1','SYNTHETIC typed constructor only; no claim this event is semantically valid or approved')
for field,value in [('irreversible_change',''),('disclosures',[]),('state_deltas',[])]:
 candidate=copy.deepcopy(event);candidate[field]=value
 try: NarrativeRealizationEvent.from_mapping(candidate);result='ACCEPTED'
 except KernelError as error: result=error.code
 record('empty_'+field+'_rejected',result,'NARRATIVE_REALIZATION_INVALID','Defect/contract reproduction; not a proposed corrected-system PASS')
try:validate_narrative_realization_event_chain([event],chapter_range=(1,2));result='ACCEPTED'
except KernelError as error:result=error.code
record('every_group_chapter_needs_event',result,'REALIZATION_SLICE_INVALID','One event for a two-chapter group lacks full coverage')
schema=planning_provider_output_schema(PlanContractType.CHAPTER_GROUP)
properties=schema['properties']['narrative_event_chain']['items']['properties']
record('schema_irreversible_nonempty',properties['irreversible_change'].get('minLength'),1,'Current rich Provider schema matches host nonempty irreversible requirement')
record('schema_disclosures_nonempty',properties['disclosures'].get('minItems'),1,'Current rich Provider schema requires disclosures for every event')
report={'sha':json.loads((O/'baseline.json').read_text())['sha'],'classification':'SYNTHETIC','scope':'pure existing frozen domain constructors and schema; no admission, persistence, qualification, acceptance or model generation',
 'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','checks':checks,'inputs':{'event':event},'provider_calls':0,'database_connections':0,
 'meaning':'PASS reproduces expected current restrictions; does not establish generality or literary quality'}
(O/'evidence/checks/engineering-chain-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'failed':[x for x in checks if not x['passed']]},ensure_ascii=False))
