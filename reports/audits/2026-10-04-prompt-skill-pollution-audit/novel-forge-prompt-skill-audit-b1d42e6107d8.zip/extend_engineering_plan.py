from pathlib import Path
import json,hashlib,shutil,ast,datetime,re
O=Path(__file__).resolve().parent;R=O/'snapshot';E=O/'evidence'
SHA=json.loads((O/'baseline.json').read_text())['sha']
extra_sources=[
 'src/novel_forge/modules/production_preparation/policies.py',
 'src/novel_forge/modules/context_builder/task_context.py',
 'src/novel_forge/modules/book_followup_authority/reader_policy.py',
 'src/novel_forge/modules/reader_judge_authority/domain.py',
 'src/novel_forge/modules/publishing/release_gate.py',
 'src/novel_forge/modules/book_design_authority/author_supervision.py',
 'src/novel_forge/modules/story_design_authority/author_supervision.py',
 'src/novel_forge/modules/plan_change_authority/semantic_impact.py',
 'src/novel_forge/modules/hierarchical_planning/realization_domain.py',
 'src/novel_forge/modules/hierarchical_planning/realization_application.py',
 'src/novel_forge/storage/narrative_realization_repositories.py',
 'src/novel_forge/modules/hierarchical_planning/definitions.py',
]
added=[]
for rel in extra_sources:
 q=E/'source'/rel
 if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,q);added.append(rel)

full=O/'PROMPTS_AND_SKILLS_FULL.md'
s=full.read_text().split('\n## E · 全工程链路补充')[0]
s+='\n## E · 全工程链路补充\n\n仍固定同一SHA；以下是追加的合同/适用性/后续边界完整原始源码。它们不是新增模型Prompt，源文件复制数量单独统计。I15事件合同为生产合法性路径；I16作者监督是严格资格之外的适用例外。公开Prompt原文、原24份装配不改。\n\n'
for rel in extra_sources:
 s+='### '+rel+'\n\nSHA '+SHA+'；源文件sha256='+hashlib.sha256((R/rel).read_bytes()).hexdigest()+'；[原字节文件](evidence/source/'+rel+')。作用与评价见全工程方案相应段落；未声称下列所有非创作字段逐项通过语义审查。\n\n~~~~python\n'+(R/rel).read_text()+'\n~~~~\n\n'
full.write_text(s)

rows=[json.loads(l) for l in (O/'inventory.jsonl').read_text().splitlines()]
rows=[x for x in rows if x['id'] not in ['I15','I16']]
for id,rel,symbol,stage,evaluation,note in [
 ('I15','src/novel_forge/modules/hierarchical_planning/realization_domain.py','NarrativeRealizationEvent',['chapter_group_plan.generate','NarrativeRealization freeze','Chapter planning slice'],'有问题','P08: new ChapterGroup event per chapter plus nonempty irreversible_change/state_deltas/disclosures; required causal/knowledge boundaries remain useful; WIRED plus 7 pure synthetic constructor/schema assertions, no real receipt'),
 ('I16','src/novel_forge/modules/story_design_authority/author_supervision.py','validate_author_review',['AUTHOR_ADVISORY design review/approval'],'合理','作者监督可凭证据处理非PASS finding，不授予独立资格；strict require_pass gate cannot be generalized to this mode; actual author decisions UNAVAILABLE')]:
 node=next(n for n in ast.walk(ast.parse((R/rel).read_text())) if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==symbol)
 rows.append({'id':id,'sha':SHA,'kind':'INLINE_INSTRUCTION_TOOL_CONFIG_OR_GATE','ref':rel+'#'+symbol,'source':rel+':'+str(node.lineno),'version':'frozen code SHA','source_file_sha256':'sha256:'+hashlib.sha256((R/rel).read_bytes()).hexdigest(),'stage':stage,'usage_status':'代码可达但缺少真实请求','condition':note,'message_role':'host contract/gate; not an invented model message','injection_order':'Schema/task path see B and E; host validation is separate','dynamic_variables':'current frozen ChapterGroup / realization / author supervision; actual instances UNAVAILABLE','full_text':'evidence/source/'+rel,'evaluation':evaluation,'evaluation_reason':note,'redacted':False})
for row in rows:
 if row['id']=='I08':row['condition']+=' 严格路径适用门禁；AUTHOR_ADVISORY不自动授独立资格，作者可有证据处理分歧，见I16。';row['evaluation_reason']=row['condition']
(O/'inventory.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))

findings=json.loads((E/'findings.json').read_text())
for f in findings:
 if f['id']=='P02':
  f['condition']+=' strict require_pass=True或独立QUALIFY才要求全适用标准PASS；AUTHOR_ADVISORY保留评价和作者有证据处置，不能泛化全模式。'
  f['why']=f['why'].replace('全部 frozen criteria 必须返回 PASS','严格独立资格要求全部 frozen criteria PASS')
  f['fix']='完整联动 W1/W2/W3/W5/W8：冻结本书适用标准，同步Schema/profile/生成任务与release；strict独立资格和AUTHOR_ADVISORY分别保留证据与授权边界。'
 if f['id']=='P06':f['quote']+='; _report: threshold=70.0 if score is not None else None';f['fix']='W6统一policy编译、测量算法、比较阈值、report、blocking与下游修订；按本书文体区分诊断和硬要求，不仅改比较数字。'
findings=[f for f in findings if f['id']!='P08']
findings.append({'id':'P08','stage':'ChapterGroup / Narrative Realization / Chapter frozen slice','quote':'irreversible_change=_required(...); state_deltas nonempty; disclosures/obligation_actions/arc_contributions nonempty; chapters==every chapter in group',
 'refs':'src/novel_forge/modules/hierarchical_planning/realization_domain.py:206,565; hierarchical_planning/domain.py:361; story_planning_runtime/execution.py:2502; realization_application.py:571',
 'condition':'新ChapterGroup正式事件链校验；rich Provider schema和realization冻结。历史pre-hierarchy compatibility另行保留。',
 'why':'每章覆盖与每事件必填不可逆变化/揭示/副作用的组合，强迫合法观察/过渡/维持状态章节编造特定动作；并非仅接口身份完整性。',
 'scope':'当前作品/章节已选择或已批准的事件及其真正适用副作用；章节执行覆盖应独立保留。',
 'affected':'观察式、低冲突、过渡、保持人物信念、无新披露或状态变化的章节；非不可逆驱动作品。',
 'override':'当前事件字段不随作者允许无不可逆变化而放宽；空值constructor拒绝。不能证明模型无法宽解释字段，或已有正文实际失真。',
 'severity':'高','confidence':'高（合同/调用/离线构造）；历史来源未确认','proof':'A+B WIRED；7 supplementary SYNTHETIC checks; no dynamic realization/qualification/Provider/accepted prose, C未验证',
 'fix':'W1/W3/W4/W6/W7/W8协同：独立章节执行覆盖和适用事件变更、支持正式零变化/零披露、同步host/provider/proof/slice/acceptance版本；选择了的变化缺证据仍失败。',
 'verify':'观察章零变化正式通过计划/实现/接受；选用不可逆策略的对照缺准备或结果仍失败；旧frozen identity不改。'})
(E/'findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n')

c=json.loads((E/'counts.json').read_text());c.update(source_files_exported=sum(p.is_file() for p in (E/'source').rglob('*')),inventory_records=len(rows),inline_instruction_or_gate_records=16,offline_checks=48,original_offline_checks=41,engineering_chain_supplement_checks=7,mechanism_findings=8)
(E/'counts.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
table=['| ID | 身份/版本 | 生效状态 | 评价 | 理由/条件 |','|---|---|---|---|---|']
for row in rows:
 if row['kind'] in ['ACCESS_GAP','CALL_OR_INJECTION_SITE']:continue
 table.append('| '+row['id']+' | '+str(row.get('ref'))+' / '+str(row.get('version'))+' | '+row['usage_status']+' | '+row['evaluation']+' | '+row.get('evaluation_reason','').replace('|','/')+' |')
(O/'ASSET_EVALUATIONS.md').write_text('# 逐资产评价\n\nSHA '+SHA+'；绑定声明不等同实际选择。新增I15/P08合同和I16作者监督边界；每个资产评价不表示其真实生产已发生。\n\n'+'\n'.join(table)+'\n')

a=O/'AUDIT.md';s=a.read_text()
s=s.replace('# Prompt / Skill 只读审计','# Prompt / Skill 与全工程生产链只读审计')
s=s.replace('7项机制问题','8项机制问题（含本次全链路补充P08）')
s=s.replace('最小修改：','对应修改层（完整方案见 ENGINEERING_OPTIMAL_CHANGE_PLAN.md）：')
s=s.replace('最小处置先核验','版本处置先核验')
s=s.replace('只改这两个商业绝对句与操作流程第8项，绑定本次作品/分析目标','修改商业绝对句与操作流程第8项，并核验本次任务目标实际进入Source输入、Card适用性及后续选择')
s=s.replace('全部 frozen criteria 必须返回 PASS','严格独立资格要求全部 frozen criteria PASS')
s=s.replace('qualifier 不按当前作者技法选择过滤。','qualifier 不按当前作者技法选择过滤；strict门禁与AUTHOR_ADVISORY不同，见本次补充。')
start=s.index('## 最小修改顺序与后续验证设计')
end=s.index('## 补充：字段丢失首点与开发约束',start)
s=s[:start]+'''## 全工程修改建议与验证设计

按用户追加要求，本报告不再把建议限定为局部或最小改写。完整架构、职责、合同、输入传播、审读回改、持久化、版本迁移、恢复与验证见 [ENGINEERING_OPTIMAL_CHANGE_PLAN.md](ENGINEERING_OPTIMAL_CHANGE_PLAN.md)。相关完整指令建议见 [REWRITE_PROPOSALS.md](REWRITE_PROPOSALS.md)。

推荐顺序：先明确本书有效创作要求与规则适用性（W1），同步修改Foundation/资格、层级/实现合同、投影/Context、质量/修订（W2/W3/W4/W6），再统一Prompt/Skill/Pack版本（W5），核对接纳与后续（W7），最后处理真实release、旧书兼容、恢复与受控文学验证（W8）。这不是只修七个局部字符串，也不是重写一套新Authority。

现有公共能力继续有效：权限、版权、精确身份、事实连续性、候选与接受分离、必要接口、限定修订、UNKNOWN调和及原子接纳。作品差异由当前输入与批准方案决定。完整方案的实现和验收全部NOT_RUN；本轮机制检查不代表修改已完成。

审计文件不是新运行Authority；没有写回生产Prompt/代码、连接DB、调用Provider、修改作品状态或commit/push/PR/merge。

'''+s[end:]
s=s.replace('165（最终counts.json核对）',str(c['source_files_exported'])+'（最终counts.json核对）')
s=s.replace('165个源文件',str(c['source_files_exported'])+'个源文件')
s=s.replace('14内联说明/门禁/作者入口','16内联说明/门禁/作者入口')
s=s.replace('inventory共352记录','inventory共'+str(len(rows))+'记录')
s=s.replace('41机制断言。','原41机制断言及本次7个纯构造检查（合计48）。')
s+='''
## 本次扩展：P08与跨层修正范围

P08定位与完整分析见 [全工程方案第10节](ENGINEERING_OPTIMAL_CHANGE_PLAN.md#10-p08narrative-realization-不能成为隐蔽的每章戏剧模板)。新ChapterGroup校验正式调用NarrativeRealizationEvent：每章需要事件覆盖，每事件irreversible_change非空、state_deltas/disclosures/obligation_actions/arc_contributions非空。planning rich Schema与host合同一致。这是新的A+B机制证据，不是fixture故事内容进入生产的证明。

严重性高；机制置信度高；来源未确认。7个追加SYNTHETIC检查复现空不可逆字段/披露/状态变化被拒、整组章覆盖及rich Schema非空要求。没有运行任何真实资格/接纳/Provider，不证明文学效果。推荐修改Chapter执行覆盖、事件适用副作用、proof、frozen slice和Book消费的整个合同链，而不是仅更改一个字段。

P02范围补正：validate_narrative_qualification只有require_pass=True才对非PASS抛失败；评估输出保存可用require_pass=False。strict独立资格仍需适用标准满足；AUTHOR_ADVISORY配合原生作者监督可有证据处置分歧，不授独立资格。固定标准的适用性问题仍在，但不能说所有模式每项模型FAIL都必然阻断。

P06补充：_report对有分数证据固定threshold=70.0，需与实际policy、测量、verdict和required_actions一起修复；不推断所有已校准分数在当前部署都使用了错误阈值。

新增代码证据完整复制到evidence/source，全文汇编E层登记；原静态Prompt原文、原24份模型装配及原41检查未改。追加检查见 evidence/checks/engineering-chain-results.json。整个方案未实施；全适用矩阵和文学验证仍NOT_RUN。
'''
s='\n'.join(line for line in s.splitlines())+'\n'
a.write_text(s)

# Extend symbol index without treating new code as observed runtime input.
symbols=json.loads((E/'symbol-index.json').read_text())
# Existing structure is retained; new discovery details are separate.
supp=[]
for rel in extra_sources:
 for n in ast.walk(ast.parse((R/rel).read_text())):
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
   supp.append({'source':rel,'symbol':n.name,'line':n.lineno,'end_line':n.end_lineno,'sha':SHA})
(E/'engineering-chain-symbol-index.json').write_text(json.dumps(supp,ensure_ascii=False,indent=2)+'\n')
(E/'engineering-plan-scope.json').write_text(json.dumps({'sha':SHA,'requested_scope':'全工程小说生产链最优修改建议；保留只读边界','new_source_copies':added,'mechanism_findings':8,'added_finding':'P08','corrections':['P02 strict/advisory separation','P06 reported threshold basis'],
 'existing_evidence_preserved':['static prompt source bytes','24 synthetic assembler captures','41 original mechanism assertions'],
 'new_checks':7,'implementation':'NOT_RUN','runtime_matrix':'NOT_RUN','literary_effect':'UNAVAILABLE','real_capture':0,'provider_calls':0,'database_connections':0},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(c,ensure_ascii=False))
