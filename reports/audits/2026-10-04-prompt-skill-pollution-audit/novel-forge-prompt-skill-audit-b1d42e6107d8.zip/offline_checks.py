exec(compile((__import__('pathlib').Path(__file__).parent/'evidence_build.py').read_text(),'evidence_build.py','exec'))
from copy import deepcopy
from novel_forge.modules.chapter_authority.execution_gateway import _materialize_production_codex_prompt
from novel_forge.modules.chapter_authority.chapter_plan_views import build_draft_plan_view,build_draft_style_view,normalize_authoritative_chapter_plan,qualification_profile_for_plan
from novel_forge.modules.chapter_authority.provider_views import build_provider_task_view,build_provider_context_view
from novel_forge.modules.story_planning_runtime.foundation_generation import FOUNDATION_INPUT_ROLES
from novel_forge.modules.story_planning_runtime.execution import planning_provider_output_schema
from novel_forge.modules.hierarchical_planning.domain import PlanContractType
from novel_forge.modules.creative.domain import validate_creative_brief
from novel_forge.modules.command_kernel.errors import KernelError
CHECK=EV/'checks';CHECK.mkdir(exist_ok=True);SNAP=EV/'inputs';SNAP.mkdir(exist_ok=True)
results=[]
def check(name,actual,expect,detail=''):
 ok=actual==expect; results.append({'id':name,'passed':ok,'actual':actual,'expected':expect,'detail':detail});return ok
resolver=default_chapter_artifact_resolver(ROOT)
base=json.loads((ROOT/'config/capability_packs/chapter_generation_pack.json').read_text())
profiles={name:manifest for name,manifest in profiles}
allcat=json.loads((EV/'generated/catalog-all.json').read_text())
def get(kind,ref,version):return next(a for a in allcat if (a['kind'],a['ref'],a['version'])==(kind,ref,version))
def mat(manifest,skill_ref,ctx,schema,stage):
 pb=manifest['prompt_binding'];skill=next(s for s in manifest['skill_binding']['skills'] if s['skill_ref']==skill_ref)
 return {'pack_artifacts':{'system_instruction':get('PROMPT_SYSTEM_INSTRUCTION',pb['system_instruction_ref'],pb['system_instruction_version']),'prompt_template':get('PROMPT_TEMPLATE',pb['template_ref'],pb['template_version']),'skill':get('SKILL',skill_ref,skill['version'])},'context_selection':[{'content':ctx}],'knowledge_selection':[get('KNOWLEDGE',ref,ref.rsplit(':',1)[-1]) for ref in manifest['assets']['knowledge']['required_packs']],'tool_permissions':{'allowed':['model.provider.invoke']},'output_schema':{'ref':'schema:audit-synthetic:'+stage+':v1','content':schema}}
def capture(name,stage,inputs,materialization):
 prompt,evidence=_materialize_production_codex_prompt(target_scope={'scope_kind':'book','scope_id':'audit-book','book_id':'audit-book'},stage=stage,inputs=inputs,materialization=materialization)
 record={'classification':'SYNTHETIC','frozen_sha':json.load(open(OUT/'baseline.json'))['sha'],'stage':stage,'ordered_messages':[{'role':'user','content':prompt}],'note':'Exact frozen prompt assembler only. Synthetic asset identities and inputs; no production admission, grant, accepted-state proof or Provider call. XML tags are not actual system/developer roles. CLI additional inputs verified statically, actual CLI/version/config not observed.','raw_inputs':inputs,'materialization':materialization,'assembly_evidence':evidence,'variable_sources':{'stage':'audit case stage','input_manifest':'build_provider_task_view(stage, raw_inputs)','context_bundle':'build_provider_context_view(stage, context_selection[0].content, task_view)','schema':'specified frozen constructor'},'adapter_evidence':{'OpenAI':'single string input in responses.create, no instructions parameter','DeepSeek':'one user message; response_format json_object or strict_tool; model/limits/pricing not supplied in this audit'}}
 write(SNAP/(name+'.json'),record);(SNAP/(name+'.prompt.txt')).write_text(prompt);return prompt
styles=[('serious','严肃现实群像；克制长句；观察式开篇；允许无反转、无不可逆代价'),('fantasy','轻松幻想冒险；口语对白；可以幽默和反转；人物后果按情境决定')]
for tag,style in styles:
 brief={'creative_brief_contract_version':'creative-brief-v2','idea':'不同人物在共同空间中相互观察，允许开放式结尾','genre':'现实群像' if tag=='serious' else '幻想冒险','audience':'成年读者' if tag=='serious' else '冒险故事读者','constraints':[style,'不强制每章爽点或结尾悬念，不强制不可逆代价'],'source_boundaries':['原创，仅允许抽象技法参考']};check(tag+'_brief_accepted',validate_creative_brief(brief)==brief,True)
 for stage,skill in [('creative.candidates.generate','topic-development'),('theme.candidates.generate','narrative-beat-design'),('ending.intent.generate','long-outline')]:
  frozen=[{'role':role,'asset_version_id':'synthetic:'+role,'asset_type':role,'content_hash':'sha256:'+'1'*64,'content':brief if role=='creative_brief' else {'objective':'依当前作者要求规划','constraints':[style]}} for role in FOUNDATION_INPUT_ROLES[stage]]
  command={'planning_scope':'NOT_APPLICABLE','book_id':'audit-book','generator_operation_name':stage}
  inputs={'planning_command':command,'frozen_inputs':frozen,'foundation_task':foundation_task(stage),'narrative_intelligence':{}}
  ctx={'schema_version':'novelos.planning_context_bundle.v1','book_id':'audit-book','planning_scope':'NOT_APPLICABLE','logical_key':'foundation:'+stage,'input_versions':frozen}
  prompt=capture(tag+'-'+stage,stage,inputs,mat(profiles['story_planning_pack'],skill,ctx,foundation_output_schema(stage),stage))
  check(tag+'_'+stage+'_style_kept',style in prompt,True)
  if stage=='ending.intent.generate':check(tag+'_irreversible_task_survives','Design an earned ending direction with irreversible costs' in prompt,True,'Counterexample: author says do not require irreversible cost, task still requires it')
 style_obj={'contract_version':'draft-style-view-v1','policies':[{'asset_version_id':'synthetic:style','safe_summary':style,'structured_facts':[{'key':'creative_style','value':{'constraints':[style],'narrator':style,'pov':'受限第三人称'}}]}]}
 plan={'chapter':2,'title':'当前作品的一章','premise':'观察不同人物的日常','chapter_objective':'保留差异','scene_sequence':['s1'],'chapter_hook':'余韵','source_chapter_plan_asset_version_id':'synthetic:plan','source_chapter_plan_content_hash':'sha256:'+'1'*64,'style_constraints':['STYLE_ONLY_IN_PLAN:始终使用现在时，不强加笑点']}
 view=build_draft_plan_view(plan);check(tag+'_plan_style_field_dropped','style_constraints' in view,False)
 ctx={'context_segments':[{'asset_type':'style_policy','asset_version_id':'synthetic:style','safe_summary':style,'structured_facts':style_obj['policies'][0]['structured_facts']}],'context_manifest':{}}
 draft_inputs={'plan':view,'style':style_obj,'chapter_memo':{'creative_guidance':{}},'realization_contract':{'slots':[],'voices':[]}}
 prompt=capture(tag+'-draft','draft',draft_inputs,mat(base,'prose-generation',ctx,chapter_provider_output_schema('draft'),'draft'))
 check(tag+'_draft_dynamic_style_kept',style in prompt,True);check(tag+'_plan_style_requirement_lost','STYLE_ONLY_IN_PLAN' in prompt,False)
 candidate={'chapter':2,'title':'当前作品的一章','text':'他没有作出决定，只把窗户打开。','realization_contract':{'contract_version':'scene-realization-composition.v1','slots':[]},'scene_artifacts':[]}
 for stage in ['review','revision','rereview']:
  ins={'draft':candidate,'review':{'issues':[]},'revision':candidate,'original_draft':candidate}
  prompt=capture(tag+'-'+stage,stage,ins,mat(base,'prose-generation' if stage=='revision' else 'quality-review',ctx,chapter_provider_output_schema(stage),stage))
  check(tag+'_'+stage+'_style_from_context_kept',style in prompt,True)
# Directly validate dormant techniques and hook prerequisites, without invented prose/gates.
from novel_forge.modules.chapter_authority.creative_memo import creative_memo_schema
memo=creative_memo_schema();check('memo_optional_cost_nullable','null' in memo['properties']['creative_guidance']['properties']['character_choices']['items']['properties']['cost']['type'],True)
for typ in [PlanContractType.BOOK,PlanContractType.VOLUME,PlanContractType.ARC]:write(EV/'generated'/(typ.value+'.planning.schema.json'),planning_provider_output_schema(typ))
check('volume_irreversible_required','irreversible_change' in planning_provider_output_schema(PlanContractType.VOLUME)['required'],True)
profile=qualification_profile_for_plan({'chapter':1,'chapter_function':'quiet_observation','genre':'serious-realism'});write(CHECK/'quiet-opening-profile.json',profile.__dict__ if hasattr(profile,'__dict__') else __import__('dataclasses').asdict(profile));check('opening_charisma_required','protagonist_charm_mechanism' in profile.required_fields,True)
nohook={'project_id':'audit-project','chapter':2,'title':'余韵','premise':'观察','chapter_objective':'观察','scene_sequence':['静态场景'],'chapter_hook':''}
try:normalize_authoritative_chapter_plan(project_id='audit-project',expected_chapter=2,content=nohook,asset_version_id='synthetic:nohook',content_hash='sha256:'+'1'*64);error='NONE'
except KernelError as e:error=e.code
check('empty_hook_rejected',error,'CHAPTER_PLAN_SEMANTIC_FIELDS_MISSING')
check('current_cost_knowledge_is_principle',get('KNOWLEDGE','knowledge:chapter-causal-cost:v2','v2')['content']['usage_role'],'PRINCIPLE')
check('default_skill_v4',next(s['version'] for s in base['skill_binding']['skills'] if s['skill_ref']=='prose-generation'),'prose-generation-v4')
# Style-policy constraints are not automatically projected if absent from safe_summary and structured_facts.
style_source={'context_segments':[{'asset_type':'style_policy','asset_version_id':'synthetic:constraints-only','safe_summary':'按本书风格','constraints':['STYLE_TOP_LEVEL_ONLY:冷峻现在时'],'structured_facts':[]}]}
style_view=build_draft_style_view(style_source);write(CHECK/'style-policy-projection.json',{'source':style_source,'view':style_view});check('top_level_style_constraints_lost','STYLE_TOP_LEVEL_ONLY' in json.dumps(style_view,ensure_ascii=False),False)
write(CHECK/'results.json',{'classification':'SYNTHETIC','status':'PASS' if all(r['passed'] for r in results) else 'FAIL','checks':results,'provider_calls':0,'production_gate_matrix':'NOT_RUN: read-only task; no stateful qualification needed','scope':'Assembler and pure projections; independent transport invocation / runtime admission not executed'})
from novel_forge.modules.chapter_quality_authority.context_views import build_quality_context_view
from novel_forge.modules.chapter_quality_authority.domain import _evaluate,QUALITY_GROUPS
for tag,style in styles:
 ctx={'project_id':'audit-project','production_input_manifest':{'quality_profile_version_id':'synthetic:q','platform_profile_version_id':'synthetic:p'},'context_segments':[{'asset_type':'quality_profile','asset_version_id':'synthetic:q','structured_facts':[{'key':'thresholds','value':{'readability':10,'maximum_average_paragraph':1000}}]},{'asset_type':'platform_profile','asset_version_id':'synthetic:p','structured_facts':[]},{'asset_type':'style_policy','asset_version_id':'synthetic:style','safe_summary':style,'structured_facts':[{'key':'creative_style','value':{'constraints':[style]}}]}]}
 for group in ['structural','commercial','source_originality','longform','platform']:
  q=build_quality_context_view(group=group,revision={'chapter':2,'text':'他没有作出决定，只把窗户打开。'},revision_asset_version_id='synthetic:revision',chapter_plan={'chapter':2,'style_constraints':[style],'chapter_intent':'按作者目标观察生活'},chapter_plan_asset_version_id='synthetic:plan',context_bundle=ctx,context_bundle_asset_version_id='synthetic:context',canon={'state_changes':{},'conflicts':[]},canon_asset_version_id='synthetic:canon')
  stage='quality_'+group
  p=capture(tag+'-'+stage,stage,{'revision':{'chapter':2,'text':'他没有作出决定，只把窗户打开。'},'quality_context':q,'dimensions':list(QUALITY_GROUPS[group])},mat(base,'quality-review',ctx,chapter_provider_output_schema(stage),stage))
  check(tag+'_'+stage+'_style_present',style in p,group=='structural','Structural carries chapter plan style_constraints; source_originality style_drift judge lacks approved style goal')
 report=_evaluate(group='structural',dimension='readability',project_id='audit-project',target='synthetic:revision',metrics={'average_sentence':60},segments=tuple(ctx['context_segments']),context_bundle=ctx,canon={},fixture=False,profile_ids={'quality_profile_version_id':'synthetic:q','platform_profile_version_id':'synthetic:p'})
 write(CHECK/(tag+'-readability-fallback.json'),report)
 check(tag+'_readability_override_ignored',report['gate_status'],'FAILED','compiled threshold 10, deterministic fallback score52 still compares hardcoded70; no calibrated Provider evidence supplied')
from novel_forge.modules.source_import.execution_contracts import content_intelligence_output_schema,compound_deconstruction_output_schema,CLASSIFICATION_STAGE,MKAOS_STAGE
for stage in [CLASSIFICATION_STAGE,MKAOS_STAGE]:
 try:write(EV/'generated'/(stage+'.schema.json'),content_intelligence_output_schema(stage))
 except Exception as e:write(EV/'generated'/(stage+'.schema.error.json'),{'error':str(e)})
write(EV/'generated'/'source.deconstruction.observe.schema.json',compound_deconstruction_output_schema())
for typ in [PlanContractType.CHAPTER_GROUP,PlanContractType.CHAPTER]:
 try:write(EV/'generated'/(typ.value+'.planning.schema.json'),planning_provider_output_schema(typ))
 except Exception as e:write(EV/'generated'/(typ.value+'.planning.schema.error.json'),{'error':str(e)})
write(CHECK/'results.json',{'classification':'SYNTHETIC','status':'PASS' if all(r['passed'] for r in results) else 'FAIL','checks':results,'provider_calls':0,'production_gate_matrix':'NOT_RUN: read-only task; no stateful qualification needed','scope':'Assembler and pure projections; independent transport invocation / runtime admission not executed'})
print(json.dumps({'checks':len(results),'all_matched':all(r['passed'] for r in results),'captures':len(list(SNAP.glob('*.json')))},ensure_ascii=False))
