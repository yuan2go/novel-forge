from pathlib import Path
import json,ast,re,hashlib,shutil
O=Path(__file__).resolve().parent;R=O/'snapshot';E=O/'evidence';SHA=json.loads((O/'baseline.json').read_text())['sha']
entries=[json.loads(s) for s in (O/'inventory.jsonl').read_text().splitlines() if not json.loads(s)['id'].startswith(('I','J'))]
stages={
'prose-generation':['draft','revision','screenplay_generate','screenplay_revision'],
'quality-review':['review','rereview','quality_structural','quality_commercial','quality_source_originality','quality_longform','quality_platform','narrative_semantic_evaluation','longform_prose_review','screenplay_review'],
'chapter-outline':['memo','chapter_plan.generate','world_candidates.generate','world_candidates.evaluate','world_candidates.actor_0','world_candidates.actor_1','world_candidates.actor_2'],
'context-builder-source-isolation':['retrieval','retrieval_query_expansion','context_compress','context_fidelity'],
'canon-continuity-graph':['canon_extraction','canon_support'],
'agent-loop-governance':['agent_session'],
'long-outline':['ending.intent.generate','book_plan.generate','volume_plan.generate','arc_plan.generate','chapter_group_plan.generate'],
'worldbuilding':['world.design.generate'],
'character-design':['character.cast.generate'],
'topic-development':['creative.candidates.generate','reader.promise.generate'],
'narrative-beat-design':['theme.candidates.generate'],
'reader-feedback':['reader_outcome'],
'hot-novel-business-deconstruction':['reader.promise.generate (旧选择条件)','source analysis 商业拆解（registry另列S02）']}
chap=['memo','draft','review','revision','rereview','canon_extraction','canon_support','quality_structural','quality_commercial','quality_source_originality','quality_longform','quality_platform','retrieval','retrieval_query_expansion','context_compress','context_fidelity']
for e in entries:
 if e['kind']=='SKILL':e['stage']=stages.get(e['ref'],['UNAVAILABLE'])
 if e['kind'] in ['PROMPT_SYSTEM_INSTRUCTION','PROMPT_TEMPLATE']:
  ref=e['ref'];e['stage']=chap if 'chapter-generation' in ref else ['agent_session'] if 'agent-session' in ref else list(dict.fromkeys(s for k in ['topic-development','narrative-beat-design','long-outline','worldbuilding','character-design','chapter-outline'] for s in stages[k])) if 'story-planning' in ref else ['reader_outcome'] if 'reader-outcome' in ref else ['longform_prose_review'] if 'longform-prose-review' in ref else ['narrative_semantic_evaluation'] if 'narrative-semantic-evaluation' in ref else ['screenplay_generate','screenplay_review','screenplay_revision']
 if e['kind']=='KNOWLEDGE':e['stage']=chap;e['condition']+=' 排除agent_session/retrieval/query/context/actor等由materializer明确省略知识的阶段，见execution_gateway源码。'
 if 'selected_by' in e:e['declared_in_pack_binding']=e.pop('selected_by');e['selection_evidence']='声明绑定，非每个stage都选择；实际single-skill selector与prompt_methods条件在B/source完整给出'
 if e.get('ref')=='hot-novel-business-deconstruction' and e['kind']=='SKILL':e['usage_status']='条件启用';e['condition']+=' 当前 reader.promise 在 topic-development-qualification-v2 存在时选择topic-development，不注入本Skill全文；该body可在旧/自定义Pack条件被选择。'
 if e['kind']=='GENERATED_SCHEMA_OR_TASK_OR_SEMANTIC_CONTRACT':
  if any(s in e['ref'] for s in ['canon_extraction','BOOK.planning','ARC.planning','CHAPTER_GROUP.planning','source.mkaos']):e['evaluation']='待核验';e['evaluation_reason']+=' 已审改变创作边界字段与来源；本轮未声称巨大完整Schema所有字段/动态组合逐项语义合格。'
inline=[
('I01','src/novel_forge/modules/source_import/execution.py','_materialization',['source.content.classify','source.deconstruction.observe','source.mkaos.extract'],'Source system/template完整常量见函数原文；精确Skill由spec决定，未知动态输入不填','合理'),
('I02','src/novel_forge/modules/chapter_authority/execution_gateway.py','_materialize_source_intelligence_prompt',['source intelligence'],'含source_analysis_input/schema与最终版权尾指令；完整函数在B','合理'),
('I03','src/novel_forge/modules/production_execution/provider_admission.py','deepseek_strict_tools',['DeepSeek STRICT_TOOL_V1'],'submit_structured_result工具description/投影schema；业务格式不固定文学结构','合理'),
('I04','src/novel_forge/modules/agent_runtime/coordinator.py',None,['generic agent work order'],'Execute the frozen Agent work order and return only a candidate AgentOutputEnvelope. Domain Authority owns commit. 动态context work_order全文未知，未证明主章路径使用','待核验'),
('I05','src/novel_forge/modules/agent_collaboration/application.py',None,['generic collaboration'],'Execute the frozen Agent collaboration work order. Return only an AgentOutputEnvelope candidate; do not claim Authority commit. 固定说明通用；实际work_order未知','待核验'),
('I06','src/novel_forge/modules/production_execution/codex_configuration.py',None,['Codex CLI'],'CODEX_INPUT_ONLY_OVERRIDES与output schema projection；实际CLI/version未观察，不推断宿主AGENTS进入写作','合理'),
('I07','src/novel_forge/modules/chapter_authority/execution_gateway.py','_language_semantic_contract',['reader facing stages'],'只接受governed zh-CN，显式拒绝其他值；明确语言支持边界，不等同古风。若产品承诺多语言则能力缺口','条件适用'),
('I08','src/novel_forge/modules/story_design_authority/qualification.py',None,['narrative_semantic_evaluation'],'固定qualification criteria definitions/strict verdict与独立Evaluator指令，见P02和G记录','有问题'),
('I09','src/novel_forge/modules/chapter_authority/chapter_plan_views.py','qualification_profile_for_plan',['production preparation'],'主角魅力/hook等由profile强制；不是仅Prompt问题，见P03','有问题'),
('I10','src/novel_forge/modules/chapter_quality_authority/domain.py','_evaluate',['quality fallback'],'固定70/270/36基点的条件fallback；exact calibrated evidence优先；见P06','有问题'),
('I11','src/novel_forge/modules/story_planning_runtime/execution.py','_repair_context',['Planning repair/retry'],'故障指令绑定本次source candidate/result与frozen task、report hash；完整代码包括raw-result repair与新Knowledge翻译分支。没有把本次修复内容硬加到所有书的证明','合理'),
('I12','src/novel_forge/modules/story_planning_runtime/knowledge_translation.py',None,['knowledge translation/craft planning'],'Schema动态descriptions要求逐card ADOPT/ADAPT/REJECT与scene定位，prerequisite/exception判断；选择card内容未知，未证明必选全部技巧','条件适用'),
('I13','src/novel_forge/modules/worldbuilding/actor_isolation.py','actor_task',['world_candidates.actor_0','world_candidates.actor_1','world_candidates.actor_2'],'v1/v2/v3 task instructions按pending commitment/persistent意图选择；只用本actor知识动机，不宣称judge/计划即事实；完整constructor source，动态私有scope未造值','条件适用')]
for id,rel,sym,stage,note,evaluation in inline:
 p=R/rel;tree=ast.parse(p.read_text());node=next((n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==sym),None) if sym else None
 line=node.lineno if node else 1
 entries.append({'id':id,'sha':SHA,'kind':'INLINE_INSTRUCTION_TOOL_CONFIG_OR_GATE','ref':rel+'#'+str(sym or 'inline/constants'),'source':rel+':'+str(line),'version':'frozen code SHA','source_file_sha256':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest(),'stage':stage,'usage_status':'代码可达但缺少真实请求' if id not in ['I04','I05'] else '无法确定','condition':note,'message_role':'user string/CLI option/host gate according to source; no invented role','injection_order':'see B function and explicit send adapter','dynamic_variables':'current frozen task/scope/context; actual runtime values UNAVAILABLE','full_text':'evidence/source/'+rel,'evaluation':evaluation,'evaluation_reason':note,'redacted':False})
# Discover every physical transport and prompt/envelope/abstract candidate callsite by AST across frozen production src, then map to known families.
callpoints=[]
for p in sorted((R/'src/novel_forge').rglob('*.py')):
 rel=str(p.relative_to(R))
 if '/tools/' in rel:continue
 try:tree=ast.parse(p.read_text())
 except SyntaxError:continue
 lines=p.read_text().splitlines()
 for node in ast.walk(tree):
  if not isinstance(node,ast.Call):continue
  fn=ast.unparse(node.func);keywords={k.arg for k in node.keywords}
  if fn in ['_materialize_production_codex_prompt','_materialize_source_intelligence_prompt','execute_domain_candidate'] or fn.endswith('.responses.create') or ('input_text' in keywords and any(t in fn for t in ['Envelope','Payload'])) or (p.name=='backends.py' and fn in ['subprocess.Popen','subprocess.run']) or (p.name=='deepseek.py' and fn=='self._transport') or (p.name=='process_supervisor.py' and fn=='subprocess.Popen') or (p.name=='backends.py' and fn in ['self.supervisor.run','self.provider_adapter.invoke']):
   family='source-analysis' if '/source_import/' in rel or fn=='_materialize_source_intelligence_prompt' else 'generic-domain/agent: dynamic downstream port gap' if fn=='execute_domain_candidate' else 'physical transport from frozen ProviderRequestEnvelope' if '/provider_control/' in rel or '/production_execution/backends' in rel else 'shared production assembler / frozen payload resolver'
   if rel.endswith('backends.py') and fn=='subprocess.run':family='CLI version probe: no model input'
   if '/sampling.py' in rel or '_sampling.py' in rel:family='sampling/reference contract producer reconstruction; shared assembler; not itself a send'
   callpoints.append({'source':rel,'line':node.lineno,'call':fn,'keywords':sorted(str(k) for k in keywords),'family':family,'sha':SHA,'evidence_status':'CODE_EXISTS' if fn=='execute_domain_candidate' else 'WIRED (static)','real_capture':'UNAVAILABLE'})
   q=E/'source'/rel
   if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
(E/'model-callpoints.json').write_text(json.dumps(callpoints,ensure_ascii=False,indent=2)+'\n')
for n,x in enumerate(callpoints,1):entries.append({'id':f'J{n:02}','sha':SHA,'kind':'CALL_OR_INJECTION_SITE','source':x['source']+':'+str(x['line']),'version':SHA,'call':x['call'],'stage':x['family'],'usage_status':'无法确定' if 'generic' in x['family'] else '代码可达但缺少真实请求','full_text':'evidence/source/'+x['source'],'evaluation':'待核验' if 'generic' in x['family'] else '合理','coverage':'静态映射，不计入原文资产数量；dynamic grant/frozen inputs/actual request未取得'})
(O/'inventory.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in entries))
c=json.loads((E/'counts.json').read_text());c.update(inventory_records=len(entries),inline_instruction_or_gate_records=len(inline),call_or_injection_sites=len(callpoints),source_files_exported=sum(p.is_file() for p in (E/'source').rglob('*')),distinct_text_source_files=len({e.get('source_bytes') for e in entries if e['kind'] in ['SKILL','PROMPT_SYSTEM_INSTRUCTION','PROMPT_TEMPLATE','SOURCE_ANALYSIS_SKILL']}))
(E/'counts.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
# Ensure metadata distinction visible, regenerate all per-asset table.
table=['| ID | 身份/版本 | 生效状态 | 评价 | 理由/条件 |','|---|---|---|---|---|']
for e in entries:
 if e['kind'] in ['ACCESS_GAP','CALL_OR_INJECTION_SITE']:continue
 table.append('| '+e['id']+' | '+str(e.get('ref'))+' / '+str(e.get('version'))+' | '+e['usage_status']+' | '+e['evaluation']+' | '+e.get('evaluation_reason','').replace('|','/')+' |')
(O/'ASSET_EVALUATIONS.md').write_text('# 逐资产评价\n\nSHA '+SHA+'；Pack绑定声明不等同每个stage选择。旧版本与动态访问缺口不冒充真实请求。\n\n'+'\n'.join(table)+'\n')
for rel in ['tests/unit/test_chapter_plan_fidelity.py','tests/unit/test_prompt_skill_calibration.py','tests/unit/test_prompt_generation_convergence.py']:
 q=E/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,q)
# Raw/assembled distinction, include generic inline full source without invented final requests.
full=O/'PROMPTS_AND_SKILLS_FULL.md';full.write_text(full.read_text().split('\n## D · 内联附加与物理调用索引')[0])
with full.open('a') as f:
 f.write('\n## D · 内联附加与物理调用索引\n\n完整内联system/template/工具说明/CLI覆盖和generic Agent固定说明分别见 inventory I01..I10及包内源；实际调用点见 evidence/model-callpoints.json。generic工作单/会话内容UNAVAILABLE，未补造。\n\n')
 for x in inline:
  id,rel,sym,stage,note,evaluation=x;f.write('### '+id+' · '+note+'\n\n[完整原始源码](evidence/source/'+rel+')；版本='+SHA+'；用途='+', '.join(stage)+'；评价='+evaluation+'。\n\n')
print(json.dumps(c,ensure_ascii=False))
