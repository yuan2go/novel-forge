from pathlib import Path
import json,ast,hashlib
O=Path(__file__).resolve().parent;R=O/'snapshot';E=O/'evidence';B=json.loads((O/'baseline.json').read_text());C=json.loads((E/'counts.json').read_text());SHA=B['sha']
def loc(rel,sym=None,line=None):
 if sym:
  t=ast.parse((R/rel).read_text());node=next((n for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)) and n.name==sym),None);line=node.lineno if node else line
 return f'[{rel}'+(f':{line}' if line else '')+'](evidence/source/'+rel+(f'#L{line}' if line else '')+')'
def m(path,sym=None,line=None):return loc('src/novel_forge/modules/'+path,sym,line)
# Package files keep frozen source line numbers. GitHub blob links below are pinned, never floating main.
P=[
 {'id':'P01','stage':'Foundation / 作品方案形成','quote':'Design an earned ending direction with irreversible costs, required closures and forbidden shortcuts; this is future intent, not a predetermined accepted event.','refs':m('story_planning_runtime/foundation_generation.py','foundation_task')+'；'+m('story_planning_runtime/foundation_generation.py','foundation_output_schema'),'condition':'所有 ending.intent.generate；theme.candidates.generate 同时使用 costly character decisions 与必填 choice/cost。既有 Formation 选定此阶段时，不受 genre/audience 条件分流。','why':'新 Skill 已说技法服从本书，但 task 又无条件要求不可逆代价。ending Schema 的 protagonist_cost 为非空字符串；theme choice_tests 每项 cost 非空且至少1项。“最终有后果”可以通用，“一定不可逆牺牲”不是所有作品目的。','scope':'当前书授权的结局/主题策略；不是公共 Foundation 强制审美。','affected':'无损成长、守成、开放式结尾、观察式现实、轻喜剧等不选择不可逆代价的作品。','override':'作者反向要求仍原文保留，公共 task 也保留，形成冲突；不能证明模型最后选了哪方。','severity':'高','confidence':'高（规则与装配）；历史任务来源未确认','proof':'A 确认；B WIRED 且 SYNTHETIC 装配确认；真实请求/实际生产激活未观察；C 文学效果 UNAVAILABLE。','fix':'先改 foundation_task；同步 ending/theme Schema 及 Foundation validators，使用现有 author constraints 与已接纳方案判断适用性，允许不适用，不用空字符串伪装代价。','verify':'同模型调用零出站地渲染两种合法作者目标；不使用不可逆代价时 task 与 Schema 都允许；有作者明确选择时完整保留。'},
 {'id':'P02','stage':'层级规划 / 独立语义资格门','quote':'"PRESSURE_ESCALATION", "IRREVERSIBLE_CHANGE", "CLIMAX_PAYOFF_COST", "NEXT_VOLUME_BRIDGE"','refs':m('story_design_authority/qualification.py',line=330)+'；'+m('story_design_authority/qualification.py','validate_narrative_qualification')+'；'+m('story_planning_runtime/execution.py','planning_provider_output_schema'),'condition':'required_qualification_profiles 按 generator operation 选固定 criteria；narrative_semantic_evaluation 逐条判断；qualifier 不按当前作者技法选择过滤。Volume schema 必填非空 irreversible_change/midpoint/climax/settlement/next_volume_bridge。','why':'全部 frozen criteria 必须返回 PASS，合法 verdict 仅 PASS/FAIL/INSUFFICIENT；不适用不能表达。SERIALIZATION_CAPACITY、REWARD_REACHABILITY 名称本身不是爽文定罪，但与硬结构/不可逆字段和无适用性通道合起来，使非升级、非连载或终卷目标无法自然表示。','scope':'当前书/Volume 所选择的商业、情绪或戏剧目标；确有到期义务仍必须验收。','affected':'独立短篇/中篇、非连载、静态群像、终卷无后续桥、非线性/开放结构、拒绝不可逆变化的卷。','override':'作者 Brief 可自由输入；后面的 profile 集合与 Schema 不因此改变。Reviewer 不需套用旧 Skill 全文也会收到这些 criteria。','severity':'高','confidence':'高（字段和门禁）；单一 criterion 的文学解释置信度中等','proof':'A+B 静态 WIRED；volume required 字段 SYNTHETIC 断言；未伪造独立 evaluator verdict/生产 receipt；C 未验证。','fix':'在已有 qualification profile 与 output-schema/validators 层做版本化适用性，不另建平台。以当前目标解释 reader promise，给非连载/终卷/无代价一个正式合法表示；不要把缺证据改成 PASS。','verify':'同输入只改变串行升级/不可逆策略与终卷标记，选定 criteria 应反映选择；不适用不会触发 repair；已适用硬约束失败仍阻断。'},
 {'id':'P03','stage':'Chapter 输入预备 / 章节结构合同','quote':'BASE_REQUIRED_FIELDS = ("title", "premise", "chapter_objective", "scene_sequence", "chapter_hook")\nif chapter == 1 or function in {"opening", "golden_opening"}:\n    required = BASE_REQUIRED_FIELDS + ("conflict_chain", "reader_promise_actions", "protagonist_charm_mechanism", "information_reveals", "next_chapter_bridge")','refs':m('chapter_authority/chapter_plan_views.py','qualification_profile_for_plan')+'；'+m('production_preparation/service.py',line=256)+'；'+m('chapter_authority/chapter_plan_views.py','normalize_authoritative_chapter_plan'),'condition':'ProductionPreparation READY 后按 chapter/function 选择 strict profile；第1章不论 quiet_observation 仍走 opening；genre/platform 只记入 profile，未改变 required_fields。','why':'身份、场景单元和目标是接口；非空 hook、主角魅力机制、ordinary 的 antagonist_pressure/suspense_curve 等是创作内容。不能以“可以随意填余韵”代替正式不适用。ending 分支还要求 next_chapter_bridge。','scope':'书/章已选择的开篇、悬念、对抗及衔接策略。','affected':'慢热群像、无中心主角、低冲突观察章、无反派章、无悬念收尾、独立终章。','override':'作者章节功能 quiet_observation 也不能让第1章避开 opening 字段；空 chapter_hook 在纯 normalization 被阻断。','severity':'高','confidence':'高（存在与阻断）；hook 可以宽解释，不证明必须悬崖结尾','proof':'A+B 静态生产准备调用；SYNTHETIC quiet-opening-profile 与 empty_hook_rejected；无实际 READY / BLOCKED 运行 receipt；C 未验证。','fix':'先调整已有 profile.required_fields 的内容适用条件和章节结束目的表达，再同步 schema；保留身份、可执行任务和连续性验证，不把缺失的必要计划放行。','verify':'首章为观察章/普通章无反派/独立终章分别可正式标不适用；对作者选定悬念仍检查；不允许仅填“无”通过伪约束。'},
 {'id':'P04','stage':'Writer 计划与风格投影','quote':'build_draft_plan_view 的白名单没有 style_constraints；build_draft_style_view 只输出 asset_version_id、safe_summary、structured_facts。','refs':m('chapter_authority/chapter_plan_views.py','build_draft_plan_view')+'；'+m('chapter_authority/chapter_plan_views.py','build_draft_style_view')+'；'+m('chapter_authority/provider_views.py','_render_context_view')+'；'+m('chapter_authority/handlers.py',line=1390),'condition':'正常 draft 从 normalized plan 构造 task view；Context 为 draft 跳过 chapter_plan/style_policy，因其预期已在 task 中。独立 operator style_policy 虽接受顶层 constraints，若其 summary/facts 没重复，投影不传。','why':'存储和 normalization 保留要求，正文投影丢失。不是文学偏好争议，而是已有合法字段没有送给 Writer；再强调“服从作者”无法恢复丢失值。','scope':'已有本书/本章作者约束，应原样随适用范围进入阶段输入。','affected':'只在 ChapterPlan.style_constraints 声明时态、句式、语气的所有作品；只在独立 style_policy.constraints 声明风格的作品。','override':'两个合成 marker 在最终 draft 均消失；Foundation 标准编译路径会将 creative_style 包进 facts，所以不能说所有风格都丢失。author_design_guidance 另一通路存在。','severity':'高','confidence':'高','proof':'A+B WIRED + SYNTHETIC 丢失对照；同 safe_summary/facts 风格在 draft/review/revision/rereview 都保留；C 未验证。','fix':'修复现有 build_draft_plan_view/build_draft_style_view 与 Context 去重假设，保留 style_constraints/constraints 及其版本/范围；不用新增题材枚举或 Prompt 套餐。','verify':'单变量 marker 对照；从真实已批准 style source 到四阶段查约束与身份；冲突时显式保留并诊断，不静默覆盖。'},
 {'id':'P05','stage':'style_drift / anti_ai 质量审读与修订依据','quote':'SourceOriginalityQualityContextView 含 revision_text、source_governance、context_manifest、source_isolation_result、copyright_boundary、governed_segment_identities，但没有本书 style_profile/style_policy 内容或 author intent。','refs':m('chapter_quality_authority/context_views.py','build_quality_context_view')+'；'+m('chapter_quality_authority/domain.py',line=49)+'；'+m('chapter_authority/provider_views.py',line=805)+'；'+m('content_quality_loop/domain.py','derive_quality_actions'),'condition':'固定 quality_source_originality 请求 dimensions 包括 originality、anti_ai、style_drift；通用 Context quality_* 分支跳过全部 segments，实际任务 quality_context 成为唯一故事判据。','why':'检测“漂移”需要本书风格基准。共享 Skill 虽要求按 author intent 审读，但该投影没给出内容。可能依靠模型默认审美解释 anti_ai；不能证明它一定禁长句或修回套路。','scope':'与当前书已批准风格、作者意图和当前候选比较；原始参考表达仍隔离。','affected':'克制长句、刻意重复、诗性、非线性等容易与通用“AI味”印象混淆的作品；所有需要真实风格一致性判断的作品。','override':'合成 style marker 在 structural 出现，在 source_originality/commercial/longform/platform 不出现；其中后3组未必需要完整风格，不据此单独判错。style_drift 非 blocking；anti_ai 是 blocking，只有实际失败及合法 evidence 才能产生修订任务。','severity':'高（anti_ai）；中（style_drift 非阻断）','confidence':'高（上下文缺项）；实际审美误判为待核验','proof':'A+B WIRED+24快照中的质量对照；未执行模型判断、修订任务或接纳；C 未验证。','fix':'将现有已批准风格与适用作者目标的精简有源投影放进相应 QualityContext；缺基准时不足证据，不用通用禁词表代替。跟随修订输入保留同一基准。','verify':'同段落改风格目标：对应style_drift/anti_ai 输入跟随变化；合意风格不能只因技法而触发修订。缺基准时给出明确不足证据；匿名文学验证另行授权。'},
 {'id':'P06','stage':'质量 deterministic fallback / 技术阈值','quote':'score = round(max(0.0, min(100.0, 100.0 - max(0.0, average - 36.0) * 2.0)), 2)\n"PASSED" if score >= 70 else "FAILED"\n"PASSED" if average <= 270 else "FAILED"','refs':m('chapter_quality_authority/context_views.py','compile_quality_policy')+'；'+m('chapter_quality_authority/domain.py','_evaluate'),'condition':'没有可消费的 exact target/dimension calibrated evidence 才进入 fallback；已校准 Provider evidence 优先。','why':'compile_quality_policy 接受 readability/maximum_average_paragraph 等覆盖，但 fallback 固定70/270；长句评分还固定36基点。结果可能把书选定长句当可读性失败。并非所有当前真实 Provider 请求都走这里。','scope':'显式质量/阅读设备配置；文体相关阈值与建议不宜伪装普适文学真理。','affected':'合法长句、长段及非移动端优先作品；仅相关 fallback。','override':'合成配置 readability=10，句均60，score52仍FAILED；证明覆盖未消费。readability blocking；mobile/paragraph 本身非blocking。','severity':'中（条件性）','confidence':'高（离线fallback）；当前部署发生频率未知','proof':'A+B 条件 WIRED+SYNTHETIC _evaluate；真实 calibrated precedence 静态确认；C 未验证。','fix':'让 fallback 消费编译后的配置；固定指标作为可解释诊断/适用作品策略，避免覆盖明确文体目标；保留客观完整性检查。','verify':'同指标不同合法阈值改变 verdict；有 exact calibrated evidence 时仍优先；设备模式/文体不得由隐蔽36基点替作者决定。'},
 {'id':'P07','stage':'条件上游专业资料分析 Skill','quote':'- 多学科知识只能增强可信度，不能替代爽点和冲突。\n- 禁止让专业合理性破坏追读和情绪奖励。','refs':loc('skills/multidisciplinary-knowledge/SKILL.md',line=63)+'；'+m('source_import/methodologies.py','require')+'；'+m('source_import/execution.py','_materialization'),'condition':'SourceMethodologyRegistry 精确选择 multidisciplinary-knowledge 时全文注入 Source 分析；分析目的本可由当前任务指定。必须 Observation→抽象/审核→Knowledge选择后才可能间接进入写作。','why':'专业可信度也服务严肃/出版/硬科幻目标；这里把商业爽点/追读优先性写成无条件禁令。不是当前 Writer 默认必选 Skill。','scope':'当本次明确面向追读/情绪奖励作品时启用；其他目标应按需求权衡可信度与阅读体验。','affected':'本次选择该资料方法的严肃现实、可信度优先硬科幻、非商业作品。','override':'上游约束可能压低专业目标，但未取得本书 Observation/Card/选择 lineage，无法证明下游已经覆盖作者输入。','severity':'中（条件上游）','confidence':'高（原文/条件加载）；下游效果待核验','proof':'A+B 条件静态 WIRED；无 Source真实请求、批准知识/Writer引用；C 未验证。','fix':'只改这两个商业绝对句与操作流程第8项，绑定本次作品/分析目标；保留安全、来源和不把知识变成无关讲义的原则。','verify':'专业资料分析目的只改变商业/可信度取舍，方法输入随之改变；源表达仍不得进入Writer；不将专业准确性降级为普遍次要。'}]
(E/'findings.json').write_text(json.dumps(P,ensure_ascii=False,indent=2)+'\n')
text=f'''# Prompt / Skill 只读审计

固定基线：[{SHA}](https://github.com/yuan2go/novel-forge/tree/{SHA})。仓库：{B['repository']}。审计起始：{B['audit_started_at']}（北京时间 2026-10-04 21:20:14）。remote refs/heads/main 在开始时以 git ls-remote 核验。全程从 git archive 的仓库外快照取证；本地用户分支 `{B['workspace_branch']}`，HEAD `{B['workspace_head']}`，未切换/覆盖/清理，未读取其未提交生产记录作为 main 的运行证据。结束核验见 baseline-end.json；main 若变化仅报告。

## 结论

发现公共生产规则存在范围过宽和作者输入绑定缺口：7项机制问题，另有2项历史兼容/旧合同风险登记。最强证据是不可逆代价 task/Schema、固定资格 criteria、章节预备必填，以及 Writer/Quality投影缺字段。**可以确认规则存在并进入指定可达装配链（A+B）；不能确认本次 main 对应的线上 release/真实请求使用，更不能确认它造成某本小说质量差（C未验证）。**

未证明这些约束出自“某次AI开发任务”。少量 blame 可定位首次提交，但没有对应局部任务授权证据。不能将已有冲突规则自动包装为作者选择：已生成/批准 Foundation 也必须回溯 Brief 与适用性；本轮尚无同版本批准产物，未替它背书。

当前默认 chapter Pack 2.9.0 的 system v3/template v7、prose v4、quality v3、chapter-outline v3 和 causal-cost v2 已明显改为按本书选择技法。没有确认默认全古风、每章笑点、固定十二章、固定人物或世界观。Formation 的 target_chapters 为明确必填1..10000，不是静默十二章；genre/audience 是自由有界字符串，没有在该入口发现未知题材静默落回固定题材。Writer尊重风格的正向路径存在；问题发生在上游硬合同与部分投影/审读基准，而不是“所有Prompt都坏了”。

## 判定标准与证据边界

A 公共处理规则；B 当前作品要求；C 条件技法；D 透明产品默认/技术限制；E 历史样例/一次性要求；F 来源/范围不明。按用途而非目录判定。具体作品输入进入 Prompt 合法；JSON/场景slots不等于全小说固定情节；保持Canon不等于所有小说共享Canon。

代码层能力状态使用 CODE_EXISTS / WIRED / EXECUTABLE / QUALIFIED / PRODUCTION_PROVEN。纯构造器和投影在阻断外部IO的沙箱中 EXECUTABLE；生产调用连接可静态判 WIRED；未取得真实资格、部署与请求证据，不能升级 QUALIFIED/PRODUCTION_PROVEN。下文A=原文存在，B=特定路径装配，C=实际文学偏差，与仓库能力状态不是一套名词。

| 限制 | 分类 | 判断 |
|---|---|---|
| 精确身份/hash、候选与接受事实分离、源表达隔离 | CURRENT_PROVEN_INVARIANT（已读代码检查的局部范围） | 保留；不宣称完整系统所有路径已生产验证 |
| 默认 Pack 版本、当前单消息 XML 装配、仅zh-CN规则 | CURRENT_RUNTIME_FACT（代码） | 部署选择另需核验；非古风或短句等题材要求 |
| 512K Context、64K planning、输出预算/timeout/目标章数 | CONFIGURABLE_POLICY / CURRENT_RUNTIME_FACT | 输入/执行容量不是作品文学规模；入口章数明确，超限失败而非偷偷改章数 |
| legacy prose/quality/causal-cost v1 | HISTORICAL_COMPATIBILITY | 当前默认未选；旧冻结Pack是否仍活跃未知 |
| 不可逆代价、无条件商业结构、固定质量fallback | UNRESOLVED_DESIGN_CONSTRAINT | 不是因为代码存在就成为合理通用文学合同 |

访问：冻结 tracked 代码/config/Skills、相关构造器、指定 git history；不连接DB、不读.env/凭证、不读取原小说/私有作者资料、不运行真实CLI/Provider、不安装依赖。本轮所有输出在仓库外。脚本先禁止socket/子进程/psycopg连接与快照写入，再import纯函数；PYTHONDONTWRITEBYTECODE=1。未知真实值留UNAVAILABLE。

## 实际生产链与决定权

下列所有位置绑定同一SHA，链接指向包内冻结源文件；完整符号行号索引 evidence/symbol-index.json。不是用文档宣称实现。

| 阶段 | 实际入口 / owner / 突变边界 | 内容决定字段与装配 |
|---|---|---|
| 作者Brief | {loc('src/novel_forge/api/routers/content_authority.py',line=98)} → ContentAuthorityApplication.admit/execute → codecs._creative_brief | creative-brief-v2 idea/genre/audience/constraints/source_boundaries；v3 author_design；v4 editorial_learning。validate_creative_brief 明确拒绝未知/超界字段，不自动补固定题材。v1是旧商业长篇合同。 |
| 作者追加/采纳 | {loc('src/novel_forge/api/routers/book_authority.py',line=285)} → author_supervision → PostgresStoryDesignAssetAuthority | 明确design、hash-bound Brief与作者身份；REQUIRED/DIRECTION、scoped fragments/decisions。作者私有原文不直传Writer，公开适用guidance有独立路径。 |
| Formation | {loc('src/novel_forge/api/routers/book_authority.py',line=1037)} → book_design_authority.formation / formation_generation | frozen brief、generation_policy.target_chapters/title/approval_mode、v3作者选定Foundation。6类Foundation按 required parent graph；task和Schema含P01。 |
| Foundation qualification / BookDesign接纳 | {m('story_design_authority/application.py','PostgresStoryDesignAssetAuthority')}、{m('story_design_authority/qualification.py','validate_narrative_qualification')} | 生成候选→独立语义判断→Story Design Authority gate/激活；profile按操作固定，P02。批准不自动证明是作者想要的，需反查输入。 |
| 创建输入 / style | {m('book_authority/creation_inputs.py',line=117)} → creative.style_projection | READY active BookDesign、批准creative/character绑定 → style_profile:narrator/pov/genre_conventions/constraints/original_examples；整体creative_style放facts，voices与realization policy保存，非外部参考表达。 |
| Book/Volume/Arc/ChapterGroup/Chapter规划 | {m('story_planning_runtime/execution.py','planning_provider_output_schema')}、{m('story_planning_runtime/execution.py',line=5254)} | frozen_inputs、author scope projection、narrative intelligence、exact Mission/scene/knowledge/Arc refs；候选由Hierarchical Planning/Plan Change激活；未来计划不作已发生事实。 |
| World/Actor条件路径 | world_preparation / world_sampling / worldbuilding | 世界proposal、独立评价、actor_0..2，冻结world action/candidate/task/policy；NO_OP/DEFER可用；无真实对象，本轮完整constructor源、未造动态slice。 |
| Chapter准备 | {m('production_preparation/service.py',line=256)} → plan normalize | 输入身份/准入→P03按章号/功能的required profile；Writer view P04。 |
| Memo / Retrieval / Context | chapter handlers、creative_memo、provider_views/context pack | accepted history、query proposal、extract unit选择/fidelity；当前memo cost可null，非强制成本套餐；知识按scope/governance选择。 |
| Pack与Skill选择 | {m('capability_pack_authority/application.py','_select_capability_skill')}、runtime:655、prompt_methods | 合同精确匹配/单一fallback，歧义failclosed；每次只取一个 skill，不是所有注册Skill全文同时注入。reader.promise当前qualification-v2选topic；规划long-outline v2；按Shared+当前method投影。 |
| Writer/Reviewer/Reviser | {m('chapter_authority/execution_gateway.py','_materialize_production_codex_prompt')}、handlers:1390、review_window | 1system→2单一skill→3required_knowledge→4条件tool_policy→5渲染template/task/context→6stage contract→7output_schema。v7writer accepted-history投影；review exact quote+author targets；targeted revision有独立范围/quote合同，保留无关slots。 |
| Quality / 回改 | {m('chapter_quality_authority/context_views.py','build_quality_context_view')}、content_quality_loop.domain | 5组QualityContext，fixed dimensions；P05风格基准缺项，P06有条件fallback；只blocking失败推repair，商业reward/hook/charisma单项默认非blocking。 |
| 接纳 / 后续 | {m('book_authority/production.py','accept_chapter')}、commit_acceptance:1299 | 锁定selected outputs，具体作者审批、grounding、ChapterOutcome/StoryState/Canon/projection一体commit；accepted cursor给后续章使用。不能用Reviewer分数代替Book接纳。Reader outcome为SHADOW，意见不直接改active plan。 |

这些owner使用 AuthorityUnitOfWork/PostgreSQL repositories 作持久化：content application:90/119，StoryDesign application:206，Book accept:1299/1494；repositories在 owning UoW里不是另一个内容决定者。相关表迁移包括 0038 story_design、0051 book_design、0071 capability_pack、0120 foundation_generation、0148 author_supervised_design、0119 grounded_chapter_acceptance；原始manifest和迁移源在evidence/source。未连接实际数据库，不能声明迁移已部署。

## 模型发送边界与额外指令

| 边界 | 代码与进入内容 | 已确认 / 缺口 |
|---|---|---|
| OpenAI | {m('provider_control/openai_v2.py','execute')} responses.create(model,input=envelope.input_text,reasoning,max_output_tokens...) | 单字符串input；XML system标签并非API system角色；无独立instructions/response_format。output Schema在业务串中，解析仍有host validator。未发送。 |
| DeepSeek | provider_control/deepseek.py:124；{m('production_execution/provider_admission.py','deepseek_strict_tools')} | 单user message，JSON object或STRICT_TOOL；submit_structured_result说明及投影schema全文已导出。strict剔除部分native限制，主机验证保留；不把它误作文学风格变化。 |
| Codex CLI | production_execution/backends.py:1830..1887；codex_configuration.py:10 | stdin input_text、--output-schema投影、--cd固定目录、--ignore-user-config/--ignore-rules/--ephemeral、project_doc_max_bytes=0、skip_host_skill_discovery=true、memories/hooks/apps等禁用。静态支持“排除宿主开发指令”，没有真实CLI版本/argv/receipt，不能断言实际已加载/未加载任何宿主AGENTS。 |
| Source intelligence | {m('source_import/execution.py','_materialization')} → {m('chapter_authority/execution_gateway.py','_materialize_source_intelligence_prompt')} | separate system+精确method Skill+template+target/source_analysis_input+schema+版权尾指令。源证据只作分析；不是小说Writer默认参考文本。 |
| 通用Agent/Longform wrappers | agent_runtime.coordinator / agent_collaboration.application / production_execution.domain_execution | generic candidate说明CODE_EXISTS；work_order/instruction/transcript可能动态改变内容，真实绑定UNAVAILABLE。不得虚构它们已主导当前章写作。 |

所有实际发现的实体发送端（SDK、HTTP、CLI）均映射到装配或动态payload resolver；embedding专用contract、Source路径及generic wrappers已单列。没有观察真实请求，代码中多个调用不能冒充多个已发生生产请求。

## 输入传播表

“有”表示源码或合成装配确认，不表示模型理解正确；“间接”表示已接纳方案而非原文继续传递。

| 输入 | 入口/保存 | 规划 | Writer | Reviewer/Reviser | 覆盖或缺口 |
|---|---|---|---|---|---|
| 题材 | v2 genre自由字符串；v1 target_genre | frozen Brief→creative/world/plan | 经过creative_style/任务/accepted world，不保证原Brief整份每次注入 | frozen story data与author guidance间接 | 无发现genre未知时静默fallback；泛化规则P01-P03仍并行 |
| 受众 / 主题 | audience/idea/constraints、theme_contract | Foundation/theme/reader promise | 当前章目标、世界人物、reader promise间接 | review目标/quality分组间接 | promise资格仍固定REWARD/SERIALIZATION；目标语义是否正确转译无真实样本 |
| 风格 / 语气 / 句式 | v2 constraints，v3author fragments；creative style_profile；style_policy | frozen inputs与author decisions有 | safe_summary/facts正常可达；ChapterPlan.style_constraints/独立顶层constraints可丢 | 普通review/revision context可保留；source_originality无风格基准 | P04、P05；标准compiled style路径不等同constraints-only反例 |
| POV / 叙述方式 | constraints/style_profile.pov/typed point_of_view | Character/scene knowledge contract | point_of_view与creative_style、voices有 | actor/POV边界与候选quote有 | 未支持所有叙述类型枚举不等于禁止；POV未因独立voice跳过而整体丢失 |
| 时态 | 无独立Brief tense字段；可写constraints/author guidance | 自然语言保留，需模型/计划表达 | 若仅plan.style_constraints承载则P04 | 自然语言路径有；没有专用保证 | 产品字段缺口，不以“未实现字段”自动定污染 |
| 篇幅 / 章数 | explicit target_chapters1..10000；target_word_count/platform_profile | bounded Book/plan依授权 | target_word_count有 | quality structural target count；platform length明确冻结 | 输出token/Context容量是技术限制；未证明固定12；裁切不是可接受静默缩书 |
| 节奏 / 开篇 / 收尾 | constraints/章功能/reader experience | plan具体化 | frozen slots/obligations/creative memo | 普通review新合同可不罚无reward/hook | P02-P03资格/结构硬约束优先限制表达 |
| 人物 / 世界 | idea/author design +批准world/character | typed parents，必要CURRENT细节；不无限填远期 | exact actor/voice/factscope | Canon/knowledge判断 | Foundation character.wound/false_belief等全非空、cast max12是有界候选合同；大群像扩展路径未离线验证，不能把它宣称全书只能12人 |
| 作者禁忌 / 允许与建议 | constraints/prohibited_outcomes；REQUIRED vs DIRECTION | exact scope/hash/decisions | prohibited_outcomes + publicguidance | author_design_review_targets + bounded preservation | strength/语义执行未模型验证；AUTHOR_ONLY原文隔离合理，公开guidance丢失另需实物核验 |
| 参考作品 / 资料 | source_boundaries / governed Source assets | 只approved abstraction / editorial-learning当前scope | Context可用知识，不读raw source | source/originality checks | 真实KnowledgeCard与选择scope未知；P07仅上游特定方法 |
| 可选技法 | Craft scope/adopt/omission、currentmemo null | typed translations/strategy、prerequisite/contraindication | realization slots按选定策略，非全部Craft常驻 | NOT_USED/UNKNOWN/约束适用性 | 当前选不使用可在Prompt说明不罚；资格层仍P02。无真实选择库，不能排除不适用Card被错误采纳。 |

作者缺项时：Brief v2必填idea/genre/audience/constraints，其他合理细节由本书授权Foundation规划；不是要求作者填完所有人物世界。超界/未知字段显式拒绝、未发现题材默默替换；输入内部语义矛盾主要仍交模型和后续gate，尚无通用显式冲突优先诊断证据。不得凭模板“respect author”宣称语义已经解决。

## 问题清单

'''
for p in P:
 text+=f'''### {p['id']} · {p['stage']}

严重性：{p['severity']}；置信度：{p['confidence']}。

原文或精确代码事实：

````text
{p['quote']}
````

固定SHA定位：{p['refs']}。

生效条件：{p['condition']}

为何不合理：{p['why']} 应有作用范围：{p['scope']} 影响作品：{p['affected']}

作者决定权：{p['override']}

证据强度：{p['proof']}

最小修改：{p['fix']}

验证：{p['verify']}

'''
text+='''### C01 / C02 · 历史兼容和声明合同风险

C01：旧 prose v1/quality v1/chapter-outline v1 无条件商业reward/hook、成本和Markdown自检等完整原文在汇编；旧causal-cost v1为CONSTRAINT且“Every decisive chapter action ... irreversible cost”。当前默认已选v4/v3/v3与knowledge v2，不能称这些是当前默认。resolver仍能精确解析历史版本，若数据库ACTIVE旧冻结Pack仍有条件性生效；实际选择未知。最小处置先核验release/attempt frozen hash，避免改历史字节或误删兼容证据；新的选择应使用已修正版本，旧请求不应偷偷换Prompt。

C02：目录 schema:chapter-plan:v1 required=[chapter_goal,conflicts,scenes,ending_hook] 且conflicts minItems1/hook minLength1。声明在目录可达，但实际rich Provider schema有另层构造；不能据此断言这一旧schema就是每次最终response format。把它作为条件旧接口偏好风险登记，当前生产预备更强证据见P03。

### 合理规则与应保留资产

当前 prose-generation-v4：按本书voice选择叙事距离/句子节奏/细节；不强求每个scene reward/cost/reversal。quality-review-v3：taste、uncertainty与硬冲突区分，literal quote由host定位，不能伪称人类批准。chapter-outline-v3：当前Mission和知识边界，NO_OP/DEFER可用。long-outline-v2：commercial escalation/rewards/cliffhangers明确为作者选择项。topic/world/character/narrative-beat现版服务当前Foundation，不固定朝代/职业/结局；新人物Skill允许保持信念/未解决矛盾，不强求次次代价。

现有causal-cost v2原则、Canon/Book接纳边界、source隔离、schema-only交付、scene slots顺序与精确引用、失败封闭、bounded revision保留无关内容均应保留。Slots是执行接口，不等于小说必须使用固定冲突套路。资料分析/平台/Screenplay等专用Skill按实际源任务/平台或改编范围使用即可，不因有“爽点”“商业”词删除专用能力。reader-feedback现版SHADOW及作品承诺判据应保留，观察不直改故事。

## 少量历史核验

只对现有问题的foundation任务、qualification、chapter profile和draft view做blame。原始line-porcelain及指定提交stat保存在evidence/history，历史证据与当前装配分开。

Foundation任务可追到 bbd59eb3f629a19499c5c79a2044a1b1c6081b96（2026-09-07，formation/Foundation治理生成提交）；Volume/profile早期规则和draft白名单也各有记录。提交主题只说明代码改动，未取得“只针对某本书/十二章”的原始任务授权，故不确认污染的单次开发成因。当前确有不合理范围，不需要推断提交者身份。历史存在修正：当前Skill和knowledge已软化；剩余任务/Schema/门禁没有同步全部软化，是冻结代码可见的层间不一致。

## 离线验证与覆盖

使用既有venv，不安装；外部快照import前设置IO阻断。两个审计输入（严肃现实群像与轻松幻想冒险）是SYNTHETIC，均符合现行v2字段，不替项目新增题材。只改变风格/不可逆策略等对照，用真实固定assembler，不走生产admission，不生成小说，不构造真实qualified receipt。

24份快照：每个输入包含creative/theme/ending 3阶段、draft/review/revision/rereview 4阶段、quality 5阶段。独立阶段方法12种；shared core assembler1种被实际离线执行。静态还追踪hierarchical、world/actor、Memo/Context/Retrieval、design evaluator、agent session、reader outcome、longform review、screenplay、Source与generic wrappers。**静态映射不等于这些路径全部离线执行。**

41个小型断言全部与预期机制匹配（evidence/checks/results.json）。这些包括发现缺陷的反例，PASS表示复现预期，不表示系统通用性通过。记录：style正常summary/facts路径贯穿四阶段；反向作者目标与不可逆task共存；plan/style顶层marker丢失；quiet首章仍强制魅力字段；空hook被拒；volume不可逆必填；cost v2为PRINCIPLE、memo cost nullable；source_originality缺风格，structural保留plan风格；fallback readability覆盖不生效。

脚本初次扩展Quality对照误用quality_context_view而非实际quality_context，出现2项检查不符；核对真实caller后更正审计脚本并重新执行，未改变生产源码/期望来追求PASS。最终全部结果来源于正确参数，脚本可审查。本轮未执行docs/runtime-operations全矩阵：NOT_RUN；只读审计不声称生产完成/QUALIFIED。

REAL_CAPTURE=0；RECONSTRUCTED=0；SYNTHETIC=24；真实模型/付费Provider调用=0。没有同SHA、同冻结作者目标/输入、模型配置、实际请求与接受正文的共同身份，因此文学效果未验证；不使用旧报告、不同分支或样例正文代替。

## 完整性统计与未完成范围

'''
text+=f'''| 项目 | 数量/状态 |
|---|---|
| 默认resolver与7种生成profile联合catalog | {C['catalog_artifacts']}个精确kind/ref/version/hash身份（不同Pack scoped同ref/version不混同） |
| Prompt/Skill注册身份 / 不同源文件 | {C['catalog_text_identities']} / {C['catalog_unique_text_sources']}；正文均完整读取、全文导出 |
| 条件Source methodology | 7身份，全文导出；与目录重复源只存原件一次 |
| 目录Schema | 81；完整解析/导出；非都直接送Provider |
| 额外纯构造记录 | {C['generated_constructed_records']}；包含103记录中的1条默认Chapter dynamic-slice缺失原始失败 |
| 独立阶段离线输入 | 12stage methods × 2输入 =24；不是24真实请求 |
| 小型必要断言 | 41/41机制预期匹配 |
| 源证据文件 | {C['source_files_exported']}（另有后补调用映射/内联asset；最终counts.json为准） |
| 全字段/动态语义审查 | 重点核验改变创作边界字段；巨大动态Canon/Planning变体未逐实例渲染，源构造逻辑完整保留 |

完整全文、身份/调用覆盖和逐资产合理/有问题/条件适用/待核验评价见PROMPTS_AND_SKILLS_FULL.md、inventory.jsonl、ASSET_EVALUATIONS.md。对已证明不自动注入的旧/示例路径单列evidence/unbound-and-demo-assets.json。所有资产全文检查文件哈希与固定snapshot一致；JSON组装schema是纯构造序列化内容，不能称原始生产请求字节。

关键缺口：数据库ACTIVE released Pack/自定义catalog，真实style/quality/platform配置，agent动态instruction/tools/transcript与Skill内容，真实CLI/workdir/config receipt，world/actor/craft冻结决策与Chapter realization slices，retry/repair/resume真实运行receipt，同版本author objective→最终正文。Chapter默认schema constructor需Frozen Narrative Realization，不填未知对象；原失败evidence/generated/CHAPTER.planning.schema.error.json，源代码完整导出。真部署/DB未访问不是不存在。

retry/repair/resume：static frozen_context_retry核验exactproject/book/inputs及range/policy；repair用原候选与验证report hash，bounded revision不应自动回模板；resume仍从frozen attempt与durable evidence取内容。没有找到正式新路径静默落回样例小说的证明；没有离线完整执行状态恢复，也不能宣布所有恢复路径已排除污染。旧frozen Pack与错误已接纳上游内容仍会被保留，这既是证据不改写原则，也需要新授权纠正，不能靠replay洗掉。

## 最小修改顺序与后续验证设计

1. 先修P04已有字段投影和P05审读目标基准，使当前作者要求能被阶段消费；这是代码绑定修复，不靠增加Prompt语气。
2. 同步修P01 task和Schema/validator；再修P02/P03资格profile、适用性和章/卷合同。旧字节不可篡改，按现有版本/hash发布新合同。不能只软化Skill后让硬字段继续迫模型补成本/魅力/悬念。
3. 修P06fallback消费配置与诊断性质；P07改专业Skill中两句商业绝对要求，使用已有输入/目标，不建新枚举/平台。
4. 核验实际release/冻结attempt选择，清理新的默认选择中的旧内容；保留历史证据。现有合理公共Skill无需整体重写或增加Agent。

后续最小文学实验（仅设计，未调用）：固定合法作者输入、冻结模型/Provider/采样/上下文/篇幅和seed支持情况；一次只改变P01或P04/P05之一；至少重复少量配对样本考虑随机性；匿名评审按这本书的明确目标比较（如克制、观察视角、无强制反转），同时检查连续性/原文隔离。分开报告目标符合度、可读性与代价，不把模型自评分或一次成功样例当通用质量证明。

审计产物是建议与证据，不是新运行Authority；未写回生产Prompt/代码，没有DB/缓存/日志/作品状态变化，没有commit/push/PR/merge。
'''
(O/'AUDIT.md').write_text(text)
# Rewrite suggestions: actual full related instruction paragraphs before/after, separate from evidence.
Q='''# 最小改写建议（PROPOSAL / NOT_RUNTIME_AUTHORITY）

基线：'''+SHA+'''。以下均是建议文件，未覆盖原始资产、源码或数据库。只使用已有 Brief constraints、author_design、批准Foundation、ChapterPlan/style_policy、QualityContext、profile版本机制。

## 1 · Foundation task 与 Schema 同步（P01）

改写前（完整相关 task 段）：

````text
Develop a distinctive, sustainable conflict from the brief. Explain reader value, choices and costs; create original operational style examples, never imitate reference prose.
Turn the approved premise into opposing thematic answers tested by costly character decisions; avoid a moral slogan.
Design an earned ending direction with irreversible costs, required closures and forbidden shortcuts; this is future intent, not a predetermined accepted event.
Specify what readers may expect, observable preparation, escalation and payoff; distinguish promise from fact and leave timing to Planning.
Compile only world depth needed by the approved conflict. Consider laws, geography/time, resources, power, history/culture, existence and information; explain deferred dimensions and extension triggers. Rules need costs, exceptions and story consequences.
Build a cast with distinct narrative functions, then deepen each through desire, fear, contradiction, beliefs and choices. Derive voice anchors from biography and motives. Ground relationships and capabilities in the approved world, never invent accepted history.
````

改写后（相同六类阶段，不是六段同时注入；每阶段仍只选择自己的task）：

````text
Develop a distinctive creative direction from the frozen author brief and approved design parents. Explain its intended reader experience and the choices, tensions or observations that sustain it. Derive conflict and narrative engine only where they serve this work. Create original operational style examples for this work; never imitate reference prose.
Turn the approved premise into a clear thematic question and relevant competing answers, uncertainties or tensions. Describe how this work tests them through character experience. Specify costs only where these choices incur them; do not add sacrifice, trauma or a resolved moral conclusion merely to fill the schema.
Design the intended ending or ending openness from the author's goals and approved parents. Explain what changes, remains unresolved, or deliberately stays the same, and what earlier preparation is needed. Include irreversible costs only when this work selects or entails them. Preserve explicit prohibitions and avoid unearned shortcuts. This is future intent, not a predetermined accepted event.
Specify the experience this work promises its intended readers and the observable preparation needed to earn it. Use progression, escalation and payoff where appropriate to this promise; a deliberately quiet, open or non-serial form is not a missing commercial reward. Distinguish promise from fact and leave authorized timing to Planning.
Compile only world depth needed by this work's approved direction. Consider relevant laws, geography/time, resources, power, history/culture, existence and information; explain deferred dimensions and extension triggers. State each applicable rule's limits, exceptions and consequences. Do not invent a price or power system for a rule that does not call for one.
Build the cast appropriate to the frozen scope and work's goals, with distinct relevant narrative functions. Explain behavior through motives, beliefs, relationships, resources and context. Include wounds, false beliefs and transformation only when appropriate to this character; a maintained conviction or unresolved contradiction is valid. Derive voice anchors from biography and motives. Ground relationships and capabilities in the approved world, never invent accepted history.
````

保留：当前输入优先、原创、读者价值、因果/世界限制、当前scope、未来/事实分离、schema-only和独立接纳。下沉：不可逆成本、创伤、反转、商业升级、闭合方式由本书目标确定。

必须同步代码：ending.protagonist_cost、theme.choice_tests.cost、world.rules.cost、character.wound/false_belief等不能仍要求每个非空文学要素；用最小兼容新版本的nullable/适用性表示，调整validator。明确不适用不同于缺证据。当前被明确授权的代价不得丢掉。cast有界预算保留，但不将单批max12解释成全书人数上限。

验证：两份合法Brief只改变不可逆/开放结局策略；task与schema都不产生相反硬要求。作者选择代价的对照仍要求合理准备和实现。先offline，无Provider。

## 2 · 资格与章节必填范围（P02/P03）

改写前（完整相关模型评估指令段）：

````text
Independently evaluate the immutable candidate against every frozen qualification profile and criterion. The frozen Provider Context is the complete evidence boundary. For EXACT_CANDIDATE_ONLY, use only the first selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the first selected input as the sole candidate under evaluation and consume each remaining exact qualified dependency's semantic_payload as evidence for that candidate's cross-layer claims. A reference-only BookDesign field is not missing evidence when its exact referenced dependency supplies the semantics. Do not consume prior qualification verdicts, demand downstream plans that cannot legally exist at the candidate's stage, or infer anything outside the frozen candidate-and-dependency envelope. Copy layer, profile_id, profile_version, profile_hash, capability_id, skill_ref, criterion, and candidate evidence identities exactly. Return one verdict per criterion. A non-PASS verdict must include a concrete repair_directive; PASS must leave repair_directive empty. Do not activate, revise, or replace the candidate, and do not infer evidence outside the frozen candidate.
````

改写后（仅随代码/Schema支持后可采用）：

````text
Independently evaluate the immutable candidate against every frozen qualification profile and criterion within the supplied current-work goals and criterion applicability. The frozen Provider Context is the complete evidence boundary. For EXACT_CANDIDATE_ONLY, use only the first selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the first selected input as the sole candidate under evaluation and consume each remaining exact qualified dependency's semantic_payload as evidence for that candidate's cross-layer claims. A reference-only BookDesign field is not missing evidence when its exact referenced dependency supplies the semantics. Do not consume prior qualification verdicts, demand downstream plans that cannot legally exist at this stage, or infer evidence outside this envelope. Copy every frozen profile, criterion and candidate identity exactly. Return one verdict per criterion under the declared output contract. Evaluate applicable criteria against this work's selected purpose, never a universal commercial form. Use NOT_APPLICABLE only when the supplied scope or goals justify it, and cite that basis; it cannot excuse a binding author constraint or due obligation. FAIL and INSUFFICIENT require concrete repair directives; PASS and justified NOT_APPLICABLE do not invent repairs. Do not activate, revise, replace or accept the candidate.
````

代码先决：当前verdict enum只有PASS/FAIL/INSUFFICIENT；不能直接只改提示词新增NOT_APPLICABLE。最小可选方案是在已有profile里按冻结当前目标选择适用criteria；如果保留逐项report则版本化新增正式NOT_APPLICABLE及host审核依据。两者择一个一致实施，不能让自由文本“无”冒充PASS。

Volume irreversible_change/midpoint/climax/next_volume_bridge，应改为可表达当前卷结构与终卷状态的合同；保持scope、parentrefs、planned future与有效因果。ChapterPlan interface保留title/objective/scene units/identity，hook/charm/antagonist/suspense等按当前章功能选用。第1章不能仅因序号覆盖作者明确的观察式开篇。当前到期披露/情节义务仍必须检查。

验证：quiet首章、无反派普通章、开放终章、非连载卷；各不适用技法不进入强制任务或repair。适用技法失败、缺真正证据与未授权变更仍阻断。不能只造qualifier PASS。

## 3 · 作者风格绑定（P04）

这里不需要把公共Prompt再写强一点。改写前完整相关投影段见PROMPTS_AND_SKILLS_FULL.md B层 build_draft_plan_view/build_draft_style_view；原始源码全文在evidence/source。

最小代码建议：已有Writer plan whitelist加入style_constraints，并保留point_of_view/target_word_count/prohibited_outcomes；已有style policy投影加入已验证顶层constraints及确切source identity/scope。只在确认这些字段已经投影到task后才从context去重。普通审读与修订使用同一有效约束基准，author_private仍隔离。

建议的完整相关公共冲突处理段（新增于既有Shared rules适用位置，不是另建模板）：

````text
Use the current work's approved style and the in-scope author constraints supplied with this task. Preserve their source identity and scope when interpreting them. A method suggestion does not override an explicit author requirement. If approved inputs conflict or a requested form cannot be represented by the declared contract, report the conflict through the task's supported diagnostic path; do not silently replace it with a default style or manufacture approval. Choose sentence rhythm, narrative distance and detail for this work and this scene while preserving accepted facts, actor knowledge, source boundaries and the declared output format.
````

目前某些生成阶段schema不支持diagnostic path，不能仅塞一句“report conflict”却迫模型返回未知字段；最小缺口是对应已存在validation/reviewIssue渠道的显式输入冲突处理，先让合法不矛盾输入完整传播。

验证：style只在plan、只在policy.constraints、只在safe_summary/facts、author_design scopedfragment四路分别验证；不是要求所有原Brief永久全文重复注入。

## 4 · 质量审读与回改基准（P05/P06）

改写前（Quality dimension方法完整段）：

````text
'''
# Exact current segment from skill, never reconstructed excerpt presented as original.
skill=(R/'skills/quality-review/SKILL.md').read_text();part=skill.split('## Quality dimension\n',1)[1].split('\n## ',1)[0].strip();Q+=part+'\n````\n\n'
Q+='''改写后（完整相关方法段）：

````text
Judge only the requested dimensions using the exact candidate and the supplied current-work goals, approved style baseline and applicable quality/platform policy. For style drift, compare the candidate against that baseline and identify a supported deviation; if no baseline is supplied, report insufficient evidence. For anti_ai, identify a concrete defect in meaning, voice, coherence or reading experience under this work's goals. Long sentences, deliberate repetition, low-conflict pacing or open endings are not defects by themselves. Distinguish an evidenced failure, uncertainty and a discretionary taste suggestion. Cite literal candidate passages and the relevant goal or policy. Never replace the requested dimension with a universal checklist or infer audience approval from a score. Return only the declared judgment contract.
````

保留：exact candidate、请求维度、定位证据、原文隔离、policy支持、人类批准不伪造。代码先决：SourceOriginalityQualityContextView加入精简有源author/style基准；不加入外部参考作品表达。style_drift当前非阻断，不能报成已强制回改；anti_ai阻断判断要与当前目标相容。修订应消费同一基准和仅有证据任务。

Fallback先消费CompiledQualityPolicy而非硬70/270；句长36等公式的文学适用性另列产品策略，不自动判成所有体裁质量真理。已校准exactdimension evidence的优先顺序保留。测试不同阈值与合法风格会产生可解释变化，客观空正文/身份/源泄漏门不变。

## 5 · 专业方法中的商业绝对句（P07）

改写前（完整相关质量/禁止条目）：

````text
- 多学科知识只能增强可信度，不能替代爽点和冲突。
- 禁止让专业合理性破坏追读和情绪奖励。
````

改写后：

````text
- 多学科知识应服务本次作品或分析任务的明确目标。专业可信度、情绪体验、冲突、观察和解释深度按当前作品需要权衡；不默认要求爽点或商业追读。
- 当当前作品明确选择追读和情绪奖励时，判断资料细节是否妨碍这些目标并说明取舍。作品以严肃表达或专业可信度为核心时，不得以默认商业偏好降低其明确要求。
````

操作流程第8项建议完整替换为：

````text
8. 交给适用的 quality-review 方法，检查这些知识是否服务当前作者目标、可信度和阅读体验；只在本次明确选择商业追读时审查对相应奖励与节奏的影响。
````

保留：安全、版权、来源、事实转译、不把无关资料直接塞正文。此方法只在指定源分析任务生效，不给所有Writer加载一个新Skill。

## 6 · 仅设计后续文学效果验证

先修装配/Schema一致性，再在额外授权下固定输入、模型、采样、上下文、篇幅和版本，单次只改变一项，做少量重复配对。匿名评价以本书作者目标为rubric，同时看连贯、可信、原创与可读。分别报告装配符合性、模型遵循性、文学结果和成本；一次样本/测试PASS不等于通用小说工厂已验证。
'''
(O/'REWRITE_PROPOSALS.md').write_text(Q)
print('AUDIT and REWRITE written')
