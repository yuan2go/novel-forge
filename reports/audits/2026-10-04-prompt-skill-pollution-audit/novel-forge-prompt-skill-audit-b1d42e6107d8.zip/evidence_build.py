import sys,os,pathlib,json,hashlib,ast,socket,subprocess,builtins,io
OUT=pathlib.Path(__file__).resolve().parent; ROOT=OUT/'snapshot'; sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'src'))
# Audit guard: no child processes, sockets, DB connections or writes outside this evidence directory.
def deny(*a,**kw):raise RuntimeError('AUDIT_IO_BLOCKED')
socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny;subprocess.Popen=deny;os.system=deny
original_open=builtins.open;original_io_open=io.open
def guard_opener(fn):
 def guarded(file,mode='r',*a,**kw):
  if isinstance(file,(str,bytes,os.PathLike)) and any(x in mode for x in 'wax+'):
   path=pathlib.Path(file).resolve()
   if OUT not in path.parents or ROOT in path.parents:raise RuntimeError('AUDIT_WRITE_BLOCKED:'+str(path))
  return fn(file,mode,*a,**kw)
 return guarded
builtins.open=guard_opener(original_open);io.open=guard_opener(original_io_open)
import psycopg
psycopg.connect=deny;psycopg.Connection.connect=deny
from novel_forge.modules.capability_packs.artifacts import default_chapter_artifact_resolver,artifact_content_hash
from novel_forge.modules.capability_packs.longform_profiles import build_story_planning_pack_profile,build_reader_outcome_pack_profile,build_longform_prose_review_pack_profile,build_narrative_evaluation_pack_profile
from novel_forge.modules.capability_packs.screenplay_profiles import build_screenplay_pack_profile
from novel_forge.modules.story_planning_runtime.foundation_generation import FOUNDATION_GENERATORS,foundation_task,foundation_output_schema
from novel_forge.modules.chapter_authority.provider_output_contracts import chapter_provider_output_schema
from novel_forge.modules.chapter_authority.execution_gateway import _stage_semantic_contract,_stage_semantic_contract_v3
from novel_forge.modules.story_design_authority.qualification import GENERATOR_QUALIFICATION_PROFILES
EV=OUT/'evidence';EV.mkdir(exist_ok=True);(EV/'assets').mkdir(exist_ok=True);(EV/'generated').mkdir(exist_ok=True)
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
artifacts={};profiles=[]
def collect(a,route):
 key=(a['kind'],a['ref'],a['version'],a['content_hash'])
 if key not in artifacts:artifacts[key]={**a,'catalog_routes':[]}
 artifacts[key]['catalog_routes'].append(route)
for a in default_chapter_artifact_resolver(ROOT).artifacts():collect(a.to_dict(),'chapter.default_resolver')
for fn in [build_story_planning_pack_profile,build_reader_outcome_pack_profile,build_longform_prose_review_pack_profile,build_narrative_evaluation_pack_profile]:
 p=fn(ROOT,operation_definition_hash='sha256:'+'0'*64);profiles.append((p.pack_id,p.manifest));write(EV/'generated'/f'{p.pack_id}.manifest.json',p.manifest)
 for a in p.artifact_catalog['artifacts']:collect(a,p.pack_id)
for stage in ['screenplay_generate','screenplay_review','screenplay_revision']:
 p=build_screenplay_pack_profile(ROOT,stage=stage,operation_definition_hash='sha256:'+'0'*64);profiles.append((p.pack_id,p.manifest));write(EV/'generated'/f'{p.pack_id}.manifest.json',p.manifest)
 for a in p.artifact_catalog['artifacts']:collect(a,p.pack_id)
write(EV/'generated'/'catalog-all.json',list(artifacts.values()))
for stage in FOUNDATION_GENERATORS:
 write(EV/'generated'/f'{stage}.schema.json',foundation_output_schema(stage));write(EV/'generated'/f'{stage}.task.json',foundation_task(stage))
for stage in ['draft','review','revision','rereview','canon_extraction','canon_support','quality_structural','quality_commercial','quality_source_originality','quality_longform','quality_platform','memo','retrieval','retrieval_query_expansion','context_compress','context_fidelity','agent_session','reader_outcome','longform_prose_review','screenplay_generate','screenplay_review','screenplay_revision']:
 try:write(EV/'generated'/f'{stage}.schema.json',chapter_provider_output_schema(stage))
 except Exception as e:write(EV/'generated'/f'{stage}.schema.error.json',{'error':str(e)})
 if stage not in ['retrieval']:
  write(EV/'generated'/f'{stage}.semantic.json',{'legacy':_stage_semantic_contract(stage),'compact':_stage_semantic_contract_v3(stage)})
for stage in ['draft','review','revision','rereview','canon_extraction','memo','quality_structural']:
 write(EV/'generated'/f'{stage}.legacy.schema.json',chapter_provider_output_schema(stage,legacy_contract=True))
write(EV/'generated'/'revision.targeted.schema.json',chapter_provider_output_schema('revision',targeted_revision=True))
write(EV/'generated'/'canon_extraction.causal_batch.schema.json',chapter_provider_output_schema('canon_extraction',causal_batch=True))
from novel_forge.modules.story_design_authority.qualification import qualification_provider_schema
for generator in GENERATOR_QUALIFICATION_PROFILES:
 write(EV/'generated'/(generator+'.qualification.schema.json'),qualification_provider_schema(generator))
for stage in [*FOUNDATION_GENERATORS,'book_plan.generate','volume_plan.generate','arc_plan.generate','chapter_group_plan.generate','chapter_plan.generate','narrative_semantic_evaluation','world_candidates.generate','world_candidates.evaluate','world_candidates.actor_0','world_candidates.actor_1','world_candidates.actor_2','retrieval']:
 write(EV/'generated'/(stage+'.semantic.json'),{'legacy':_stage_semantic_contract(stage),'compact':_stage_semantic_contract_v3(stage)})
write(EV/'generated'/'qualification-profiles.json',{k:[{'layer':p.layer.value,'profile_id':p.profile_id,'profile_version':p.profile_version,'profile_hash':p.profile_hash,'skill_ref':p.skill_ref,'criteria':p.criteria} for p in v] for k,v in GENERATOR_QUALIFICATION_PROFILES.items()})
write(EV/'guard.json',{'sockets':'BLOCKED','subprocess':'BLOCKED','psycopg_connections':'BLOCKED','production_writes':'BLOCKED','imports_from':str(ROOT/'src'),'synthetic_operation_definition_hash':'sha256:'+'0'*64,'note':'Pack constructors only; no release/admission/state mutation'})
print(json.dumps({'artifacts':len(artifacts),'profiles':len(profiles),'status':'PASS'},ensure_ascii=False))
