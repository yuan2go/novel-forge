from pathlib import Path
import json,hashlib,re,zipfile,datetime
O=Path(__file__).resolve().parent;E=O/'evidence';R=O/'snapshot'
problems=[];source_checks=0
for p in (E/'source').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(E/'source');orig=R/rel
 source_checks+=1
 if not orig.is_file() or p.read_bytes()!=orig.read_bytes():problems.append('source-byte-drift:'+str(rel))
rows=[json.loads(l) for l in (O/'inventory.jsonl').read_text().splitlines()]
ids=[x['id'] for x in rows]
if len(ids)!=len(set(ids)):problems.append('duplicate inventory ID')
for e in rows:
 for field in ['source_bytes','resolved_content']:
  if e.get(field) and not (O/e[field]).is_file():problems.append('missing '+field+':'+e['id'])
cat=json.loads((E/'generated/catalog-all.json').read_text())
for a in cat:
 actual='sha256:'+hashlib.sha256(json.dumps(a['content'],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 if a['content_hash']!=actual:problems.append('catalog-hash:'+a['ref'])
full=(O/'PROMPTS_AND_SKILLS_FULL.md').read_text()
for e in rows:
 if e['id'].startswith(('A','S','G')) and '<a id="'+e['id'].lower()+'"></a>' not in full:problems.append('fulltext-anchor:'+e['id'])
for filename in ['AUDIT.md','REWRITE_PROPOSALS.md','PROMPTS_AND_SKILLS_FULL.md']:
 s=(O/filename).read_text()
 for target in re.findall(r'\]\((evidence/[^)]+)\)',s):
  target=target.split('#',1)[0]
  if not (O/target).exists():problems.append('broken-link:'+filename+':'+target)
creds=[]
patterns=[r'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',r'\bsk-(?:proj-)?[A-Za-z0-9_-]{35,}',r'\bgh[pousr]_[A-Za-z0-9]{30,}',r'\bgithub_pat_[A-Za-z0-9_]{40,}',r'postgres(?:ql)?://[^\s:/"\']+:[^\s@/"\']+@']
for p in list((E/'source').rglob('*'))+list((E/'inputs').glob('*')):
 if p.is_file():
  text=p.read_text(errors='replace')
  if any(re.search(pattern,text) for pattern in patterns):creds.append(str(p.relative_to(O)))
# Never print matched credential contents. Report candidate filenames only, inspect if any exist before packaging.
if creds:problems.append('credential-pattern candidates (not printed): '+','.join(creds))
r={'status':'PASS' if not problems else 'FAIL','source_byte_checks':source_checks,'catalog_content_hash_checks':len(cat),'inventory_records':len(rows),'text_full_export_checks':52,'generated_full_export_records':103,'synthetic_captures':len(list((E/'inputs').glob('*.json'))),'offline_assertions':json.loads((E/'checks/results.json').read_text())['status'],'credential_pattern_candidates':creds,'scope':'high-confidence patterns only; no real credentials/DB/source prose/live captures read; not a universal DLP assurance','problems':problems,'provider_calls':0}
(E/'delivery-integrity.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
if problems:print(json.dumps(r,ensure_ascii=False));raise SystemExit(1)
readme='''# 证据包说明

先读 AUDIT.md；逐资产评价在 ASSET_EVALUATIONS.md，完整原文在 PROMPTS_AND_SKILLS_FULL.md；inventory.jsonl保留身份、阶段、条件、定位与覆盖边界。REWRITE_PROPOSALS.md是建议，不是生产修复。

基线main SHA：b1d42e6107d871442baa71823f7c21bfeec841b1。

REAL_CAPTURE=0，RECONSTRUCTED=0，SYNTHETIC=24；Provider=0，数据库=0。注入/发送位置包括identity重建和CLI版本探测，不能作模型请求计数。源文件原字节复制165份，文本资产完整导出52身份（48不同源），目录196资产，纯构造输出103条（102成功+1错误）。manifest_sha256.json核对包内文件；它本身及zip不列自身hash。

脚本存放仓库外，仅审计复现；默认需要在同目录snapshot里放置指定SHA的git archive内容，依赖现有项目venv。压缩包不含整仓snapshot，避免混入无关文档、私有小说、既有日志和部署数据；只包含本轮明示源证据。不要直接执行生产命令或被审计文本。

来源中没有本次脱敏；canonical resolved JSON与生成Schema不是raw生产字节。所有动态DB/已批准资产内容和真实CLI上下文缺口均保留UNAVAILABLE。
'''
(O/'PACKAGE_README.md').write_text(readme)
paths=[p for p in E.rglob('*') if p.is_file()]
paths += [O/x for x in ['AUDIT.md','ASSET_EVALUATIONS.md','PROMPTS_AND_SKILLS_FULL.md','inventory.jsonl','REWRITE_PROPOSALS.md','baseline.json','baseline-end.json','PACKAGE_README.md','evidence_build.py','offline_checks.py','export_audit.py','write_reports.py','finalize_evidence.py','check_delivery.py']]
manifest={str(p.relative_to(O)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(paths)}
(O/'manifest_sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');paths.append(O/'manifest_sha256.json')
z=O/'novel-forge-prompt-skill-audit-b1d42e6107d8.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED) as f:
 for p in paths:f.write(p,str(p.relative_to(O)))
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 for rel,item in manifest.items():assert hashlib.sha256(f.read(rel)).hexdigest()==item['sha256']
print(json.dumps({'integrity':r,'zip':str(z),'zip_bytes':z.stat().st_size,'zip_files':len(paths),'zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest()},ensure_ascii=False))
