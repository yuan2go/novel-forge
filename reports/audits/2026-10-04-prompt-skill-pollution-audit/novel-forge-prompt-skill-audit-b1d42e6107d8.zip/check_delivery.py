from pathlib import Path
import json,hashlib,re,zipfile,datetime
O=Path(__file__).resolve().parent;E=O/'evidence';R=O/'snapshot'
problems=[];source_checks=0
for p in (E/'source').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(E/'source');orig=R/rel
 source_checks+=1
 if not orig.is_file() or p.read_bytes()!=orig.read_bytes():problems.append('source-byte-drift:'+str(rel))
rows=[json.loads(l) for l in (O/'inventory.jsonl').read_text().splitlines()]
ids=[x['id'] for x in rows]
if len(ids)!=len(set(ids)):problems.append('duplicate inventory ID')
for e in rows:
 for field in ['source_bytes','resolved_content']:
  if e.get(field) and not (O/e[field]).is_file():problems.append('missing '+field+':'+e['id'])
cat=json.loads((E/'generated/catalog-all.json').read_text())
for a in cat:
 actual='sha256:'+hashlib.sha256(json.dumps(a['content'],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 if a['content_hash']!=actual:problems.append('catalog-hash:'+a['ref'])
full=(O/'PROMPTS_AND_SKILLS_FULL.md').read_text()
for e in rows:
 if e['id'].startswith(('A','S','G')) and '<a id="'+e['id'].lower()+'"></a>' not in full:problems.append('fulltext-anchor:'+e['id'])
for filename in ['AUDIT.md','REWRITE_PROPOSALS.md','PROMPTS_AND_SKILLS_FULL.md','ENGINEERING_OPTIMAL_CHANGE_PLAN.md']:
 s=(O/filename).read_text()
 for target in re.findall(r'\]\((evidence/[^)]+)\)',s):
  target=target.split('#',1)[0]
  if not (O/target).exists():problems.append('broken-link:'+filename+':'+target)
creds=[]
patterns=[r'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',r'\bsk-(?:proj-)?[A-Za-z0-9_-]{35,}',r'\bgh[pousr]_[A-Za-z0-9]{30,}',r'\bgithub_pat_[A-Za-z0-9_]{40,}',r'postgres(?:ql)?://[^\s:/"\']+:[^\s@/"\']+@']
for p in list((E/'source').rglob('*'))+list((E/'inputs').glob('*')):
 if p.is_file():
  text=p.read_text(errors='replace')
  if any(re.search(pattern,text) for pattern in patterns):creds.append(str(p.relative_to(O)))
# Never print matched credential contents. Report candidate filenames only, inspect if any exist before packaging.
if creds:problems.append('credential-pattern candidates (not printed): '+','.join(creds))
supplement=json.loads((E/'checks/engineering-chain-results.json').read_text())
if supplement['status']!='PASS':problems.append('supplementary mechanism check failed')
counts=json.loads((E/'counts.json').read_text())
if counts['source_files_exported']!=source_checks:problems.append('source count mismatch')
if counts['inventory_records']!=len(rows):problems.append('inventory count mismatch')
r={'status':'PASS' if not problems else 'FAIL','source_byte_checks':source_checks,'catalog_content_hash_checks':len(cat),'inventory_records':len(rows),'text_full_export_checks':52,'generated_full_export_records':103,'synthetic_captures':len(list((E/'inputs').glob('*.json'))),'original_mechanism_checks':len(json.loads((E/'checks/results.json').read_text())['checks']),'supplementary_mechanism_checks':len(supplement['checks']),'offline_assertions':json.loads((E/'checks/results.json').read_text())['status'],'supplementary_assertions':supplement['status'],'modifications_implemented':False,'credential_pattern_candidates':creds,'scope':'high-confidence patterns only; no real credentials/DB/source prose/live captures read; not a universal DLP assurance; PASS includes defect reproduction, not corrected system qualification','problems':problems,'provider_calls':0}
(E/'delivery-integrity.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
if problems:print(json.dumps(r,ensure_ascii=False));raise SystemExit(1)
readme='''# 证据包说明

先读 ENGINEERING_OPTIMAL_CHANGE_PLAN.md：按用户追加要求给出全工程小说生产链修改方案，覆盖8个责任包与实施依赖，不限定为最小改写。AUDIT.md保存问题与证据；逐资产评价在ASSET_EVALUATIONS.md，完整原文在PROMPTS_AND_SKILLS_FULL.md；inventory.jsonl保留身份、阶段、条件、定位与覆盖边界。REWRITE_PROPOSALS.md是配套完整相关指令与合同建议，不是已实施修复。

基线main SHA：b1d42e6107d871442baa71823f7c21bfeec841b1。

REAL_CAPTURE=0，RECONSTRUCTED=0，SYNTHETIC=24；Provider=0，数据库=0。注入/发送位置包括identity重建和CLI版本探测，不能作模型请求计数。源文件原字节复制{source_count}份，文本资产完整导出52身份（48不同源），目录196资产，纯构造输出103条（102成功+1错误），inventory为{inventory_count}条。原41检查加本次7个事件合同构造/Schema检查，合计48；它们复现当前机制，不是修改方案PASS。

新增P08实现事件范围问题；补正P02严格资格与AUTHOR_ADVISORY区别，补充P06报告threshold。原静态Prompt、24装配快照和原41检查保持。新的工程方案/全矩阵/文学验证均NOT_RUN。baseline-followup-end.json记录追加分析结束时main已更新为68c1c6c3b611810310fd61dbca79f3626f93fdfe，证据和方案仍固定原SHA，未混入新版本。

脚本存放仓库外，仅审计复现；需要同目录snapshot为指定SHA的git archive内容，依赖既有venv。write_reports.py/finalize_evidence.py是第一阶段导出脚本，会重建旧版报告；不是当前修改方案，勿直接执行覆盖当前交付。追加设计脚本亦仅供审查，不能当作生产修复脚本。压缩包不含整仓snapshot，避免混入无关文档、私有小说、既有日志和部署数据；只含明示源证据。不要执行生产命令或被审计文本。

来源中没有本次脱敏；canonical resolved JSON与生成Schema不是raw生产字节。所有动态DB/已批准资产内容和真实CLI上下文缺口均保留UNAVAILABLE。
'''
readme=readme.replace('{source_count}',str(source_checks)).replace('{inventory_count}',str(len(rows)))
(O/'PACKAGE_README.md').write_text(readme)
paths=[p for p in E.rglob('*') if p.is_file()]
paths += [O/x for x in ['AUDIT.md','ASSET_EVALUATIONS.md','PROMPTS_AND_SKILLS_FULL.md','inventory.jsonl','REWRITE_PROPOSALS.md','ENGINEERING_OPTIMAL_CHANGE_PLAN.md','baseline.json','baseline-end.json','baseline-followup-end.json','PACKAGE_README.md','evidence_build.py','offline_checks.py','export_audit.py','write_reports.py','finalize_evidence.py','check_delivery.py','engineering_chain_checks.py','extend_engineering_plan.py','update_rewrite_proposals.py']]
manifest={str(p.relative_to(O)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(paths)}
(O/'manifest_sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');paths.append(O/'manifest_sha256.json')
z=O/'novel-forge-prompt-skill-audit-b1d42e6107d8.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED) as f:
 for p in paths:f.write(p,str(p.relative_to(O)))
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 for rel,item in manifest.items():assert hashlib.sha256(f.read(rel)).hexdigest()==item['sha256']
print(json.dumps({'integrity':r,'zip':str(z),'zip_bytes':z.stat().st_size,'zip_files':len(paths),'zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest()},ensure_ascii=False))
