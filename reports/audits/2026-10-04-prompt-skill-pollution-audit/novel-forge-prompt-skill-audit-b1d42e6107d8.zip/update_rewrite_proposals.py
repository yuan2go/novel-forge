from pathlib import Path
O=Path(__file__).resolve().parent;p=O/'REWRITE_PROPOSALS.md';s=p.read_text()
s=s.replace('# 最小改写建议（PROPOSAL / NOT_RUNTIME_AUTHORITY）','# 全链路指令与合同改写建议（PROPOSAL / NOT_RUNTIME_AUTHORITY）')
s=s.replace('只使用已有 Brief constraints、author_design、批准Foundation、ChapterPlan/style_policy、QualityContext、profile版本机制。','这是全工程方案的指令与合同配套文件，须与 [ENGINEERING_OPTIMAL_CHANGE_PLAN.md](ENGINEERING_OPTIMAL_CHANGE_PLAN.md) 的W1–W8一起实施。复用现有Brief、author_design、Foundation、ChapterPlan/style_policy、QualityContext和profile；必要适用性能力需扩展相应版本化合同，不能仅替换文字。')
s=s.replace('用最小兼容新版本的nullable/适用性表示，调整validator','采用明确的新版本适用性及nullable/合法空集合表示，联动validator、profile与下游消费者')
before='''Independently evaluate the immutable candidate against every frozen qualification profile and criterion within the supplied current-work goals and criterion applicability. The frozen Provider Context is the complete evidence boundary. For EXACT_CANDIDATE_ONLY, use only the first selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the first selected input as the sole candidate under evaluation and consume each remaining exact qualified dependency's semantic_payload as evidence for that candidate's cross-layer claims. A reference-only BookDesign field is not missing evidence when its exact referenced dependency supplies the semantics. Do not consume prior qualification verdicts, demand downstream plans that cannot legally exist at this stage, or infer evidence outside this envelope. Copy every frozen profile, criterion and candidate identity exactly. Return one verdict per criterion under the declared output contract. Evaluate applicable criteria against this work's selected purpose, never a universal commercial form. Use NOT_APPLICABLE only when the supplied scope or goals justify it, and cite that basis; it cannot excuse a binding author constraint or due obligation. FAIL and INSUFFICIENT require concrete repair directives; PASS and justified NOT_APPLICABLE do not invent repairs. Do not activate, revise, replace or accept the candidate.'''
after='''Evaluate the immutable candidate against the exact applicable qualification profiles and criteria already selected and frozen by the owning Authority for this work and stage. The frozen Provider Context is the complete evidence boundary. Use the supplied current-work goals and the selected strategy basis when interpreting a creative criterion; do not substitute a universal commercial form. Do not add, omit or waive a frozen criterion yourself.
For EXACT_CANDIDATE_ONLY, use only the first selected input. For EXACT_CANDIDATE_AND_CANONICAL_DEPENDENCIES, keep the first selected input as the sole candidate under evaluation and consume each remaining exact dependency's semantic_payload as evidence for cross-layer claims. A reference-only BookDesign field is not missing evidence when its exact referenced dependency supplies the semantics. Do not consume prior qualification verdicts, demand downstream plans that cannot legally exist at this stage, or infer evidence outside this envelope.
Copy every frozen profile, criterion and candidate identity exactly. Return one verdict per applicable criterion under the declared output contract. Missing evidence for an applicable requirement is INSUFFICIENT, never PASS. FAIL and INSUFFICIENT identify the supported problem and the evidence or bounded correction needed; do not invent a new literary requirement. PASS leaves repair_directive empty. Do not activate, revise, replace or accept the candidate. If this evaluation is AUTHOR_ADVISORY, preserve that purpose and the model findings; the author's evidenced disposition remains a separate Authority decision and does not confer independent qualification.'''
s=s.replace(before,after)
start=s.index('代码先决：当前verdict enum只有')
end=s.index('\n\nVolume irreversible_change',start)
s=s[:start]+'''代码先决：推荐由宿主依据本书冻结决策选择精确适用criteria，再构造对应profile/hash/output Schema，模型不自行返回NOT_APPLICABLE来豁免。未适用标准在选择/manifest中留痕，不请求其模型verdict；适用但缺证据保留INSUFFICIENT。当前verdict enum与固定criteria仍需版本化调整构造逻辑，不能只改上段提示。strict与AUTHOR_ADVISORY分别保持资格与作者决定证据。'''+s[end:]
s=s.replace('最小代码建议：','完整投影修改建议：')
s=s.replace('最小缺口是','必须补齐的是')
s=s.replace('Fallback先消费CompiledQualityPolicy而非硬70/270','Fallback、report实际threshold、blocking与required_actions共同消费同一CompiledQualityPolicy，而非硬70/270')
s=s.replace('## 6 · 仅设计后续文学效果验证','## 6 · 改写的工程与文学验证')
s+='''

## 7 · 公共职责、作品要求与冲突处理的统一指令段

本段是新增/整合建议；没有声称仓库原来存在下面的同名段落。现有system全文见全文汇编A层，固定原件不改。本段应纳入现有Shared规则及各阶段真正的task/Context；不能只放在一个Writer模板上却让上游不消费。

改写后的完整相关段：

```text
Complete only the declared stage for the current work and frozen scope. Treat the supplied source boundaries, permissions, accepted facts and output contract as binding. Current-work author requirements and explicitly approved planning decisions determine creative direction; reusable method suggestions do not select a genre, voice, audience, plot pattern or ending for the work.
Use the supplied effective work requirements within their exact scope and strength. Preserve the distinction between required, preferred, permitted and deliberately excluded choices. A scene-level requirement does not become a book-wide rule. A candidate proposal or inferred preference is not an accepted author decision.
When the author delegates planning, supply appropriate creative details that serve this work. Do not inherit an unselected example, prior book, development task or compatibility rule as its purpose. Use a specialized strategy only when its applicable choice is present in the frozen task. Absence of a choice is not permission to force all available techniques into the chapter.
Do not invent accepted history, external approval or gate evidence. Follow the declared structured output and produce only the current-stage candidate. Input conflicts or unsupported creative requirements must use the owning workflow's declared diagnostic route; never silently substitute a default genre or style.
```

工程前提：公开有效要求与适用性先装配；host在模型调用前处理无输出字段可承载的输入冲突。不能向JSON-only阶段凭空加diagnostics字段。公共权限、事实、版权和格式不因“作者输入优先”而取消。

## 8 · 层级规划与实现事件的相关指令

改写前的完整相关字段合同与Schema原文分别见全文汇编B/E层：planning_provider_output_schema、validate_planning_contract、NarrativeRealizationEvent、NarrativeRealizationContract与_realization_proof_decisions。原代码不能用一段文字替代，P08全文证据已导出。

建议加入现有规划/实现方法的完整段（同时版本化Schema与host）：

```text
Decompose this work's approved goals into the current planning scope while preserving exact parent, chapter, scene, event, fact and actor identities. Cover the work assigned to this scope; do not assume that every unit needs escalation, an antagonist, a reward, a revelation or irreversible change.
Represent each chapter's intended experience and executable scene coverage. Describe causal events and state changes when they are actually planned. An observation, transition, sustained condition or deliberate uncertainty may have no new state delta, disclosure or obligation action. Use the contract's explicit empty or inapplicable representation rather than manufacturing a change or writing a placeholder claim.
For every applicable planned action, identify its real motivations, prerequisites, relevant knowledge boundaries and consequences. Preserve selected cause/next-event relationships and the exact accepted boundary. An irreversible change is required only when selected or entailed by the approved event; it is not a universal chapter obligation.
Verify only the transitions, disclosures, obligations and Arc contributions actually assigned to this scope. Missing an assigned requirement is a failure; having no assigned requirement is not evidence of failure. Do not claim proof, accepted progress or authority activation from a planning proposal. Use the declared Schema and leave factual acceptance to the owning Authority.
```

需要一体修改：Volume字段、ChapterGroup事件覆盖、event side effects、proof标准、frozen realization slice、ChapterMission / SceneTask和接纳消费。执行覆盖不能取消；文学事件副作用可以按真实任务为空。不能用“所有字段optional”或事件`required=false`绕过不合理非空合同。

建议的相关Schema表示原则（不是可直接部署的完整Schema）：

| 字段 | 新合同推荐语义 | 宿主必须验证 |
|---|---|---|
| irreversible_change | 本次适用时非空，否则显式null/未适用记录 | 已批准策略或事件所选变化与来源 |
| state_deltas | 真实计划变化列表，可空 | 非空时精确实体、前后状态与既有边界；不能编造变化 |
| disclosures | 本次新披露列表，可空 | 每项许可与reader知识边界；已计划必披露未执行仍失败 |
| obligation_actions | 真实生命周期动作，可空 | 引用已存在/授权计划义务；到期项仍检查 |
| decision / resistance | 与任务适用的行动/决定/阻力，不适用可正式表示 | 不需要决策冲突的观察单元仍有执行目标 |
| chapter coverage | 当前scope所有章有明确任务/场景覆盖 | 不能以没有状态变更而跳过整个章任务 |
| next_volume / chapter bridge | 有后续计划且已选桥接目的时适用 | 终章/终卷合法为空；确有桥接任务仍要兑现 |

## 9 · Writer与场景实现的相关指令

当前prose v4原文已多数合理，应保留其阶段方法、事实/角色知识边界、slots合同与原创约束；不整体替换成一句“写高质量小说”。以下是与新增有效要求配套的相关段，不是整份Skill替代。

```text
Write the prose for the exact frozen chapter and scene tasks using this work's approved voice, narrative distance, point of view and in-scope author requirements. Choose sentence rhythm, description, dialogue, observation and action to serve the current scene's intended experience.
Realize the assigned scene work and selected craft obligations. Do not add a joke, reversal, battle, revelation, irreversible cost, reward or cliffhanger merely because it appears in a reusable method or unselected example. Quiet, reflective, open or non-linear execution is valid when consistent with the current plan and author goals.
Maintain accepted facts, actor knowledge, source isolation, planned identities and the declared output structure. A planned future is not accepted history. Use only approved original operational examples; do not copy reference expression. Produce prose and structured evidence only as the current output contract requests.
```

工程前提：修复plan.style_constraints、operator style_policy.constraints的首点与Writer view；Budget不能删除必要要求。当前Foundation compiled-style正常路径保留。同一场景的声音/POV/人物知识约束一致，不能靠更多风格文本覆盖未知事实。

## 10 · 审读、修订、rereview的相关指令

普通review/revision/rereview完整原文在全文汇编A/G；当前质量维度方法的改写前后见第4节。以下三段是全链路目标绑定配套，分别用于对应阶段，不同时混入同一次请求。

Reviewer：

```text
Review the exact frozen candidate against its current-work goals, approved style, applicable plan obligations and objective continuity/source constraints. For each finding, identify the relevant requirement or policy, its scope, the candidate evidence and whether the issue is a binding failure, insufficient evidence or optional improvement.
Do not treat an unselected commercial technique or your general literary preference as a requirement. A long sentence, deliberate repetition, quiet opening or open ending is not a defect by itself. If a needed baseline is absent, identify that evidence gap rather than inventing a default style. Produce only findings supported by the declared review contract; do not rewrite or accept the candidate.
```

Reviser：

```text
Apply only the authorized corrections supported by the selected issues and their exact current-work requirement or policy basis. Preserve approved voice, permitted deliberate techniques, accepted facts, actor knowledge and all material outside the permitted change scope.
Use the frozen candidate quotes and locations required by the targeted edit contract. Do not introduce a new global rule, change a chapter's purpose, or add an unselected reward, reversal or cost to improve a generic score. A missing baseline requires evidence, not speculative rewriting. Changes to active plans belong to the owning Plan Change workflow. Return only the declared bounded revision output.
```

Rereviewer：

```text
Evaluate the exact revised candidate using the same applicable requirements and evidence basis that authorized the correction. Verify the addressed issues, preservation of unaffected material and any newly introduced binding problem. Do not replace the frozen baseline with a new default rubric or equate a higher aesthetic score with proof of improvement. Record unresolved uncertainty and return only the declared rereview contract.
```

工程前提：QualityContext补基准，quality维度与blocking按适用性冻结；anti_ai宽泛审美不独立驱动强制改文。Issue、evidence、required_action、edit和rereview target有共同版本身份。适用真实问题仍按原门禁失败封闭。

## 11 · repair与resume：纠正输出，不扩展创作范围

改写前原段与装配源见 story_planning_runtime.execution._repair_context、_validate_frozen_context_retry及真实Materializer全文。当前有正确的frozen retry和scoped修复，应保留；此建议不把现有机制称为已证污染。

```text
Repair only the specific invalid result of this frozen task using the supplied validation evidence. Preserve the current work requirements, applicable strategy choices, source boundary, exact scene and candidate identities, and previously correct content. Do not turn this local repair into a rule for other chapters or works.
A technical retry or resume does not authorize a new creative direction, different examples, replacement Pack or changed quality baseline. Follow the host's frozen request identity and declared recovery contract. If a creative or contract change is required, report it through the owning workflow instead of silently replacing this request. Earlier results and evidence remain immutable.
```

工程前提：由host而非模型保证同Attempt/Effect冻结；新合同纠偏创建新版本与相应授权；UNKNOWN先调和，不复用身份偷换Prompt。

## 12 · 指令改写不能代替的工程工作

| 工作 | 仅改文案是否足够 | 完整配套 |
|---|---|---|
| 风格字段丢失 | 否 | 首点candidate、stage view、Context去重与最终发送 |
| 固定代价/开篇/事件副作用 | 否 | Schema、host validator、qualification、proof、下游消费 |
| 质量基准缺失/阈值不生效 | 否 | Context、policy算法/report、blocking、aggregate与修订 |
| 源方法商业绝对句 | 相关正文需要改 | 任务目标进入Source，知识适用与拒用结果正确传播 |
| 未选Skill/旧Pack残留 | 否 | 选择条件、版本/hash、真实release、兼容与恢复 |
| 专用技法被作者选中 | 不应删除 | 保留精确策略与任务范围，验证已选义务 |
| 文学效果 | 文案或工程PASS均不足 | 固定条件、随机性、匿名按本书目标比较与成本 |

以上全部建议尚未实施。完整原件在独立证据层，建议不冒充运行输入，也不覆盖历史身份。
'''
p.write_text(s)
print('Updated full-chain rewrite proposals')
