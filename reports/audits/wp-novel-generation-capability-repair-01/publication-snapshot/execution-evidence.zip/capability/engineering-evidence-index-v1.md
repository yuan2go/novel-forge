WP-NOVEL-GENERATION-CAPABILITY-REPAIR-01 — evidence index, in progress

Overall: IN_PROGRESS; novel capability and 100-chapter delivery NOT_PROVEN / NOT_COMPLETED.

Reproducible source and installation

- Main observed: 4b827faef9c5f9f4998a303ce8b4495037f047fb.
- PR #166 observed OPEN Draft: 5d0ca7447089b89b55230ef0657e5ec255d4d1ff; historical 399fc434 is not the execution head. No Draft was merged.
- Isolated code commit: e94973ef970fecb4fdc919a3168ac92334eb6cd1.
- Subsequent documentation-only commit: 2b0286c0f5a2c0cd57ec707d95b1d0786d90c662.
- Own branch: codex/wp-novel-generation-capability-repair-01. Original dirty checkout untouched.
- Runtime is non-editable wheel from e94973ef. See installed-runtime-verification.json for wheel hash, SDK versions, console entrypoints and installed module/source hashes.
- Existing migration chain through 20261013_0204; no new business migration in this delta, published migration bodies unchanged.

Relevant verification, not additive qualification counts

- focused-matrix-02.log: 388 risk-related unit tests passed.
- final-generation-unit.log: 84 focused generation/recovery/reextraction tests passed after final generation classification change.
- generation-postgres-04.log: 11 PostgreSQL checks passed, including real persisted native Chapter definitions before first model child, historical 2000 deadlines, historical attempt counts, scan pagination, result recovery and Canon reextraction.
- native-coordinator-postgres-04.log: native Book/Group past deadlines committed and read back before/after independent Chapter wiring; manual cancellation and mixed/invalid delegation negatives passed.
- native-creation-postgres-10.log: native generated naming and default profile activation passed with interrupted projection/result reuse.
- working-continuity-postgres-02.log: eight native scripted author-first chapters, selected working continuity and interrupted result recovery passed.
- installed-generation-behavior.log: 34 tests ran against installed modules, including silent process completion across injected 270/600/parent time, verified manual cancellation and PID reuse protection.
- final-static.log: architecture manifests, fitness, instruction ownership, generated Skills and documentation reality checks passed.
- Standards and Spec reviews completed; discovered durable deadline test gap and dependency-changed Craft coverage gap were fixed. These reviews are not runtime/literary qualification.
- Full unrelated/release qualification matrix NOT_RUN. Scripted tests remain scripted, and installed tests do not prove literary quality.

Host timer handling and boundaries

- PR #166 already removed host per-attempt subdivision, settlement margin and model process total timeout; Codex backend uses ProcessTimeout(None), OpenAI generation has no read/write timeout, DeepSeek removes socket response timeout after connection. Those repaired paths were verified, not recreated.
- Native empty Book/Group/Chapter coordinator roots now classify before first model child through exact persisted contracts and scoped owner/Saga/delegation evidence. Mixed and irreversible work remains excluded.
- Deadline probe/scanner and native recovery paths ignore historical generation deadlines; scanner keyset pagination prevents exempt generation rows starving infrastructure deadlines.
- Canon reextraction no longer escalates solely on elapsed deadline or cumulative generations. New policy stores no generation deadline/count/cost cap; identical-result/no-progress diagnosis remains controlled and history remains retained.
- Creation healthy waits and unchanged scheduling yields remain backoff observations, not false CREATION_NO_PROGRESS. Scheduling windows yield between work; they do not interrupt a model.
- Cancellation, lease renewal, actual executor loss, fencing, result identity, late-result isolation and unknown usage remain enforced.
- Infrastructure connection, pool, lock/transaction and cancellation signalling protections remain.
- Installed CLI 0.159.2: offline real executable SSE probe shows stream_idle_timeout_ms=0 terminates immediately, 50 ms terminates, 1000 ms permits a 300 ms silent fixture. Public configuration does not provide a disable value. This upstream CLI limitation remains; no huge-number substitute was installed.
- Known actual native call completed at 342202 ms across the old 270-second boundary; this is one real observation, not complete end-to-end timeout qualification.

Narrative implementation and proof limits

- Ordinary fresh Creation now installs Chapter 3.0.3, prose Skill v5 / Template v15, event-first Planning 2.15.0 and long-outline v5. Frozen historical Formation profiles replay unchanged.
- Selected working prose v3, schedule UNASSESSED evidence and soft selected Craft allocation history are separate from formal accepted Canon and realized craft effects.
- Complete/current native prose root-cause evidence can inform only the next unexecuted PLANNED future plan; consumed report IDs enter lineage and idempotency. Frozen/executed plans and author core requirements retain their owners.
- Versioned FROZEN_SELECTED_RANGE currentness accepts append beyond the reviewed range, rejects changed reviewed sources, and leaves old full-manifest contracts unchanged.
- Native naming binds generated title to versioned Foundation task/Schema/recovery, then reads the active Book Design title without rewriting the immutable genesis Book record.
- These establish CODE_EXISTS / WIRED and bounded EXECUTABLE evidence. No assertion of literary improvement, human choice, formal acceptance or PRODUCTION_PROVEN.

Native execution and recovery

- Control A uses the former effective profile on repaired execution, fresh independent contemporary input. Native generated title: 那台机器还在响. No old novel prose was supplied.
- Independent new traditional cultivation work: project:author:a82e253a8edfe1294d71ff6e05cff8bad1c5871a5d15888a16617774ddcc9903; Formation story-formation:22526029247c0518ef4e460a63cb1eef5533c244f5c6d9c1691325b53bcac088.
- New work input: only author-level genre, quality, length and delivery scope; total 600, first 100, 4000–5000 Han/chapter, no hand-written title/world/plot/sample. Default native Pack activations were read back as ACTIVE 2.15.0 / 3.0.3.
- Runtime model/reasoning fixed at gpt-6.1-sol / high. Raw frozen requests, dispatches, stdout, result files, process receipts and UNKNOWN records are retained in private evidence.
- A real response-body stream failure and two workspace discovery failures were retained. Read-only Doctor showed inference endpoint timeout with direct networking and reachability using the already-configured macOS proxy. Task-only HTTP/HTTPS proxy environment was corrected; system configuration untouched. Native successors preserved original IDs/history and resumed the same works.
- Shared port 55483 then crashed on system-disk ENOSPC. No original cluster restart or source data modification was performed. Stopped-source physical copy plus separately copied tablespace recovered on task-owned DevSSD port 55577; DB nf_gen_cap_repair_20261013, OID 1925316 and system identifier retained. Copy is a recovered task runtime, not proof of the unavailable original instance.
- Snapshot pg_amcheck passed; historical NOT VALID constraints were retained rather than forcibly validated. A local complete/VALID model result from the interrupted commit remains available for native recovery before any successor generation.
- One diagnostic search accidentally included private environment credentials. Private files are excluded from further searches and from this report/code/PR. Copy-role credential was rotated; original shared role was not altered.

Actual delivery at this version

- First drafts: 0/100. Native revisions: 0. Selected: 0. Han-length compliant: 0. Formally accepted: 0. Human evaluation: NOT_RUN.
- A/B/C prose comparison: NOT_COMPLETED. B/C paired outputs and randomized model comparison NOT_RUN.
- First ten reading report across native groups: NOT_RUN.
- Current dynamic counts/phase/latency/usage are in append-only delivery-observation-*.json. Neither Foundation assets nor successful calls count as prose delivery.
