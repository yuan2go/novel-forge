WP-NOVEL-GENERATION-CAPABILITY-REPAIR-01 implementation plan

1. Pin main/PR/isolated source and running instances; preserve baseline docs.
2. Reproduce healthy-wait false no-progress through native creation claim; retain cause-based diagnostics. Verify already-disabled model lifetime deadlines, silent process waiting, executor fencing/cancellation and stored results with fault injection. Audit installed CLI/API transport limits separately.
3. Freeze prospective native Creation narrative execution selection: event-first Planning, full selected-prose continuity, stage-specific v5 Skill/v15 Template. Historical Formation profiles remain replay inputs.
4. Resolve accepted-only consumers and scope future Plan Change to unexecuted writing frontier using existing owners.
5. Build/install isolated wheel, migrate isolated PostgreSQL databases, activate through normal Creation, read back complete requests and manifests.
6. Native A/B/C paired controls with all original results/failures; then independent 600-chapter cultivation Book with first 100 chapters, retaining first draft, revision and selected prose separately. Read first ten across two groups and continue same Book.
7. Report saved/readback counts, actual costs/time/recovery, risks and unproven goals.
