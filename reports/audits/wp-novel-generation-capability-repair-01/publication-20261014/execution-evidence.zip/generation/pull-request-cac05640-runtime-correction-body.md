工作包 WP-NOVEL-GENERATION-CAPABILITY-REPAIR-01 仍在实施；独立新书首稿、修订、选定稿交付均为 **0/100**。本 PR 保持 Draft，尚未证明文学目标或完成交付。

在 main 198a3c12 已整合的纯生成时限删除及创作主链修复上，继续修复正常 Creation 的 Foundation 输入、未启动后继跨部署恢复，以及 World 实际输入与完整结果恢复。新 World source/task v3 对齐 agency v2 的动作语义和 schema；旧冻结请求保留原样。0205–0208 是追加迁移，已发布迁移未改写，chain_depth 仍只要求正数。

已有完整 World 结果遭遇字段地址失败、零发送容量失败或祖先 Director 绑定另一 source 时，现有 continuation Owner 精确绑定原 Creator、冻结输入、当前未执行章节、完整回执和隔离证明，复用保存结果并仅执行缺失阶段。跨发布与后续容量恢复保留并重新核对证明；数据库拒绝 marker-only 授权和证明丢失/篡改。保留原失败、UNKNOWN、用量、取消、lease/fence 和晚到结果隔离。

本次焦点验证：120 个相关单元通过；9 个 PostgreSQL 守卫/0207→0208/备份恢复通过。捕获真实失败数据的隔离副本上，原生 Owner 登记、幂等、Kernel admission 及零发送容量后继验证通过，完整 generation/isolation proof 保留；重复故障在真实单请求上下文容量处停止，0 次新增模型调用。这些证据不等于完整 Provider 恢复。

实际安装的 cac05640 非 editable wheel：984 个源码文件、11 个实际 console/worker 启动器逐一匹配；SDK read/write=None。任务专用 PostgreSQL 已备份、恢复验证并升级 0208，对照书 Pack 已激活，正在正式 Creation 入口恢复原书。先前 native Creation 的 World v3/旧结果恢复和 0206/0207 焦点证据保留。完整适用发布矩阵尚未执行。

保留负证据：545d7f53 在复核后遭遇容量失败，丢失 proof 并重复调用一次 World；此后真实 Director 解码故障保留 UNKNOWN，祖先 source 混读导致后继拒绝。修正不会抹去这些记录。既存协调合同测试 4 失败在隔离 b49c205c archive 同样复现，未修改 frozen hash；一次共享测试库并发死锁及捕获副本测试 oracle 错误均保留。安装 CLI 0.162.0-alpha.17.2 的上游 SSE idle 限制无公开禁用选项，仍不可控，未用超大阈值替代。

独立新书《炉火照仙途》继续同一 Formation/Opening。实际历史调用使用 gpt-6.1-sol / gpt-6-sol（high），不能声称全程固定一个模型或未变更的单版本留出。严格 A/B/C 配对正文、前10章阅读报告、100章交付与真人评价尚未完成。生成、修订、选定、篇幅、接纳和未知用量分别统计，代码、fixture、模型评分不能替代小说交付。
