工作包 WP-NOVEL-GENERATION-CAPABILITY-REPAIR-01 仍在实施，独立新书正文交付目前 **0/100**；本 PR 保持 Draft，不能作为文学能力完成声明。

在 main 198a3c12 已整合的超时与创作主链接线修复上，本差异继续修复正常 Creation 的 Foundation 输入、跨部署未启动恢复和 World 实际输入合同：新 World source/task v3 对齐 agency v2 的动作语义、字段清单及 schema；旧冻结请求保持原样。旧完整生成和 Director 输出遇到字段地址失败时，由现有 continuation Owner 追加 v2 复核和后继，唯一绑定公开标量，保留原 FAILED_FINAL、回执、未知用量和取消/lease/fence，避免重复 World 调用。0205、0206 为新增迁移，已发布迁移没有改写；0206 保留现行正数 chain_depth 观测约束。

验证：新增 World 焦点单元 174 passed；原生 PostgreSQL Creation 的 v3 和旧结果恢复、NULL 未知预算与迁移守卫 3 passed；0205→0206 升级及备份恢复 1 passed。此前 Foundation/部署恢复 PostgreSQL 和焦点测试证据保留。安装包 545d7f53 的 982 个源码文件、11 个实际 console/worker 启动器逐一匹配；SDK read/write=None，任务专用数据库完成备份/恢复升级。完整适用发布矩阵尚未执行。

负证据保留：协调合同测试有 4 个既存失败，隔离 b49c205c archive 同样 4 failed/29 passed，未修改 frozen hash。一次测试共享库并发 preflight 死锁保留原日志，串行重新验证通过。安装版本 CLI 0.162.0-alpha.17.2 的上游 SSE idle 限制无公开禁用选项，仍不可控；不使用超大阈值替代。实际历史调用使用 gpt-6.1-sol / gpt-6-sol，均 high，不能声称全程固定一个模型。

任务实例内原生对照书正在恢复，新独立书《炉火照仙途》仍在 Opening/Planning，尚无原生首稿。A/B/C 配对正文、前10章阅读报告、100章交付和真人评价 **NOT_RUN/NOT_COMPLETED**。实际原始输出、修订、选定、篇幅、接纳、真实耗时与未知用量将分别统计。代码接线、fixture、模型评分不替代真实正文和阅读证据。

实际安装态后续反例：World v2复核登记成功，但后继在materialization前遇到Context容量失败；普通容量恢复丢失完整World proof，发生一次新的World调用。因此安装态跨容量边界的无重复恢复尚未通过，原失败和新调用都已保存。正在补原生继承及0207入库守卫，尚未发布/安装；不会把fixture成功升级为实际完成。
