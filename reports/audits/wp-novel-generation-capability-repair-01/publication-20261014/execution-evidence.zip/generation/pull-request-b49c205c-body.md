## Summary

部署版本变化曾使已保存的完整 Planning 结果无法消费，也使已经隔离、尚未启动的原生后继卡在旧版本绑定。本变更沿现有 Owner 恢复同一工作，保留原失败、冻结请求及 UNKNOWN 回执；同时为新 Foundation 请求加入版本化阶段投影，并限定容量恢复只能使用当前失败原因。

```text
Creation / Opening recovery
  saved complete result → exact-identity revalidation v2 → candidate
  isolated unstarted successor → append deployment binding v4
    admission UoW locks and rechecks binding → one successor
```

这是 WP-NOVEL-GENERATION-CAPABILITY-REPAIR-01 的进行中工程增量。main 已包含此前的超时与工作稿连续性修复；本 PR 不重复这些实现，也不宣称小说能力或 100 章交付完成。

## Evidence

- **Before:** 完整 Planning 回执因仅 `release_sha` 不同被拒绝；原生 Opening 在未启动后继的旧部署绑定处报 `PLANNING_RUNTIME_CONTINUATION_COMMAND_DRIFT`。
  **After:** 实际安装态中，A 通过 v2 复用原完整结果，原请求未重发；同一新书通过 v4 登记恢复，后继 Attempt/Pack 绑定 `b49c205c`，原 UNKNOWN 及原 continuation 未改写。
- PostgreSQL：当前 0205 DDL 的 generate/scan/cancel-race 3 项通过；v4 原生 Creation/Opening 回归通过，覆盖并发同键登记、旧 worker 预检后竞争、提交前拒绝和启动后重放。早期失败证据保留。
- 0205 新装与 0204→0205 升级、私有备份恢复及原 Operation/Attempt/Effect 指纹核对通过；已发布迁移未修改。
- 49 项定向单元检查、相关静态/清单/文档检查通过；Standards 与 Spec 审查发现的问题已修复。独立非 editable 安装核对 14 个模块哈希及实际迁移头。
- **尚未证明：** 全发布资格矩阵 NOT_RUN；真实正文首稿 0/100，修订/选定/正式接纳 0；B/C 配对正文、十章阅读报告和真人反馈 NOT_RUN。实际 CLI 的上游 idle 限制仍无已验证的公共配置关闭值。安装及受控测试不等于文学改善或 PRODUCTION_PROVEN。

## Merge Danger

**Door:** one-way

新增 forward-only 迁移 0205；恢复记录追加版本，不回写终态历史。代码可回退，已发布迁移及新增恢复证据应保留。

**Blast Radius:** recovery

影响原生 Foundation 容量恢复、完整 Planning 结果接纳，以及隔离后尚未启动的 Planning 后继部署切换。已经启动的后继、语义/输入/权限变更、取消及不确定结果仍拒绝此恢复路径。原始工作区及其他任务运行实例未修改。
