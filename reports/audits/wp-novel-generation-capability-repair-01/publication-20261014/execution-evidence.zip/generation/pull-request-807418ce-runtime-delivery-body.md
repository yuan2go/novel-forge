纯模型生成曾被本地调用、父级期限和累计额度拦截；小说链还把 Book 适用性当作章节义务，并把空的 Genesis 当作缺少已声明的世界规则。本分支删除纯生成时间终止与累计 Book 封禁，修正输入/规划/工作稿/审稿消费，并通过现有 Owner 复用身份一致的完整结果。

当前 HEAD：807418ceced5f10dd2e60c9dd59967567c7d2fef。保持 Draft，不合并。main 为198a3c12bed4613b470623fa2636bdfeccc516cb。PR166已关闭且仍标记Draft，最新历史HEAD为5d0ca7447089b89b55230ef0657e5ec255d4d1ff；未盲目合并它。

本次增量：
- Book 与 Chapter 的 applicability 分离，原冻结 v1 合同保留；原生新入口使用 v2。精确完整 Writer 回执可通过受控 3.10.3 后继重新校验与保存，零新 Writer 调用。
- 新 World source.v4 仅投影 Foundation 中实际声明的 world_rule 标量，不使用 predicate 期望值制造事实，不覆盖已有状态，不授予人物知识。旧 source.v3 保持重放。
- world-host-revalidation.v3 沿原运行继续，复用同一 Source 下各自原 Owner 的完整 generation/Director 回执。0209 追加准入函数，保留已发布迁移、失败、旧 Action、隔离 UNKNOWN 与未知用量。
- Action/primary 保存 UoW 校验当前有效 fence 的 Operation/project 归属，锁 Formation→Book 后检查取消、当前前沿与冻结输入。容量后继保留现有 Kernel 登记及 typed admission 证据、原 proof、repair 字段和租约链。

已验证的边界：
- 定向 World/规划/Handler 单元258 PASS；随后 fence/容量增量定向110 PASS（有重叠，不相加冒充覆盖）。PG World准入/升级备份恢复2 PASS；既有容量矩阵9 PASS。失败的早期验证日志全部保留。
- 非 editable807安装包985模块逐字节匹配；11实际 console/worker launcher核对；SDK read/write=None、connect/pool=30。 owned PostgreSQL1925316/55577升级0209，原55483实例及其他任务工作区未改。
- captured native副本经历一次零发送容量故障后，复用原两份 World结果，真实当前 fence 下保存 Action，新增 Model Effect为0，原失败/UNKNOWN未变。primary仅核其真实live-child guard，副本未生成或伪造主输出/正文。报告字段 KeyError单独保留，后续只读持久读回确认。
- Documentation Reality、架构fitness、迁移manifest、定向lint及diff检查通过。完整发布矩阵 NOT_RUN；旧 native 大测试1 FAIL仍保留，不算全链通过。

实际交付与未完成项：
- 对照A《那台机器还在响》原生恢复交付1份1606汉字首稿，正文未改、零新 Writer调用；正式接纳0。不能据此认定文学改善。
- 独立新书《炉火照仙途》600章、4000–5000汉字、首期100章，已完成原生Foundation/Opening；同一Book正在恢复首章Planning。此刻正文0/100，十章阅读报告未完成。
- 严格固定模型的A/B/C配对、文学目标和真人评价尚未证明。系统变更按版本分段；该书不再称未受调整的单一release留出。
- CLI0.162.0-alpha.17.2公开stream-idle配置尚无可验证禁用值，这是上游限制；没有声称删除远端限制，也没有用超大数值替代删除。

此PR仍为进行中的能力修复与交付工作，不以测试数量、提示词接线、模型评分或问题关闭替代100章完成声明。完整正文与工程执行证据保留在任务owned evidence目录中，未提交私有数据库、账户配置或原始用量秘密。
