第3章 — 候选正文

来源：47670bba-de87-437e-8213-1521cd099bca
状态：COMPLETE_SOURCE_RESULT；NOT_REVIEWED；NOT_SELECTED；NOT_ACCEPTED

{"edits":[{"issue_codes":["CH3-PRACTICE-DENSITY"],"quote":"轮到他时，他在转向前放慢，等鞋底踩实才继续送盘，没有急着追上前一人的速度。其余弟子也各走了一趟，先前放盘太急的留意最后那点距离，木块偏到一侧的便先落盘摆平。坡上不再有人抢着往前，等候的人能看清前一只盘是否已经放稳。","replacement":"圆脸弟子再走时，转向前先踩实了脚，木块这回没有滚动。他放好盘，朝徐照扬了扬眉，便退开让路。其余弟子接着练，乔令仪在各人先前出错的地方提醒；上方的盘放稳了，下一人才动身。"}],"resolved_issue_codes":["CH3-PRACTICE-DENSITY"]}
