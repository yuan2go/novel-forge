from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
from io import BytesIO
import hashlib,json
from tests.unit.test_work_intent_consistency import final_input,work_input,test_work_prompt_reaches_isolated_cli_stdin
from tests.unit.test_provider_token_admission import COMPLETE_COVERAGE
from tests.unit.test_deepseek_provider import adapter,invocation,response
from novel_forge.modules.production_execution.provider_admission import ProviderRequestEnvelope,TokenAccountingContract,build_route_token_accounting_contract,prepare_provider_admission
from novel_forge.modules.provider_control.contracts import ProviderInvocationRequest
from novel_forge.modules.provider_control.openai_v2 import OpenAISdkTransport
out=Path(__file__).parent/'final_inputs';out.mkdir(exist_ok=True)
manifest=[]
for mode,style in [('restrained','克制冷峻，允许长句，禁止笑点'),('light_fantasy','轻松幻想，允许笑点')]:
 for stage in ('draft','review','revision','rereview'):
  prompt,metadata=final_input(stage,style)
  plan,context,candidate=work_input(style)
  schema=json.loads(prompt.split('<output_schema>\n',1)[1].split('\n</output_schema>',1)[0])
  envelope=ProviderRequestEnvelope(provider='openai',model='synthetic-model',protocol='openai-responses-text-envelope-v1',input_text=prompt,max_output_tokens=4096,timeout_seconds=60,stable_idempotency_key='synthetic:'+mode+':'+stage,reasoning_effort='high')
  contract=build_route_token_accounting_contract(provider='openai',model=envelope.model,route_identity='synthetic-route',accounting_method='OPENAI_UTF8_BYTES_UPPER_BOUND_V1',accounting_evidence_ref='synthetic-byte-bound',model_context_limit=512000,execution_token_limit=512000,output_reserve=4096,safety_margin=256,framing_overhead=32)
  admission=prepare_provider_admission(envelope,contract,complete_request_coverage=COMPLETE_COVERAGE)
  calls=[]
  client=SimpleNamespace(responses=SimpleNamespace(create=lambda **kwargs:calls.append(kwargs) or SimpleNamespace(id='synthetic-request',output_text='{}',usage=SimpleNamespace(input_tokens=1,output_tokens=1))))
  request=ProviderInvocationRequest(provider='openai',model=envelope.model,capability='model.'+stage,stage=stage,stable_idempotency_key=envelope.stable_idempotency_key,request_payload=envelope.to_dict(),request_hash=envelope.envelope_hash,timeout_seconds=60,trace_id='synthetic-trace',correlation_id='synthetic-correlation',operation_id='synthetic-operation',external_effect_id='synthetic-effect',budget_reservation_id='synthetic-reservation',provider_admission=admission.to_dict())
  OpenAISdkTransport(client).execute(request)
  deep=invocation();deepenv=replace(ProviderRequestEnvelope.from_dict(deep.request_payload),input_text=prompt,max_output_tokens=4096)
  deepcontract=replace(TokenAccountingContract.from_dict(deep.provider_admission['accounting_contract']),model_context_limit=512000,execution_token_limit=512000,output_reserve=4096)
  deepadmit=prepare_provider_admission(deepenv,deepcontract,complete_request_coverage=COMPLETE_COVERAGE)
  wire=[]
  def transport(req,**kwargs):
   wire.append({'method':req.method,'url':req.full_url,'body':json.loads(req.data),'timeout_seconds':kwargs['timeout']})
   return BytesIO(json.dumps(response()).encode())
  adapter(transport=transport).invoke(replace(deep,stage=stage,request_payload=deepenv.to_dict(),request_hash=deepenv.envelope_hash,provider_admission=deepadmit.to_dict()))
  assert calls[0]['input']==prompt==wire[0]['body']['messages'][0]['content'] and style in prompt and 'SYNTHETIC_HOST_ONLY_MARKER' not in prompt
  name=mode+'-'+stage
  (out/(name+'.prompt.txt')).write_text(prompt)
  record={'evidence_type':'SYNTHETIC','stage':stage,'input_style':style,'ordered_sdk_messages':[{'role':'user','content':prompt}],'openai_sdk_arguments':calls[0],'deepseek_http_request':wire[0],'actual_output_schema':schema,'materialization_metadata':metadata,'provider_admission':admission.to_dict(),'source_variables':{'chapter_plan':plan,'style_policy':context['context_segments'][-1],'creative_baseline':candidate['creative_baseline']},'variable_sources':{'style_constraints':'synthetic ChapterPlan.style_constraints and synthetic style_policy.structured_facts.style_constraints','creative_baseline':'native build_creative_baseline(plan,context)','output_schema':'native PostgresChapterExecutionContractBinder._provider_output_contract(stage,v8)','prompt':'native _materialize_production_codex_prompt with actual versioned Pack assets'},'external_io_replaced_only':True,'headers':'NOT_EXPORTED: no real credentials; synthetic transport fixture key','real_provider_called':False}
  (out/(name+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
  manifest.append({'id':name,'type':'SYNTHETIC','prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'files':[name+'.prompt.txt',name+'.json']})
cli=out/'cli';cli.mkdir(exist_ok=True);test_work_prompt_reaches_isolated_cli_stdin(cli)
(out/'manifest.json').write_text(json.dumps({'evidence_type':'SYNTHETIC','snapshot_count':8,'paths':['OpenAI SDK text-envelope','DeepSeek native JSON HTTP','isolated CLI stdin'],'snapshots':manifest,'limitation':'No real Provider, deployed configuration, paid CLI or literary-effect proof. These are synthetic chapter tasks, not all possible requests.'},indent=2,ensure_ascii=False)+'\n')
print('Exported 8 exact final prompts, SDK/HTTP arguments, actual schemas, variable sources and isolated CLI stdin.')
