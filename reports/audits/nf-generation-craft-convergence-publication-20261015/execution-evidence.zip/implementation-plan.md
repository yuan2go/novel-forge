# WP-NF-GENERATION-CRAFT-CONVERGENCE-01 execution map

External execution notes; not canonical documentation or runtime Authority.

- [x] Freeze main6359289e and craft16291555; preserve151-worktree inventory, original failures and expanded205-member archive.
- [x] Reconcile canonical migration policy before code; documentation Reality PASS; commitb80d2546.
- [ ] Integrate native Source abstraction/isolation, experimental governed methods and Book namespaces through owning Source/MKAOS/StoryDesign/Planning UoWs.
- [ ] Append0213-0217 after main0212; preserve published main/craft bodies. Run fresh, genuine main-prefix upgrade, foreign/discontinuous rejection, scoped backfill and combined capacity tests.
- [ ] Freeze new working-prose.v5 predecessor identity manifest and bounded selected text/memory; retain v4 replay. Test130/600, source replacement, complete recent input overflow and actual Writer/World transport.
- [ ] Bind separate working Craft phase evidence under budgetv5/strategyv4; retain accepted contracts, require located native Review for phase advancement, invalidate selected-source changes.
- [ ] Audit real sourcefork ledger and object/execution identity, create an isolated snapshot and rebuild on actual canonical migrations while retaining sourceledger provenance. Original source/process unchanged.
- [ ] Complete actual native Source/Observation/method lineage and material gaps; reuse eight verified excerpts and three source hypotheses without presenting full-book reading.
- [ ] Establish new independent A/B/C600-chapter/100-first-window protocol and same model/reasoning/author/packs/allowance for A/B. C uses controlled reference owner.
- [ ] Deliver first native output plus failures/revisions for3x3 chapters4000-5000Han; B proceeds across real ChapterGroup boundary. Exact readback/export, input capture and source-method trace required.
- [ ] Read plans/prose for comparative findings, anonymize reading package, mark no human response pending.
- [ ] Commit reviewable final implementation and run current exact-source applicable governance/P0. Separate engineering, actual deployment, realProvider and literary evidence.
