# 第 4 章真实 Provider 正文比较

本页的后稿来自真实 `gpt-6.1-sol` / high，使用已有 process supervisor 和 capture 的账号/CLI 配置，不是人手写示例。全部原始输出、失败、stdin 与回执保留。运行范围是重新装配的隔离阶段输入，**不是 native Saga/正式 Plan Change/已验收正文**。

## 输入与调用

- 历史原章：[完整原文](source/chapter-004-effective.txt)，4395 汉字。[原 stdin 的回执 hash 对账](source/original-writer-stdin-proof.json)。
- 新输入均携带第 1–3 章全部有效原文，accepted=0，未补造 Canon 或人物已知 fact ID。
- 第一、第二次 Planning 仍受原 parent `ending_hook.const` 约束，虽然压缩维护段，无法产生所需强出口，保留为负面证据。
- 第三次 Planning 为上游纠正 **proposal**：仅在外部实验 schema 中解除静态 ending const，源 production schema 和 active plan 未变。[候选计划](benchmark-plan-candidate-v3-proposal.json)、[输入](benchmark-planning-input-v3-proposal.json)。它给出自身旧钳冷态比较与限用途标记，但仍只承诺下次接工时说明，眼前任务容量不足。
- 第一份 Writer [原始正文](chapter-004-after-ablation.txt) 4488 汉字；schema 和 realization integration 通过，但 storage-less 重建缺 native Context/Retrieval lineage，且发现遗漏原 Style/length 的完整投影，故保留为 **ablation**，不能称为最终受控验证。
- 第二份 Writer 修正了上述投影：[冻结输入](benchmark-writer-input.json)、[逐字重放证明](benchmark-writer-frozen-input-proof.json)，原 Style 与 4000–5000 Han profile 原样保留。然而约 21 分钟后 stream disconnected，没有完整 result。[UNKNOWN 记录](writer-b2-unknown-outcome.json)、[原 ID 本地 recover/query](writer-b2-existing-recovery-query.json)。不能用内部草稿或进度消息冒充交付，也没有重发同一输入。该调用的本地退出码 1 不证明远端取消或零成本。
- 第四次 Planning 进一步要求试验影响眼前工作及另一人的选择，不能把生活 filler 换成反复测量/记录。[最终上游提案](benchmark-plan-candidate-v4-proposal.json)、[冻结 Planning 输入](benchmark-planning-input-v4-proposal.json)。它安排实际承托失败、木料/对位时间损耗、承重方式调整、限时借钳的利益协商，结尾截销并开始拆原销。
- 第三份 Writer 按第四次 Planning 的不同冻结输入生成；不是中断调用的换 ID 重发。完整输入/原始结果和最终判断在下方追加。

## 已观察的前后差异与负面结果

| 项目 | 原章 | 第一份后稿 ablation |
|---|---|---|
| 开头继承 | 记着“提盘”，复述昨日饭食和休息，再问旧夹具能否另用 | 一句过桥压缩饭食休息，既有冷端工作、结算与身体限制作为前提；直接进入拥挤工台和严述有限空隙 |
| 中段动作 | 约 2038 汉字的工具问答/轻示范后，2357 汉字吃饭、回铺、收整、洗手、靠稳 | 自己的钳尝试夹冷木，延长伸出部分后失败，改变摆法，咳喘迫使停止；但反复画线、测距、写记录仍占大量篇幅，存在程序性 padding |
| 出口 | “饭已经吃过，铲子收好了……没有挪动身子……歇下来。” | 系“侧提未查”标记，承诺下次领料前说明；末句“下次站到贺循那张桌前……再谈领哪一份料。”仍偏向未来准备 |
| 判定 | 长度 PASS，推进 FAIL | 长度 PASS，维护压缩改善；强情势推进/立即行动要求 FAIL；完整原生协议 NOT_VERIFIED |

第一份后稿虽然解决了反复吃饭/休息场景，却没有证明系统完成商业推进目标。程序步骤的增多不能替代情势的变化。这个失败直接促成“当前任务必须受影响”的新系统指导及更有容量的上游计划提案。

## 审计限制

[调用/费用记录](benchmark-call-cost-ledger.json) 与 [独占会话审计](owned-transcript-audit.json) 分别保留 supervisor/stdout 和本任务原 thread 的证据。Writer 的工具元数据探查、纯 JavaScript 字数自查/内部草稿扩展没有完整出现在 stdout 标准工具分类中，不能以 `unauthorized_tools=[]` 升级为 native tool permission PASS。未发现外部文学资料读取；仍保留这个协议差异。

所有后稿仅存于本任务外部 evidence 目录，没有写入原书 chosen/accepted；没有 Chapter 5 dispatch，没有 craft migration/integration。既有父级合同要获得生产效力，仍须 owning native Plan Change，再经完整运行资格与作者判断；本页不伪造这一状态。

## 最后一次调用的终态与恢复正文

最后 Writer `benchmark-writer-268fe96a28bd4a8b8430d27040f9f0f5` 在 1177905 ms 后因 `stream disconnected ... error decoding response body` 本地退出 1；没有 final result 文件。[UNKNOWN 记录](writer-b3-unknown-outcome.json)、[原 ID recover/query](writer-b3-existing-recovery-query.json)。它不是可验收的 final Provider output；原远端结果和最终消耗仍未知。

从该调用已经落盘的三段 **原模型 pure-JavaScript string assembly/replacement** 恢复内部 s1、s2，逐条在无 I/O 的 VM 重放，再以两换行连接；没有新增、修改或补写正文。[恢复脚本](recover_internal_writer_b3.cjs)、[来源代码与 hash](chapter-004-recovered-internal.json)、[恢复的完整工作正文](chapter-004-recovered-internal.txt)。该文件已完整读回，正文 hash 相符，既有 `han_characters()` 计得 **4340**。这是模型内部工作文本的字面长度 PASS，**native 最终首稿长度仍 NOT_VERIFIED**，没有伪造 final Schema/receipt。

### 逐段比较（本任务读稿，非独立人类验证）

- **开头**：一过桥句承接已结工钱、饭和休息，紧接严述“空出的两根指头够向桌上的窄锉，够到一半，又收了回来”。当前难处立即可见。前章尚未回答的“旧夹具另作何用”只问一次；旧 `勿提盘` 结论保留，原夹具没有重新拿来演示。没有再申请已取得的试工、重新结算或重复初诊。
- **中段**：许照先夹住垫木，软木压凹、原已对齐的销孔退开，消耗木料及对位时间；他提出让桌面承重，严述校正拆销空间并削去一角，两人重新分工。第二种布置使严述确实空出一手，拿到短销/窄锉。这里每次调整改变正在做的任务，没有用连续画线、记笔记和复述同一限制撑篇幅。
- **利益与主动选择**：许照原想取回自己的钳。严述说明取走会使这一边冷装停下，于是双方谈到次日午前归还、只在冷台、不转借、损伤说明/修赔，以及求教不以借钳为条件。许照主动接受限时借用，失去一段时间携钳接零活的选项，同时明确不能守到晚，保留身体和求工边界。对白实际改变使用权、期限和关系。
- **结尾**：已削木角、截去销余段、工具限时留下；严述从腾出的空间开始抽出原销。最后一句是“……沿着腾出的空处继续往外带，销身随之从这一边的接合里又退出来一截。”工作已进入拆开的状态，没有回铺、收包、睡下的封闭归零。后续需要承接冷装和借钳期限，具备可见的局部前行动力。

第一场 1061 汉字、第二场 3279 汉字。后者约占 75.6%，集中在失败、调整和权利协商；这依实际分段说明篇幅落点，不是 routine regex 或新的文学 gate。

**结论**：内部工作正文显示所需推进方向的实质改善，字面长度符合要求；但受控 Writer 的最终交付、native output/receipt/工具权限闭环与正式计划采纳均 **NOT_VERIFIED / NOT_DONE**。因此 Phase 3 的“native 4000–5000 首稿 + 完整生成验证通过”目标仍未完成，不能以恢复内部文本替代。没有宣告起点商业质量 QUALIFIED，更没有 author acceptance 或 PRODUCTION_PROVEN。

当前可以交付系统 diff、工程测试、归因和真实模型工作正文的比较；生产中的静态父级 hook 仍需 owning Plan Change，两个未知远端调用仍需原身份对账。它们没有被重发、清零成本或人工补出终稿。
