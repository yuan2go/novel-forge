**最终状态：诊断与系统代码已完成；相关工程回归通过。受控第 4 章 Writer 两次流中断，native 终稿验证未完成；恢复的 4340 汉字仅为内部工作正文。**

# 叙事推进与连续性诊断

本报告绑定 main `dc969e64f23567f806d59cdb1a0f7caa5fb32e7b`（含 PR #168/#170），系统修改位于隔离分支 `codex/narrative-progression-engine-20261014`。原工作目录和进行中的第 5 章恢复未被本任务修改。正文、请求和数据库均重新读取；旧任务记忆只用于查找证据位置。

## 1. 身份与证据边界

- 原库 `nf_gen_cap_repair_20261013`，OID `1925316`，端口 `55577`。
- 项目/Book 后缀均为 `author:a82e253a8edfe1294d71ff6e05cff8bad1c5871a5d15888a16617774ddcc9903`；BookRun `book-run:86a75a74-c326-47cc-a857-d983484ed537`。这不是旧《青岚问道》项目。
- [初始原库 checkpoint](source/book-checkpoint.json)、[有效正文与来源清单](source/inventory.json)、[最终原库只读复查](source/final-original-sentinel.json)：`selected=1`，`accepted=0`，4 份原有效正文资产内容逐字未变。
- 原库只读 dump 后使用独立副本 `nf_progression_1afb99ec4df44b38`，OID `3619159`。[副本身份](clone-identity.json)。副本读取和行锁没有业务写入；副本不是原实例的生产证明。
- 后文的新 Planning/Writer 调用使用真实 Provider、原生阶段装配函数和已有进程 supervisor，但没有创建 native Kernel Operation/Attempt、retrieval receipt 或正式 Plan Change。证据类别为 `RECONSTRUCTED_STAGE_INPUT_REAL_PROVIDER_NOT_NATIVE_SAGA`。没有虚构 native ledger、选择或验收记录。

## 2. 第 4 章没有字面正文交接缺口

原 Writer effect `829fb50d-df84-4a17-88a6-fca44f32a47f`，Operation `ff8f509b-a9ef-4f1d-ac02-3e4eb43421b8`。实际冻结请求见 [draft-request.json](source/draft-request.json)，materialization 见 [draft-materialization.json](source/draft-materialization.json)。

第 4 章的 `input.execution_intent.working_manuscript.sources` 包含完整第 1–3 章，没有 omitted ranges：

| 章 | 原 Writer 实际收到的资产 | Unicode 字符 | 汉字 |
|---|---|---:|---:|
| 1 | `authority-output:449a4ae8-ec71-4876-8d47-cf30eb0e200d:chapter.best_candidate:v1` | 5160 | 4390 |
| 2 | `authority-output:60ef7e0a-dfdf-4fc9-a046-babf2c768625:chapter.draft:v1` | 5041 | 4174 |
| 3 | `authority-output:b7bb4cb4-ce78-41af-8605-8ee0b6542e41:chapter.draft:v1` | 5134 | 4342 |

将保存的请求重新经过实际 prompt builder 装配，stdin SHA256 为 `c95672172130974fad3918fdb8caff12e4dca313631f805ba900fe24a11a890b`，与原 SUCCEEDED 进程回执的 `input_sha256` 完全一致。[字节级证明](source/original-writer-stdin-proof.json)、[完整原 stdin](source/draft-reconstructed-prompt.txt)。这排除了“selected=1 导致第 2–3 章正文完全未送到 Writer”的归因。

但原 v3 结构化 working memory 没有 entries：第 1 章 MISSING，第 2–3 章 NOT_REQUESTED，semantic support 为 NOT_VERIFIED。已发生的领取安排、初诊、交工结算、夹具受力发现只能从完整原文中读取，不能冒称有已验证状态摘要。字面传递完整与语义导航薄弱是两件不同的事。

`manuscript.selected_source()` 原本已能按章回退 native delivery / committed accepted / SUCCEEDED draft，并叠加有来源的 working/editor selection；它不以全书 selected 数量为遍历上限。因此本次 resolver 加固是确定性、accepted 优先级和审计来源升级，而非该真实案例缺失正文的补丁。

## 3. 四章 Planning 容量逐章变薄

直接检查各 Writer 的实际冻结 plan：[第 1 章](source/chapter-001-frozen-draft-request.json)、[第 2 章](source/chapter-002-frozen-draft-request.json)、[第 3 章](source/chapter-003-frozen-draft-request.json)、[第 4 章](source/chapter-004-frozen-draft-request.json)。typed `character_participation` 中确有目标和预期改变；旧兼容字段 `character_goals=[]` 不代表没有人物目标。

| 章 | 实际任务与冲突容量 | 出口 |
|---|---|---|
| 1 | 岗位结束后的钱物取舍、带肺伤赶路、找落脚处；前两场有身体/路费阻力 | 已离乡并抵院，但以睡下、明早问活收束 |
| 2 | 说明旧经验和身体限制，争取有限有偿冷端入口；另两场是初诊和生活安排 | 新安排已成立，回铺整理次日用品、坐下休息 |
| 3 | 分料清点，扬尘/肺伤和陌生工序造成实际阻力；后两场为工具说明、交工结算 | 收到工钱，留下下一次工具问题 |
| 4 | 一次旧工具求教，随后吃饭、回铺、洗手、整理、休息 | 又留下下一次工具问题，眼前无需行动 |

第 4 章三场 `scene_plan[*].conflict` 全为 null。原存储 [ChapterPlan](source/asset-chapter_plan.json) 的 objective 明确要求“再以饭食及休息呈现第一次所得的生活用途”。第三场末拍明确写“无需新的悬疑刺激”，exit state 是收妥工具、留下问题、停下来休息。原计划也尝试禁止“逐项重演第一章收拾”，但仍把大量生活收束列成独立场景；局部提醒没有改变总任务容量。

更关键的是，原 [Planning materialization](source/chapter_plan.generate-materialization.json) 的 `output_schema.content.properties.ending_hook.const` 锁为：

> 许照知道下一回该带着哪个问题来，也知道眼下要先把饭吃好、把身体养住；后续学习由已有入口自然展开。

这个 hook 来自 ChapterGroup schedule row，经真实 `PostgresPlanningExecutionPreparer` 的 schedule/selector binding 冻结。它不是 Writer 可以自由改的软提醒。系统必须改善新计划，并通过拥有者 Plan Change 修正既有父级合同；不能为了 benchmark 放宽生产 validator 或暗改冻结 schema。

原 v3 `CONSEQUENCE_INSTRUCTION` 同时允许 “quiet scenes and unchanged positions are valid” 并写 “Do not force conflict, reward, reversal or cost.” 这保护安静叙事的权限本身合理，但没有另行要求安静场景也推动行动和情势。第 4 章的静态计划因而得到持续强化。

## 4. 原正文与篇幅分配

已完整阅读 [有效第 1 章](source/chapter-001-effective.txt)、[第 2 章](source/chapter-002-effective.txt)、[第 3 章](source/chapter-003-effective.txt)、[第 4 章](source/chapter-004-effective.txt)，并保留 [第 1 章原始首稿](source/chapter-001-first-draft.txt)。

- 第 1 章原始首稿 3030 汉字，当前 chosen revision 4390 汉字，增加 1360 汉字。整理铺盖、工具包、钱、吃饭和睡下已形成开头/结尾框架。扩写与字数压力的联系属于证据支持的机制推断，不等于已经做了单变量因果实验。
- 第 2 章结尾：“到时候先吃饭，再去领那一份料；眼下……再坐一会儿。”
- 第 3 章结尾：“下次有机会……是否还能留下做别的？”前章的有偿冷端入口、交工和结算是真实已发生前提。
- 第 4 章开头承接布角“提盘”及旧夹具示范；中段说明工具用途后转往饭铺；后段吃热饭、挪包、记录咳喘、回客舍、放钳、洗手、摸铲柄、靠稳休息。末尾再次给未来求教留问题，并明确“今日不必再起身去把它们催定”。

逐段阅读定位第 4 章从“从廊下到饭铺，许照走的是来时那一小段路。”开始的后半部：2357/4395 汉字，约 53.6%；之前的工具求教段为 2038 汉字。[定位与计数](source/chapter-004-section-allocation.json)。这是本任务读稿定位的场景边界分析，不是 routine regex 计数，更没有变成生成后的文学拒绝 gate。

生活细节并非天然无效：此处的问题是连续数章以同类细节完成同类封闭收束，而第 4 章这些内容占一半以上，却不改变当前任务或后续选项。

## 5. 根因权重

| 维度 | 权重判断 | 证据及限度 |
|---|---|---|
| Planning 重复/容量不足 | **主因，高** | 第 4 章全部场景缺冲突；两场直接安排生活维护；父级 const 锁静态 hook。计划直接导致了 Writer 的结构选择。 |
| prior-context handoff gap | **字面缺失：排除；语义导航：次因** | 全三章原文进入实际 stdin，hash 与回执一致。optional memory 为空，后果仍需 Writer 从原文辨读。 |
| 4000–5000 字压力 | **显著放大因素** | 薄任务与强字数要求共同存在；首章 3030→4390 扩写，原 Ch4 53.6% 落在生活收束。硬汉字计量没有错误，分配方向有问题。 |
| Writer 结构/表达重复 | **次因，中** | 有重现工具、热饭、收包、休息、下一回问题的结构；完整先文提供模仿样本。但计划也直接指令这些段落，因此不能把全部重复单独归给 in-context contagion。 |

以上是有证据的定性权重，未伪造因果贡献百分比。一次四章回归也不能证明所有题材的商业质量可靠性。

## 6. 约束分类与结果边界

- 完整字面源、hash、来源身份、原 selection/acceptance、accepted Canon 不升级：`CURRENT_PROVEN_INVARIANT`，测试/实际输入绑定支持。
- 原 ChapterGroup 静态 hook 的 const 和这次真实 frozen v3：`CURRENT_RUNTIME_FACT`，不能追改。
- quiet 权限、字数上下界、source window/预算及新 v4：`CONFIGURABLE_POLICY`。
- v2/v3 payload 和原 Schema/receipt replay：`HISTORICAL_COMPATIBILITY`。
- “所有题材均稳定达到起点商业质量”：仍是 `UNRESOLVED_DESIGN_CONSTRAINT`，不能由 prompt、测试或一份候选宣告成立。

代码与测试结果见 [系统 diff 与验证](system-diff-and-tests.md)；真实调用、原文比较和失败证据见 [第 4 章比较](chapter-004-comparison.md)。新候选不是原 Book 的 chosen/accepted 正文，也不是生产证明。
