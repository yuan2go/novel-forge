# 系统改动与工程验证

最终提交 `866f3ee2b0c68c18ce98df6595e5fc37046c4957`，基础 `dc969e64f23567f806d59cdb1a0f7caa5fb32e7b`，分支 `codex/narrative-progression-engine-20261014`，工作树 `/Users/yuan/.codex/worktrees/narrative-progression-engine/novel-forge`，已提交且干净。完整 [patch](system-upgrade.patch) 可以直接审阅；没有合并或部署。

## 改动

1. [working_prose.py](/Users/yuan/.codex/worktrees/narrative-progression-engine/novel-forge/src/novel_forge/modules/book_authority/working_prose.py:53) 新增 opt-in `working-prose-projection.v4`，保持 Frozen Input 的 context version 和 v2/v3 payload/instruction。新规则锁已完成询问/发现为后续前提，按人物真实知情边界承接后果；既往生活框架不作为模仿样本，必要维护压缩为桥句。开场阻力→有代价的行动/调整→不可逆变化触发下一行动，放进现有 goals/conflicts/beats/exit fields，不新增文学 regex 或拒绝 gate。单场可容纳多次转折，也不强迫无关危险或“三场模板”。
2. [manuscript.py](/Users/yuan/.codex/worktrees/narrative-progression-engine/novel-forge/src/novel_forge/modules/book_authority/manuscript.py:297) v4 逐章采用 committed accepted → 有来源的 working/editor selection → 完整 native effective prose；同 generation 加 asset ID 稳定排序。保留旧 `selected_source` 排序供历史消费者使用。freeze 为全部 1…N−1 源记录 `native_basis/native_source/overrides/effective_source` 和原 hash。缺章/预算窗口不能覆盖完整身份链时明示失败，不暗截断；无选择/验收写入。显式选择损坏仍 fail closed，不能用无声回退隐藏审计问题。
3. optional source-bound memory 沿用既有 v3 导航机制，允许 v4 消费；真实旧稿没有 memory 时保留 MISSING/NOT_REQUESTED，不凭空制造 verified consequences。完整 raw passages 仍传递，指导 Planning/Writer 读取实际已发生后果。v4 的 source_resolution 只属于 v4；v2/v3 不被补字段或改 hash。旧 receipt/schema 不变，没有 migration。
4. [provider_views.py](/Users/yuan/.codex/worktrees/narrative-progression-engine/novel-forge/src/novel_forge/modules/chapter_authority/provider_views.py:2569) 将 v4 本次 `repair_reason` 作为 `planning_correction` 传入 narrative inputs，标 `NEW_CANDIDATE_CORRECTION_NOT_ACCEPTED_HISTORY`。原投影把 repair reason 当 host bookkeeping 删除，导致真实纠正要求没有进入故事输入。旧版本继续原投影。
5. [Planning execution](/Users/yuan/.codex/worktrees/narrative-progression-engine/novel-forge/src/novel_forge/modules/story_planning_runtime/execution.py:4476) 给实际 hierarchical Planning 的既有 schema fields 加叙事容量说明和版本后缀，保留父级 `const`。World provider 子阶段明确排除，不能因复用父命令名误加后缀。没有放宽 validator、角色能力或 Source 权限。
6. [Writer/Planning prompt builder](/Users/yuan/.codex/worktrees/narrative-progression-engine/novel-forge/src/novel_forge/modules/chapter_authority/execution_gateway.py:4577) 在 v4 draft/ChapterGroup/ChapterPlan 的实际 system 文本投影后加入 generic progression overlay。prompt evidence 记录源 working snapshot hash、policy version、overlay hash 和 effective system hash；原 Pack system artifact hash 仍指向原 artifact，不冒充已修改原 Skill/Pack。instruction 与原文不只躲在 data payload 内。
7. 默认新 Creation 模板使用 v4；既有生产 Book 的 v3 profile 和已冻结请求不自动升级。domain handlers、task compression、longform scheduling 接受 v4 memory/prose packet。既有 canonical docs 说明新 policy 和验证要求，reality projection 仅刷新 implementation identity，没有升级文学或生产 evidence class。

生产源码完全不含本书人名、地点、工具情节或固定小说结果。测试中的合成 trial/material 不是单书规则；外部 benchmark 中的本书正文只用于指定回归。

## 测试

[机器可读结果](test-results.json) 绑定最终 SHA：

- 相关 focused unit：**344 passed，5 subtests passed**。[日志](final-focused-tests-866f3ee2.log)
- 全量 `tests/unit tests/architecture`：**5862 passed，28 failed，1508 subtests passed**。[最终日志](backend-final-866f3ee2.log)
- 28 项全部在未修改 main 单独重现，最终失败节点集合逐项完全一致；新增失败 **0**。用户确认保留叙事链范围，将它们单列。涉及已有架构边界、旧合同/Schema、编辑器、Skill hash fixture、检索和迁移身份等，不通过扩大改动掩盖。
- 新覆盖包括：selected=1/accepted=0/4 effective chapters，目标 N=4/5；缺章拒绝；accepted 不被 editor override；稳定来源与全 SELECT；lineage/hash tamper；history 窗口耗尽；Planning/Writer 字面交接；v4 repair_reason surviving projection；parent const 不移除；实际 system overlay 及 v2/v3 replay。
- PostgreSQL 原生 scripted native Creation/World 回归：**11 passed，0 failed**，[运行摘要](focused-postgres-status-final-v4.json) 与 [脱敏日志](focused-postgres-final-v4-sanitized.log)。该轮启动后仅调整单元测试 helper 的兼容调用；生产运行模块与最终提交一致。它证明装配、Kernel、repository/UoW、故障恢复和传递路径；不能证明文学质量。

开发中真实暴露了 World 子阶段误加 schema 后缀以及 fixture 对 citation/source coverage 的过时假定，均保留失败日志并修正后重跑；没有把失败涂改成成功。

## 完整矩阵边界

[P0 exact SHA 报告](p0-866f3ee2/p0-backend-qualification-866f3ee2b0c68c18ce98df6595e5fc37046c4957.json)：source-preflight **PASS**，documentation-reality **PASS**，static-and-manifests **FAIL**，原因是未修改 main 已存在的 `tests/unit/test_working_manuscript_revision.py E701=18` Ruff ratchet。后续 P0 backend/PostgreSQL-start/migrations/query-plan/Compose 为 **NOT_RUN**，cleanup **PASS**。本任务独立运行的 backend 和相关本地 PG 测试分别记录，不能顶替 fail-fast P0 后续关卡。

当前 Docker daemon 也不可用，但它不是这次 P0 已执行的失败原因；P0 在此前 static gate 就停止。没有修改 Ruff baseline、未通过测试或 accepted states 以获得绿灯。

代码证据最高为 **EXECUTABLE**（相关路径原生 scripted PG 与实际 Provider prompt/正文另列）；不宣告完整 backend **QUALIFIED**、所有题材文学可靠性或 **PRODUCTION_PROVEN**。原本生产事实的 Chapter1–4 保存记录不升级为新系统生产证明。

## Standalone Provider 协议限度

[独占会话审计](owned-transcript-audit.json) 只读取本任务 supervisor 回执中的 thread ID。Writer 会话存在 `custom_tool_call: exec`：工具元数据查询、纯 JavaScript 汉字计量及模型内部草稿扩展。没有发现读取外部文学材料的调用，但这些 custom 调用不属于冻结的唯一允许工具 `model.provider.invoke`，也未完整映射进标准 stdout 的工具分类。因此 stdout parser 的 `unauthorized_tools=[]` **不足以证明 native 工具权限已符合**。这是 standalone benchmark 的协议限度，不在本次叙事链 diff 中扩大修改 Provider。

新正文仍可逐字阅读、计量并做本任务读稿叙事比较（非独立人类验证）；不将这一证据升级为 native Saga、native tool permission、完整预算结算或生产资格。中断调用的部分 token 记录只是观察，不是最终 usage settlement，成本不按零处理。
