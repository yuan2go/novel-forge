from run import ROOT,ENV
import os,json,hashlib,psycopg
from psycopg.conninfo import make_conninfo
os.environ.update(ENV)
from novel_forge.storage.migrations import get_migration_status,run_migrations
base=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'])
with psycopg.connect(make_conninfo(base,dbname='postgres'),autocommit=True) as c:c.execute('CREATE DATABASE nf_dbq_drift_test TEMPLATE nf_dbq_fresh_test')
def catalog(db):
 with psycopg.connect(make_conninfo(base,dbname=db)) as c:
  return {'guard':c.execute("SELECT prosrc FROM pg_proc WHERE oid='authority_planning_result_repair_guard()'::regprocedure").fetchone()[0],
          'index':c.execute("SELECT indexdef FROM pg_indexes WHERE indexname='authority_retained_working_operation_idx'").fetchone()[0]}
expected=catalog('nf_dbq_fresh_test')
url=make_conninfo(base,dbname='nf_dbq_drift_test')
with psycopg.connect(url) as c:
 c.execute("CREATE OR REPLACE FUNCTION authority_planning_result_repair_guard() RETURNS TRIGGER LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END $$")
 c.execute('DROP INDEX authority_retained_working_operation_idx')
 c.execute('CREATE INDEX authority_retained_working_operation_idx ON authority_book_retained_working_continuation(created_at)')
status=get_migration_status(url);replay=run_migrations(url);actual=catalog('nf_dbq_drift_test')
assert status['ok'] and replay['ok'] and status['schema_qualification']=='NOT_CHECKED' and expected!=actual
report={'status':'PASS_NEGATIVE_DETECTION','scope':'EMPTY_TASK_OWNED_DRIFT_CLONE_ONLY','head_id_set_matches':status['ok'],'runner_schema_qualification':status['schema_qualification'],'independent_catalog_qualification':'FAIL','differences':{k:{'canonical_sha256':hashlib.sha256(expected[k].encode()).hexdigest(),'drift_sha256':hashlib.sha256(actual[k].encode()).hexdigest()} for k in expected if expected[k]!=actual[k]},'same_head_rerun_did_not_rewrite_objects':actual==catalog('nf_dbq_drift_test'),'provider_calls':0}
(ROOT/'same-name-drift.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
