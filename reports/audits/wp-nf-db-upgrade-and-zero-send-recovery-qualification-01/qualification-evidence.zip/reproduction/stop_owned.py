from run import *
import psycopg
records=[]
with psycopg.connect(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='postgres') as c:
 directory=c.execute("SELECT current_setting('data_directory')").fetchone()[0]
 assert directory==str(ROOT/'pgdata')
 sessions=c.execute('SELECT datname,backend_type,state FROM pg_stat_activity WHERE pid<>pg_backend_pid() AND backend_type=\'client backend\'').fetchall()
 assert not sessions,sessions
p=subprocess.run([PG+'/pg_ctl','-D',directory,'-m','fast','stop'],env=ENV,capture_output=True,text=True,check=True)
records.append({'resource':'owned_postgresql','data_directory':directory,'active_other_clients':sessions,'stop_stdout':p.stdout,'data_retained':True})
name='nf-dbq-zero-send-20261016'
d=json.loads(subprocess.run(['docker','inspect',name],env=ENV,capture_output=True,text=True,check=True).stdout)[0]
assert d['Config']['Labels']['nf.task']=='dbq-zero-send-20261016'
assert d['Mounts'][0]['Source']==str(ROOT/'private/objects')
subprocess.run(['docker','stop',name],env=ENV,capture_output=True,text=True,check=True)
subprocess.run(['docker','rm',name],env=ENV,capture_output=True,text=True,check=True)
records.append({'resource':'owned_minio','container_id':d['Id'],'label':d['Config']['Labels']['nf.task'],'object_bind_retained':True,'removed':True})
for name in ['nf-dbq-zero-send-20261016','nf-dbq-zero-send-host-20261016']:
 d=json.loads(subprocess.run(['docker','network','inspect',name],env=ENV,capture_output=True,text=True,check=True).stdout)[0]
 assert d['Labels'].get('nf.task')=='dbq-zero-send-20261016'
 assert not d['Containers']
 subprocess.run(['docker','network','rm',name],env=ENV,capture_output=True,text=True,check=True)
 records.append({'resource':'owned_network','name':name,'label':d['Labels']['nf.task'],'removed':True})
assert not (ROOT/'pgdata/postmaster.pid').exists()
(ROOT/'owned-resource-shutdown.json').write_text(json.dumps({'status':'PASS','records':records,'private_data_retained':True,'production_resources_touched':False},indent=2))
print('Owned resources stopped; private data retained')
