from run import *
import psycopg,hashlib
from psycopg.conninfo import make_conninfo
queries={
 'functions':"SELECT p.proname||'('||pg_get_function_identity_arguments(p.oid)||')',pg_get_functiondef(p.oid),pg_get_userbyid(p.proowner),p.proacl::text,p.prosecdef FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.prokind IN ('f','p') ORDER BY 1",
 'triggers':"SELECT c.relname||'.'||t.tgname,pg_get_triggerdef(t.oid),t.tgenabled FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND NOT t.tgisinternal ORDER BY 1",
 'constraints':"SELECT c.relname||'.'||k.conname,pg_get_constraintdef(k.oid),k.convalidated,k.condeferrable FROM pg_constraint k JOIN pg_class c ON c.oid=k.conrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' ORDER BY 1",
 'indexes':"SELECT indexname,indexdef FROM pg_indexes WHERE schemaname='public' ORDER BY 1",
 'tables':"SELECT c.relname,pg_get_userbyid(c.relowner),c.relacl::text,c.relrowsecurity,c.relforcerowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') ORDER BY 1",
 'extensions':"SELECT extname,extversion FROM pg_extension ORDER BY 1",
 'roles':"SELECT rolname,rolsuper,rolinherit,rolcreaterole,rolcreatedb,rolcanlogin,rolreplication,rolbypassrls FROM pg_roles WHERE rolname NOT LIKE 'pg_%' ORDER BY 1"}
all_values={}
for name in ['nf_dbq_historical_test','nf_dbq_samebook_test','nf_dbq_fresh_test','nf_dbq_0218_test']:
 with psycopg.connect(make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname=name)) as c:
  c.execute('SET TRANSACTION READ ONLY')
  values={key:{row[0]:list(row[1:]) for row in c.execute(query).fetchall()} for key,query in queries.items()}
 all_values[name]=values
 (ROOT/'private'/(name+'-catalog-final.json')).write_text(json.dumps(values,indent=2,default=str))
base=all_values['nf_dbq_fresh_test'];report={}
for name,values in all_values.items():
 diff={}
 for kind in values:
  differences={k:{'fresh':base[kind].get(k),'restored':values[kind].get(k)} for k in sorted(set(values[kind])|set(base[kind])) if values[kind].get(k)!=base[kind].get(k)}
  if differences:diff[kind]=differences
 report[name]={'counts':{k:len(v) for k,v in values.items()},'differences':diff}
(ROOT/'catalog-comparison-final.json').write_text(json.dumps(report,indent=2,default=str))
print(json.dumps({k:{'counts':v['counts'],'differing_kinds':{kk:len(vv) for kk,vv in v['differences'].items()}} for k,v in report.items()},indent=2))
