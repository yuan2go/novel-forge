from run import *
import psycopg,hashlib
from psycopg import sql
from psycopg.conninfo import make_conninfo
os.environ.update(ENV)
os.environ['NOVEL_FORGE_MIGRATION_BACKUP_DIR']=str(ROOT/'private'/'runner-backups')
from novel_forge.storage.migrations import runner
ADMIN=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='postgres')
def dsn(name): return make_conninfo(ADMIN,dbname=name)
def freeze(name,label,baseline=None):
 result={}
 with psycopg.connect(dsn(name)) as c:
  c.execute('SET TRANSACTION READ ONLY')
  tables=c.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY 1").fetchall()
  for (table,) in tables:
   columns=[r[0] for r in c.execute("SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s ORDER BY ordinal_position",[table])]
   extra=sorted(set(columns)-set(baseline[table]['columns'])) if baseline and table in baseline else []
   query=sql.SQL("SELECT sha256(convert_to((to_jsonb(t)-%s::text[])::text,'UTF8')) FROM {} t ORDER BY 1").format(sql.Identifier(table))
   digest=hashlib.sha256();count=0
   with c.cursor(name='freeze_'+str(len(result))) as cur:
    cur.execute(query,[extra])
    for row in cur: digest.update(bytes(row[0]));count+=1
   result[table]={'count':count,'sha256':digest.hexdigest(),'columns':columns,'ignored_added_columns':extra}
 (ROOT/'private'/(label+'.json')).write_text(json.dumps(result,indent=2))
 return result
report={}
for name in ['nf_dbq_historical_test','nf_dbq_samebook_test']:
 before=runner.get_migration_status(dsn(name));runner.pending_migrations({r['migration_id'] for r in before['applied']})
 orig=freeze(name,name+'-before')
 (ROOT/'private'/(name+'-migration-before.json')).write_text(json.dumps(before,indent=2))
 try: after=runner.run_migrations(dsn(name))
 except Exception as error:
  report[name]={'status':'FAIL','error_type':type(error).__name__,'error':str(error)}
  (ROOT/'db-matrix-progress.json').write_text(json.dumps(report,indent=2));raise
 end=freeze(name,name+'-after',orig)
 differences={t:{'before':v,'after':end.get(t)} for t,v in orig.items() if t not in end or (v['count'],v['sha256'])!=(end[t]['count'],end[t]['sha256'])}
 report[name]={'status':'PASS','before_applied_head':before['applied_head'],'pending':[m.migration_id for m in runner.pending_migrations({r['migration_id'] for r in before['applied']})], 'after_head':after['applied_head'],'backup':after['backup'],'ledger_prefix_unchanged':all(r in after['applied'] for r in before['applied']),'differences':differences,'added_tables':sorted(set(end)-set(orig)),'replay':runner.run_migrations(dsn(name))['ok']}
 (ROOT/'db-matrix-progress.json').write_text(json.dumps(report,indent=2));print(name,report[name]['status'],list(differences),flush=True)
with psycopg.connect(ADMIN,autocommit=True) as c: c.execute('CREATE DATABASE nf_dbq_fresh_test')
fresh=runner.run_migrations(dsn('nf_dbq_fresh_test'))
report['fresh']={'status':'PASS','head':fresh['applied_head'],'applied_count':len(fresh['applied']),'replay':runner.run_migrations(dsn('nf_dbq_fresh_test'))['ok']}
(ROOT/'db-matrix-progress.json').write_text(json.dumps(report,indent=2))
