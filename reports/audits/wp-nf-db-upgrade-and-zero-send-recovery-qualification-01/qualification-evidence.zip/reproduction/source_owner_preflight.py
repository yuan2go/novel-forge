from run import ROOT,ENV
import os,json,psycopg
from psycopg.conninfo import make_conninfo
os.environ.update(ENV)
from novel_forge.storage.authority_uow import AuthorityUnitOfWork
from novel_forge.modules.story_planning_runtime.runtime_continuation import require_source
url=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='nf_dbq_samebook_test')
with psycopg.connect(url) as c:
 rows=c.execute("""SELECT op.operation_id,op.project_id,op.status,last.status,last.result->>'error_code'
 FROM authority_operation op JOIN authority_story_planning_generation g USING(operation_id)
 JOIN LATERAL(SELECT status,result FROM authority_attempt WHERE operation_id=op.operation_id ORDER BY attempt_number DESC LIMIT 1) last ON true
 WHERE op.status IN ('FAILED_FINAL','FAILED_RETRYABLE') AND (
 last.result->>'error_message' LIKE 'PROTECTED_CONTEXT_BUDGET_EXCEEDED: %'
 OR last.result->>'error_message'='CONTEXT_CAPACITY_EXCEEDED: Complete input leaves no model context for generation') ORDER BY op.created_at""").fetchall()
report=[]
for oid,project,opstatus,astatus,code in rows:
 record={'source_operation_id':oid,'operation_status':opstatus,'attempt_status':astatus,'failure_code':code}
 try:
  with AuthorityUnitOfWork(url) as u:
   source=require_source(u,source_operation_id=oid,project_id=project)
   record.update(status='PASS_SOURCE_OWNER_PREFLIGHT',mode=source['mode'],contract=(source.get('context_revalidation') or {}).get('contract_version'))
 except Exception as e:record.update(status='BLOCKED',code=getattr(e,'code',''),exception=type(e).__name__)
 report.append(record)
(ROOT/'source-owner-preflight.json').write_text(json.dumps({'scope':'ACTUAL_SNAPSHOT_OWNER_CHECK_ROLLED_BACK','real_provider_calls':0,'results':report},indent=2));print(json.dumps(report,indent=2))
