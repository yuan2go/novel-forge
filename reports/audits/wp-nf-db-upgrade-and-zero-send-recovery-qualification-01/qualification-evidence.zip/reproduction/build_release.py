from run import *
import hashlib,shutil,tarfile,importlib
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
artifact_root=ROOT/'artifacts'/sha[:12]
artifact_root.mkdir(exist_ok=True)
bundle=artifact_root/'runtime-resources.tar'
manifest={}
with tarfile.open(bundle,'w') as archive:
 for directory in ['config','skills']:
  for p in sorted((WORK/directory).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:
    relative=str(p.relative_to(WORK));manifest[relative]=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();archive.add(p,arcname=relative,recursive=False)
resources=ROOT/'release-resources'
resources.mkdir(exist_ok=True)
with tarfile.open(bundle) as archive: archive.extractall(resources,filter='data')
(artifact_root/'resource-manifest.json').write_text(json.dumps({'source_sha':sha,'files':manifest,'bundle_sha256':hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest()},indent=2))
run('wheel-build-'+sha[:12],['/opt/homebrew/bin/uv','build','--wheel','--no-build-isolation','--python',PY,'--out-dir',str(artifact_root)])
run('wheel-install-'+sha[:12],['/opt/homebrew/bin/uv','pip','install','--python',PY,'--reinstall','--no-deps',str(next(artifact_root.glob('*.whl')))])

shutil.copyfile(artifact_root/'resource-manifest.json', ROOT/'artifacts/resource-manifest.json')
(ROOT/'active-artifact.txt').write_text(str(artifact_root))
