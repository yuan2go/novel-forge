from run import *
import hashlib
assert not (ROOT/'pgdata/postmaster.pid').exists()
assert hashlib.sha256((ROOT/'pgdata/postgresql.conf').read_bytes()).hexdigest()==json.loads((ROOT/'isolation-restart.json').read_text())['current_config_sha256']
assert not any(p.is_symlink() for p in (ROOT/'pgdata').rglob('*'))
assert not list((ROOT/'pgdata/pg_tblspc').iterdir())
run('pg-start-libpq-final',[PG+'/pg_ctl','-D',str(ROOT/'pgdata'),'-l',str(ROOT/'logs/postgres.log'),'-w','start'])
for name,internal in [('nf-dbq-zero-send-20261016',True),('nf-dbq-zero-send-host-20261016',False)]:
 p=subprocess.run(['docker','network','inspect',name],env=ENV,capture_output=True);assert p.returncode
 run('recreate-'+name,['docker','network','create',*(['--internal'] if internal else []),'--label','nf.task=dbq-zero-send-20261016',name])
p=subprocess.run(['docker','container','inspect','nf-dbq-zero-send-20261016'],env=ENV,capture_output=True);assert p.returncode
run('minio-restart-libpq-final',['docker','run','-d','--name','nf-dbq-zero-send-20261016','--label','nf.task=dbq-zero-send-20261016','--network','nf-dbq-zero-send-host-20261016','--env-file',str(ROOT/'private/minio.env'),'-p','127.0.0.1::9000','--mount','type=bind,source='+str(ROOT/'private/objects')+',target=/data','minio/minio:RELEASE.2024-07-16T23-46-41Z','server','/data'])
run('minio-reconnect-internal-final',['docker','network','connect','nf-dbq-zero-send-20261016','nf-dbq-zero-send-20261016'])
port=subprocess.check_output(['docker','port','nf-dbq-zero-send-20261016','9000'],env=ENV,text=True).strip().rsplit(':',1)[1]
b=json.loads((ROOT/'private/minio.json').read_text());b['endpoint']='127.0.0.1:'+port;(ROOT/'private/minio.json').write_text(json.dumps(b))
(ROOT/'isolation-libpq-final-restart.json').write_text(json.dumps({'status':'PASS','config_sha256':hashlib.sha256((ROOT/'pgdata/postgresql.conf').read_bytes()).hexdigest(),'symlinks':[],'external_tablespaces':[],'socket':ENV['PGHOST'],'workers_started':False,'provider_brake':'1','object_store':'recreated only task-labelled networks/container; same private task bind and task credentials'},indent=2))
