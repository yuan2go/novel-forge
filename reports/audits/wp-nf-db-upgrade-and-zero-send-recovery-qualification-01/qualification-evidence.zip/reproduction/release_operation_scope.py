from run import *
import psycopg,hashlib
from psycopg.conninfo import make_conninfo
config=ROOT/'pgdata/postgresql.conf'
assert hashlib.sha256(config.read_bytes()).hexdigest()==json.loads((ROOT/'isolation-restart.json').read_text())['current_config_sha256']
assert not (ROOT/'pgdata/postmaster.pid').exists()
assert not any(p.is_symlink() for p in (ROOT/'pgdata').rglob('*'))
run('pg-start-final-operation-scope',[PG+'/pg_ctl','-D',str(ROOT/'pgdata'),'-l',str(ROOT/'logs/postgres.log'),'-w','start'])
try:
 rows={}
 for database in ['nf_dbq_original_comparison_test','nf_dbq_samebook_test']:
  with psycopg.connect(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname=database) as c:
   assert c.execute("SELECT current_setting('data_directory')").fetchone()[0]==str(ROOT/'pgdata')
   c.execute('SET TRANSACTION READ ONLY')
   rows[database]={r['operation_id']:r for (r,) in c.execute('SELECT to_jsonb(t) FROM authority_operation t')}
 old,new=rows.values();added=[v for k,v in new.items() if k not in old]
 from collections import Counter
 counts=Counter((r['definition_name'],r['status']) for r in added)
 report={'scope':'READ_ONLY_ORIGINAL_0220_VS_CURRENT_SAME_BOOK_COPY','new_operation_types_and_statuses':[{'definition_name':a,'status':b,'count':n} for (a,b),n in sorted(counts.items())],'new_operations':[{'id_sha256':hashlib.sha256(r['operation_id'].encode()).hexdigest(),'definition_name':r['definition_name'],'command_payload_keys':sorted(r['command_payload']),'payload_keys':sorted(r['command_payload'].get('payload',{}))} for r in added],'old_operations_value_identical':all(new.get(k)==v for k,v in old.items()),'new_real_provider_calls':0}
 (ROOT/'release-operation-scope-initial.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='new_operations'},indent=2))
finally:
 run('pg-stop-final-operation-scope',[PG+'/pg_ctl','-D',str(ROOT/'pgdata'),'-m','fast','-w','stop'])
