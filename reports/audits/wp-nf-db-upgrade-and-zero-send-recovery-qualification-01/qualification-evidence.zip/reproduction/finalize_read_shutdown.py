from run import *
import hashlib,psycopg,shutil
p=ROOT/'native-read-report.json';d=json.loads(p.read_text());old=ROOT/'private/same-book-installed.md'
assert d['status']=='PASS'
assert hashlib.file_digest(old.open('rb'),'sha256').hexdigest()==d['export_sha256']
d.update(matches_prior_export_sha256=True,prior_export_preserved=True);p.write_text(json.dumps(d,indent=2))
with psycopg.connect(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='postgres') as c:
 assert c.execute("SELECT current_setting('data_directory')").fetchone()[0]==str(ROOT/'pgdata')
 assert not c.execute("SELECT pid FROM pg_stat_activity WHERE backend_type='client backend' AND pid<>pg_backend_pid()").fetchall()
run('pg-stop-after-final-export',[PG+'/pg_ctl','-D',str(ROOT/'pgdata'),'-m','fast','-w','stop'])
shutil.copy2(ROOT/'owned-resource-shutdown.json',ROOT/'owned-resource-shutdown-before-final-read.json')
s=json.loads((ROOT/'owned-resource-shutdown.json').read_text());s['final_read_only_restart']={'isolation_evidence':'isolation-read-export-restart.json','reason':'versioned installed read/export verification','stopped_again':not (ROOT/'pgdata/postmaster.pid').exists(),'workers_started':False,'real_provider_calls':0};(ROOT/'owned-resource-shutdown.json').write_text(json.dumps(s,indent=2))
p=ROOT/'manual-native-command-index.json';d=json.loads(p.read_text());d['harness_sha256']=hashlib.file_digest((ROOT/'native_installed.py').open('rb'),'sha256').hexdigest()
for row in d['commands']:
 if row['action']=='read':row.update(status='PASS',report_sha256=hashlib.file_digest((ROOT/'native-read-report.json').open('rb'),'sha256').hexdigest(),record_semantics='Actual versioned rerun is in commands.jsonl as native-read-versioned; earlier existing-file refusal retained separately')
p.write_text(json.dumps(d,indent=2))
p=ROOT/'prepare_delivery.py';s=p.read_text().replace("'final-resource-check.json','owned-resource-shutdown.json'","'final-resource-check.json','isolation-read-export-restart.json','native-read-existing-file-failure-report.json','owned-resource-shutdown.json'");p.write_text(s)
print('PASS: fresh export exact; hashes retained; owned PostgreSQL stopped again')
