from run import *
import psycopg
from psycopg.conninfo import make_conninfo
from novel_forge.storage.migrations import run_migrations,get_migration_status
from invariants import freeze,dsn
os.environ.update(ENV)
report={}
for name in ['nf_dbq_historical_test','nf_dbq_samebook_test','nf_dbq_fresh_test','nf_dbq_0218_test']:
 before=get_migration_status(dsn(name));after=run_migrations(dsn(name))
 replay=run_migrations(dsn(name));assert replay==after
 orig_path=ROOT/'private'/(name+'-before.json')
 if orig_path.exists():
  orig=json.loads(orig_path.read_text());end=freeze(name,name+'-final',orig)
  differences={t:{'before_count':v['count'],'before_sha256':v['sha256'],'after_count':end.get(t,{}).get('count'),'after_sha256':end.get(t,{}).get('sha256')} for t,v in orig.items() if t not in end or (v['count'],v['sha256'])!=(end[t]['count'],end[t]['sha256'])}
 else:differences={}
 report[name]={'status':'PASS','before_head':before['applied_head'],'target_head':after['target_head'],'applied_head':after['applied_head'],'new_ids':before['missing'],'ledger_prefix_and_times_preserved':all(v in after['applied'] for v in before['applied']),'replay_identical':True,'table_differences_from_original_snapshot':differences}
 (ROOT/'installed-db-upgrade.json').write_text(json.dumps(report,indent=2));print(name,'PASS',list(differences),flush=True)
