from run import ROOT,ENV,WORK
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,os,sys,traceback,uuid
import psycopg
from psycopg.conninfo import make_conninfo
source=Path('<PRIOR_PRIVATE_EVIDENCE>/wp-nf-working-consumption-repair-01')
v=json.loads((source/'runtime.private.json').read_text());m=json.loads((source/'same-book-manuscript.private.json').read_text())
sha=json.loads((ROOT/'artifacts/resource-manifest.json').read_text())['source_sha'];build='db-upgrade-zero-send:'+sha[:12]
values=dict(ENV);values['PYTHONPATH']=str(ROOT/'guard')
for key,value in v.items():
 if key.startswith('NOVEL_FORGE_') and not any(part in key for part in ('SECRET','PASSWORD','ACCESS_KEY','API_KEY')):
  values[key]=value
for key in ('NOVEL_FORGE_LOCAL_OPERATOR_PRINCIPAL_ID','NOVEL_FORGE_NARRATIVE_EVALUATOR_PRINCIPAL_ID'):
 values[key]=v.get(key,'')
values.update(NOVEL_FORGE_DATABASE_URL=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='nf_dbq_samebook_test'),NOVEL_FORGE_ROOT=str(ROOT/'release-resources'),NOVEL_FORGE_ENVIRONMENT='production',NOVEL_FORGE_COMMIT_SHA=sha,NOVEL_FORGE_APPLICATION_BUILD_ID=build,NOVEL_FORGE_AUTHORITY_PROJECT_SCOPE=m['project_id'],NOVEL_FORGE_AUTHORITY_OBJECT_STORE_BACKEND='local',NOVEL_FORGE_AUTHORITY_OBJECT_STORE_ROOT=str(ROOT/'private/objects'),NOVEL_FORGE_CODEX_EXECUTION_ROOT=str(ROOT/'private/executions'),NOVEL_FORGE_CODEX_WORKSPACE=str(ROOT/'private/codex-workspace'),NOVEL_FORGE_CODEX_HOME=str(ROOT/'empty-home'),NOVEL_FORGE_NO_MODEL_DISPATCH='1')
object_config=json.loads((ROOT/'private/minio.json').read_text())
values.update(NOVEL_FORGE_AUTHORITY_OBJECT_STORE_BACKEND='minio',NOVEL_FORGE_MINIO_ENDPOINT=object_config['endpoint'],NOVEL_FORGE_MINIO_ACCESS_KEY=object_config['access'],NOVEL_FORGE_MINIO_SECRET_KEY=object_config['secret'],NOVEL_FORGE_MINIO_SECURE='false')
os.environ.clear();os.environ.update(values)
blocked_roots=[row['source'] for row in json.loads((ROOT/'private/assets-inventory.json').read_text()).values()]+[str(WORK)]
def audit(event,args):
 if event=='subprocess.Popen':
  program=str(args[0]).lower()
  if any(token in program for token in ('codex','claude','gemini','curl','wget')) and not (len(args[1])==2 and args[1][1]=='--version'):
   raise RuntimeError('TASK_REAL_PROVIDER_PROCESS_DISABLED')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=str(Path(os.fsdecode(args[0])).absolute())
  if any(p==r or p.startswith(r+'/') for r in blocked_roots):raise RuntimeError('TASK_ORIGINAL_RUNTIME_FILE_ACCESS_DISABLED')
sys.addaudithook(audit)
from novel_forge.infrastructure.settings import IndustrialSettings
from novel_forge.cli.authority import _authority_parser
from novel_forge.cli.manuscript import run_manuscript_command
from novel_forge.api.authority_dependencies import build_trusted_principal_resolver
from novel_forge.modules.book_authority.creation_runtime import creation_runtime_environment
from novel_forge.storage.authority_uow import AuthorityUnitOfWork
import novel_forge.storage.migrations.runner as migration
assert not Path(migration.__file__).is_relative_to(WORK)
settings=IndustrialSettings.from_env(values,root=ROOT/'release-resources')
with AuthorityUnitOfWork(settings.database_url) as u:
 u.cursor.execute('SELECT workspace_id,book_id,current_chapter,accepted_through_chapter,version FROM authority_book_production WHERE book_run_id=%s',[m['book_run_id']]);book=u.cursor.fetchone()
 m['workspace_id']=book[0];m['book_id']=book[1]
args_base=['--project-id',m['project_id'],'--book-run-id',m['book_run_id']]
action=sys.argv[1]
report={'action':action,'source_sha':sha,'scope':'INSTALLED_ARTIFACT_ISOLATED_ACTUAL_SNAPSHOT','module_origin':migration.__file__,'real_provider_calls':0}
try:
 if action=='read':
  read_output=ROOT/'private'/('native-read-'+sha[:12]+'-'+uuid.uuid4().hex);read_output.mkdir(mode=0o700)
  for operation in ['read','export']:
   extra=['--output',str(read_output/'same-book-installed.md')] if operation=='export' else []
   result=run_manuscript_command(settings,_authority_parser().parse_args(['authority-manuscript',operation,*args_base,*extra]))
   (read_output/('samebook-'+operation+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str))
   if operation=='read':
    report['units']=[{k:u.get(k) for k in ('chapter','asset_version_id','content_hash','text_hash','selection_status')} for u in result.get('units',[])]
  text=read_output/'same-book-installed.md';report['private_export_path']=str(text);report['export_sha256']=hashlib.sha256(text.read_bytes()).hexdigest();report['status']='PASS'
 elif action.startswith('reader-check'):
  from novel_forge.modules.book_authority.reader_pack import ensure_creation_reader_pack
  principal=build_trusted_principal_resolver().resolve_api_principal()
  env=creation_runtime_environment(m['project_id'],dict(os.environ));os.environ.update(env)
  report['reader']=ensure_creation_reader_pack(settings,SimpleNamespace(project_id=m['project_id'],workspace_id=m['workspace_id'],book_id=m['book_id'],repository_root=settings.root),principal=principal,build_id=build,sha=sha,pack_id=env['NOVEL_FORGE_READER_OUTCOME_CAPABILITY_PACK_ID']);report['status']='PASS'
 elif action=='align':
  from novel_forge.modules.book_authority.reader_pack import ensure_creation_reader_pack
  from novel_forge.modules.capability_packs.longform_profiles import build_reader_outcome_pack_profile
  from novel_forge.modules.capability_packs.validation_deployment import register_validation_runtime_definitions,install_longform_validation_pack
  from novel_forge.modules.command_kernel.dispatch_control import dispatch_control_status,change_dispatch_control
  principal=build_trusted_principal_resolver().resolve_api_principal()
  control=dispatch_control_status(settings.database_url,project_id=m['project_id'])
  if control['state']!='PAUSED':
   change_dispatch_control(settings.database_url,project_id=m['project_id'],principal=principal,state='PAUSED',expected_version=control['version'],idempotency_key='dbq-copy-pause:'+sha,reason='Isolated zero-send recovery qualification; dispatch stays disabled',release_identity={'application_build_id':build,'commit_sha':sha})
  hashes=register_validation_runtime_definitions(settings.database_url,application_build_id=build,commit_sha=sha)
  env=creation_runtime_environment(m['project_id'],dict(os.environ));os.environ.update(env)
  profile=build_reader_outcome_pack_profile(settings.root,operation_definition_hash=hashes['reader_proxy_current'],pack_id=env['NOVEL_FORGE_READER_OUTCOME_CAPABILITY_PACK_ID'],coordinated_contract=True)
  with AuthorityUnitOfWork(settings.database_url) as u:
   u.cursor.execute('SELECT a.activation_version,d.pack_version FROM authority_capability_pack_activation a JOIN authority_capability_pack_deployment d ON d.deployment_id=a.active_deployment_id WHERE a.project_id=%s AND a.book_id=%s AND a.pack_id=%s',[m['project_id'],m['book_id'],profile.pack_id]);active=u.cursor.fetchone()
  result=install_longform_validation_pack(settings.database_url,profile=profile,pack_version='1.6.'+str(100000+int(sha[:8],16)),agent_generation=1,expected_activation_version=active[0] if active else 0,project_id=m['project_id'],workspace_id=m['workspace_id'],book_id=m['book_id'],application_build_id=build,commit_sha=sha,compiler=principal,approver=principal,agent_admin=principal,agent_domain='reader_outcome',agent_scope_type='BOOK',runtime_environment=settings.environment)
  (ROOT/'private/reader-alignment.json').write_text(json.dumps(result,indent=2,default=str))
  report['reader']=ensure_creation_reader_pack(settings,SimpleNamespace(project_id=m['project_id'],workspace_id=m['workspace_id'],book_id=m['book_id'],repository_root=settings.root),principal=principal,build_id=build,sha=sha,pack_id=profile.pack_id);report['status']='PASS'
 else:
  result=run_manuscript_command(settings,_authority_parser().parse_args(['authority-manuscript','continue',*args_base,'--stop-after-chapter','5','--foreground','--reason','Isolated zero-send preflight only']))
  (ROOT/'private'/('native-'+action+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str));report['status']=result.get('status');report['failure']=result.get('failure')
except Exception as e:
 (ROOT/'private'/('native-'+action+'-error.txt')).write_text(traceback.format_exc())
 report.update(status='BLOCKED',code=getattr(e,'code',''),exception=type(e).__name__,message=str(e)[:300])
(ROOT/('native-'+action+'-report.json')).write_text(json.dumps(report,indent=2,default=str));print(json.dumps(report,indent=2,default=str))
