from run import *
import psycopg,hashlib
from psycopg.conninfo import make_conninfo
candidates=[]
for p in (ROOT/'private/runner-backups').glob('*.json'):
 v=json.loads(p.read_text())
 if v.get('database')=='nf_dbq_historical_test' and v['applied'][-1]['migration_id']=='20261014_0211_world_input_delivery_recovery':candidates.append((p,v))
p,metadata=sorted(candidates)[0];archive=Path(metadata['path'])
assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()==metadata['sha256']
admin=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='postgres')
with psycopg.connect(admin,autocommit=True) as c:c.execute('CREATE DATABASE nf_dbq_runner_restore_test OWNER longform_owner')
run('runner-backup-actual-restore',[PG+'/pg_restore','--exit-on-error','--no-tablespaces','--dbname='+make_conninfo(admin,dbname='nf_dbq_runner_restore_test'),str(archive)])
from invariants import freeze
expected=json.loads((ROOT/'private/nf_dbq_historical_test-before.json').read_text())
actual=freeze('nf_dbq_runner_restore_test','runner-backup-restored')
assert actual==expected
report={'status':'PASS','backup_sha256':metadata['sha256'],'backup_manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'restored_database':'nf_dbq_runner_restore_test','original_table_count':len(expected),'all_rows_and_columns_identical':True,'source_backup_metadata_restore_qualification':'NOT_RUN retained unchanged; this separate validation appends restore proof','provider_calls':0}
(ROOT/'runner-backup-restore.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
