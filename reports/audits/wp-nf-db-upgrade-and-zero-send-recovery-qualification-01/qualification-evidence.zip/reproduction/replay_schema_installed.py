from pathlib import Path
from types import SimpleNamespace
import json
import os
import psycopg
from novel_forge.modules.chapter_authority.execution_gateway import PostgresProductionExecutionPayloadResolver
from novel_forge.modules.production_execution import ExecutionRequest
from novel_forge.modules.production_execution.postgres import PostgresExecutionContractSource

from run import ROOT,ENV,WORK
from psycopg.conninfo import make_conninfo
base=ROOT
os.environ.clear();os.environ.update(ENV)
manifest=json.loads(Path('<PRIOR_PRIVATE_EVIDENCE>/wp-nf-working-consumption-repair-01/same-book-manuscript.private.json').read_text())
database=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='nf_dbq_samebook_test')
resolver = PostgresProductionExecutionPayloadResolver(database)
contracts = PostgresExecutionContractSource(database, project_id=manifest['project_id'])
report = {'scope': 'RECONSTRUCTED_READ_ONLY_EXISTING_REQUESTS', 'provider_calls': 0, 'calls': []}
with psycopg.connect(database, options='-c default_transaction_read_only=on') as connection:
    rows = connection.execute("SELECT v.asset_version_id,v.content FROM authority_asset a JOIN authority_asset_version v USING(asset_id) WHERE a.project_id=%s AND a.asset_type='model_call_log' ORDER BY v.created_at", [manifest['project_id']]).fetchall()
    for version, log in rows:
        execution = log.get('provider_evidence', log).get('production_execution', {})
        if not execution.get('execution_request'):
            continue
        request = ExecutionRequest.from_dict(execution['execution_request'])
        route = contracts.route_snapshot(request.route_snapshot_id)
        result = resolver.resolve(request, SimpleNamespace(route_snapshot=route))
        metadata = connection.execute('SELECT request_payload FROM authority_external_effect WHERE external_effect_id=%s AND operation_id=%s', [request.external_effect_id, request.operation_id]).fetchone()[0]['_production_execution']['capability_runtime']
        frozen = connection.execute('SELECT content FROM authority_asset_version WHERE asset_version_id=%s', [metadata['provider_admission_asset_version_id']]).fetchone()[0]['contract']
        expected = frozen['prompt_materialization']['fully_rendered_prompt_hash']
        actual = result.capability_evidence['fully_rendered_prompt_hash']
        assert actual == expected, request.execution_id
        assert result.capability_evidence['provider_request_envelope_hash']==metadata['provider_request_envelope_hash'], request.execution_id
        assert result.capability_evidence['output_schema_hash']==frozen['prompt_materialization']['output_schema_hash'], request.execution_id
        report['calls'].append({'stage': request.stage, 'execution_id': request.execution_id,
            'model_call_version': version, 'operation_id': request.operation_id,
            'external_effect_id': request.external_effect_id, 'prompt_hash': actual,
            'provider_envelope_hash': result.capability_evidence['provider_request_envelope_hash'],
            'prompt_bytes': len(result.input_text.encode()), 'exact_match': True, 'envelope_exact_match': True, 'output_schema_exact_match': True})
report['matching_requests'] = len(report['calls'])
(base / 'input-replay-schema-verified.json').write_text(json.dumps(report, indent=2))
print(json.dumps({'matching_requests': report['matching_requests'], 'provider_calls': 0}))
