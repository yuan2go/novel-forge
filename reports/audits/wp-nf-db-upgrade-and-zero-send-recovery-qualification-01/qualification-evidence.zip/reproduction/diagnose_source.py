from run import ROOT,ENV
import psycopg,json
from psycopg.conninfo import make_conninfo
from novel_forge.modules.mkaos_authority.craft_selection import _hash
from novel_forge.storage.authority_uow import AuthorityUnitOfWork
from novel_forge.modules.story_planning_runtime.runtime_continuation import require_source
url=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='nf_dbq_samebook_test');oid='dd0d92b0-585a-444e-ac92-37b24d9acd59'
with psycopg.connect(url) as c:
 project=c.execute('SELECT project_id FROM authority_operation WHERE operation_id=%s',[oid]).fetchone()[0]
 context=c.execute("SELECT v.content FROM authority_operation_output_asset o JOIN authority_asset_version v USING(asset_version_id) WHERE operation_id=%s AND output_key='planning.context_bundle'",[oid]).fetchone()[0]
 s=context.get('narrative_intelligence',{});need=s.get('need',{})
 report={'context_markers':{k:v for k,v in context.items() if 'projection_version' in k or 'accounting_version' in k},'selection_schema':s.get('schema_version'),'root_policy_keys':sorted(context.get('knowledge_access_policy',{})),'selection_policy':{k:v for k,v in s.get('knowledge_access_policy',{}).items() if k in ('mode','usage_scope','craft_candidate_review_version')},'selected_count':len(s.get('selected',[])),'need_hash_matches':need.get('need_digest')==_hash({k:v for k,v in need.items() if k!='need_digest'}),'selection_hash_matches':s.get('selection_digest')==_hash({k:v for k,v in s.items() if k!='selection_digest'}),'selection_projection_keys':[k for k in s if 'receipt' in k or 'projection' in k]}
try:
 with AuthorityUnitOfWork(url) as u:require_source(u,source_operation_id=oid,project_id=project)
except Exception as e:report['error']={'code':getattr(e,'code',''),'message':str(e)}
(ROOT/'source-owner-diagnosis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
