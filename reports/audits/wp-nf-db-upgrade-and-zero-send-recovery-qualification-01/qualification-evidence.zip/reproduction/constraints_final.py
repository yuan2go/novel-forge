from run import *
from pglast import parse_sql
import json
comparison=json.loads((ROOT/'catalog-comparison-final.json').read_text())
def normalize(value):
 if isinstance(value,(tuple,list)):return [normalize(v) for v in value]
 if isinstance(value,dict):
  v={k:normalize(x) for k,x in value.items() if k not in ('location','stmt_location','stmt_len','list_start','list_end','rexpr_list_start','rexpr_list_end')}
  if v.get('@')=='BoolExpr':
   args=[]
   for a in v['args']:
    if isinstance(a,dict) and a.get('@')=='BoolExpr' and a.get('boolop')==v.get('boolop'):args.extend(a['args'])
    else:args.append(a)
   v['args']=args
  return v
 return value
report={}
for db,v in comparison.items():
 report[db]={}
 for key,row in v['differences'].get('constraints',{}).items():
  ast=[]
  for expression in (row['fresh'][0],row['restored'][0]):
   ast.append(normalize(parse_sql('SELECT '+expression.removeprefix('CHECK (')[:-1])[0]()))
  report[db][key]={'associative_boolean_ast_equal':ast[0]==ast[1]}
  if ast[0]!=ast[1]:
   (ROOT/"private/ast-differences.json").write_text(json.dumps(ast,indent=2))
(ROOT/'constraint-equivalence-final.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
