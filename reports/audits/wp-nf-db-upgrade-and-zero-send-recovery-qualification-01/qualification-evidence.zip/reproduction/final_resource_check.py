from run import *
import hashlib,psycopg
from minio import Minio
from urllib.request import build_opener, ProxyHandler
initial=json.loads((ROOT/'private/assets-inventory.json').read_text());files={}
for key,row in initial.items():
 source=Path(row['source']);copy=Path(row['copy']);old=row['manifest']
 now={str(p.relative_to(source)):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in sorted(source.rglob('*')) if p.is_file()}
 copied={name:hashlib.file_digest((copy/name).open('rb'),'sha256').hexdigest() for name in old}
 assert all(now.get(k)==v and copied.get(k)==v for k,v in old.items())
 files[key]={'original_files':len(old),'original_hashes_unchanged':True,'copy_hashes_unchanged':True,'new_source_files':len(set(now)-set(old)),'manifest_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest()}
for row in json.loads((ROOT/'snapshot-sources.json').read_text()):assert hashlib.file_digest(Path(row['path']).open('rb'),'sha256').hexdigest()==row['sha256']
with psycopg.connect(host=ENV['PGHOST'],port=ENV['PGPORT'],dbname='nf_dbq_samebook_test') as c:
 state=c.execute("SELECT current_setting('data_directory'),current_setting('listen_addresses'),current_setting('archive_mode'),current_setting('restore_command'),current_setting('max_locks_per_transaction'),(SELECT system_identifier::text FROM pg_control_system())").fetchone()
 assert str(ROOT/'pgdata')==state[0] and state[1:4]==('','off','')
 from novel_forge.storage.migrations import get_migration_status
 status=get_migration_status('host='+ENV['PGHOST']+' port='+ENV['PGPORT']+' dbname=nf_dbq_samebook_test');assert status['ok']
 d=c.execute('SELECT state,version FROM authority_runtime_dispatch_control').fetchall()
blob=json.loads((ROOT/'private/minio.json').read_text());health=build_opener(ProxyHandler({})).open('http://'+blob['endpoint']+'/minio/health/ready',timeout=5).status
client=Minio(blob['endpoint'],access_key=blob['access'],secret_key=blob['secret'],secure=False)
buckets={b.name:sum(1 for _ in client.list_objects(b.name,recursive=True)) for b in client.list_buckets()}
report={'status':'PASS','file_integrity':files,'source_dump_hashes_unchanged':True,'pg_runtime_identity':state,'head':status['target_head'],'dispatch_controls':d,'minio':{'ready_http':health,'buckets_and_counts':buckets,'source_blob_rows':0,'independent_bind_root':str(ROOT/'private/objects')},'real_provider_calls':0}
(ROOT/'final-resource-check.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='file_integrity'},indent=2))
