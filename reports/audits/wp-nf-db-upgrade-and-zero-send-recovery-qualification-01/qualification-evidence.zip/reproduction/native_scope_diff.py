from run import ROOT,ENV
import psycopg,json
from psycopg.conninfo import make_conninfo
from collections import Counter
m=json.loads(open('<PRIOR_PRIVATE_EVIDENCE>/wp-nf-working-consumption-repair-01/same-book-manuscript.private.json').read())
pack='reader_outcome_pack.creative.a3f0b3a47c54fe9ac0bc2e6c'
base=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'])
allowed_types={'capability_pack_manifest','capability_pack_artifact_catalog','capability_pack_compilation_report','capability_materialization_manifest','capability_pack_deployment_manifest','capability_pack_compilation_manifest','capability_pack_deployment','capability_pack_binding_set','compiled_capability_pack'}
report={'violations':[]}
with psycopg.connect(make_conninfo(base,dbname='nf_dbq_original_comparison_test')) as a,psycopg.connect(make_conninfo(base,dbname='nf_dbq_samebook_test')) as b:
 old=dict(a.execute('SELECT asset_id,asset_type FROM authority_asset'));new=dict(b.execute('SELECT asset_id,asset_type FROM authority_asset'))
 added=Counter(value for key,value in new.items() if key not in old);report['new_asset_types']=dict(added)
 if set(added)-allowed_types:report['violations'].append({'new_asset_types_outside_pack_release':sorted(set(added)-allowed_types)})
 for table in ['authority_capability_pack_activation','authority_capability_pack_deployment']:
  rowsa={r['activation_key' if table.endswith('activation') else 'deployment_id']:r for (r,) in a.execute('SELECT to_jsonb(t) FROM '+table+' t')}
  rowsb={r['activation_key' if table.endswith('activation') else 'deployment_id']:r for (r,) in b.execute('SELECT to_jsonb(t) FROM '+table+' t')}
  for key,row in rowsa.items():
   if row!=rowsb[key] and (row.get('pack_id')!=pack or row.get('project_id')!=m['project_id'] or row.get('book_id')!=m['book_id']):report['violations'].append({'release_mutation_outside_exact_reader_scope':table})
 old_versions={x[0] for x in a.execute('SELECT asset_version_id FROM authority_asset_version')}
 version_types=Counter(kind for identity,kind in b.execute('SELECT v.asset_version_id,x.asset_type FROM authority_asset_version v JOIN authority_asset x USING(asset_id)') if identity not in old_versions)
 report['new_asset_version_types']=dict(version_types)
 if set(version_types)-allowed_types:report['violations'].append({'new_versions_outside_pack_release':sorted(set(version_types)-allowed_types)})
 report['same_book_effects']={}
 for c,label in [(a,'before'),(b,'after')]:
  report['same_book_effects'][label]=c.execute("SELECT status,count(*) FROM authority_external_effect WHERE project_id=%s GROUP BY status ORDER BY status",[m['project_id']]).fetchall()
 assert report['same_book_effects']['before']==report['same_book_effects']['after']
report['status']='PASS' if not report['violations'] else 'FAIL'
(ROOT/'native-scope-diff-final.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
