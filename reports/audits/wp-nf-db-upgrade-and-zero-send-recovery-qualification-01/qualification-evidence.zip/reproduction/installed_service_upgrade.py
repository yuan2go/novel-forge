from run import *
import psycopg,hashlib
from psycopg import sql
from psycopg.conninfo import make_conninfo
from invariants import freeze,dsn
from novel_forge.storage.migrations import runner
assert not Path(runner.__file__).is_relative_to(WORK)
name='nf_dbq_service_history_test';restored='nf_dbq_service_backup_restore_test'
with psycopg.connect(dsn('postgres'),autocommit=True) as c:
 for db in [name,restored]:
  assert not c.execute('SELECT 1 FROM pg_database WHERE datname=%s',[db]).fetchone()
  c.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(db)))
run('service-history-source-restore',[PG+'/pg_restore','--exit-on-error','--no-tablespaces','--dbname='+dsn(name),str(ROOT/'private/nf_dbq_historical_test.dump')])
before=freeze(name,'service-history-before')
service=ROOT/'private/libpq-service.conf';service.write_text('[dbq_private]\nhost='+ENV['PGHOST']+'\nport='+ENV['PGPORT']+'\nuser=yuan\ndbname='+name+'\n');service.chmod(0o600)
os.environ.update(ENV)
for key in ('PGHOST','PGPORT','PGUSER','PGDATABASE'):os.environ.pop(key,None)
os.environ.update(PGSERVICEFILE=str(service),PGSYSCONFDIR=str(ROOT/'empty-home'))
backup_root=ROOT/'private/runner-backups';prior=set(backup_root.glob('*.json'))
status_before=runner.get_migration_status('service=dbq_private');status=runner.run_migrations('service=dbq_private');assert runner.run_migrations('service=dbq_private')==status
meta_files=set(backup_root.glob('*.json'))-prior;assert len(meta_files)==1
meta=json.loads(next(iter(meta_files)).read_text());assert meta['database']==name and meta['archive_readable']
after=freeze(name,'service-history-after',before)
differences={t:{'before':v,'after':after.get(t)} for t,v in before.items() if t!='nf_schema_migrations' and (v['count'],v['sha256'])!=(after[t]['count'],after[t]['sha256'])}
assert not differences,differences
run('service-backup-actual-restore',[PG+'/pg_restore','--exit-on-error','--no-tablespaces','--dbname='+dsn(restored),meta['path']])
back=freeze(restored,'service-backup-actual-restored',before)
assert all((v['count'],v['sha256'],v['columns'])==(back[t]['count'],back[t]['sha256'],back[t]['columns']) for t,v in before.items())
report={'status':'PASS','tested_code_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),'installed_runner':runner.__file__,'connection_contract':'Only service= alias supplies host/port/user/database; explicit private HOME/PGSERVICEFILE/PGSYSCONFDIR survive child environment; no password','service_config_sha256':hashlib.sha256(service.read_bytes()).hexdigest(),'source_snapshot_sha256':hashlib.file_digest((ROOT/'private/nf_dbq_historical_test.dump').open('rb'),'sha256').hexdigest(),'source_head':status_before['applied_head'],'pending_ids':status_before['missing'],'target_head':status['target_head'],'head_replay_identical':True,'original_business_table_hashes_unchanged':True,'original_table_count':len(before),'backup':meta,'actual_backup_restore_all_original_columns_rows_hashes_equal':True,'restored_backup_head':runner.get_migration_status(dsn(restored))['applied_head'],'new_real_provider_calls':0}
(ROOT/'installed-service-upgrade.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='backup'},indent=2))
