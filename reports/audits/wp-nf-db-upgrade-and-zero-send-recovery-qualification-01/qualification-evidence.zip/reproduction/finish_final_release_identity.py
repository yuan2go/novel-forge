from run import *
import hashlib
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
active=ROOT/'artifacts'/sha[:12];wheel=next(active.glob('*.whl'));bundle=active/'runtime-resources.tar'
old=json.loads((ROOT/'artifact-identity.json').read_text())
deps=sorted(tuple(x) for x in json.loads((ROOT/'dependencies-final-installed.json').read_text()))
assert deps==sorted(tuple(x) for x in old['dependencies'])
old.update(code_sha=sha,wheel_sha256=hashlib.file_digest(wheel.open('rb'),'sha256').hexdigest(),wheel_bytes=wheel.stat().st_size,resource_bundle_sha256=hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest())
(ROOT/'artifact-identity.json').write_text(json.dumps(old,indent=2))
read=json.loads((ROOT/'native-read-report.json').read_text());assert hashlib.file_digest((ROOT/'private/same-book-installed.md').open('rb'),'sha256').hexdigest()==read['export_sha256'];read.update(matches_prior_export_sha256=True,prior_export_preserved=True);(ROOT/'native-read-report.json').write_text(json.dumps(read,indent=2))
print('Final installed release, normal Reader binding, strict frozen request replay and private export PASS; actual continuation BLOCKED as expected')
