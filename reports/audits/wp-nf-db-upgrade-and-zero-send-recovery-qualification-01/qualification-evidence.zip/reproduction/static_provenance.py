from run import *
import hashlib,re,importlib
from novel_forge.storage.migrations import MIGRATIONS
from novel_forge.storage.migrations.versions import v20261015_0220_chapter_prior_audit_convergence as head
from novel_forge.storage.migrations.versions import v20261015_0217_craft_context_convergence as combined
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only','c9987b86','--','src/novel_forge/storage/migrations'],cwd=WORK,text=True).splitlines()
changed=[];checked=[]
for rel in tracked:
 if rel.endswith('.py') and ('/versions/' in rel or '/historical/' in rel) and not rel.endswith('__init__.py'):
  prior=subprocess.check_output(['git','show','c9987b86:'+rel],cwd=WORK)
  actual=(WORK/rel).read_bytes();assert prior==actual,rel
  checked.append({'path':rel,'sha256':hashlib.sha256(actual).hexdigest()})
names=re.findall(r'AND NOT (authority_\w+_continuation_permitted)\(',head.GUARD_STATEMENT)
assert len(names)==len(set(names))==11
assert 'world-host-revalidation.v4' in combined.CAPACITY_STATEMENT
assert 'world-source-inheritance.v1' in combined.CAPACITY_STATEMENT
report={'status':'PASS','main_sha':'c9987b86f761de755e5d53191999793415304e61','tested_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),'unchanged_published_python_modules':checked,'dispatch_predicates':names,'combined_capacity_sha256':hashlib.sha256(combined.CAPACITY_STATEMENT.encode()).hexdigest()}
(ROOT/'static-provenance.json').write_text(json.dumps(report,indent=2));print(json.dumps({'unchanged_modules':len(checked),'public_predicates':names},indent=2))
