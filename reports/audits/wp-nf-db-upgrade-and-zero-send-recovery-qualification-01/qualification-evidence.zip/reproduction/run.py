from pathlib import Path
import os, subprocess, json, sys, time
ROOT=Path(__file__).resolve().parent
WORK=Path('<ISOLATED_WORKTREE>')
PY=str(ROOT/'venv/bin/python')
PG=str(ROOT/'pg-runtime/bin')
ENV={'HOME':str(ROOT/'empty-home'),'PATH':PG+':'+str(Path(PY).parent)+':/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin','TMPDIR':str(ROOT/'tmp'),'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','NOVEL_FORGE_NO_MODEL_DISPATCH':'1','PYTHONPATH':str(ROOT/'guard')+':'+str(WORK/'src'),'PYTHONDONTWRITEBYTECODE':'1','NOVEL_FORGE_ENVIRONMENT':'test','NOVEL_FORGE_STORAGE_AUTHORITY':'postgresql','PGHOST':'/private/tmp/nf-dbq-20261016-93cd','PGPORT':'55741','PGUSER':'yuan','PGDATABASE':'postgres'}
ENV['DOCKER_CONFIG']=str(ROOT/'docker-config')
ENV['DOCKER_HOST']='unix:///Users/yuan/.docker/run/docker.sock'
ENV['NOVEL_FORGE_DATABASE_URL']='<ISOLATED_DATABASE_DSN>'
ENV['NOVEL_FORGE_MIGRATION_BACKUP_DIR']=str(ROOT/'private/runner-backups')
for p in ['empty-home','tmp','guard']: (ROOT/p).mkdir(exist_ok=True)
def run(name,args,*,cwd=WORK,extra=None,check=True):
 env=ENV| (extra or {})
 start=time.time()
 with (ROOT/'logs'/f'{name}.log').open('w') as out:
  p=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 record={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'start':start,'duration':time.time()-start,'returncode':p.returncode,'no_model_dispatch':env['NOVEL_FORGE_NO_MODEL_DISPATCH'],'home':env['HOME']}
 with (ROOT/'commands.jsonl').open('a') as out: out.write(json.dumps(record)+'\n')
 print(json.dumps(record),flush=True)
 if check and p.returncode: raise RuntimeError(f'{name} failed; see log')
 return p.returncode
if __name__=='__main__': run(sys.argv[1],sys.argv[2:])
