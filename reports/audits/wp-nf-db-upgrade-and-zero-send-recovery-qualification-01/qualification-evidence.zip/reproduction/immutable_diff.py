from run import ROOT,ENV
import psycopg,json,hashlib
from psycopg import sql
from psycopg.conninfo import make_conninfo
from collections import Counter
base=make_conninfo(host=ENV['PGHOST'],port=ENV['PGPORT'])
allowed_append={'nf_schema_migrations','audit_log','authority_asset','authority_asset_version','authority_capability_pack_compilation','authority_capability_pack_deployment','authority_capability_pack_validation_admission','authority_capability_pack_version','authority_idempotency_record','authority_operation','authority_operation_definition_release','authority_runtime_dispatch_control','authority_runtime_dispatch_event','outbox_event','state_event','authority_capability_pack_binding_set'}
allowed_mutate={'authority_capability_pack_activation':{'active_deployment_id','activation_version','activated_at','activated_by','updated_at','activated_by_operation_id','binding_set_id'},'authority_capability_pack_deployment':{'deployment_status','updated_at'},'authority_asset_version':{'lifecycle'}}
report={'scope':'ORIGINAL_0220_SNAPSHOT_VS_POST_UPGRADE_AND_READER_BINDING','allowed_appends':sorted(allowed_append),'allowed_mutations':{k:sorted(v) for k,v in allowed_mutate.items()},'tables':{},'violations':[]}
with psycopg.connect(make_conninfo(base,dbname='nf_dbq_original_comparison_test')) as old,psycopg.connect(make_conninfo(base,dbname='nf_dbq_samebook_test')) as new:
 old.execute('SET TRANSACTION READ ONLY');new.execute('SET TRANSACTION READ ONLY')
 tables=[r[0] for r in old.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY 1")]
 for table in tables:
  def hashes(c):
   return Counter(bytes(r[0]).hex() for r in c.execute(sql.SQL("SELECT sha256(convert_to(to_jsonb(t)::text,'UTF8')) FROM {} t").format(sql.Identifier(table))))
  before,after=hashes(old),hashes(new);removed=sum((before-after).values());added=sum((after-before).values())
  record={'before_rows':sum(before.values()),'after_rows':sum(after.values()),'original_rows_missing_or_changed':removed,'new_or_changed_rows':added}
  if removed and table in allowed_mutate:
   keys=[x[0] for x in old.execute("SELECT a.attname FROM pg_index i CROSS JOIN LATERAL unnest(i.indkey) WITH ORDINALITY k(n,ord) JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=k.n WHERE i.indisprimary AND i.indrelid=%s::regclass ORDER BY k.ord",[table])]
   def rows(c):return {tuple(v[k] for k in keys):v for (v,) in c.execute(sql.SQL('SELECT to_jsonb(t) FROM {} t').format(sql.Identifier(table)))}
   a,b=rows(old),rows(new);changes=[]
   for key,value in a.items():
    if key not in b:report['violations'].append({'table':table,'kind':'deleted_row'});continue
    fields={k for k in value.keys()|b[key].keys() if value.get(k)!=b[key].get(k)}
    if fields:
     if table=='authority_asset_version' and (value.get('asset_version_id') not in ('a5c87073-a549-4443-84e5-c70d4cd03f4f','726d36a0-1b87-47ed-a63a-3404d0a1d473') or fields!={'lifecycle'}):
      report['violations'].append({'table':table,'kind':'asset_outside_reader_lifecycle_scope'})
     changes.append({'primary_key_sha256':hashlib.sha256(json.dumps(key,default=str).encode()).hexdigest(),'fields':sorted(fields)})
     if fields-allowed_mutate[table]:report['violations'].append({'table':table,'kind':'unallowlisted_mutation','fields':sorted(fields)})
   record['mutations']=changes
  elif removed:report['violations'].append({'table':table,'kind':'original_rows_changed','count':removed})
  if added and table not in allowed_append and table not in allowed_mutate:report['violations'].append({'table':table,'kind':'unallowlisted_append','count':added})
  report['tables'][table]=record
 report['execution_states']={}
 for table,column in [('authority_external_effect','status'),('authority_budget_reservation','status')]:
  q=sql.SQL('SELECT {},count(*) FROM {} GROUP BY 1 ORDER BY 1').format(sql.Identifier(column),sql.Identifier(table))
  a=old.execute(q).fetchall();b=new.execute(q).fetchall();report['execution_states'][table]={'before':a,'after':b,'identical':a==b};assert a==b
 report['book_cursor_before_after']=[c.execute("SELECT current_chapter,accepted_through_chapter,version,state FROM authority_book_production WHERE book_run_id='book-run:86a75a74-c326-47cc-a857-d983484ed537'").fetchone() for c in (old,new)]
report['status']='PASS' if not report['violations'] else 'FAIL'
(ROOT/'immutable-diff-final.json').write_text(json.dumps(report,indent=2,default=str));print(json.dumps({'status':report['status'],'violations':report['violations'],'changed_tables':{k:v for k,v in report['tables'].items() if v['original_rows_missing_or_changed'] or v['new_or_changed_rows']},'execution_states':report['execution_states'],'book_cursor_before_after':report['book_cursor_before_after']},indent=2,default=str))
